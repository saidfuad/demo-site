Download more cultures from: https://github.com/jquery/globalize/tree/master/lib/cultures
License: https://github.com/jquery/globalize/blob/master/LICENSE
