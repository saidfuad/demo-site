<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
class SMSsend {


    function send_text_message ($reciever, $message) {

        $ci =& get_instance();
        $ci->load->library('africastalkinggateway');

        $phones = array();
        foreach ($reciever as $k=>$phone) {
            array_push($phones , $phone);
        }


        $reciever = implode(',', array_unique($phones));
        $result = false;

        ///$Obj = new AfricasTalkingGateway();
        $res = $ci->africastalkinggateway->sendMessage($reciever, $message);

        $ress = 0;
        foreach ($res as $key => $value) {
            $result = $value->status;
            if ($result=='Success') {
                $ress++;    
            }
        }

       
        return $result;
    }
    
    
}