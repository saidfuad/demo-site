<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Vehiclereports extends CI_Controller {
    function __construct() {

        parent::__construct();
        
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
        
        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

        $this->load->model('mdl_vehicle_reports');
       
    }

    public function index() {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Reports';
        $data['content_title'] = 'Reports';
        $data['content_subtitle'] = 'Reports that suit your specific requirements.';
        $data['content'] = 'reports/view_reports.php';
        $this->load->view('main/main.php', $data);
    }

    

    
}
?>  