<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Reports extends CI_Controller {
    function __construct() {

        parent::__construct();

        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
        
        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

        $this->load->model('mdl_reports');
        $this->load->model('mdl_vehicle_reports');
       
    }

    public function index() {

        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Reports';
        $data['content_title'] = 'Reports';
        $data['content_subtitle'] = 'Reports that suit your specific requirements.';
        $data['content'] = 'reports/view_reports.php';
        $this->load->view('main/report.php', $data);
    }

    public function tests(){
        $assets = $this->input->post('asset_id');
        echo $assets;
        die();
        $this->load->library('excel');
        $query = $this->db->select('itms_assets.*, (itms_personnel_master.fname) as driver_name, 
                            itms_personnel_master.phone_no as driver_phone, (itms_users.first_name + " " + itms_users.last_name) as add_user_name,
                                itms_users.phone_number as add_user_phone, itms_assets_categories.assets_cat_name, itms_assets_types.assets_type_nm,
                                    itms_assets_groups.assets_group_nm, itms_owner_master.owner_name');
        $this->db->from('itms_assets');
        $this->db->join('itms_personnel_master', 'itms_assets.personnel_id=itms_personnel_master.personnel_id', 'left');
        $this->db->join('itms_users', 'itms_assets.add_uid=itms_users.user_id', 'left');
        $this->db->join('itms_assets_categories', 'itms_assets.assets_category_id=itms_assets_categories.assets_category_id', 'left');
        $this->db->join('itms_assets_types', 'itms_assets.assets_type_id=itms_assets_types.assets_type_id', 'left');
        $this->db->join('itms_assets_groups', 'itms_assets.assets_group_id=itms_assets_groups.assets_group_id', 'left');
        $this->db->join('itms_owner_master', 'itms_assets.owner_id=itms_owner_master.owner_id', 'left');

        $this->db->where('itms_assets.asset_id',$assets);
        $query = $this->db->get();
 
        if(!$query)
            return false;
 
        // Starting the PHPExcel library
        $this->load->library('PHPExcel');
        // $this->load->library('PHPExcel/IOFactory');
 
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("export")->setDescription("none");
 
        $objPHPExcel->setActiveSheetIndex(0);
 
        // Field names in the first row
        $fields = $query->list_fields();
        $col = 0;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
 
        // Fetching the table data
        $row = 2;
        foreach($query->result() as $data)
        {
            $col = 0;
            foreach ($fields as $field)
            {
                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $data->$field);
                $col++;
            }
 
            $row++;
        }
 
        $objPHPExcel->setActiveSheetIndex(0);
 
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
 
        // Sending headers to force the user to download the file
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Products_'.date('dMy').'.xls"');
        header('Cache-Control: max-age=0');
ob_end_clean();
$objWriter->save('php://output');
    }

    public function vehicle_summary_report () {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Vehicle Summary Reports';
        $data['content_title'] = 'Vehicles Summary Reports';
        $data['content_subtitle'] = 'Summary of vehicles : Owners, drivers, distance travelled e.t.c';
        $data['content'] = 'reports/vehicle_summary_report.php';
        $this->load->view('main/main.php', $data);
    }

    public function fetch_vehicle_summary_report () {
        $page = isset($_POST['page']) ? $_POST['page'] : 1; // get the requested page
        $limit = isset($_POST['rows']) ? $_POST['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset($_POST['sidx']) ? $_POST['sidx'] : 'asset_id'; // get index row - i.e. user click to sort
        $sord = isset($_POST['sord']) ? $_POST['sord'] : 'DESC'; // get the direction

        $searchField = isset($_POST['searchField'])?$_POST['searchField']:null; // get the direction
        $searchString = isset($_POST['searchString'])?$_POST['searchString']:null; // get the direction
        $searchOper = isset($_POST['searchOper'])?$_POST['searchOper']:null; // get the direction
        
        if (!$sidx)
            $sidx = 1;

        $company_id = $this->session->userdata('itms_company_id');
        
        $query = $this->mdl_vehicle_reports->get_vehicle_summary_report ($limit, $sidx, $sord, $searchField, $searchString,$searchOper, $company_id);
        $count = count($query);

        if ($count > 0) {
            $total_pages = ceil($count / $limit);    //calculating total number of pages
        } else {
            $total_pages = 0;
        }
        
        //print_r('<pre>');
        //print_r($query);
        //exit;

        if ($page > $total_pages)
            $page = $total_pages;

        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        $start = ($start < 0) ? 0 : $start;  // make sure that $start is not a negative value
//        $responce->page = $page;
//        $responce->total = $total_pages;
//        $responce->records = $count;
        
        $i = 0;
        
        /*print_r('<pre>');
        print_r($query);
        exit;*/
        
        foreach ($query as $row) {

            $km_reading = ($row->km_reading !=null && $row->km_reading > 0) ? $row->km_reading . ' Miles': 'Not set';
            $max_speed_limit = ($row->max_speed_limit !=null && $row->max_speed_limit > 0) ? $row->max_speed_limit . ' Kmh': 'Not set';      
            $assets_group_nm = ($row->assets_group_nm !=null && $row->assets_group_nm !="") ? $row->assets_group_nm : 'Not assigned';      
            $owner_name = ($row->owner_name !=null && $row->owner_name !="") ? $row->owner_name : 'Not set';      

            $responce->rows[$i]['id'] = $row->asset_id;
            $responce->rows[$i]['cell'] = array(
                                                $i+1, 
                                                $row->assets_friendly_nm, 
                                                $row->assets_name,
                                                $row->device_id,
                                                $row->driver_name,
                                                $row->driver_phone,
                                                $row->assets_type_nm,
                                                $row->assets_cat_name,
                                                $assets_group_nm,
                                                $max_speed_limit,
                                                $row->no_of_axles,
                                                $km_reading,
                                                $row->add_user_name,
                                                $owner_name,
                                                $row->add_user_phone);
            $i++;
        }
        
        
        $blank_array = array();
        if (!isset($responce)) {
            echo json_encode($blank_array);
        } else {
            echo json_encode($responce);
        }
    }

    public function driver_performance_report () {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Driver Performance Reports';
        $data['content_title'] = 'Driver Performance Reports';
        $data['content_subtitle'] = 'Summary of Driver performance';
        $data['content'] = 'reports/driver_performance_report.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_driver_performance_report () {
        $page = isset($_POST['page']) ? $_POST['page'] : 1; // get the requested page
        $limit = isset($_POST['rows']) ? $_POST['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset($_POST['sidx']) ? $_POST['sidx'] : 'asset_id'; // get index row - i.e. user click to sort
        $sord = isset($_POST['sord']) ? $_POST['sord'] : 'DESC'; // get the direction

        $searchField = isset($_POST['searchField'])?$_POST['searchField']:null; // get the direction
        $searchString = isset($_POST['searchString'])?$_POST['searchString']:null; // get the direction
        $searchOper = isset($_POST['searchOper'])?$_POST['searchOper']:null; // get the direction
        
        if (!$sidx)
            $sidx = 1;

        $company_id = $this->session->userdata('itms_company_id');
        
        $query = $this->mdl_vehicle_reports->get_driver_performance_report ($limit, $sidx, $sord, $searchField, $searchString,$searchOper, $company_id);
        $count = count($query);

        if ($count > 0) {
            $total_pages = ceil($count / $limit);    //calculating total number of pages
        } else {
            $total_pages = 0;
        }
        
        //print_r('<pre>');
        //print_r($query);
        //exit;

        if ($page > $total_pages)
            $page = $total_pages;

        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        $start = ($start < 0) ? 0 : $start;  // make sure that $start is not a negative value
//        $responce->page = $page;
//        $responce->total = $total_pages;
//        $responce->records = $count;
        
        $i = 0;
        
        /*print_r('<pre>');
        print_r($query);
        exit;*/
        
        foreach ($query as $row) {

            $km_reading = ($row->km_reading !=null && $row->km_reading > 0) ? $row->km_reading . ' Miles': 'Not set';
            $max_speed_limit = ($row->max_speed_limit !=null && $row->max_speed_limit > 0) ? $row->max_speed_limit . ' Kmh': 'Not set';      
            $assets_group_nm = ($row->assets_group_nm !=null && $row->assets_group_nm !="") ? $row->assets_group_nm : 'Not assigned';      
            $owner_name = ($row->owner_name !=null && $row->owner_name !="") ? $row->owner_name : 'Not set';      

            $responce->rows[$i]['id'] = $row->asset_id;
            $responce->rows[$i]['cell'] = array(
                                                $i+1, 
                                                $row->driver_name, 
                                                $row->driver_phone,
                                                $row->assets_friendly_nm,
                                                $row->assets_name,
                                                $row->assets_cat_name,
                                                $assets_group_nm,
                                                $max_speed_limit,
                                                $row->no_of_axles,
                                                $km_reading,
                                                $owner_name);
            $i++;
        }
        
        
        $blank_array = array();
        if (!isset($responce)) {
            echo json_encode($blank_array);
        } else {
            echo json_encode($responce);
        }
    }

    public function vehicle_owners () {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Vehicle Owners Reports';
        $data['content_title'] = 'Vehicle Owners Reports';
        $data['content_subtitle'] = 'Summary of Vehicle Owners';
        $data['content'] = 'reports/vehicle_owners_report.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_vehicle_owners_report () {
        $page = isset($_POST['page']) ? $_POST['page'] : 1; // get the requested page
        $limit = isset($_POST['rows']) ? $_POST['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset($_POST['sidx']) ? $_POST['sidx'] : 'owner_id'; // get index row - i.e. user click to sort
        $sord = isset($_POST['sord']) ? $_POST['sord'] : 'DESC'; // get the direction

        $searchField = isset($_POST['searchField'])?$_POST['searchField']:null; // get the direction
        $searchString = isset($_POST['searchString'])?$_POST['searchString']:null; // get the direction
        $searchOper = isset($_POST['searchOper'])?$_POST['searchOper']:null; // get the direction
        
        if (!$sidx)
            $sidx = 1;

        $company_id = $this->session->userdata('itms_company_id');
        
        $query = $this->mdl_vehicle_reports->get_vehicle_owners_report ($limit, $sidx, $sord, $searchField, $searchString,$searchOper, $company_id);

        // var_dump($query);
        // die();
        $count = count($query);

        if ($count > 0) {
            $total_pages = ceil($count / $limit);    //calculating total number of pages
        } else {
            $total_pages = 0;
        }
        
        //print_r('<pre>');
        //print_r($query);
        //exit;

        if ($page > $total_pages)
            $page = $total_pages;

        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        $start = ($start < 0) ? 0 : $start;  // make sure that $start is not a negative value
//        $responce->page = $page;
//        $responce->total = $total_pages;
//        $responce->records = $count;
        
        $i = 0;
        
        /*print_r('<pre>');
        print_r($query);
        exit;*/
        
        foreach ($query as $row) {   

            $responce->rows[$i]['id'] = $row->owner_id;
            $responce->rows[$i]['cell'] = array(
                                                $i+1, 
                                                $row->owner_name, 
                                                $row->phone_no,
                                                $row->email,
                                                $row->address);
            $i++;
        }
        
        
        $blank_array = array();
        if (!isset($responce)) {
            echo json_encode($blank_array);
        } else {
            echo json_encode($responce);
        }
    }

    public function vehicle_groups () {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Driver Performance Reports';
        $data['content_title'] = 'Driver Performance Reports';
        $data['content_subtitle'] = 'Summary of Driver performance';
        $data['content'] = 'reports/vehicle_groups_report.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_vehicle_groups_report () {
        $page = isset($_POST['page']) ? $_POST['page'] : 1; // get the requested page
        $limit = isset($_POST['rows']) ? $_POST['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset($_POST['sidx']) ? $_POST['sidx'] : 'group_id'; // get index row - i.e. user click to sort
        $sord = isset($_POST['sord']) ? $_POST['sord'] : 'DESC'; // get the direction

        $searchField = isset($_POST['searchField'])?$_POST['searchField']:null; // get the direction
        $searchString = isset($_POST['searchString'])?$_POST['searchString']:null; // get the direction
        $searchOper = isset($_POST['searchOper'])?$_POST['searchOper']:null; // get the direction
        
        if (!$sidx)
            $sidx = 1;

        $company_id = $this->session->userdata('itms_company_id');
        
        $query = $this->mdl_vehicle_reports->get_vehicle_groups_report ($limit, $sidx, $sord, $searchField, $searchString,$searchOper, $company_id);
        $count = count($query);
// var_dump($query);
// die();
        if ($count > 0) {
            $total_pages = ceil($count / $limit);    //calculating total number of pages
        } else {
            $total_pages = 0;
        }
        
        //print_r('<pre>');
        //print_r($query);
        //exit;

        if ($page > $total_pages)
            $page = $total_pages;

        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        $start = ($start < 0) ? 0 : $start;  // make sure that $start is not a negative value
//        $responce->page = $page;
//        $responce->total = $total_pages;
//        $responce->records = $count;
        
        $i = 0;
        
        /*print_r('<pre>');
        print_r($query);
        exit;*/
        
        foreach ($query as $row) {

            $responce->rows[$i]['id'] = $row->group_id;
            $responce->rows[$i]['cell'] = array(
                                                $i+1, 
                                                $row->group_name, 
                                                $row->group_description);
            $i++;
        }
        
        
        $blank_array = array();
        if (!isset($responce)) {
            echo json_encode($blank_array);
        } else {
            echo json_encode($responce);
        }
    }

    public function vehicle_categories () {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Driver Performance Reports';
        $data['content_title'] = 'Driver Performance Reports';
        $data['content_subtitle'] = 'Summary of Driver performance';
        $data['content'] = 'reports/vehicle_categories_report.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_vehicle_categories_report () {
        $page = isset($_POST['page']) ? $_POST['page'] : 1; // get the requested page
        $limit = isset($_POST['rows']) ? $_POST['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset($_POST['sidx']) ? $_POST['sidx'] : 'assets_category_id'; // get index row - i.e. user click to sort
        $sord = isset($_POST['sord']) ? $_POST['sord'] : 'DESC'; // get the direction

        $searchField = isset($_POST['searchField'])?$_POST['searchField']:null; // get the direction
        $searchString = isset($_POST['searchString'])?$_POST['searchString']:null; // get the direction
        $searchOper = isset($_POST['searchOper'])?$_POST['searchOper']:null; // get the direction
        
        if (!$sidx)
            $sidx = 1;

        $company_id = $this->session->userdata('itms_company_id');
        
        $query = $this->mdl_vehicle_reports->get_vehicle_category_report ($limit, $sidx, $sord, $searchField, $searchString,$searchOper, $company_id);
        $count = count($query);

// var_dump($query);
// die();
        if ($count > 0) {
            $total_pages = ceil($count / $limit);    //calculating total number of pages
        } else {
            $total_pages = 0;
        }
        
        //print_r('<pre>');
        //print_r($query);
        //exit;

        if ($page > $total_pages)
            $page = $total_pages;

        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        $start = ($start < 0) ? 0 : $start;  // make sure that $start is not a negative value
//        $responce->page = $page;
//        $responce->total = $total_pages;
//        $responce->records = $count;
        
        $i = 0;
        
        /*print_r('<pre>');
        print_r($query);
        exit;*/
        
        foreach ($query as $row) {

            $responce->rows[$i]['id'] = $row->assets_category_id;
            $responce->rows[$i]['cell'] = array(
                                                $i+1, 
                                                $row->assets_cat_name, 
                                                $row->assets_type_nm);
            $i++;
        }
        
        
        $blank_array = array();
        if (!isset($responce)) {
            echo json_encode($blank_array);
        } else {
            echo json_encode($responce);
        }
    }

    public function vehicle_types () {
        $data['content_url'] = 'reports';
        $data['fa'] = 'fa fa-list';
        $data['title'] = 'ITMS Africa | Driver Performance Reports';
        $data['content_title'] = 'Driver Performance Reports';
        $data['content_subtitle'] = 'Summary of Driver performance';
        $data['content'] = 'reports/vehicle_types_report.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_vehicle_types_report () {
        $page = isset($_POST['page']) ? $_POST['page'] : 1; // get the requested page
        $limit = isset($_POST['rows']) ? $_POST['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset($_POST['sidx']) ? $_POST['sidx'] : 'asset_id'; // get index row - i.e. user click to sort
        $sord = isset($_POST['sord']) ? $_POST['sord'] : 'DESC'; // get the direction

        $searchField = isset($_POST['searchField'])?$_POST['searchField']:null; // get the direction
        $searchString = isset($_POST['searchString'])?$_POST['searchString']:null; // get the direction
        $searchOper = isset($_POST['searchOper'])?$_POST['searchOper']:null; // get the direction
        
        if (!$sidx)
            $sidx = 1;

        $company_id = $this->session->userdata('itms_company_id');
        
        $query = $this->mdl_vehicle_reports->get_vehicle_type_report ($limit, $sidx, $sord, $searchField, $searchString,$searchOper, $company_id);
        $count = count($query);

        if ($count > 0) {
            $total_pages = ceil($count / $limit);    //calculating total number of pages
        } else {
            $total_pages = 0;
        }
        
        //print_r('<pre>');
        //print_r($query);
        //exit;

        if ($page > $total_pages)
            $page = $total_pages;

        $start = $limit * $page - $limit; // do not put $limit*($page - 1)
        $start = ($start < 0) ? 0 : $start;  // make sure that $start is not a negative value
//        $responce->page = $page;
//        $responce->total = $total_pages;
//        $responce->records = $count;
        
        $i = 0;
        
        /*print_r('<pre>');
        print_r($query);
        exit;*/
        
        foreach ($query as $row) {

            $km_reading = ($row->km_reading !=null && $row->km_reading > 0) ? $row->km_reading . ' Miles': 'Not set';
            $max_speed_limit = ($row->max_speed_limit !=null && $row->max_speed_limit > 0) ? $row->max_speed_limit . ' Kmh': 'Not set';      
            $assets_group_nm = ($row->assets_group_nm !=null && $row->assets_group_nm !="") ? $row->assets_group_nm : 'Not assigned';      
            $owner_name = ($row->owner_name !=null && $row->owner_name !="") ? $row->owner_name : 'Not set';      

            $responce->rows[$i]['id'] = $row->asset_id;
            $responce->rows[$i]['cell'] = array(
                                                $i+1, 
                                                $row->assets_friendly_nm, 
                                                $row->assets_name,
                                                $row->assets_cat_name,
                                                $row->assets_type_nm,
                                                $owner_name);
            $i++;
        }
        
        
        $blank_array = array();
        if (!isset($responce)) {
            echo json_encode($blank_array);
        } else {
            echo json_encode($responce);
        }
    }

    
}
?>  