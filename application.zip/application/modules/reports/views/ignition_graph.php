<div id="container" style="height: 400px; min-width: 310px"></div>
<script src="<?php echo base_url('assets/js/jquery-2.1.4.min.js') ?>"></script>
<script src="https://code.highcharts.com/stock/highstock.js"></script>
<script src="https://code.highcharts.com/stock/modules/exporting.js"></script>
<script type="text/javascript">
    $(function () {
        var data = "<?= $_POST['data'] ?>";
        var list = data.split(",");
        var list2 = [];
        for (var i = 0; i < list.length; i++) {
            list2.push(list[i] + "," + list[i+1]);
            i++;
        }
       var result = [];
        for (var i = 0; i < list2.length; i++) {
            temp = list2[i].split(",").map(Number);
            result.push(temp);
        }
        console.log(result);
        // Create the chart
        $('#container').highcharts('StockChart', {
            rangeSelector: {
                selected: 0.5
            },
            title: {
                text: "<?= $_POST['asset_name'] ?> Ignition graph"
            },
            series: [{
                    name: "<?= $_POST['asset_name'] ?>",
                    data: result,
                    turboThreshold: 0,
                    step: true,
                    tooltip: {
                        valueDecimals: 2
                    }
                }]
        });
    });
</script>

