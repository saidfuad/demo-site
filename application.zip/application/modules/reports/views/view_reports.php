<div class="container-fluid">
    <div class="row">
    <div class="col-sm-1"></div>
        <div class="col-sm-10">
   <div class="panel panel-primary">
      <div class="panel-heading">
        <h3 class="panel-title">Reports</h3>
      </div>
      <div class="panel-body">
        <div class="row well">
        <div class="col-sm-1"></div>
        <div>
            <button class="btns btn-xs btn-primary"><i class="fa fa-plus"></i> New</button>
            <button class="btns btn-xs btn-primary"><i class="fa fa-save"></i> Save</button>
            <button class="btns btn-xs btn-primary"><i class="fa fa-send"></i> Create</button> 
        </div>
        </div>
        <div><legend><h5>Reports</h5></legend></div>
        <div class="row">
        <div class="col-xs-6">
            <form id="create-xls">
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 form-control-label">Name</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control form-control-sm input-sm" id="inputEmail3" placeholder="">
                </div>
              </div>
              <div class="form-group row">
                <label for="inputPassword3" class="col-sm-4 form-control-label">Type</label>
                <div class="col-sm-8 ">
                  <select class="form-control form-control-sm input-sm">
                    <option>General Information</option>
                    <option>Events</option>
                    <option>Overspeeds</option>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="inputPassword3" class="col-sm-4 form-control-label">Format</label>
                <div class="col-sm-8">
                 <select class="form-control form-control-sm input-sm">
                    <option>HTML</option>
                    <option>XSL</option>
                 </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-4">Show address</label>
                <div class="col-sm-8">
                  <div class="checkbox-inline">
                    <label>
                      <input type="checkbox" >
                    </label>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-4">Zones instead of addresses</label>
                <div class="col-sm-8">
                  <div class="checkbox-inline">
                    <label>
                      <input type="checkbox" >
                    </label>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="inputPassword3" class="col-sm-4 form-control-label">Stops</label>
                <div class="col-sm-8">
                 <select class="form-control form-control-sm input-sm">
                    <option>1 min</option>
                    <option>2 min</option>
                 </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 form-control-label">Speed limit (kph)</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control form-control-sm input-sm" id="inputEmail3" placeholder="">
                </div>
              </div>
            </form>
        </div>
        <div class="col-xs-6">

            <ul class="nav nav-pills">
              <li class="active"><a data-toggle="tab" href="#home">Objects</a></li>
              <li><a data-toggle="pill" href="#menu1">Data Items</a></li>
              <li><a data-toggle="pill" href="#menu2">Zones</a></li>
              <li><a data-toggle="pill" href="#menu3">Devices</a></li>
            </ul><legend></legend>
            <div class="tab-content">
              <div id="home" class="tab-pane fade in active">
                <div class="panel panel-default">
                  <div class="panel-body" style="max-height: 200px; overflow-y: scroll;">
                    <form>
                    <ul class="list-group">
                    <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;<b> Select All</b></li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"></li>
                    </ul>
                    </form>
                  </div>
                </div>
              </div>
              <div id="menu1" class="tab-pane fade">
                <div class="panel panel-default">
                  <div class="panel-body" style="max-height: 200px; overflow-y: scroll;">
                    <form>
                    <ul class="list-group">
                    <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;<b> Select All</b></li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"></li>
                    </ul>
                    </form>
                  </div>
                </div>
              </div>
              <div id="menu2" class="tab-pane fade">
                <div class="panel panel-default">
                  <div class="panel-body" style="max-height: 200px; overflow-y: scroll;">
                    <form>
                    <ul class="list-group">
                    <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;<b> Select All</b></li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" > &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"></li>
                    </ul>
                    </form>
                  </div>
                </div>
              </div>
              <div id="menu3" class="tab-pane fade">
                <div class="panel panel-default">
                  <div class="panel-body">
                    <form>
                    <script type="text/javascript">
                        $(document).ready(function(){
                            $('#all').on('click', function(){
                                var status = $(this).is(':checked');
                                $('#now', $(this).parent('li')).attr('checked', status);
                            });
                        });
                    </script>
                    <ul class="list-group" style="max-height: 150px; overflow-y: scroll;">
                      <li class="list-group-item"><input type="checkbox" name="all" id="all" > &nbsp; &nbsp;<b> Select All</b></li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Cras justo odio</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Dapibus ac facilisis in</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Porta ac consectetur ac</li>
                      <li class="list-group-item"><input type="checkbox" id="now"> &nbsp; &nbsp;Vestibulum at eros</li>
                      <li class="list-group-item"></li>
                    </ul>
                    </form>
                  </div>
                </div>
              </div>
            </div>
        </div>
        </div>
        <div class="row">
            <div class="col-xs-6">
                <legend><h5>Time Period</h5></legend>
                <form>
                    <div class="form-group row">
                        <label for="" class="col-sm-4 form-control-label">Filter</label>
                        <div class="col-sm-8 ">
                          <select class="form-control form-control-sm input-sm">
                            <option>Last Hour</option>
                            <option>Today</option>
                            <option>Yesterday</option>
                          </select>
                        </div>
                      </div>
                       <div class="form-group row">
                        <label for="" class="col-sm-4 form-control-label">Time From</label>
                        <div class="col-sm-4 ">
                         <input type="text" class="form-control form-control-sm input-sm" id="" placeholder="">
                        </div>
                        <div class="col-sm-2">
                          <select class="form-control form-control-sm input-sm">
                            <option>00</option>
                            <option>01</option>
                            <option>02</option>
                            <option>03</option>
                            <option>04</option>
                            <option>05</option>
                            <option>06</option>
                            <option>07</option>
                            <option>08</option>
                            <option>09</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <option>13</option>
                            <option>14</option>
                            <option>15</option>
                            <option>16</option>
                            <option>17</option>
                            <option>18</option>
                            <option>19</option>
                            <option>20</option>
                            <option>21</option>
                            <option>22</option>
                            <option>23</option>
                          </select>
                        </div>
                        <div class="col-sm-2 ">
                          <select class="form-control form-control-sm input-sm">
                            <option>00</option>
                            <option>01</option>
                            <option>02</option>
                            <option>03</option>
                            <option>04</option>
                            <option>05</option>
                            <option>06</option>
                            <option>07</option>
                            <option>08</option>
                            <option>09</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <option>13</option>
                            <option>14</option>
                            <option>15</option>
                            <option>16</option>
                            <option>17</option>
                            <option>18</option>
                            <option>19</option>
                            <option>20</option>
                            <option>21</option>
                            <option>22</option>
                            <option>23</option>
                            <option>24</option>
                            <option>25</option>
                            <option>26</option>
                            <option>27</option>
                            <option>28</option>
                            <option>29</option>
                            <option>30</option>
                            <option>31</option>
                            <option>32</option>
                            <option>33</option>
                            <option>34</option>
                            <option>35</option>
                            <option>36</option>
                            <option>37</option>
                            <option>38</option>
                            <option>39</option>
                            <option>40</option>
                            <option>41</option>
                            <option>42</option>
                            <option>43</option>
                            <option>44</option>
                            <option>45</option>
                            <option>46</option>
                            <option>47</option>
                            <option>48</option>
                            <option>49</option>
                            <option>50</option>
                            <option>51</option>
                            <option>52</option>
                            <option>53</option>
                            <option>54</option>
                            <option>55</option>
                            <option>56</option>
                            <option>57</option>
                            <option>58</option>
                            <option>59</option>
                          </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="" class="col-sm-4 form-control-label">Time To</label>
                        <div class="col-sm-4 ">
                          <input type="text" class="form-control form-control-sm input-sm" id="" placeholder="">
                        </div>
                        <div class="col-sm-2 ">
                          <select class="form-control form-control-sm input-sm">
                            <option>00</option>
                            <option>01</option>
                            <option>02</option>
                            <option>03</option>
                            <option>04</option>
                            <option>05</option>
                            <option>06</option>
                            <option>07</option>
                            <option>08</option>
                            <option>09</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <option>13</option>
                            <option>14</option>
                            <option>15</option>
                            <option>16</option>
                            <option>17</option>
                            <option>18</option>
                            <option>19</option>
                            <option>20</option>
                            <option>21</option>
                            <option>22</option>
                            <option>23</option>
                          </select>
                        </div>
                        <div class="col-sm-2 ">
                          <select class="form-control form-control-sm input-sm">
                            <option>00</option>
                            <option>01</option>
                            <option>02</option>
                            <option>03</option>
                            <option>04</option>
                            <option>05</option>
                            <option>06</option>
                            <option>07</option>
                            <option>08</option>
                            <option>09</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <option>13</option>
                            <option>14</option>
                            <option>15</option>
                            <option>16</option>
                            <option>17</option>
                            <option>18</option>
                            <option>19</option>
                            <option>20</option>
                            <option>21</option>
                            <option>22</option>
                            <option>23</option>
                            <option>24</option>
                            <option>25</option>
                            <option>26</option>
                            <option>27</option>
                            <option>28</option>
                            <option>29</option>
                            <option>30</option>
                            <option>31</option>
                            <option>32</option>
                            <option>33</option>
                            <option>34</option>
                            <option>35</option>
                            <option>36</option>
                            <option>37</option>
                            <option>38</option>
                            <option>39</option>
                            <option>40</option>
                            <option>41</option>
                            <option>42</option>
                            <option>43</option>
                            <option>44</option>
                            <option>45</option>
                            <option>46</option>
                            <option>47</option>
                            <option>48</option>
                            <option>49</option>
                            <option>50</option>
                            <option>51</option>
                            <option>52</option>
                            <option>53</option>
                            <option>54</option>
                            <option>55</option>
                            <option>56</option>
                            <option>57</option>
                            <option>58</option>
                            <option>59</option>
                          </select>
                        </div>
                      </div>
                </form>
            </div>
            <div class="col-xs-6">
                <legend><h5>Schedule</h5></legend>
                <div class="form-group row">
                <label class="col-sm-4">Daily</label>
                <div class="col-sm-8">
                  <div class="checkbox-inline">
                    <label>
                      <input type="checkbox" >
                    </label>
                  </div>
                </div>
              </div>
              <div class="form-group row" style="margin-bottom: 15px;">
                <label class="col-sm-4">Weekly</label>
                <div class="col-sm-8">
                  <div class="checkbox-inline">
                    <label>
                      <input type="checkbox" >
                    </label>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-4 form-control-label">Send to Email</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control form-control-sm input-sm" id="inputEmail3" placeholder="">
                </div>
              </div>
            </div>
        </div>
        <div class="row" style="margin-top:20px;">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>NAME</th>
                    <th>TYPE</th>
                    <th>FORMAT</th>
                    <th>OBJECTS</th>
                    <th>ZONE</th>
                    <th>SCHEDULE</th>
                    <th>DELETE</th>
                </tr>
            </thead>
            <tbody>
                <tr class="" style="" role="row">
                    <td>Stops</td>
                    <td>Drives and Stops</td>
                    <td>xls</td>
                    <td>1</td>
                    <td>0</td>
                    <td><i class="fa fa-tick"></i></td>
                    <td><i class="fa fa-trash"></i></td>
                </tr>    
                <tr class="" style="" role="row">
                    <td>Stops</td>
                    <td>Drives and Stops</td>
                    <td>xls</td>
                    <td>1</td>
                    <td>0</td>
                    <td><i class="fa fa-tick"></i></td>
                    <td><i class="fa fa-trash"></i></td>
                </tr>    
                <tr class="" style="" role="row">
                    <td>Stops</td>
                    <td>Drives and Stops</td>
                    <td>xls</td>
                    <td>1</td>
                    <td>0</td>
                    <td><i class="fa fa-tick"></i></td>
                    <td><i class="fa fa-trash"></i></td>
                </tr>    
                <tr class="" style="" role="row">
                    <td>Stops</td>
                    <td>Drives and Stops</td>
                    <td>xls</td>
                    <td>1</td>
                    <td>0</td>
                    <td><i class="fa fa-tick"></i></td>
                    <td><i class="fa fa-trash"></i></td>
                </tr>    
                <tr class="" style="" role="row">
                    <td>Stops</td>
                    <td>Drives and Stops</td>
                    <td>xls</td>
                    <td>1</td>
                    <td>0</td>
                    <td><i class="fa fa-tick"></i></td>
                    <td><i class="fa fa-trash"></i></td>
                </tr>    
                <tr class="" style="" role="row">
                    <td>Stops</td>
                    <td>Drives and Stops</td>
                    <td>xls</td>
                    <td>1</td>
                    <td>0</td>
                    <td><i class="fa fa-tick"></i></td>
                    <td><i class="fa fa-trash"></i></td>
                </tr>    
            </tbody>
        </table>
        </div>
      </div>
      <div class="panel-footer">
        <h3 class="panel-title">Reports</h3>
      </div>
    </div>

    </div>
</div>    
</div>

    