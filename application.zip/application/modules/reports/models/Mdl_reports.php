<?php 

class Mdl_reports extends CI_Model{

	
				
}

?>