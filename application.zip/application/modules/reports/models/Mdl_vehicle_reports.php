<?php 

class Mdl_vehicle_reports extends CI_Model{

    public function get_data()
    {
        $data = $this->db->query("SELECT * FROM itms_assets");

        return $data;
    }

    // model function to obtain landmark
    function get_landmarks () {

        $query = $this->db->get('itms_assets');

        return $query->row();        
    }

	public function get_vehicle_summary_report ($limit, $sidx, $sord, $searchField=null, $searchString=null,$searchOper=null, $company_id=null) {
        
        $where = '';
        switch ($searchOper) {
            case 'eq':
                $oper = '=';
                // $where = $this->db->like('column', $keyword, 'before');
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'ne':
                $oper = '!=';
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'bw':
                $oper = 'after';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'bn':
                $oper = 'after';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'ew':
                $oper = 'before';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'en':
                $oper = 'before';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'cn':
                $oper = 'both';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'nc':
                $oper = 'both';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'nu':
                $oper = '=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'nn':
                $oper = '!=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'in':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_in($searchField, $searchString);
                break;
            
            case 'ni':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_not_in($searchField, $searchString);
                break;
        }

        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        $this->db->select('itms_assets.*, (itms_personnel_master.fname) as driver_name, 
                            itms_personnel_master.phone_no as driver_phone, (itms_users.first_name + " " + itms_users.last_name) as add_user_name,
                                itms_users.phone_number as add_user_phone, itms_assets_categories.assets_cat_name, itms_assets_types.assets_type_nm,
                                    itms_assets_groups.assets_group_nm, itms_owner_master.owner_name');
        $this->db->from('itms_assets');
        $this->db->join('itms_personnel_master', 'itms_assets.personnel_id=itms_personnel_master.personnel_id', 'left');
        $this->db->join('itms_users', 'itms_assets.add_uid=itms_users.user_id', 'left');
        $this->db->join('itms_assets_categories', 'itms_assets.assets_category_id=itms_assets_categories.assets_category_id', 'left');
        $this->db->join('itms_assets_types', 'itms_assets.assets_type_id=itms_assets_types.assets_type_id', 'left');
        $this->db->join('itms_assets_groups', 'itms_assets.assets_group_id=itms_assets_groups.assets_group_id', 'left');
        $this->db->join('itms_owner_master', 'itms_assets.owner_id=itms_owner_master.owner_id', 'left');
        $this->db->order_by($sidx, $sord);
        $query = $this->db->get();
        
        return $query->result();    
    }

public function get_driver_performance_report ($limit, $sidx, $sord, $searchField=null, $searchString=null,$searchOper=null, $company_id=null) {
        
        $where = '';
        switch ($searchOper) {
            case 'eq':
                $oper = '=';
                // $where = $this->db->like('column', $keyword, 'before');
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'ne':
                $oper = '!=';
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'bw':
                $oper = 'after';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'bn':
                $oper = 'after';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'ew':
                $oper = 'before';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'en':
                $oper = 'before';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'cn':
                $oper = 'both';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'nc':
                $oper = 'both';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'nu':
                $oper = '=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'nn':
                $oper = '!=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'in':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_in($searchField, $searchString);
                break;
            
            case 'ni':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_not_in($searchField, $searchString);
                break;
        }

        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        $this->db->select('itms_assets.*, (itms_personnel_master.fname) as driver_name, 
                            itms_personnel_master.phone_no as driver_phone, (itms_users.first_name + " " + itms_users.last_name) as add_user_name,
                                itms_users.phone_number as add_user_phone, itms_assets_categories.assets_cat_name, itms_assets_types.assets_type_nm,
                                    itms_assets_groups.assets_group_nm, itms_owner_master.owner_name');
        $this->db->from('itms_assets');
        $this->db->join('itms_personnel_master', 'itms_assets.personnel_id=itms_personnel_master.personnel_id', 'left');
        $this->db->join('itms_users', 'itms_assets.add_uid=itms_users.user_id', 'left');
        $this->db->join('itms_assets_categories', 'itms_assets.assets_category_id=itms_assets_categories.assets_category_id', 'left');
        $this->db->join('itms_assets_types', 'itms_assets.assets_type_id=itms_assets_types.assets_type_id', 'left');
        $this->db->join('itms_assets_groups', 'itms_assets.assets_group_id=itms_assets_groups.assets_group_id', 'left');
        $this->db->join('itms_owner_master', 'itms_assets.owner_id=itms_owner_master.owner_id', 'left');
        $this->db->order_by($sidx, $sord);
        $query = $this->db->get();
        
        return $query->result();    
    }
public function get_vehicle_owners_report ($limit, $sidx, $sord, $searchField=null, $searchString=null,$searchOper=null, $company_id=null) {
        
        $where = '';
        switch ($searchOper) {
            case 'eq':
                $oper = '=';
                // $where = $this->db->like('column', $keyword, 'before');
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'ne':
                $oper = '!=';
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'bw':
                $oper = 'after';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'bn':
                $oper = 'after';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'ew':
                $oper = 'before';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'en':
                $oper = 'before';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'cn':
                $oper = 'both';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'nc':
                $oper = 'both';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'nu':
                $oper = '=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'nn':
                $oper = '!=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'in':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_in($searchField, $searchString);
                break;
            
            case 'ni':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_not_in($searchField, $searchString);
                break;
        }

        if ($company_id!=null) {
            $this->db->where('itms_owner_master.company_id', $company_id);
        }

        $this->db->select('itms_owner_master.*');
        $this->db->from('itms_owner_master');
        $this->db->order_by($sidx, $sord);
        $query = $this->db->get();

        return $query->result();    
    }
public function get_vehicle_groups_report ($limit, $sidx, $sord, $searchField=null, $searchString=null,$searchOper=null, $company_id=null) {
        
        $where = '';
        switch ($searchOper) {
            case 'eq':
                $oper = '=';
                // $where = $this->db->like('column', $keyword, 'before');
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'ne':
                $oper = '!=';
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'bw':
                $oper = 'after';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'bn':
                $oper = 'after';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'ew':
                $oper = 'before';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'en':
                $oper = 'before';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'cn':
                $oper = 'both';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'nc':
                $oper = 'both';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'nu':
                $oper = '=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'nn':
                $oper = '!=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'in':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_in($searchField, $searchString);
                break;
            
            case 'ni':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_not_in($searchField, $searchString);
                break;
        }

        if ($company_id!=null) {
            $this->db->where('itms_vehicle_groups.company_id', $company_id);
        }

        $this->db->select('itms_vehicle_groups.*');
        $this->db->from('itms_vehicle_groups');
        $this->db->order_by($sidx, $sord);
        $query = $this->db->get();
        
        return $query->result();    
    }
public function get_vehicle_category_report ($limit, $sidx, $sord, $searchField=null, $searchString=null,$searchOper=null, $company_id=null) {
        
        $where = '';
        switch ($searchOper) {
            case 'eq':
                $oper = '=';
                // $where = $this->db->like('column', $keyword, 'before');
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'ne':
                $oper = '!=';
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'bw':
                $oper = 'after';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'bn':
                $oper = 'after';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'ew':
                $oper = 'before';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'en':
                $oper = 'before';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'cn':
                $oper = 'both';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'nc':
                $oper = 'both';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'nu':
                $oper = '=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'nn':
                $oper = '!=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'in':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_in($searchField, $searchString);
                break;
            
            case 'ni':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_not_in($searchField, $searchString);
                break;
        }

        if ($company_id!=null) {
            $this->db->where('itms_assets_categories.company_id', $company_id);
        }

        $this->db->select('itms_assets_categories.*, (itms_assets_categories.assets_cat_name) as assets_cat_name, 
                            itms_assets_types.assets_type_nm as assets_type_nm');
        $this->db->from('itms_assets_categories');
        $this->db->join('itms_assets_types', 'itms_assets_categories.assets_type_id=itms_assets_types.assets_type_id', 'left');
        $this->db->order_by($sidx, $sord);
        $query = $this->db->get();
        
        return $query->result();    
    }
public function get_vehicle_type_report ($limit, $sidx, $sord, $searchField=null, $searchString=null,$searchOper=null, $company_id=null) {
        
        $where = '';
        switch ($searchOper) {
            case 'eq':
                $oper = '=';
                // $where = $this->db->like('column', $keyword, 'before');
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'ne':
                $oper = '!=';
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'bw':
                $oper = 'after';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'bn':
                $oper = 'after';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'ew':
                $oper = 'before';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'en':
                $oper = 'before';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'cn':
                $oper = 'both';
                $where = $this->db->like($searchField, $searchString, $oper);
                break;
            
            case 'nc':
                $oper = 'both';
                $where = $this->db->not_like($searchField, $searchString, $oper);
                break;
            
            case 'nu':
                $oper = '=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'nn':
                $oper = '!=';
                $searchString = null;
                $where = $this->db->where($searchField . $oper, $searchString);
                break;
            
            case 'in':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_in($searchField, $searchString);
                break;
            
            case 'ni':
                $searchString = explode(',', $searchString);
                $where = $this->db->where_not_in($searchField, $searchString);
                break;
        }

        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        $this->db->select('itms_assets.*, (itms_personnel_master.fname) as driver_name, 
                            itms_personnel_master.phone_no as driver_phone, (itms_users.first_name + " " + itms_users.last_name) as add_user_name,
                                itms_users.phone_number as add_user_phone, itms_assets_categories.assets_cat_name, itms_assets_types.assets_type_nm,
                                    itms_assets_groups.assets_group_nm, itms_owner_master.owner_name');
        $this->db->from('itms_assets');
        $this->db->join('itms_personnel_master', 'itms_assets.personnel_id=itms_personnel_master.personnel_id', 'left');
        $this->db->join('itms_users', 'itms_assets.add_uid=itms_users.user_id', 'left');
        $this->db->join('itms_assets_categories', 'itms_assets.assets_category_id=itms_assets_categories.assets_category_id', 'left');
        $this->db->join('itms_assets_types', 'itms_assets.assets_type_id=itms_assets_types.assets_type_id', 'left');
        $this->db->join('itms_assets_groups', 'itms_assets.assets_group_id=itms_assets_groups.assets_group_id', 'left');
        $this->db->join('itms_owner_master', 'itms_assets.owner_id=itms_owner_master.owner_id', 'left');
        $this->db->order_by($sidx, $sord);
        $query = $this->db->get();
        
        return $query->result();    
    }


    public function get_all_categories ($company_id = null) {
             
        $this->db->select('itms_assets_categories.*');
        $this->db->from('itms_assets_categories');
           if ($company_id!=null) {
                $this->db->where('itms_assets_categories.company_id', $company_id);
           }
        $this->db->order_by('assets_cat_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }
	public function get_all_owners ($company_id = null) {
       
        $this->db->select('itms_owner_master.*');
        $this->db->from('itms_owner_master');
           if ($this->session->userdata('protocal') <= 7) {
                $this->db->where('itms_owner_master.company_id', $company_id);
           }

        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }
    public function get_all_types ($company_id = null) {
       
        $this->db->select('itms_assets_types.*');
        $this->db->from('itms_assets_types');
           if ($company_id!=null) {
                $this->db->where('itms_assets_types.company_id', $company_id);
           }

        $this->db->order_by('assets_type_nm', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    public function get_personnel ($company_id=null, $role_id=null, $user_id=null){
        $whereCompany ='';
        $whereUser = "";
        $whereRole = "";
        if ($company_id!=null) {
            $whereCompany = " AND itms_personnel_master.company_id = '".$company_id."' ";
        }

        if ($user_id!=null) {
            $whereUser = " AND itms_personnel_master.add_uid = '".$user_id."' ";
        }

        if ($role_id!=null) {
            $whereRole = " AND itms_personnel_master.role_id = '".$role_id."' ";
        }

        $SQL="SELECT itms_personnel_master.*, itms_roles.role_name from itms_personnel_master 
                INNER JOIN 
                    itms_roles ON(itms_personnel_master.role_id = itms_roles.role_id) 
                    WHERE 1 
                        {$whereCompany} 
                        {$whereUser} 
                        {$whereRole}";

        $rarr=$this->db->query($SQL);
        return $rarr->result();
    }

    public function get_vehicles ($company_id = null) {
       
        $this->db->select('itms_assets.*');
        $this->db->from('itms_assets');
           if ($company_id!=null) {
                $this->db->where('itms_assets.company_id', $company_id);
           }

        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }
				
}


