<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class TMS extends CI_Controller {

    function __construct() {

        parent::__construct();

        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }

        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
            redirect('home');
        }

        $this->load->model('mdl_tms');
        $this->load->model('mdl_fetch');

    }

    public function index() {

        $company_id =$this->session->userdata('itms_company_id');

        $data['count_inwarehouse'] = $this->mdl_fetch->count_inwarehouse($company_id);
        $data['count_assigned'] = $this->mdl_fetch->count_assigned($company_id);
        $data['count_treaded'] = $this->mdl_fetch->count_treaded($company_id);

        $data['content_url'] = 'tms';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS Dashboard';
        $data['content_title'] = 'TMS Dashboard';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/tms_dashboard.php';

        $this->load->view('main/main.php', $data);
    }

    public function view_tyres() {

        $data['tyres'] = $this->mdl_tms->get_all_tyres($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'view_tyres';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Tyres';
        $data['content_title'] = 'TMS - Tyres';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/view_tyres.php';

        $this->load->view('main/main.php', $data);
    }

    public function view_custom_tyres() {

        $data['custom_tyres'] = $this->mdl_tms->get_all_custom_tyres($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'view_custom_tyres';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Custom tyres';
        $data['content_title'] = 'TMS - Custom tyres';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/view_custom_tyres.php';

        $this->load->view('main/main.php', $data);
    }

    public function create_custom_tyre() {

        $data['all_manufacturers'] = $this->mdl_tms->get_all_manufacturers($this->session->userdata('itms_company_id'));
        $data['all_tyre_widths'] = $this->mdl_tms->get_tyre_widths();
        $data['all_tyre_profiles'] = $this->mdl_tms->get_tyre_profiles();
        $data['all_rim_sizes'] = $this->mdl_tms->get_rim_sizes();
        $data['all_tyre_rubbers'] = $this->mdl_tms->get_tyre_rubbers();
        $data['all_speed_ratings'] = $this->mdl_tms->get_speed_ratings();

        // echo "<pre>";
        // print_r($data['all_speed_ratings']);
        // exit;

        $data['content_url'] = 'creat_custom_tyre';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Create Custom tyre';
        $data['content_title'] = 'TMS - Create Custom tyre';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/create_custom_tyre.php';

        $this->load->view('main/main.php', $data);
    }

    public function save_custom_tyre() {

        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        echo $this->mdl_tms->save_custom_tyre($data);

    }

    public function edit_custom_tyre($custom_tyre_id) {

        $data['custom_tyre'] = $this->mdl_tms->get_custom_tyre_by_id($custom_tyre_id);
        $data['all_manufacturers'] = $this->mdl_tms->get_all_manufacturers($this->session->userdata('itms_company_id'));
        $data['all_tyre_widths'] = $this->mdl_tms->get_tyre_widths();
        $data['all_tyre_profiles'] = $this->mdl_tms->get_tyre_profiles();
        $data['all_rim_sizes'] = $this->mdl_tms->get_rim_sizes();
        $data['all_tyre_rubbers'] = $this->mdl_tms->get_tyre_rubbers();
        $data['all_speed_ratings'] = $this->mdl_tms->get_speed_ratings();

        // echo "<pre>";
        // print_r($data);
        // exit;
        
        $data['content_url'] = 'edit_custom_tyre';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Edit Custom tyre';
        $data['content_title'] = 'TMS - Edit Custom tyre';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/edit_custom_tyre.php';

        $this->load->view('main/main.php', $data);
    }

    public function update_custom_tyre() {

        $data = $this->input->post();

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        $this->mdl_tms->update_custom_tyre($data);
    }

    public function add_tyre() {

        $data['all_custom_tyres'] = $this->mdl_tms->get_custom_tyres();
        $data['all_tyre_status_types'] = $this->mdl_tms->get_tyres_status_type();

        $data['content_url'] = 'add_tyre';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Add tyre';
        $data['content_title'] = 'TMS - Add tyre';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/add_tyre.php';

        $this->load->view('main/main.php', $data);

    }

    public function save_tyre() {

        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        $data['purchase_date'] = date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $data['purchase_date'])));
        $data['warranty_expiry'] = date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $data['warranty_expiry'])));
        
		echo $this->mdl_tms->save_tyre($data);
    }

    public function edit_tyre($serial_number) {

        $data['tyre'] = $this->mdl_tms->get_tyre_by_id($serial_number);
        $data['all_custom_tyres'] = $this->mdl_tms->get_custom_tyres();
        $data['all_tyre_status_types'] = $this->mdl_tms->get_tyres_status_type();

        $ml['mileage'] = $this->mdl_tms->calculate_tyre_mileage($serial_number);

        // echo "<pre>";
        // print_r($ml);
        // exit;

        $data['content_url'] = 'edit_tyre';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Edit tyre';
        $data['content_title'] = 'TMS - Edit tyre';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/edit_tyre.php';

        $this->load->view('main/main.php', $data);
    }

    public function update_tyre() {

        $data = $this->input->post();

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        $this->mdl_tms->update_tyre($data);

    }

    public function assign_tyre() {

        $data['content_url'] = 'assign_tyre';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Assign tyre';
        $data['content_title'] = 'TMS - Assign tyre';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/assign_tyre.php';

        $this->load->view('main/main.php', $data);

    }

    public function inventory(){

        $data['inventory'] = $this->mdl_tms->get_inventory($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'inventory';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Inventory';
        $data['content_title'] = 'TMS - Inventory';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/inventory.php';

        $this->load->view('main/main.php', $data);
    }

    public function journal(){

        $data['journal'] = $this->mdl_tms->get_journal($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'journal';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Journal';
        $data['content_title'] = 'TMS - Journal';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/journal.php';

        $this->load->view('main/main.php', $data);
    }

    public function assets_inspection(){

        $data['content_url'] = 'journal';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TMS | Inspection';
        $data['content_title'] = 'TMS - Assets Inspection';
        $data['content_subtitle'] = '';
        $data['content'] = 'tms/inspection.php';

        $this->load->view('main/main.php', $data);
    }

    public function dashboard(){

        $company_id =$this->session->userdata('itms_company_id');

        $sql = $this->db->query('SELECT
        COUNT(CASE WHEN assign_status = 1 AND active_status = 1 THEN 1
                   ELSE NULL
              END) AS assigned,
        COUNT(CASE WHEN assign_status = 0 AND active_status > 1 THEN 1
                    ELSE NULL
               END) AS inwarehouse,
        COUNT(CASE WHEN assign_status = 0 AND active_status > 0 THEN 1
                    ELSE NULL
               END) AS inactive

        FROM itms_tms_tyres_inventory
        WHERE company_id = '.$company_id.'');

        $data= $sql->result_array();
        $result = array();

        foreach($data as $value){
            if (array_key_exists("assigned", $value)) {
                array_push($result, array('label'=>'Assigned','data' => $value['assigned'] ));
            }

            if (array_key_exists("inwarehouse", $value)) {
                array_push($result, array('label'=>'In Warehouse','data' => $value['inwarehouse'] ));
            }

            if (array_key_exists("inactive",$value)) {
                array_push($result, array('label'=>'Disposed','data' => $value['inactive'] ));
            }
        }
        echo json_encode($result);
    }

    public function graphs(){

        $company_id =$this->session->userdata('itms_company_id');
        $data['assigned'] = $this->mdl_fetch->count_assigned($company_id);
        $data['available'] = $this->mdl_fetch->count_inwarehouse($company_id);
        $data['new'] = $this->mdl_fetch->count_new($company_id);

        $result1 = array('label'=>"Assigned Tyres",'value'=>$data['assigned']);
        $result2 = array('label'=>"Available Tyres",'value'=>$data['available']);
        $result3 = array('label'=>"New Tyres",'value'=>$data['new']);

        $result = array($result1,$result2,$result3);

        echo json_encode($result);
    }

}

