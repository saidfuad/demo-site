<?php

class Mdl_tms extends CI_Model{

    function __construct () {
        parent::__construct();
    }

    function get_all_tyres ($company_id) {

        $this->db->select('itms_tms_tyres.*,
            itms_tms_custom_tyre.custom_tyre_name,
            itms_tms_custom_tyre.manufacturer_id,
            itms_tms_manufacturer.name,
            itms_tms_tyres_status_type.status_type_name');

        $this->db->from('itms_tms_tyres')
            ->join('itms_tms_custom_tyre', 'itms_tms_custom_tyre.custom_tyre_id = itms_tms_tyres.tyre_type_id', 'left')
            ->join('itms_tms_manufacturer', 'itms_tms_custom_tyre.manufacturer_id = itms_tms_manufacturer.manufacturer_id', 'left')
            ->join('itms_tms_tyres_status_type', 'itms_tms_tyres_status_type.tyres_status_type_id = itms_tms_tyres.tyre_status_type_id', 'left');

        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('itms_tms_tyres.company_id', $this->session->userdata('itms_company_id'));
            $this->db->where('itms_tms_tyres.inactive_date IS NULL');
        }

        if ($this->session->userdata('protocal') < 7) {
            //$this->db->where('itms_assets.company_id', $this->session->userdata('itms_company_id'));

        }

        $query = $this->db->get();

        return $query->result();

    }

    function calculate_tyre_mileage($tyre_id){

        $this->db->select('itms_tms_tyres.*');
        $this->db->from('itms_tms_tyres');
        $this->db->where('serial_number=', $tyre_id);

        $query = $this->db->get();

        return $query->result();

    }

    function get_tyre_by_id ($serial_no) {

        $this->db->select('itms_tms_tyres.*,
            itms_tms_custom_tyre.custom_tyre_name,
            itms_tms_tyres_status_type.status_type_name');

        $this->db->from('itms_tms_tyres')
            ->join('itms_tms_custom_tyre', 'itms_tms_custom_tyre.custom_tyre_id = itms_tms_tyres.tyre_type_id', 'left')
            ->join('itms_tms_tyres_status_type', 'itms_tms_tyres_status_type.tyres_status_type_id = itms_tms_tyres.tyre_status_type_id', 'left');

        $this->db->where('itms_tms_tyres.company_id', $this->session->userdata('itms_company_id'));
        $this->db->where('itms_tms_tyres.serial_number', $serial_no);
        $this->db->where('itms_tms_tyres.inactive_date IS NULL');

        $query = $this->db->get();

        return $query->row_array();

    }

    function get_all_custom_tyres ($company_id) {

        $this->db->select('itms_tms_custom_tyre.custom_tyre_id,
            itms_tms_custom_tyre.custom_tyre_name,
            itms_tms_custom_tyre.load_rating,
            itms_tms_custom_tyre.rotation,

            itms_tms_manufacturer.name,
            itms_tms_tyre_profile.tyre_profile,
            itms_tms_rim_size.rim_size,
            itms_tms_tyre_width.tyre_width,
            itms_tms_speed_rating.kmh,
            itms_tms_tyre_rubber_type.tyre_rubber_name');

        $this->db->from('itms_tms_custom_tyre')
            ->join('itms_tms_manufacturer', 'itms_tms_custom_tyre.manufacturer_id = itms_tms_manufacturer.manufacturer_id', 'right')
            ->join('itms_tms_tyre_profile', 'itms_tms_custom_tyre.tyre_profile_id = itms_tms_tyre_profile.tyre_profile_id', 'right')
            ->join('itms_tms_rim_size', 'itms_tms_custom_tyre.rim_size_id = itms_tms_rim_size.tyre_rim_size_id', 'right')
            ->join('itms_tms_tyre_width', 'itms_tms_custom_tyre.tyre_width_id = itms_tms_tyre_width.tyre_width_id', 'right')
            ->join('itms_tms_tyre_rubber_type', 'itms_tms_custom_tyre.tyre_rubber_id = itms_tms_tyre_rubber_type.tyre_rubber_id', 'right')
            ->join('itms_tms_speed_rating', 'itms_tms_custom_tyre.speed_rating_id = itms_tms_speed_rating.speed_rating_id', 'right');

        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('itms_tms_custom_tyre.company_id', $this->session->userdata('itms_company_id'));
            $this->db->where('itms_tms_custom_tyre.del_date IS NULL');
        }

        $query = $this->db->get();

        return $query->result();

    }

    function get_custom_tyre_by_id ($custom_tyre_id) {

        $this->db->select('itms_tms_custom_tyre.custom_tyre_name,
            itms_tms_custom_tyre.custom_tyre_id,
            itms_tms_custom_tyre.manufacturer_id,
            itms_tms_custom_tyre.tyre_profile_id,
            itms_tms_custom_tyre.rim_size_id,
            itms_tms_custom_tyre.tyre_width_id,
            itms_tms_custom_tyre.tyre_rubber_id,
            itms_tms_custom_tyre.load_rating,
            itms_tms_custom_tyre.rotation,

            itms_tms_manufacturer.name,
            itms_tms_tyre_profile.tyre_profile,
            itms_tms_rim_size.rim_size,
            itms_tms_tyre_width.tyre_width,
            itms_tms_speed_rating.kmh,
            itms_tms_tyre_rubber_type.tyre_rubber_name');

        $this->db->from('itms_tms_custom_tyre')
            ->join('itms_tms_manufacturer', 'itms_tms_custom_tyre.manufacturer_id = itms_tms_manufacturer.manufacturer_id', 'right')
            ->join('itms_tms_tyre_profile', 'itms_tms_custom_tyre.tyre_profile_id = itms_tms_tyre_profile.tyre_profile_id', 'right')
            ->join('itms_tms_rim_size', 'itms_tms_custom_tyre.rim_size_id = itms_tms_rim_size.tyre_rim_size_id', 'right')
            ->join('itms_tms_tyre_width', 'itms_tms_custom_tyre.tyre_width_id = itms_tms_tyre_width.tyre_width_id', 'right')
            ->join('itms_tms_tyre_rubber_type', 'itms_tms_custom_tyre.tyre_rubber_id = itms_tms_tyre_rubber_type.tyre_rubber_id', 'right')
            ->join('itms_tms_speed_rating', 'itms_tms_custom_tyre.speed_rating_id = itms_tms_speed_rating.speed_rating_id', 'right');

        $this->db->where('itms_tms_custom_tyre.company_id', $this->session->userdata('itms_company_id'));
        $this->db->where('itms_tms_custom_tyre.custom_tyre_id', $custom_tyre_id);
        $this->db->where('itms_tms_custom_tyre.del_date IS NULL');

        $query = $this->db->get();

        return $query->row_array();

    }

    function get_all_manufacturers($company_id) {

        $this->db->select('itms_tms_manufacturer.*');
        $this->db->from('itms_tms_manufacturer');
        $this->db->where('company_id=', 1);
        $this->db->or_where('company_id=', $company_id);
        $this->db->order_by('name', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function get_tyre_widths () {

        $this->db->select('itms_tms_tyre_width.*');
        $this->db->from('itms_tms_tyre_width');
        $this->db->order_by('tyre_width', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function get_tyre_profiles () {

        $this->db->select('itms_tms_tyre_profile.*');
        $this->db->from('itms_tms_tyre_profile');
        $this->db->order_by('tyre_profile', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function get_rim_sizes () {

        $this->db->select('itms_tms_rim_size.*');
        $this->db->from('itms_tms_rim_size');
        $this->db->order_by('rim_size', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function get_tyre_rubbers () {

    	$this->db->select('itms_tms_tyre_rubber_type.*');
        $this->db->from('itms_tms_tyre_rubber_type');
        $this->db->order_by('tyre_rubber_name', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function get_speed_ratings(){

        $this->db->select('itms_tms_speed_rating.*');
        $this->db->from('itms_tms_speed_rating');
        $this->db->order_by('kmh', 'ASC');
        $query = $this->db->get();

        return $query->result_array();
    }

    function save_custom_tyre ($data) {

        if ($this->check_custom_tyre_exists ($data)) {
            return 77;
            exit;
        }

        $query = $this->db->insert('itms_tms_custom_tyre', $data);

        if ($query) {
            return $query;
        }else{
            return false;
        }

    }

    function check_custom_tyre_exists($data) {

    	$query = $this->db->get_where('itms_tms_custom_tyre',
    		array(
    			'company_id'=>$data['company_id'],
    			'load_rating'=>$data['load_rating'],
    			'speed_rating'=>$data['speed_rating'],
    			'rotation'=>$data['rotation'],
    			'tyre_rubber_id'=>$data['tyre_rubber_id'],
    			'tyre_width_id'=>$data['tyre_width_id'],
    			'manufacturer_id'=>$data['manufacturer_id'],
    			'tyre_profile_id'=>$data['tyre_profile_id'],
    			'rim_size_id'=>$data['rim_size_id']
    			)
    		);

        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }

    function update_custom_tyre ($data) {

        $company_id = $this->session->userdata('itms_company_id');

        if ($this->session->userdata('protocal') <= 7) {
            $this->db->where('itms_tms_custom_tyre.company_id', $company_id);
        }

        $this->db->where('custom_tyre_id', $data['custom_tyre_id']);
        echo $this->db->update('itms_tms_custom_tyre', $data);

    }

    function get_custom_tyres () {

        $this->db->select('itms_tms_custom_tyre.*');
        $this->db->from('itms_tms_custom_tyre');
        $this->db->order_by('custom_tyre_name', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function get_tyres_status_type () {

        $this->db->select('itms_tms_tyres_status_type.*');
        $this->db->from('itms_tms_tyres_status_type');
        $this->db->where('status_type_name!=', 'burst');
        $this->db->where('status_type_name!=', 'spare tyre');
        $this->db->where('status_type_name!=', 'dismounted');

        $this->db->order_by('status_type_name', 'ASC');
        $query = $this->db->get();

        return $query->result_array();

    }

    function save_tyre ($data) {

        if ($this->check_tyre_exists ($data)) {
            return 77;
            exit;
        }

        $query = $this->db->insert('itms_tms_tyres', $data);
        $query2 = $this->db->insert('itms_tms_tyres_inventory', 
            array(
                'company_id'=>$data['company_id'],
                'tyre_id'=>$data['serial_number'],
                'tyre_type_id'=>$data['tyre_type_id'],
                'company_id'=>$data['company_id']
                )
            );

        if ($query) {
            return $query;
        }else{
            return false;
        }

    }

    function check_tyre_exists($data) {

        $query = $this->db->get_where('itms_tms_tyres',
            array(
                //'company_id'=>$data['company_id'],
                'serial_number'=>$data['serial_number']
                )
            );

        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }


    function update_tyre ($data) {

        $company_id = $this->session->userdata('itms_company_id');

        if ($this->session->userdata('protocal') <= 7) {
            $this->db->where('itms_tms_tyres.company_id', $company_id);
        }

        $query = $this->db->where('id', $data['id']);
        echo $query->update('itms_tms_tyres', $data);

        $query2 = $this->db->where('related_tyre_id', $data['id']);
        $query2->update('itms_tms_tyres_inventory', array('tyre_id'=>$data['serial_number'], 'tyre_status_id'=>$data['tyre_status_type_id'], 'company_id'=>$data['company_id'], 'tyre_type_id'=>$data['tyre_type_id']));



    }

    function get_inventory($company_id){

        $this->db->select('itms_tms_tyres_inventory.tyre_id, itms_tms_tyres_inventory.assign_status,
            itms_tms_custom_tyre.custom_tyre_name,
            itms_tms_custom_tyre.load_rating, itms_tms_custom_tyre.rotation,
            itms_tms_manufacturer.name, itms_tms_manufacturer.logo,
            itms_assets.assets_friendly_nm,
            itms_tms_tyres.*,
            itms_tms_tyres_status_type.status_type_name,
            itms_tms_rim_size.rim_size,
            itms_tms_tyre_profile.tyre_profile,
            itms_tms_tyre_width.tyre_width,
            itms_tms_speed_rating.speed_symbol, itms_tms_speed_rating.kmh
        ');

        $this->db->from('itms_tms_tyres_inventory')
            ->join('itms_tms_tyres', 'itms_tms_tyres.serial_number = itms_tms_tyres_inventory.tyre_id', 'left')
            ->join('itms_tms_custom_tyre', 'itms_tms_custom_tyre.custom_tyre_id = itms_tms_tyres.tyre_type_id', 'left')
            ->join('itms_tms_manufacturer', 'itms_tms_manufacturer.manufacturer_id = itms_tms_custom_tyre.manufacturer_id', 'left')
            ->join('itms_tms_tyres_status_type', 'itms_tms_tyres_status_type.tyres_status_type_id = itms_tms_tyres.tyre_status_type_id', 'left')
            ->join('itms_tms_master', 'itms_tms_master.tyre_id = itms_tms_tyres_inventory.tyre_id', 'left', 'right')
            ->join('itms_tms_rim_size', 'itms_tms_rim_size.tyre_rim_size_id = itms_tms_custom_tyre.rim_size_id', 'left')
            ->join('itms_tms_tyre_profile', 'itms_tms_tyre_profile.tyre_profile_id = itms_tms_custom_tyre.tyre_profile_id', 'left')
            ->join('itms_tms_tyre_width', 'itms_tms_tyre_width.tyre_width_id = itms_tms_custom_tyre.tyre_width_id', 'left')
            ->join('itms_tms_speed_rating', 'itms_tms_speed_rating.speed_rating_id = itms_tms_custom_tyre.speed_rating_id', 'left')
            ->join('itms_assets', 'itms_assets.asset_id = itms_tms_tyres_inventory.asset_id', 'left');

        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('itms_tms_tyres_inventory.company_id', $this->session->userdata('itms_company_id'));
            $this->db->where('itms_tms_tyres_inventory.active_status=1');
            $this->db->group_by('itms_tms_tyres_inventory.tyre_id');
        }

        $query = $this->db->get();

        return $query->result();
    }

    function get_journal($company_id){

        $this->db->select('itms_tms_journal.*,
            itms_tms_tyre_position.position,
            itms_tms_tyres_status_type.status_type_name,
            itms_assets.assets_friendly_nm,
            itms_tms_journal_status.journal_status_name,
            itms_tms_master.*,
            itms_axle_pressure_config.axle_no');

        $this->db->from('itms_tms_journal')
            ->join('itms_tms_master', 'itms_tms_master.tms_id = itms_tms_journal.tms_id', 'left')
            ->join('itms_tms_tyre_position', 'itms_tms_tyre_position.tyre_position_id = itms_tms_journal.tyre_position_id', 'left')
            ->join('itms_tms_tyres_status_type', 'itms_tms_tyres_status_type.tyres_status_type_id = itms_tms_journal.tyre_status_id', 'left')
            ->join('itms_tms_journal_status', 'itms_tms_journal_status.journal_status_id = itms_tms_journal.journal_status', 'left')
            ->join('itms_assets', 'itms_assets.asset_id = itms_tms_master.asset_id', 'left')
            ->join('itms_axle_pressure_config', 'itms_axle_pressure_config.id = itms_tms_master.axle_id', 'left');

        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('itms_tms_journal.company_id', $this->session->userdata('itms_company_id'));
            $this->db->order_by('itms_tms_journal.journal_date');
        }

        $query = $this->db->get();

        return $query->result();
    }
}
