<?php

class Mdl_fetch extends CI_Model{

    function __construct () {
        parent::__construct();
    }

    function count_new ($company_id=null) {
        if ($company_id!=null) {
            $data['company_id'] = $company_id;
        }
        $d = $this->session->userdata('itms_company_id');
        $query = $this->db->query("SELECT COUNT(`itms_tms_tyres_inventory`.`tyre_id`) AS new 
                                    FROM `itms_tms_tyres_inventory`
                                    WHERE `itms_tms_tyres_inventory`.`tyre_status_id`= 1
                                    AND  company_id = $d
                                    ");
        
        $data = $query->row_array();
        
        return $data['new'];
    }

    function count_inwarehouse ($company_id=null) {
        if ($company_id!=null) {
            $data['company_id'] = $company_id;
        }
        $d = $this->session->userdata('itms_company_id');
        $query = $this->db->query("SELECT COUNT(`itms_tms_tyres_inventory`.`tyre_id`) AS warehouse 
                                    FROM `itms_tms_tyres_inventory`
                                    WHERE `itms_tms_tyres_inventory`.`assign_status`= 0
                                    AND  company_id = $d
                                    ");
        
        $data = $query->row_array();
        
        return $data['warehouse'];
    }

    function count_assigned ($company_id=null) {
        if ($company_id!=null) {
            $data['company_id'] = $company_id;
        }
        $d = $this->session->userdata('itms_company_id');
        $query = $this->db->query("SELECT COUNT(`itms_tms_tyres_inventory`.`tyre_id`) AS assigned 
                                    FROM `itms_tms_tyres_inventory`
                                    WHERE `itms_tms_tyres_inventory`.`assign_status`= 1
                                    AND  company_id = $d
                                    ");
        
        $data = $query->row_array();
        
        return $data['assigned'];
    }

    function count_treaded ($company_id=null) {
        if ($company_id!=null) {
            $data['company_id'] = $company_id;
        }
        $d = $this->session->userdata('itms_company_id');
        $query = $this->db->query("SELECT COUNT(`itms_tms_journal`.`journal_id`) AS treaded 
                                   FROM `itms_tms_journal`
                                   WHERE `itms_tms_journal`.`journal_status` = 'treaded'
                                   AND  company_id = $d
                                  ");
        
        $data = $query->row_array();
        
        return $data['treaded'];
    }

    function count_disposed ($company_id=null) {
        if ($company_id!=null) {
            $data['company_id'] = $company_id;
        }
        $d = $this->session->userdata('itms_company_id');
        $query = $this->db->query("SELECT COUNT(`itms_tms_tyres_inventory`.`tyre_id`) AS disposed 
                                    FROM `itms_tms_tyres_inventory`
                                    WHERE `itms_tms_tyres_inventory`.`assign_status`= 0
                                    AND `itms_tms_tyres_inventory`.`active_status`= 0
                                    AND  company_id = $d
                                    ");
        
        $data = $query->row_array();
        
        return $data['disposed'];
    }

    function get_dashboard_pie1($company_id=null){
        if ($company_id!=null) {
            $data['company_id'] = $company_id;
        }
        $d = $this->session->userdata('itms_company_id');
        $query = $this->db->query("SELECT COUNT(`itms_tms_journal`.`journal_id`) AS treaded 
                                   FROM `itms_tms_journal`
                                   WHERE `itms_tms_journal`.`journal_status` = 'treaded'
                                   AND  company_id = $d
                                  ");
        
        $data = $query->row_array();
        
        return $data['treaded'];
    }

}

?>