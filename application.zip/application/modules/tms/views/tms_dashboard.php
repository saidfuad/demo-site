<div class="container-fluid">
    <div class="row fleet-content">
        <div class="col-lg-4">
            <div class="panel panel-square">
                <div class="panel-heading panel-info clearfix">
                    <h4 class="panel-title">Tyre Statistics</h4> </div>
                    <div class="panel-body fleet-issues">
                      <div class="row">
                        <div class="col-sm-4 text-center">
                            <h1 class="warning">
                                <?php if ($count_inwarehouse > 0){
                                ?>
                                <a href="<?php echo base_url('index.php/tms/inventory');?>"> <?php echo $count_inwarehouse; ?>
                                </a>
                                <?php
                                    } else {
                                        echo $count_inwarehouse;
                                    }
                                ?>
                            </h1>
                            <span class="caption">In Warehouse</span>
                        </div>
                        <div class="col-sm-4 text-center">
                            <h1 class="warning">
                                <?php if ($count_assigned > 0){
                                ?>
                                <a href="<?php echo base_url('index.php/tms/inventory');?>"> <?php echo $count_assigned; ?>
                                </a>
                                <?php
                                    } else {
                                        echo $count_assigned;
                                    }
                                ?>
                            </h1>
                            <span class="caption">Assigned</span>
                        </div>
                        <div class="col-sm-4 text-center">
                            <h1 class="warning">
                                <?php if ($count_treaded > 0){
                                ?>
                                <a href="<?php echo base_url('index.php/tms/inventory');?>"> <?php echo $count_treaded; ?>
                                </a>
                                <?php
                                    } else {
                                        echo $count_treaded;
                                    }
                                ?>
                            </h1>
                            <span class="caption">Retreaded</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading"> tyre status chart </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="flot-chart">
                            <div class="flot-chart-content" id="status-pie-chart"></div>
                        </div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading"> Tyre Assignment chart </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div id="trips-status-chart"></div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
        </div>
    </div>

    <!-- /.row -->
</div>
<!-- Page-Level Plugin Scripts - Dashboard -->
<script src="<?php echo base_url('assets/js/plugins/morris/raphael-2.1.0.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.time.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.pie.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/morris/morris.js')?>"></script>
<script type="text/javascript">
//Flot Pie Chartalert("this");
$(function() {
    $.ajax({
        type: "GET",
        url: "<?php echo base_url('index.php/tms/dashboard') ?>",
        dataType: "html", //expect html to be returned
        success: function(response) {
            var statusData = JSON.parse(response);
            var plotObj = $.plot($("#status-pie-chart"), statusData, {
                series: {
                    pie: {
                        show: true
                    }
                },
                grid: {
                    hoverable: true
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%p.0%, %s", // show percentages, rounding to 2 decimal places
                    shifts: {
                        x: 20,
                        y: 0
                    },
                    defaultTheme: true
                }
            });
        }
    });
});
$(function() {
    $.ajax({
        type: "GET",
        url: "<?php echo base_url('index.php/tms/graphs') ?>",
        dataType: "html", //expect html to be returned
        success: function(response) {
            var data = JSON.parse(response);
            if ($("#trips-status-chart").length) {
                Morris.Donut({
                    element: 'trips-status-chart',
                    data: data,
                    resize: true
                });
            }
        }
    });
});
</script>
