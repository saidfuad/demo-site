<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-tyre-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Tyre Details
	                </div>
	                <div class="panel-body">

	                    <div class="form-group">
	                        <label for="reservation">Serial No <sup>*</sup>:</label>
													<input class="form-control" type="text" name="serial_number" id="serial_number"/>
	                    </div>
	                    <div class="form-group">
	                        <input type="hidden" name="tyre_type_id" id="tyre_type_id"/>
	                        <label for="reservation">Custom Tyre Name <sup>*</sup>:</label>
	                        <input class="form-control" type="text" id="tyre_type"/>

                            <a style="float: right; margin-top: -28px; margin-right: 5px" href="<?php echo site_url('tms/create_custom_tyre');?>" class='btn btn-success btn-xs'>New Custom Tyre
								<span class='fa fa-plus'></span>
							</a>

	                        <div class="custom_tyre_holder" style="border-radius: 5px;">
							    <ul id="custom-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_custom_tyres == null)
							    	{
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Custom Tyres Found</li>";

							        // echo $value->driver_name;
						    	} else{
							    foreach($all_custom_tyres as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='custom_tyresClicked(this.id,this.title)' class='custom_tyres' id='" . $row['custom_tyre_id'] . "'
							        title='".$row['custom_tyre_name'] . "'>" . $row['custom_tyre_name'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>

							$('#tyre_type').on('focus', function(){
								$('.tyre_status_holder').hide();
							});

                            $('#tyre_type').on('keydown', function(){
								$('#custom-list').show();
								$('.custom_tyre_holder').show();
							});

							$('#tyre_type').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#tyre_type_id").val("");
                                    $('.custom_tyre_holder').hide();
							    }

							    $('#custom-list').show();
							    $("#custom-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function custom_tyresClicked(tyre_type,value) {
                                $("#tyre_type").val(value);
							    $("#tyre_type_id").val(tyre_type);
							    //$("#assets_type").focus();
							    $('#custom-list').hide();
							}
							</script>
	                    </div>

	                    <div class="form-group">
	                        <input type="hidden" name="tyre_status_type_id" id="tyre_status_type_id"/>
	                        <label for="reservation">Tyre Status Type <sup>*</sup>:</label>
	                        <input class="form-control" type="text" id="status_type_name"/>

	                        <div class="tyre_status_holder" style="border-radius: 5px;">
							    <ul id="status-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_tyre_status_types == null)
							    	{
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Custom Tyres Found</li>";

							        // echo $value->driver_name;
						    	} else{
							    foreach($all_tyre_status_types as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='statusClicked(this.id,this.title)' class='status' id='" . $row['tyres_status_type_id'] . "'
							        title='".$row['status_type_name'] . "'>" . $row['status_type_name'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>

							$('#status_type_name').on('focus', function(){
								$('.custom_tyre_holder').hide();
							});

                            $('#status_type_name').on('keydown', function(){
								$('#status-list').show();
								$('.tyre_status_holder').show();
							});

							$('#status_type_name').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#tyre_status_type_id").val("");
                                    $('.tyre_status_holder').hide();
							    }

							    $('#status-list').show();
							    $("#status-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function statusClicked(status_type,value) {
                                $("#status_type_name").val(value);
							    $("#tyre_status_type_id").val(status_type);
							    //$("#assets_type").focus();
							    $('#status-list').hide();
							}
							</script>
	                    </div>

	                    <div class="form-group">
	                        <label for="reservation">Price (Kshs.) <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="tyre_price" id="tyre_price"/>
	                    </div>
	                </div>
	            </div>
			</div>
			<div class="col-md-6 col-lg-6">

				<div class="panel panel-default">
	                <div class="panel-body">
	                    <div id="dropzone">
					    	<div class="form-group">
	                        <label for="reservation">Initial Tread Depth <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="initial_tread_depth" id="initial_tread_depth"/>
                            <input class="form-control" type="hidden" name="current_tread_depth" id="current_tread_depth"/>

                            <div style="float: right; margin-top: -35px; margin-right: 0px; cursor: none" class='btn btn-primary btn-xsm'> / 32 "
							</div>

	                    </div>
                        <div id="dropzone">
					    	<div class="form-group">
	                        <label for="reservation">Mileage Estimate (KM) <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="mileage_est" id="mileage_est"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Purchase Date <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="purchase_date" id="purchase_date"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Warranty Expiry Date <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="warranty_expiry" id="warranty_expiry"/>
	                    </div>

	                  	<script>

	                  		$('#serial_number').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#tyre_price').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#mileage_est').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#purchase_date').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#warranty_expiry').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                	</script>
					    </div>
	                </div>
	            </div>
<!--
	            <div class="col-md-12 bg-crumb" align="center">
					<h2><i class="fa fa-circle-o-notch"></i> Tyre</h2>
					<br>
					<p>Manage tyres details and information. Assign tyres to assets, track tyre positions on vehicles, mileage covered and insepctions.</p>

					<a href="<?php echo site_url('tms/view_tyres');?>" class="btn btn-success">View Tyres</a>
				</div>-->
			</div>
            <div class="panel-footer" align="right">
                <button class="btn btn-primary" type="submit" id="save-tyre">Save</button>
            </div>
            </div>
		</form>	
    </div>
</div>

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script type="text/javascript">

		$("#purchase_date").daterangepicker({
        singleDatePicker: true,
        showDropdowns: true
    });
		
		$("#warranty_expiry").daterangepicker({
        singleDatePicker: true,
        showDropdowns: true
    });

    $(function () {

        $('#add-tyre-form').on('submit', function(){

				if ( $('#serial_number').val().trim() == 0 || $('#tyre_type_id').val().trim() == 0 ||
					$('#tyre_status_type_id').val().trim() == 0 || $('#tyre_price').val().trim() == 0 ||
					$('#initial_tread_depth').val().trim() == 0 || $('#mileage_est').val().trim() == 0 ||
                    $('#purchase_date').val().trim() == 0 || $('#warranty_expiry').val().trim() == 0) {

						swal({   title: "Info",   text: "Fill in all required fields ( * )",
							type: "info",   confirmButtonText: "ok" });

						return false;
				}
                var init_tread = $('#initial_tread_depth').val();
				$('#current_tread_depth').val(init_tread);

                if(init_tread > 5){
                    swal({   title: "Info",   text: 'Tyre tread cannot be greater than 5/32"',
							type: "info",   confirmButtonText: "ok" });
                }

                var $this = $(this);

				$('#save-tyre').html('<i class="fa fa-spinner fa-spin"></i>');
	            $('#save-tyre').prop('disabled', true);

	            swal({
	                title: "Info",
	                text: "Add Tyre?",
	                type: "info",
	                showCancelButton: true,
	                closeOnConfirm: false,
	                allowOutsideClick: false,
	                showLoaderOnConfirm: true
	                }, function(){

			            $.ajax({

			                method: 'post',
			                url: '<?= base_url('index.php/tms/save_tyre') ?>',
			                data: $this.serialize(),
			                success: function (response) {

			                    if (response==1) {

			                    	$('#add-tyre-form').find('input[type="text"]').val("");
			                    	$('#add-tyre-form').find('select').val("");
			                    	$('#add-tyre-form').find('textarea').val("");

			                    	swal({   title: "Info",   text: "Saved successfully",   type: "success",   confirmButtonText: "ok" });
			                    }
			                    else if (response==0) {

			                    	swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
			                    }
			                    else if (response==77) {

			                    	swal({   title: "Info",   text: "Serial No. already exists",   type: "error",   confirmButtonText: "ok" });
			                    }

			                    $('#save-tyre').html('Save');
			            		$('#save-tyre').prop('disabled', false);
			                }

				        });
			        });

	           return false;
	        });
    });
</script>
