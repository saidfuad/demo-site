<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('tms/create_custom_tyre').""; ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                Add Custom Tyre
            </a>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($custom_tyres)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Custom tyre name</th>
                                <th>Manufacturer</th>
                                <th>Tyre Type</th>
                                <th>Tyre Width / Profile / Rim Size</th>
                                <th>Load Rating (KGs)</th>
                                <th>Speed Rating (KM/H)</th>
                                <th>Tyre Rotation (Degrees)</th>
                                <th>Action</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php foreach ($custom_tyres as $key => $value) { ?>
                           <tr class="gradeU" style="text-transform: capitalize">
                                <td><?php echo $value->custom_tyre_name; ?></td>
                                <td><?php echo $value->name; ?></td>
                                <td><?php echo $value->tyre_rubber_name; ?></td>
                                <td><?php echo $value->tyre_width." / ".$value->tyre_profile." / ".$value->rim_size; ?></td>
                                <td><?php echo $value->load_rating; ?></td>
                                <td><?php echo $value->kmh; ?></td>
                                <td><?php echo $value->rotation; ?></td>
                                
                                <td><?php echo "<a data-placement='top' data-toggle='tooltip' data-original-title='Edit ".$value->custom_tyre_name."' href='".base_url('index.php/tms/edit_custom_tyre/'.$value->custom_tyre_id)
                                                ."'class='btn btn-success btn-xs'>edit details &nbsp; <span class='fa fa-pencil'></span></a>"?></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Tyres</h2>
                    <br>
                    <p>Manage custom tyres details and information, tyre width, profile and rim sizes.</p>

                    <a href="<?php echo site_url('tms/create_custom_tyre');?>" class="btn btn-success">Add Custom Tyres</a>
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });

   // $('a').tooltip();
</script>