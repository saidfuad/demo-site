<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-custom-tyre-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Custom Tyre Details
	                </div>
	                <div class="panel-body">

	                    <div class="form-group">
	                        <label for="reservation">Custom Tyre Name <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="custom_tyre_name" id="custom_tyre_name"/>
	                    </div>
	                    <div class="form-group">
	                        <input id="manufacturer_id" name="manufacturer_id" hidden="true" />
	                    	<label for="reservation">Manufacturer <sup>*</sup>:</label>
	                        <input class="form-control" id="manufacturer"/>

	                        <div class="manufacturer_holder" style="border-radius: 5px;">
							    <ul id="manufacturers-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_manufacturers == null) 
							    	{	
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Manufacturers Found</li>";
							    		
							        // echo $value->driver_name;
						    	} else{
							    foreach($all_manufacturers as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='manufacturersClicked(this.id,this.title)' class='manufacturers' id='" . $row['manufacturer_id'] . "'
							        title='".$row['name'] . "'>" . $row['name'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>
							
							$('#manufacturer').on('focus', function(){
								$('.tyre_width_holder').hide();
								$('.tyre_profile_holder').hide();
								$('.rim_size_holder').hide();
								$('.tyre_rubber_holder').hide();
								$('.speed_rating_holder').hide();
								
							});

                            $('#manufacturer').on('keydown', function(){
								$('#manufacturers-list').show();
								$('.manufacturer_holder').show();

							});

							$('#manufacturer').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#manufacturer_id").val("");
                                    $('.manufacturer_holder').hide();
							    }

							    $('#manufacturers-list').show();
							    $("#manufacturers-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function manufacturersClicked(manufacturer,value) {
                                $("#manufacturer").val(value);
							    $("#manufacturer_id").val(manufacturer);
							    //$("#assets_type").focus();
							    $('#manufacturers-list').hide();
							}
							</script>
	                    </div>

	                    <div class="form-group">
	                        <input type="hidden" name="tyre_width_id" id="tyre_width_id"/>
	                        <label for="reservation">Tyre Width <sup>*</sup>:</label>
	                        <input class="form-control" type="text" id="tyre_width"/>
                            
                            <div class="tyre_width_holder" style="border-radius: 5px;">
							    <ul id="width-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_tyre_widths == null) 
							    	{	
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Tyre Widths Found</li>";
							    		
						    	} else{
							    foreach($all_tyre_widths as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='widthClicked(this.id,this.title)' class='width' id='" . $row['tyre_width_id'] . "'
							        title='".$row['tyre_width'] . "'>" . $row['tyre_width'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>
							
							$('#tyre_width').on('focus', function(){
								$('.manufacturer_holder').hide();
								$('.tyre_profile_holder').hide();
								$('.rim_size_holder').hide();
								$('.tyre_rubber_holder').hide();
								$('.speed_rating_holder').hide();
							});

                            $('#tyre_width').on('keydown', function(){
								$('#width-list').show();
								$('.tyre_width_holder').show();
							});

							$('#tyre_width').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#tyre_width_id").val("");
                                    $('.tyre_width_holder').hide();
							    }

							    $('#width-list').show();
							    $("#width-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function widthClicked(width,value) {
                                $("#tyre_width").val(value);
							    $("#tyre_width_id").val(width);
							    //$("#assets_type").focus();
							    $('#width-list').hide();
							}
							</script>
	                    </div>
                        
	                    <div class="form-group">
	                        <input type="hidden" name="tyre_profile_id" id="tyre_profile_id"/>
	                        <label for="reservation">Tyre Profile <sup>*</sup>:</label>
	                        <input class="form-control" type="text" id="tyre_profile"/>
                            
                            <div class="tyre_profile_holder" style="border-radius: 5px;">
							    <ul id="profile-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_tyre_profiles == null) 
							    	{	
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Tyre profiles Found</li>";
							    		
						    	} else{
							    foreach($all_tyre_profiles as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='profileClicked(this.id,this.title)' class='profile' id='" . $row['tyre_profile_id'] . "'
							        title='".$row['tyre_profile'] . "'>" . $row['tyre_profile'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>
							
							$('#tyre_profile').on('focus', function(){
								$('.tyre_width_holder').hide();
								$('.manufacturer_holder').hide();
								$('.rim_size_holder').hide();
								$('.tyre_rubber_holder').hide();
								$('.speed_rating_holder').hide();
							});

                            $('#tyre_profile').on('keydown', function(){
								$('#profile-list').show();
								$('.tyre_profile_holder').show();
							});

							$('#tyre_profile').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#tyre_profile_id").val("");
							    }

							    $('#profile-list').show();
							    $("#profile-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function profileClicked(profile,value) {
                                $("#tyre_profile").val(value);
							    $("#tyre_profile_id").val(profile);
							    //$("#assets_type").focus();
							    $('#profile-list').hide();
							}
							</script>
	                    </div> 

	                    <div class="form-group">
	                        <input type="hidden" name="rim_size_id" id="rim_size_id"/>
	                        <label for="reservation">Rim Size/Tyre Diameter <sup>*</sup>:</label>
	                        <input class="form-control" type="text" id="rim_size"/>

	                        <div class="rim_size_holder" style="border-radius: 5px;">
							    <ul id="rim-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_rim_sizes == null) 
							    	{	
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Tyre rims Found</li>";
							    		
						    	} else{
							    foreach($all_rim_sizes as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='rimClicked(this.id,this.title)' class='rim' id='" . $row['tyre_rim_size_id'] . "'
							        title='".$row['rim_size'] . "'>" . $row['rim_size'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>
							
							$('#rim_size').on('focus', function(){
								$('.tyre_width_holder').hide();
								$('.tyre_profile_holder').hide();
								$('.manufacturer_holder').hide();
								$('.tyre_rubber_holder').hide();
								$('.speed_rating_holder').hide();
							});

                            $('#rim_size').on('keydown', function(){
								$('#rim-list').show();
								$('.rim_size_holder').show();
							});

							$('#rim_size').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#rim_size_id").val("");
                                    $('.rim_size_holder').hide();
							    }

							    $('#rim-list').show();
							    $("#rim-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function rimClicked(rim,value) {
                                $("#rim_size").val(value);
							    $("#rim_size_id").val(rim);
							    //$("#assets_type").focus();
							    $('#rim-list').hide();
							}
							</script>
	                    </div>

	                </div>
	            </div>
	            
			</div>
			<div class="col-md-6 col-lg-6">
				<div class="panel panel-default">
	                <div class="panel-body">
	                    <div id="dropzone">
                    	    
		                    <div class="form-group">
		                        <input type="hidden" name="tyre_rubber_id" id="tyre_rubber_id"/>
		                        <label for="reservation">Tyre Type <sup>*</sup>:</label>
		                        <input class="form-control" type="text" id="tyre_rubber_name"/>

		                        <div class="tyre_rubber_holder" style="border-radius: 5px;">
								    <ul id="rubber-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

								    <?php
								    if ( $all_tyre_rubbers == null) 
								    	{	
								    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Tyre rims Found</li>";
								    		
							    	} else{
								    foreach($all_tyre_rubbers as $key => $row) {
								        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='rubberClicked(this.id,this.title)' class='rubber' id='" . $row['tyre_rubber_id'] . "'
								        title='".$row['tyre_rubber_name'] . "'>" . $row['tyre_rubber_name'] . "</li>";
								        }
								    }
								    ?>
								    </ul>
								</div>
								<script>
								
								$('#tyre_rubber_name').on('focus', function(){
									$('.tyre_width_holder').hide();
									$('.tyre_profile_holder').hide();
									$('.rim_size_holder').hide();
									$('.manufacturer_holder').hide();
									$('.speed_rating_holder').hide();
								});

                                $('#tyre_rubber_name').on('keydown', function(){
									$('#rubber-list').show();
									$('.tyre_rubber_holder').show();
								});

								$('#tyre_rubber_name').on('keyup', function () {
								    var value = $(this).val().trim();

								    if (value.length == 0) {
										$("#tyre_rubber_id").val("");
								    }

								    $('#rubber-list').show();
								    $("#rubber-list >li").each(function () {
								        if($(this).text().toLowerCase().search(value) > -1) {
								            $(this).show();
								        }
								        else {
								            $(this).hide();
								        }
								    });
								});

								function rubberClicked(rim,value) {
	                                $("#tyre_rubber_name").val(value);
								    $("#tyre_rubber_id").val(rim);
								    //$("#assets_type").focus();
								    $('#rubber-list').hide();
								}
								</script>

		                    </div>

		                   	 <div class="form-group">
		                        <input class="form-control" type="hidden" name="speed_rating_id" id="speed_rating_id"/>
		                        <label for="reservation">Speed Rating (KM/H) :</label>
		                        <input class="form-control" type="text" id="speed_rating"/>

		                        <div class="speed_rating_holder" style="border-radius: 5px;">
								    <ul id="speed-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

								    <?php
								    if ( $all_speed_ratings == null) 
								    	{	
								    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Tyre rims Found</li>";
								    		
							    	} else{
								    foreach($all_speed_ratings as $key => $row) {
								        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='speedClicked(this.id,this.title)' class='speed' id='" . $row['speed_rating_id'] . "'
								        title='".$row['kmh'] . " Km/h'>" . $row['kmh'] . " Km/h</li>";
								        }
								    }
								    ?>
								    </ul>
								</div>
								<script>
								
								$('#speed_rating').on('focus', function(){
									$('.tyre_width_holder').hide();
									$('.tyre_profile_holder').hide();
									$('.rim_size_holder').hide();
									$('.tyre_rubber_holder').hide();
									$('.manufacturer_holder').hide();
								});

                                $('#speed_rating').on('focus', function(){
									$('#speed-list').show();
									$('.speed_rating_holder').show();
								});

								$('#speed_rating').on('keyup', function () {
								    var value = $(this).val().trim();

								    if (value.length == 0) {
										$("#speed_rating_id").val("");
								    }

								    $('#speed-list').show();
								    $("#speed-list >li").each(function () {
								        if($(this).text().toLowerCase().search(value) > -1) {
								            $(this).show();
								        }
								        else {
								            $(this).hide();
								        }
								    });
								});

								function speedClicked(speed,value) {
	                                $("#speed_rating").val(value);
								    $("#speed_rating_id").val(speed);
								    //$("#assets_type").focus();
								    $('#speed-list').hide();
								}
								</script>

		                    </div>
		                   	<div class="form-group">
		                        <label for="reservation">Load Rating (KG) :</label>
		                        <input class="form-control" type="text" name="load_rating" id="load_rating"/>
		                    </div>
		                   	<div class="form-group">
		                        <label for="reservation">Rotation (Degrees) :</label>
		                        <input class="form-control" type="text" name="rotation" id="rotation"/>
		                    </div>

		                    <script>
		                    	
		                    	$('#load_rating').on('focus', function(){
									$('.speed_rating_holder').hide();
									$('.tyre_width_holder').hide();
									$('.tyre_profile_holder').hide();
									$('.rim_size_holder').hide();
									$('.tyre_rubber_holder').hide();
									$('.manufacturer_holder').hide();
								});

								$('#rotation').on('focus', function(){
									$('.speed_rating_holder').hide();
									$('.tyre_width_holder').hide();
									$('.tyre_profile_holder').hide();
									$('.rim_size_holder').hide();
									$('.tyre_rubber_holder').hide();
									$('.manufacturer_holder').hide();
								});

								$('#custom_tyre_name').on('focus', function(){
									$('.speed_rating_holder').hide();
									$('.tyre_width_holder').hide();
									$('.tyre_profile_holder').hide();
									$('.rim_size_holder').hide();
									$('.tyre_rubber_holder').hide();
									$('.manufacturer_holder').hide();
								});

		                    </script>

	                    </div>
	                </div>
		        </div>
		        <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="save-tyre">Save</button>
                </div>
			</div>
		</form>	
    </div>
</div>

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script type="text/javascript">
    $(function () {

        $('#add-custom-tyre-form').on('submit', function() {

        	var $this = $(this);

			if ( $('#custom_tyre_name').val().trim() == 0 || $('#manufacturer').val().trim() == 0 || 
				$('#tyre_width').val().trim() == 0 || $('#rim_size').val().trim() == 0 || 
				$('#tyre_profile').val().trim() == 0 || $('#tyre_rubber_name').val().trim() == 0){

					swal({   title: "Info",   text: "Fill in all required fields ( * )",  
						type: "info",   confirmButtonText: "ok" });

					return false;
			}

			$('#save-tyre').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-tyre').prop('disabled', true);

            swal({   
                title: "Info",   
                text: "Add Custom Tyre?",   
                type: "info",   
                showCancelButton: true,   
                closeOnConfirm: false, 
                allowOutsideClick: false,  
                showLoaderOnConfirm: true                            
                }, function(){

		            $.ajax({

		                method: 'post',
		                url: '<?= base_url('index.php/tms/save_custom_tyre') ?>',
		                data: $this.serialize(),
		                success: function (response) {

		                    if (response==1) {

		                    	$('#add-custom-tyre-form').find('input[type="text"]').val("");


		                    	swal({   title: "Info",   text: "Saved successfully",   type: "success",   confirmButtonText: "ok" });
		                    }
		                    else if (response==0) {

		                    	swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
		                    }
		                    else if (response==77) {

		                    	swal({   title: "Info",   text: "Custom tyre already exists",   type: "error",   confirmButtonText: "ok" });
		                    }
		                    
		                    $('#save-tyre').html('Save');
		            		$('#save-tyre').prop('disabled', false);
		                }

			        });
		        });

           return false;
        });
    });

</script>
