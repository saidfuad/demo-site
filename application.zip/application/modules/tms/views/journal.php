<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('tms/assets_inspection').""; ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                &nbsp;New Inspection
            </a>
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('tms/assign_tyre').""; ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                &nbsp;New Assignment
            </a>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($journal)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Serial No</th>
                                <th>Status</th>
                                <th>Asset</th>
                                <th>Axle No.</th>
                                <th>Tyre Position</th>
                                <th>Odometer Reading</th>
                                <th>Cost</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php foreach ($journal as $key => $value) { ?>
                           <tr class="gradeU" style="text-transform: capitalize">
                                <td><?php echo $value->journal_date; ?></td>
                                <td><?php echo $value->tyre_id; ?></td>
                                <td><?php echo $value->journal_status_name; ?></td>
                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                <td><?php echo $value->axle_no; ?></td>
                                <td>
                                <?php 

                                    if ($value->position == "LO") {
                                        echo "Left Out"; 
                                    }
                                    if ($value->position == "LI") {
                                        echo "Left In"; 
                                    }
                                    if ($value->position == "RO") {
                                        echo "Right Out"; 
                                    }
                                    if ($value->position == "LI") {
                                        echo "Right In"; 
                                    }
                                    
                                ?>
                                </td>
                                <td><?php echo $value->odometer_reading." KM"; ?></td>
                                <td><?php echo "Kshs. ".$value->status_cost.".00"; ?></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>

            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i>Tyre Journals</h2>
                    <br>
                    <p>Monitoring and track your tyres' status, assignments on vehicles, positions on vehicles, mileage estimations and inspections.</p>

                    <button style="cursor: initial" href="#" class="btn btn-success">No Journals Currently</button>
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>

<div class="panel-diagnostics" id="panel-diagnostics">
            <div class="panel-heading">
                <span>Serial No</span> : <span id="panel-action"></span>
                <span class="close cx" id="close-pd"><b>&times;</b></span>
            </div>
            <div class="row vinfo-area">
                <div class="col-md-12 col-sm-12">


                    <div class="col-md-12 top-info-div">
                        <!-- User Card Mini - Right Profile Image -->
                        <div class="user-card-mini row bgf5" style="height:210px">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <p>
                                    <i id="tag-comments"></i><br>

                                </p>
                            </div>
                        </div>
                          <br>
                    </div>


                </div>



            </div>


        </div>


    <div id="tyre-info-div">
        <div class="row">
            <span class="col-sm-6 col-md-6"><h2 id="pressure-info"></h2></span>
            <span class="col-sm-6 col-md-6"><h2 id="temperature-info"></h2></span>
            <span class="col-sm-12 col-md-12">Condition</span>
            <span class="col-sm-12 col-md-12 btn btn-block" id="status-info"></span>
            <span class="col-sm-12 col-md-12" id="axle-info"></span>
            <span class="col-sm-12 col-md-12" id="tyre-info"></span>

        </div>
    </div>

<script src="<?php echo base_url('tyres/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('tyres/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script type="text/javascript">
    $(function () {

        $('.tyre-li').on('click', function () {
            $("#pressure-status-area").html("<h4><i class='fa fa-spinner fa-spin fa-2x' style='color:#18bc9c;'></i></h4>");
            $("#bg-vehicle-area").html('<h3 style="text-align:center;margin-top:50px;"><i class="fa fa-spinner fa-spin fa-2x" style="color:#18bc9c;"></i></h3>');



            //alert(completePattern.length);
            //Display the panel if above conditions have been met.
            $('#bg-vehicle-area').html('');
            $('#panel-diagnostics').fadeOut(500);
            $('#panel-diagnostics').fadeIn(1000);
            $('.overshadow').fadeIn(1000);
            $('#bg-vehicle-area').html('');


            //Render some info about the  vehicle on the diagnostic panel

            /*  Manufacturer: <i id="tag-manufacturer"></i><br>
              Tyre Name: <i id="tag-name"></i><br>
              Tyre Profile: <i id="tag-tyre-profile"></i><br>
              Rim Size: <i id="tag-rim-size"></i><br>
              Load Rating: <i id="tag-load-rating"></i><br>
              Speed Rating: <i id="tag-speed-rating"></i><br>
              Load Rating: <i id="tag-load-rating"></i><br>
              Added: <i id="tag-added-date"></i><br>
              attr-tyre-profile='$value->tyre_profile'
              attr-tyre-added-date='$value->inventory_add_date'*/

                        var comments = $(this).attr('attr-comments-id');
                        var tyre_id = $(this).attr('attr-tyre-id');

                        $('#tag-comments').html(comments);
                        $('#panel-action').html(tyre_id);
      });

      $('.close').on('click', function () {

          //alert(completePattern.length);
          //Display the panel if above conditions have been met.
          $('#bg-vehicle-area').html('');
          $('#panel-diagnostics').fadeIn(500);
          $('#panel-diagnostics').fadeOut(1000);
          $('.overshadow').fadeOut(1000);
          $('#bg-vehicle-area').html('');

    });


});
</script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>
