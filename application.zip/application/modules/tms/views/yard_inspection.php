<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />
<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js">
</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/DataTables/media/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/DataTables/media/css/dataTables.bootstrap.css">
<div class="container-fluid">
  <div class="row">
    <div class="col-md-5 col-lg-5">
      <div class="col-md-12">
        <div class="form-group">
          <b>Vehicle Name
          </b>
          <br>
          <input type="text" name="vehnm" id="vehnam" list="vehdet" placeholder="Enter Vehicle Name..." class="form-control" oninput="enterpressalert()">
          <datalist id="vehdet">
          </datalist>
        </div>
      </div>
      <div class="col-md-12" id="assetview">
      </div>
    </div>
    <div class="col-md-7 col-lg-7" id="tyredetails">
      <div class="col-md-12" style="padding:10px;">
        <ul class="nav nav-pills">
          <!--li class='active' id="toggle-avail"><a href='#'><span>Tyres Available</span></a></li>
<li id="toggle-mounted"><a href='#'><span>Mounted Tyres</span></a></li-->
          <li class="active" id="toggle-rotate">
            <a href='#'>
              <span>Mounted Tyres
              </span>
            </a>
          </li>
        </ul>
      </div>
      <div class="col-md-12">
        <div id="rotate">
          <table class="table table-striped" id="vehrotate">
            <thead>
              <tr style="background-color:grey;color:white;">
                <td>
                  <b>Tyre Serial
                  </b>
                </td>
                <td>
                  <b>Axle No.
                  </b>
                </td>
                <td>
                  <b>Tire Position
                  </b>
                </td>
                <td>
                </td>
                <td>
                  <b>Action
                  </b>
                </td>
                <td>
                </td>
              </tr>
            </thead>
            <tbody id="assetrotated">
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-12">
        <br>
        <br>
        <div id="listmounting" style="display:none;border:1px solid grey;border-radius:5px;padding:5px;margin:auto;">
          <b>Tire Mounting Process
          </b>
          <br>
          <br>
          <input type="hidden" class="form-control" id="vehiclenm" required>
          <input type="hidden" class="form-control" id="comid" value="1">
          <input type="hidden" class="form-control" id="userid" value="1">
          <input type="hidden" class="form-control" id="tyreidnos" required>
          <b>Tire Serial Number
          </b>
          <br>
          <input type="text" id="tyreserial" class="form-control" required>
          <br>
          <input type="checkbox" id="spare" onchange="mouseUp()" value="spare">Mount as spare wheel
          <br>
          <br>
          <b>Select Axle
          </b>
          <br>
          <div id="getax">
          </div>
          <!--  <select id="axlepick" class="form-control">
<option value="">Select Axle</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
</select> -->
          <!-- <input type="text" id="axlepick" list="selectax" class="form-control" required>
<datalist id="selectax"></datalist> -->
          <br>
          <b>Select Position
          </b>
          <br>
          <select id="position" class="form-control">
            <option value="">Select Position
            </option>
            <option value="1">Left Out
            </option>
            <option value="2">Left In
            </option>
            <option value="3">Right In
            </option>
            <option value="4">Right Out
            </option>
          </select>
          <br>
          <p style="text-align:center;">
            <button class="btn-success" onclick="assign()" style="border-radius:5px;padding:5px;" data-dismiss="modal">Assign
            </button>
          </p>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
  <div class="modal fade" id="myLog" tabindex="-1" role="dialog" aria-labelledby="myLogLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="background:black">&times;
            </span>
          </button>
          <h4 class="modal-title" id="myLogLabel">Inspection Form
          </h4>
        </div>
        <div class="modal-body">
          <div class="">
            <div id="listmounting" style="border:1px solid grey;border-radius:5px;padding:5px;margin:auto;">
              <b>Tyre Loging Process
              </b>
              <br>
              <br>
              <input type="hidden" class="form-control" id="vehiclenm" required>
              <input type="hidden" class="form-control" id="userid" value="1">
              <input type="hidden" class="form-control" id="tyreidnos" required>
              <b>Tyre Serial Number
              </b>
              <br>
              <input type="text" id="tyreserials" class="form-control" required>
              <br>
              <b>Odometer Reading
              </b>
              <br>
              <input type="number" id="oddolog" class="form-control" placeholder="Enter Numbers,no decimals eg.18887 " required>
              <br>
              <b>Comments
              </b>
              <br>
              <textarea class="col-md-12" rows="7" id="commentslog">
              </textarea>
              <br>
              <p style="text-align:center;">
                <button class="btn-success" onclick="log()" data-dismiss="modal" style="border-radius:5px;padding:5px;">Log
                </button>
              </p>
            </div>
          </div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
  </div>
  <!-- Button trigger dismount -->
  <!-- Modal -->
  <div class="modal fade" id="myDismount" tabindex="-1" role="dialog" aria-labelledby="myDismountLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="background:black">&times;
            </span>
          </button>
          <h4 class="modal-title" id="myDismountLabel">Inspection Form
          </h4>
        </div>
        <div class="modal-body">
          <div class="">
            <div id="listmounting" style="border:1px solid grey;border-radius:5px;padding:5px;margin:auto;">
              <b>Tyre Dismounting Process
              </b>
              <br>
              <br>
              <input type="hidden" class="form-control" id="vehiclenm" required>
              <input type="hidden" class="form-control" id="userid" value="1">
              <input type="hidden" class="form-control" id="tyreidnos" required>
              <b>Tyre Serial Number
              </b>
              <br>
              <input type="text" id="tyreserialls" class="form-control" required>
              <br>
              <input type="hidden" id="tmsid" class="form-control" required>
              <br>
              <b>Odometer Reading
              </b>
              <br>
              <input type="number" id="odometerdis" class="form-control" placeholder="Enter Numbers,no decimals eg.18887 " required>
              <br>
              <b>Comments
              </b>
              <br>
              <textarea class="col-md-12" rows="7" id="commentsdis">
              </textarea>
              <br>
              <p style="text-align:center;">
                <button class="btn-success" onclick="dismounting()" data-dismiss="modal" style="border-radius:5px;padding:5px;">Dismount
                </button>
              </p>
            </div>
          </div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
  <div class="modal fade" id="myRotation" tabindex="-1" role="dialog" aria-labelledby="myRotationLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="background:black">&times;
            </span>
          </button>
          <h4 class="modal-title" id="myRotationLabel">Inspection Form
          </h4>
        </div>
        <div class="modal-body">
          <div class="">
            <div id="listrotate" style="display:none;border:1px solid grey;border-radius:5px;padding:5px;margin:auto;">
              <b>Tire Rotation Process
              </b>
              <br>
              <br>
              <input type="hidden" class="form-control" id="vehiclenam" required>
              <input type="hidden" class="form-control" id="tmsidnum">
              <input type="hidden" class="form-control" id="tidnum">
              <input type="hidden" class="form-control" id="olda">
              <input type="hidden" class="form-control" id="oldp">
              <b>Tire Serial Number
              </b>
              <br>
              <input type="text" id="tyreseriall" class="form-control" required>
              <br>
              <b>Select Axle
              </b>
              <br>
              <div id="getrotax">
              </div>
              <!-- <select id="axlerot" class="form-control" required>
<option value="">Select Axle</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
</select> -->
              <br>
              <b>Select Position
              </b>
              <br>
              <select id="posrot" class="form-control" required>
                <option value="">Select Position
                </option>
                <option value="1">Left Out
                </option>
                <option value="2">Left In
                </option>
                <option value="3">Right In
                </option>
                <option value="4">Right Out
                </option>
              </select>
              <br>
              <b>Comments
              </b>
              <br>
              <textarea class="col-md-12" rows="7" id="commentsrot">
              </textarea>>
              <br>
              <p style="text-align:center;">
                <button class="btn-success" onclick="rot()" style="border-radius:5px;padding:5px;" data-dismiss="modal">Rotate
                </button>
              </p>
            </div>
          </div>
        </div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
  </div>
  <script src="<?php echo base_url(); ?>/assets/js/jquery.js">
  </script>
  <script src="<?php echo base_url(); ?>/assets/js/jquery.min.js">
  </script>
  <script src="<?php echo base_url(); ?>/assets/DataTables/media/js/jquery.dataTables.js">
  </script>
  <!--<script src="js/app.js"></script>-->
  <!-- <script src="DataTables/media/js/app.js"></script> -->
  <script>
    function mouseUp() {
      var x = document.getElementById("spare").checked;
      if (x == true) {
        document.getElementById("axlepick").disabled = true;
        document.getElementById("position").disabled = true;
      }
      else {
        document.getElementById("axlepick").disabled = false;
        document.getElementById("position").disabled = false;
      }
    }
    $(document).ready(function() {
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournaljournal.php',
        type: 'POST',
        data: {
          tire: 1
        }
        ,
        success: function(rec) {
          $("#assetsearch").html(rec);
          $('#vehavail').DataTable();
        }
      }
            );
      $('#vehnam').keyup(function() {
        $.get("<?php echo base_url(); ?>/assignment/suggest.php", {
          vehnm: $(this).val()
        }
              , function(data) {
          $("datalist").empty();
          $("datalist").html(data);
        }
             );
      }
                        );
      $('#rotate').show();
      $('#mounted').hide();
      $('#avail').hide();
    }
                     );
    function setseriallog() {
      $('body').delegate('.lo', 'click', function() {
        var x = $(this).attr('idtid');
        document.getElementById("tyreserials").value = x;
      }
                        );
    }
    function setserial() {
      $('body').delegate('.dis', 'click', function() {
        var x = $(this).attr('idtid');
        var y = $(this).attr('idtms');
        document.getElementById("tyreserialls").value = x;
        document.getElementById("tmsid").value = y;
      }
                        );
    }
    function gettyres() {
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          tire: 1
        }
        ,
        success: function(rec) {
          $("#assetsearch").html(rec);
          $('#vehavail').DataTable();
        }
      }
            );
    }
    function getmounted() {
      var inputm = $('#vehnam').val();
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          mountdet: 1,
          assmount: inputm
        }
        ,
        success: function(rec) {
          $("#assetmounted").html(rec);
          $('#vehdismount').DataTable();
        }
      }
            );
    }
    function getrotate() {
      var inputr = $('#vehnam').val();
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          rotatedet: 1,
          assrotat: inputr
        }
        ,
        success: function(rec) {
          $("#assetrotated").html(rec);
          $('#vehrotate').DataTable();
        }
      }
            );
    }
    function getview() {
      var inputss = $('#vehnam').val();
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          viewass: 1,
          assnm: inputss
        }
        ,
        success: function(rec) {
          $('#assetview').html(rec);
        }
      }
            );
    }
    function enterpressalert() {
      //Enter keycode
      var inputs = $('#vehnam').val();
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          viewass: 1,
          assnm: inputs
        }
        ,
        success: function(rec) {
          $('#assetview').html(rec);
          gettyres();
          getmounted();
          getrotate();
          $('#tyredetails').show();
          $('#completion').show();
        }
      }
            );
    }
    function mounting() {
      document.getElementById("vehiclenm").value = $('#vehnam').val();
      document.getElementById("tyreidnos").value = $('#tyreid').val();
      document.getElementById("tyreserial").value = $('#tyreser').val();
      var vehaxle = $('#vehiclenm').val();
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          getvehaxle: 1,
          vehiclea: vehaxle
        }
        ,
        success: function(rec) {
          $("#getax").html(rec);
        }
      }
            );
      //  var trys=$('#vehiclenm').val();
      // $('#axlepick').keyup(function(){
      //      $.get("<?php echo base_url(); ?>/suggest2.php",{vehnm : $('#vehnam').val()},function(data){
      //          $("datalist").empty();
      //          $("datalist").html(data);
      //      });
      //  });
      $('#listmounting').show();
    }
    function assign() {
      var name = $('#vehiclenm').val();
      var tidnos = $('#tyreidnos').val();
      var tser = $('#tyreserial').val();
      var axlepik = $('#axlepick').val();
      var tpos = $('#position').val();
      var comid = $('#comid').val();
      var uid = $('#userid').val();
      var x = document.getElementById("spare").checked;
      if (x == true) {
        if (name == "") {
          swal({
            title: "Error!",
            text: "No Vehicle Selected",
            type: "error",
            confirmButtonText: "Change"
          }
              );
          $('#listmounting').hide();
        }
        else {
          var sparet = $('#spare').val();
          var noax = 0;
          var notpos = 0;
          swal({
            title: "Are you sure?",
            text: "This tire will be mounted as spare!",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, mount as spare!",
            closeOnConfirm: false
          }
               ,
               function() {
            $.ajax({
              url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
              type: 'POST',
              data: {
                mountspare: 1,
                assname: name,
                tireid: tidnos,
                axlenone: noax,
                tirepos: notpos,
                cid: comid,
                usid: uid,
                tserr: tser,
                tspare: sparet
              }
              ,
              success: function(rec) {
                swal(rec);
                gettyres();
                getmounted();
                getrotate();
                getview();
                $('#listmounting').hide();
              }
            }
                  );
          }
              );
        }
      }
      else {
        if (name == "") {
          swal({
            title: "Error!",
            text: "No Vehicle Selected",
            type: "error",
            confirmButtonText: "Change"
          }
              );
          $('#listmounting').hide();
        }
        else if (axlepik == "") {
          swal({
            title: "Error!",
            text: "No Axle Selected",
            type: "error",
            confirmButtonText: "Change"
          }
              );
        }
        else if (tpos == "") {
          swal({
            title: "Error!",
            text: "No Tire Position Selected",
            type: "error",
            confirmButtonText: "Change"
          }
              );
        }
        else {
          $.ajax({
            url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
            type: 'POST',
            data: {
              mountass: 1,
              assname: name,
              tireid: tidnos,
              axledet: axlepik,
              tirepos: tpos,
              cid: comid,
              usid: uid,
              tserr: tser
            }
            ,
            success: function(rec) {
              swal(rec);
              gettyres();
              getmounted();
              getrotate();
              getview();
              $('#listmounting').hide();
            }
          }
                );
        }
      }
    }
    function dismounting() {
      swal({
        title: "Please Confirm",
        text: "Dismount tyre from vehicle?",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Confirm",
        closeOnConfirm: false
      }
           ,
           function() {
        var comm = $('#commentsdis').val();
        var oddo = $('#odometerdis').val();
        var atmsid = $('#tmsid').val();
        var atireid = $('#tyreserialls').val();
        $.ajax({
          url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
          type: 'POST',
          data: {
            dismountass: 1,
            asstms: atmsid,
            asstyre: atireid,
            ododis: oddo,
            com:  comm
          }
          ,
          success: function(rec) {
            swal(rec);
            getmounted();
            gettyres();
            getrotate();
            getview();
          }
        }
              );
      }
          );
    }
    function rotation() {
      $('body').delegate('.rotat', 'click', function() {
        document.getElementById("vehiclenam").value = $('#vehnam').val();
        document.getElementById("tmsidnum").value = $('#tmsidnew').val();
        document.getElementById("tidnum").value = $('#tyreidnew').val();
        document.getElementById("tyreseriall").value = $(this).attr('idtyreid');
        document.getElementById("olda").value = $('#oldaxle').val();
        document.getElementById("oldp").value = $('#oldpos').val();
        var vehrotaxle = $('#vehiclenam').val();
        $.ajax({
          url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
          type: 'POST',
          data: {
            getvehrotaxle: 1,
            vehiclerota: vehrotaxle
          }
          ,
          success: function(rec) {
            $("#getrotax").html(rec);
          }
        }
              );
        $('#listrotate').show();
      }
                        );
    }
    function rot() {
      var vname = $('#vehiclenam').val();
      var tmsnos = $('#tmsidnum').val();
      var trid = $('#tidnum').val();
      var tserl = $('#tyreseriall').val();
      var taxle = $('#axlerot').val();
      var tposrot = $('#posrot').val();
      var oldax = $('#olda').val();
      var oldpo = $('#oldp').val();
      var comm = $('#commentsrot').val();
      var oddo = $('#oddo').val();
      if (vname == "") {
        swal({
          title: "Error!",
          text: "No Vehicle Selected",
          type: "error",
          confirmButtonText: "Change"
        }
            );
      }
      else if (taxle == "") {
        swal({
          title: "Error!",
          text: "No Axle Selected",
          type: "error",
          confirmButtonText: "Change"
        }
            );
      }
      else if (tposrot == "") {
        swal({
          title: "Error!",
          text: "No Tire Position Selected",
          type: "error",
          confirmButtonText: "Change"
        }
            );
      }
      else {
        $.ajax({
          url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
          type: 'POST',
          data: {
            od: oddo,
            com: comm,
            rotateass: 1,
            vehname: vname,
            tmsnum: tmsnos,
            tnum: trid,
            tsernum: tserl,
            txlenum: taxle,
            tposnum: tposrot,
            tolda: oldax,
            toldp: oldpo
          }
          ,
          success: function(rec) {
            swal(rec);
            gettyres();
            getmounted();
            getrotate();
            getview();
            $('#listrotate').hide();
          }
        }
              );
      }
    }
    function log() {
      var vname = $('#vehiclenam').val();
      var tmsnos = $('#tmsidnum').val();
      var trid = $('#tidnum').val();
      var tserl = $('#tyreserials').val();
      var taxle = $('#axlerot').val();
      var tposrot = $('#posrot').val();
      var oldax = $('#olda').val();
      var oldpo = $('#oldp').val();
      var comm = $('#commentslog').val();
      var oddo = $('#oddolog').val();
      $.ajax({
        url: '<?php echo base_url(); ?>/assignment/mountajaxjournal.php',
        type: 'POST',
        data: {
          od: oddo,
          com: comm,
          log: 1,
          vehname: vname,
          tmsnum: tmsnos,
          tnum: trid,
          tsernum: tserl,
          txlenum: taxle,
          tposnum: tposrot,
          tolda: oldax,
          toldp: oldpo
        }
        ,
        success: function(rec) {
          swal(rec);
          gettyres();
          getmounted();
          getrotate();
          getview();
          $('#listrotate').hide();
        }
      }
            );
    }
    function complete() {
      document.location.href = '<?php echo base_url(); ?>/application/modules/tms/views/assign_tyre.php';
    }
  </script>
</div>
