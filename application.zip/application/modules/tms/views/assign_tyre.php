<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />


        <script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>

<style>
datalist {
    height:10px;
    border-radius:5px;
    background-color:#c0c0c0;
    overflow-y:auto;
}
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <div class="col-md-12">


                                         <div class="form-group">
                                             <?php
                                             if(!empty($_GET['asset'])){
                                                 $vehpassd=$_GET['asset'];
                                                 $connect=mysqli_connect('localhost','root','','itms_africa') or die(mysqli_errno());
                                                 $assetname2=mysqli_query($connect,"SELECT assets_name FROM itms_assets WHERE asset_id='$vehpassd'");
                                                 $assetrow=mysqli_fetch_array($assetname2);

                                                 if(!is_null($assetrow)){
                                                     $vehiclename=$assetrow['assets_name'];
                                                 }
                                                 ?>
                                             <b>Vehicle Name</b><br>
                                            <input type="text" name="vehnm" id="vehnam" value="<?php echo $vehiclename; ?>" class="form-control">
                                             <script>

                                                function enterpressalert(){
                                                 //Enter keycode
                                                 var inputs = $('#vehnam').val();


                                                        $.ajax({
                                                            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
                                                            type : 'POST',
                                                            data : {
                                                                viewass : 1,
                                                                assnm : inputs
                                                            },
                                                            success : function (rec){
                                                                $('#assetview').html(rec);
                                                                gettyres();
                                                                getmounted();
                                                                getrotate();
                                                                passedid();
                                                                $('#vehavail').dataTable( );
                                                                $('#vehdismount').dataTable( );
                                                                $('#vehrotate').dataTable( );
                                                                $('#tyredetails').show();
                                                                $('#completion').show();
                                                            }
                                                        });
                                                }
                                                 enterpressalert();
                                             </script>
                                             <?php
                                             }
                                             else{
                                                 ?>
                                            <b>Vehicle Name</b><br>
                                            <input type="text" name="vehnm" id="vehnam" list="vehdet" placeholder="Enter Vehicle Name..." class="form-control" oninput="enterpressalert()">
                                            <datalist id="vehdet"></datalist>
                                             <?php
                                             }
                                             ?>
                                        </div>

                                </div>
                                <div class="col-md-12" id="assetview">
                                    </div>

        </div>
        <div class="col-md-5" id="tyredetails">
            <div class="col-md-12" style="padding:10px;">
        <ul class="nav nav-pills">
            <li class='active' id="toggle-avail"><a href='#'><span>Tyres Available</span></a></li>
            <li id="toggle-mounted"><a href='#'><span>Mounted Tyres</span></a></li>
            <li id="toggle-rotate"><a href='#'><span>Rotate Tyres</span></a></li>
            </ul>
    </div>
                <div class="col-md-12">
                    <div id="avail">
                <table class="table table-striped" style="width:100%" id="vehavail">
                                        <thead>

                                            <tr style="background-color:grey;color:white;">
                                                <td><b>Brand Name</b></td><td><b>Tyre Serial</b></td><td><b>Tyre Size</b></td><td><b>Action</b></td>
                                            </tr>
                                        </thead>
                                        <tbody id="assetsearch"></tbody>
                                     <tfoot></tfoot>
                                    </table>
                                </div>

                                        <div id="mounted" style="width:100%">
                <table class="table table-striped" style="width:100%" id="vehdismount">
                                        <thead>
                                            <tr style="background-color:grey;color:white;">
                                                <td><b>Tyre Serial</b></td><td><b>Axle No.</b></td><td><b>Tyre Position</b></td><td><b>Action</b></td>
                                            </tr>
                                        </thead>
                                        <tbody id="assetmounted">

                                        </tbody>
                                    </table>
                                </div>

                                        <div id="rotate">
                <table class="table table-striped" style="/* width:539; */" id="vehrotate">
                                        <thead>

                                            <tr style="background-color:grey;color:white;">
                                                <td><b>Tyre Serial</b></td><td><b>Axle No.</b></td><td><b>Tyre Position</b></td><td><b>Action</b></td>
                                            </tr>
                                        </thead>
                                        <tbody id="assetrotated">


                                        </tbody>
                                    </table>
                                </div>
                                </div>

        </div>

        <div class="col-md-4">
            <div class="col-md-12">
                                    <div id="listmounting" style="border:1px solid grey;border-radius:5px;padding:5px;margin:auto;">
                                        <b>Tyre Mounting Process</b>
                                        <br><br>
                                        <input type="hidden" class="form-control" id="vehiclenm" required>
                                        <input type="hidden" class="form-control" id="userid" value="1">
                                        <input type="hidden" class="form-control" id="tyreidnos" required>
                                        <b>Tyre Serial Number</b><br>
                                        <?php
                                        if(!empty($_GET["id"])){
                                            ?>
                                            <input type="text" id="tyreserial" value="<?php echo $_GET['id']; ?>" onmouseover="mounting()" class="form-control" readonly required><br>
                                            <?php
                                        }
                                        else{
                                            ?>
                                            <input type="text" id="tyreserial" class="form-control" readonly required><br>
                                            <?php

                                        }
                                        ?>


                                        <input type="checkbox" id="spare" onchange="mouseUp()" value="spare">Mount as spare wheel<br><br>
                                        <b>Odometer Reading</b><br>
                                        <input type="number" min="1" id="odometer" class="form-control" placeholder="Enter Numbers,no decimals eg.18887 " required><br>
                                        <div id="getax">
                                        </div>
                                        <br>
                                        <div id="getpo">
                                        </div>
                                        <br>
                                        <p style="text-align:center;"><button class="btn-success" onclick="assign()" style="border-radius:5px;padding:5px;">Assign</button></p>
                                    </div>

                                </div>

                                 <div class="col-md-12">
                                    <div id="listrotate" style="display:none;border:1px solid grey;border-radius:5px;padding:5px;margin:auto;">
                                        <b>Tyre Rotation Process</b>
                                        <br><br>
                                        <input type="hidden" class="form-control" id="vehiclenam" required>
                                        <input type="hidden" class="form-control" id="tmsidnum">
                                        <input type="hidden" class="form-control" id="tidnum">
                                        <input type="hidden" class="form-control" id="olda">
                                        <input type="hidden" class="form-control" id="oldp">
                                        <b>Tyre Serial Number</b><br>
                                        <input type="text" id="tyreseriall" class="form-control" readonly required><br>
                                        <div id="getrotax">
                                        </div>
                                        <br>
                                        <div id='getrotposs'>
                                        </div>
                                        <br>
                                        <p style="text-align:center;"><button class="btn-success" onclick="rot()" style="border-radius:5px;padding:5px;">Rotate</button></p>
                                    </div>

                                </div>
        </div>

    </div>

         <script src="<?php echo base_url(); ?>/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
         <script src="<?php echo base_url(); ?>/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>
         <!--<script src="js/app.js"></script>-->
<!-- <script src="DataTables/media/js/app.js"></script> -->
        <script>

function mouseUp(){
var x = document.getElementById("spare").checked;

    if(x==true){
        document.getElementById("axlepick").disabled = true;
        document.getElementById("position").disabled = true;
    }
    else{
        document.getElementById("axlepick").disabled = false;
        document.getElementById("position").disabled = false;
    }

}

function getposition(){
    var getpos=$('#axlepick').val();
      var vehpos=$('#vehiclenm').val();

         $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                getvehpos : 1,
                vehiclep:vehpos,
                axlepos : getpos
            },
            success : function (rec){
                 $("#getpo").html(rec);

            }
        });
}

function getrotposition(){
    var getrotpos=$('#axlerot').val();
    var vehrotpos=$('#vehiclenam').val();

       $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                getvehrotpos : 1,
                vehiclerotp :vehrotpos,
                axleposrot : getrotpos
            },
            success : function (rec){
                 $("#getrotposs").html(rec);

            }
        });

}

function passedid(){
    var checkpass=$('#tyreserial').val();

    if(checkpass!=""){
        document.getElementById("vehiclenm").value=$('#vehnam').val();

         var vehaxle=$('#vehiclenm').val();

         $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                getvehaxle : 1,
                vehiclea :vehaxle
            },
            success : function (rec){
                 $("#getax").html(rec);

            }
        });

    }

}


   $(document).ready(function(){

    passedid();

     $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                tyre : 1
            },
            success : function (rec){
                 $("#assetsearch").html(rec);
                 $('#vehavail').dataTable( );


            }
        });

     $('#vehnam').focus(function(){
        $.get("<?php echo base_url(); ?>/assignment/suggest.php",{},function(data){

            $("datalist").empty();
            $("datalist").html(data);

        });
     });



$('#rotate').hide();
$('#mounted').hide();
$('#avail').fadeIn(1050);
$('#toggle-mounted').click(function(){
    $('#toggle-avail').removeClass('active');
    $('#toggle-mounted').addClass('active');
    $('#toggle-rotate').removeClass('active');
    $('#avail').fadeOut(1);
    $('#rotate').fadeOut(1);
    $('#listrotate').fadeOut(1);
    $('#listmounting').show();
    $('#mounted').fadeIn(1050);
});
$('#toggle-avail').click(function() {
    $('#toggle-mounted').removeClass('active');
    $('#toggle-rotate').removeClass('active');
    $('#toggle-avail').addClass('active');
    $('#mounted').fadeOut(1);
    $('#rotate').fadeOut(1);
    $('#listrotate').fadeOut(1);
     $('#listmounting').show();
    $('#avail').fadeIn(1050);
});
$('#toggle-rotate').click(function() {
    $('#toggle-rotate').addClass('active');
    $('#toggle-mounted').removeClass('active');
    $('#toggle-avail').removeClass('active');
    $('#rotate').fadeIn(1050);
    $('#mounted').fadeOut(1);
    $('#listmounting').fadeOut(1);
     $('#listrotate').show();
    $('#avail').fadeOut(1);
});
});




function gettyres(){
        $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                tyre : 1
            },
            success : function (rec){
                 $("#assetsearch").html(rec);
                 $('#vehavail').dataTable( );

            }
        });

}

function getmounted(){
    var inputm = $('#vehnam').val();
        $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                mountdet : 1,
                assmount : inputm
            },
            success : function (rec){
                 $("#assetmounted").html(rec);
                 $('#vehdismount').dataTable( );

            }
        });

}

function getrotate(){
    var inputr = $('#vehnam').val();
        $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                rotatedet : 1,
                assrotat : inputr
            },
            success : function (rec){
                 $("#assetrotated").html(rec);
                 $('#vehrotate').dataTable( );

            }
        });

}

function getview(){
    var inputss = $('#vehnam').val();
     $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                viewass : 1,
                assnm : inputss
            },
            success : function (rec){
                $('#assetview').html(rec);
            }
        });
}


function enterpressalert(){
 //Enter keycode
 var inputs = $('#vehnam').val();


        $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                viewass : 1,
                assnm : inputs
            },
            success : function (rec){
                $('#assetview').html(rec);
                gettyres();
                getmounted();
                getrotate();
                passedid();
                $('#vehavail').dataTable( );
                $('#vehdismount').dataTable( );
                $('#vehrotate').dataTable( );
                $('#tyredetails').show();
                $('#completion').show();
            }
        });
}

function mounting(){



    $('body').delegate('.mount','click', function(){
        document.getElementById("vehiclenm").value=$('#vehnam').val();
        document.getElementById("tyreidnos").value = $(this).attr('idmtid');
        document.getElementById("tyreserial").value = $(this).attr('idms');

         var vehaxle=$('#vehiclenm').val();

         $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                getvehaxle : 1,
                vehiclea :vehaxle
            },
            success : function (rec){
                 $("#getax").html(rec);

            }
        });



    $('#listmounting').show();


    });


}



function assign(){
    var name=$('#vehiclenm').val();
    var tidnos=$('#tyreidnos').val();
    var tser=$('#tyreserial').val();
    var axlepik=$('#axlepick').val();
    var tpos=$('#position').val();
    var comid=$('#comid').val();
    var uid=$('#userid').val();
    var odo=$('#odometer').val();
    var x = document.getElementById("spare").checked;

        swal({
  title: "Confirm",
  text: "Mount the tyre!",
  type: "info",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Mount",
  closeOnConfirm: false
},
function(){
    if(x==true){
    if(name==""){
    swal({   title: "Error!",   text: "No Vehicle Selected",   type: "error",   confirmButtonText: "Change" });

    }
    else if(odo<=0){
        swal({   title: "Error!",   text: "No Odometer Reading Input",   type: "error",   confirmButtonText: "Change" });
    }
        else{
    var sparet=$('#spare').val();
    var noax=0;
    var notpos=0;
           swal({
          title: "Confirm",
          text: "Mount tyre as spare!",
          type: "info",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Mount",
          closeOnConfirm: false
        },
        function(){

            $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                mountspare : 1,
                assname : name,
                tyreid : tidnos,
                axlenone :noax,
                tyrepos :notpos,
                cid : comid,
                usid : uid,
                tserr : tser,
                odomt : odo,
                tspare : sparet
            },
            success : function (rec){
                 swal({   title: "info!",   text:rec,   type: "info",   confirmButtonText: "Ok" });
                gettyres();
                getmounted();
                getrotate();
                getview();

            }
        });
        });
       }
    }
    else{
        if(name==""){
        swal({   title: "Error!",   text: "No Vehicle Selected",   type: "error",   confirmButtonText: "Change" });

    }
    else if(odo<=0){
        swal({   title: "Error!",   text: "No Odometer Reading Input",   type: "error",   confirmButtonText: "Change" });
    }
    else if(axlepik==""){
        swal({   title: "Error!",   text: "No Axle Selected",   type: "error",   confirmButtonText: "Change" });

    }
    else if(tpos==""){
        swal({   title: "Error!",   text: "No Tyre Position Selected",   type: "error",   confirmButtonText: "Change" });
    }
else{
             $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                mountass : 1,
                assname : name,
                tyreid : tidnos,
                axledet : axlepik,
                tyrepos : tpos,
                cid : comid,
                usid : uid,
                tserr: tser,
                odomt : odo
            },
            success : function (rec){
                 swal({   title: "info!",   text:rec,   type: "info",   confirmButtonText: "Ok" });
                gettyres();
                getmounted();
                getrotate();
                getview();

            }
        });

            }
    }
});




}

function dismounting(){
       $('body').delegate('.dis','click', function(){
        var disveh=$(this).attr('dassetid');
        var atmsid = $(this).attr('idtms');
        var atyreid = $(this).attr('idtid');


        swal({
  title: "Confirm",
  text: "Dismount the tyre!",
  type: "info",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Dismount",
  closeOnConfirm: false
},
function(){

    swal({
     title: "Odometer Reading",
     text: "Enter Odometer Reading:",
     type: "input",
     showCancelButton: true,
     closeOnConfirm: false,
     animation: "slide-from-top",
     inputPlaceholder: "Write odometer reading in numbers,no decimals eg.1888" },
     function(inputValue){
        if (inputValue === false)
         return false;
        if (inputValue < 0) {
           swal.showInputError("Write value greater than 1");
            return false   }

             if (isNaN(inputValue)) {
           swal.showInputError("Write in numbers");
            return false   }

            $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                dismountass : 1,
                asstms : atmsid,
                asstyre : atyreid,
                assetid : disveh,
                ododis : inputValue
            },
            success : function (rec){
                 swal({   title: "info!",   text:rec,   type: "info",   confirmButtonText: "Ok" });
                getmounted();
                gettyres();
                getrotate();
                getview();

            }
        });
 });




});
    });



}

function rotation(){

    $('body').delegate('.rotat','click', function(){

    document.getElementById("vehiclenam").value=$('#vehnam').val();
    document.getElementById("tmsidnum").value=$(this).attr('idtmsid');
    document.getElementById("tidnum").value=$(this).attr('idtyreid');
    document.getElementById("tyreseriall").value=$(this).attr('idts');
    document.getElementById("olda").value=$(this).attr('idaxle');
    document.getElementById("oldp").value=$(this).attr('idpos');


    var vehrotaxle=$('#vehiclenam').val();

         $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                getvehrotaxle : 1,
                vehiclerota :vehrotaxle
            },
            success : function (rec){
                 $("#getrotax").html(rec);

            }
        });


    $('#listrotate').show();

    });

}

function rot(){
    var vname=$('#vehiclenam').val();
    var tmsnos=$('#tmsidnum').val();
    var trid=$('#tidnum').val();
    var tserl=$('#tyreseriall').val();
    var taxle=$('#axlerot').val();
    var tposrot=$('#posrot').val();
    var oldax=$('#olda').val();
    var oldpo=$('#oldp').val();

    if(vname==""){
        swal({   title: "Error!",   text: "No Vehicle Selected",   type: "error",   confirmButtonText: "Change" });

    }
    else if(taxle==""){
        swal({   title: "Error!",   text: "No Axle Selected",   type: "error",   confirmButtonText: "Change" });

    }
    else if(tposrot==""){
        swal({   title: "Error!",   text: "No Tyre Position Selected",   type: "error",   confirmButtonText: "Change" });
    }
else{
             $.ajax({
            url : '<?php echo base_url(); ?>/assignment/mountajax.php',
            type : 'POST',
            data : {
                rotateass : 1,
                vehname : vname,
                tmsnum : tmsnos,
                tnum : trid,
                tsernum : tserl,
                txlenum : taxle,
                tposnum : tposrot,
                tolda :oldax,
                toldp :oldpo
            },
            success : function (rec){
                 swal({   title: "info!",   text:rec,   type: "info",   confirmButtonText: "Ok" });
                gettyres();
                getmounted();
                getrotate();
                getview();


            }
        });

            }

}

function complete(){
    document.location.href='<?php echo base_url(); ?>/application/modules/tms/views/assign_tyre.php';
}

//  $(document).ready(function(){
// $('#vehavail').dataTable( );
// });
        </script>

</div>


