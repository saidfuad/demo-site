<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('tms/add_tyre').""; ?>" class="btn btn-primary btn-xsm">
                <i class="fa fa-plus"></i>
                Add Tyre
            </a>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($inventory)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Serial Number</th>
                                <th>Custom Type</th>
                                <th>Manufacturer</th>
                                <th>Assigned</th>
                                <th>Tyre Condition</th>
                                <th>Current Tread Depth</th>
                                <th>Mileage Remaining(KM)</th>
                                <th>Action</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php foreach ($inventory as $key => $value) { ?>
                           <tr class="gradeU" style="text-transform: capitalize">
                                <td><?php echo $value->tyre_id; ?></td>
                                <td><?php echo $value->custom_tyre_name; ?></td>
                                <td><?php echo $value->name; ?></td>
                                <td>
                                    <?php if($value->assets_friendly_nm == null){
                                        echo"<a href='assign_tyre?id=$value->tyre_id' id='goto_assign' data-placement='top' data-toggle='tooltip' data-original-title='click to assign' class='btn btn-info btn-xs'>click to assign</a>";
                                    }else{
                                      echo $value->assets_friendly_nm;
                                    } ?>
                                </td>
                                <td><?php echo $value->status_type_name; ?></td>
                                <td><?php echo $value->current_tread_depth.' / 32"'; ?></td>
                                <td><?php echo ($value->mileage_est - $value->mileage_covered); ?></td>
                                <td>
                                    <?php echo "<a data-placement='top' data-original-title='More Details'
                                            class='btn btn-info btn-xs tyre-li'
                                            attr-tyre-id='$value->tyre_id'
                                            attr-tyre-manufacturer-id=' $value->name'
                                            attr-manufacturer-logo='$value->logo'
                                            attr-tyre-load-rate='$value->load_rating'
                                            attr-tyre-speed-symbol='$value->speed_symbol'
                                            attr-tyre-speed-rate='$value->kmh'
                                            attr-tyre-rotation='$value->rotation'
                                            attr-tyre-rime-size='$value->rim_size'
                                            attr-tyre-width='$value->tyre_width'
                                            attr-tyre-profile='$value->tyre_profile'>view details <span class='fa fa-eye'></span></a>
                                            <a data-placement='top' data-toggle='tooltip' data-original-title='Edit Tyre'  href='".base_url('index.php/tms/edit_tyre/'.$value->tyre_id)
                                            ."'class='btn btn-success btn-xs'>edit tyre <span class='fa fa-pencil'></span></a>"?></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>

            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Tyres</h2>
                    <br>
                    <p>Manage Tyres and begin monitoring your tyres Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

                    <a href="<?php echo site_url('tms/add_tyre');?>" class="btn btn-success">Add Tyres</a>
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>

<div class="panel-diagnostics" id="panel-diagnostics">
    <div class="panel-heading">
        <span>Tyre Details</span>
        <span class="close cx" id="close-pd"><b>&times;</b></span>
    </div>
    <div class="row vinfo-area">
        <div class="col-md-12 col-sm-12">

            <div class="col-md-4 top-info-div">
            <!-- User Card Mini - Right Profile Image -->
                <div class="user-card-mini row bgf5" style="height:230px; text-align: center">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div id='tag-logo'></div>
                        <b><div id="tag-manufacturer"></div>Tyre<br></b>
                    </div>
                </div>
            </div>
                    
            <div class="col-md-5 top-info-div">
            <!-- User Card Mini - Right Profile Image -->
                <div class="user-card-mini row bgf5" style="height:230px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="tyre" id='tyre-image'></div>
                        <input type="text" class="tyre_width" disabled="disabled">
                        <input type="text" class="tyre_profile" disabled="disabled">
                        <input type="text" class="rim_size" disabled="disabled">
                        <input type="text" class="load_rating" disabled="disabled">
                        <input type="text" class="speed_rating_sym" disabled="disabled">

                    </div>
                </div>
            </div>

            <div class="col-md-3 top-info-div">
            <!-- User Card Mini - Right Profile Image -->
                <div class="user-card-mini row bgf5" style="height:230px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        Serial No.: <i style="float:right" id="panel-tyre-id"></i><br>
                        <legend></legend>
                        Tyre Width: <i style="float:right" id="tag-tyre-width"></i><br>
                        Tyre Profile: <i style="float:right" id="tag-tyre-profile"></i><br>
                        Rim Size: <i style="float:right" id="tag-rim-size"></i><br>
                        <legend></legend>
                        Speed Rating: <i style="float:right" id="tag-speed-symbol"></i><br>
                        Load Rating: <i style="float:right" id="tag-load-rating"></i><br>
                        Tyre Rotation: <i style="float:right" id="tag-rotation"></i><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
</div>

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script type="text/javascript">
    $(function () {

        $('.tyre-li').on('click', function () {
            
            $('#bg-vehicle-area').html('');
            $('#panel-diagnostics').fadeOut(500);
            $('#panel-diagnostics').fadeIn(1000);
            $('.overshadow').fadeIn(1000);
            $('#bg-vehicle-area').html('');

            var tyre_id = $(this).attr('attr-tyre-id');
            var manufacturer = $(this).attr('attr-tyre-manufacturer-id');
            var logo = $(this).attr('attr-manufacturer-logo');
            var tyre_load_rate = $(this).attr('attr-tyre-load-rate');
            var tyre_speed_rate = $(this).attr('attr-tyre-speed-rate');
            var tyre_speed_rate_sym = $(this).attr('attr-tyre-speed-symbol');
            var tyre_rotation_rate = $(this).attr('attr-tyre-rotation');
            var tyre_rim_size = $(this).attr('attr-tyre-rime-size');
            var tyre_profile = $(this).attr('attr-tyre-profile');
            var tyre_width = $(this).attr('attr-tyre-width');

            $(".tyre_profile").val(tyre_profile);
            $(".tyre_width").val(tyre_width);
            $(".rim_size").val(tyre_rim_size);
            $(".load_rating").val(tyre_load_rate);
            $(".speed_rating_sym").val(tyre_speed_rate_sym);

            $('#panel-tyre-id').html(tyre_id);
            $('#tag-manufacturer').html(manufacturer);
            //$('#tag-logo').html(logo);

            var elem1 = document.createElement("img");
            document.getElementById("tag-logo").appendChild(elem1);
            elem1.src = '<?=base_url('assets/images/itms/tms/tyre_brands')?>'+ "/" +logo;
            elem1.setAttribute("height", "160");
            elem1.setAttribute("width", "160");

            var elem2 = document.createElement("img");
            document.getElementById("tyre-image").appendChild(elem2);
            elem2.src = '<?=base_url('assets/images/itms/tms/tyre_brands/tyre-size-graphic.png')?>';
            elem2.setAttribute("height", "180");
            elem2.setAttribute("width", "300");

            $('#tag-tyre-width').html(tyre_width);
            $('#tag-tyre-profile').html(tyre_profile);
            $('#tag-rim-size').html(tyre_rim_size);
            $('#tag-load-rating').html(tyre_load_rate);
            $('#tag-speed-rating').html(tyre_speed_rate);
            $('#tag-speed-symbol').html(tyre_speed_rate_sym);
            $('#tag-rotation').html(tyre_rotation_rate);
      });

      $('.close').on('click', function () {

          //alert(completePattern.length);
          //Display the panel if above conditions have been met.
          $('#panel-diagnostics').fadeIn(500);
          $('#panel-diagnostics').fadeOut(1000);
          $('.overshadow').fadeOut(1000);
          $('#bg-vehicle-area').html('');
          $('#tag-logo').html('');
          $('#tyre-image').html('');
          
    });


});
</script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });

   // $('a').tooltip();
</script>
