<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('tms/add_tyre').""; ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                Add Tyre
            </a>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($tyres)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Serial Number</th>
                                <th>Custom tyre name</th>
                                <th>Manufacturer</th>
                                <th>Tyre Status</th>
                                <th>Tyre Price</th>
                                <th>Tyre Mileage</th>
                                <th>Remaining Mileage</th>
                                <th>Purchase Date</th>
                                <th>Action</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php foreach ($tyres as $key => $value) { ?>
                           <tr class="gradeU" style="text-transform: capitalize">
                                <td><?php echo $value->serial_number; ?></td>
                                <td><?php echo $value->custom_tyre_name; ?></td>
                                <td><?php echo $value->name; ?></td>
                                <td><?php echo $value->status_type_name; ?></td>
                                <td><?php echo $value->tyre_price; ?></td>
                                <td><?php echo $value->mileage_est." KM"; ?></td>
                                <td><?php echo $value->mileage_est - $value->mileage_covered." KM"; ?></td>
                                <td><?php echo $value->purchase_date; ?></td>

                                <td><?php echo "<a data-placement='top' data-toggle='tooltip' data-original-title='Edit Tyre'  href='".base_url('index.php/tms/edit_tyre/'.$value->serial_number)
                                                ."'class='btn btn-success btn-xs'>edit tyre <span class='fa fa-pencil'></span></a>"?></td>

                               <!-- <a data-placement='top' data-toggle='tooltip' data-original-title='View Details'  href='".base_url('index.php/tms/fetch_tyre/'.$value->serial_number)
                                                ."'class='btn btn-info btn-xs'>view details <span class='fa fa-eye'></span></a>
                                                -->
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Tyres</h2>
                    <br>
                    <p>Manage tyres details and information. Assign tyres to assets, track tyre positions on vehicles, mileage covered and insepctions.</p>

                    <a href="<?php echo site_url('tms/add_tyre');?>" class="btn btn-success">Add Tyres</a> 
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });

   // $('a').tooltip();
</script>