<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-tyre-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Edit Tyre Details
	                </div>
	                <div class="panel-body">
	                    
                        <input class="form-control" type="hidden" name="id" id="id" value="<?php echo $tyre['id']; ?>" />

	                    <div class="form-group">
	                    	<label class="control-lable">Serial No.: </label>
							<input class="form-control" type="text" name="serial_number" id="serial_number" value="<?php echo $tyre['serial_number']; ?>" />
	                    </div>
	                   	                    	                    
	                    <div class="form-group">
	                    	<input id="tyre_type_id" name="tyre_type_id" hidden="true" value="<?php echo $tyre['tyre_type_id']; ?>" />
	                    	<label class="control-lable">Custom Tyre Type: </label>
							<input id="tyre_type" class="form-control" value="<?php echo $tyre['custom_tyre_name']; ?>"/>

							<a style="float: right; margin-top: -28px; margin-right: 5px" href="<?php echo site_url('tms/create_custom_tyre');?>" class='btn btn-success btn-xs'>New Custom Tyre
								<span class='fa fa-plus'></span>
							</a>

							<div class="custom_tyre_holder" style="border-radius: 5px;">
							    <ul id="custom-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_custom_tyres == null) 
							    	{	
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Custom Tyres Found</li>";
							    		
							        // echo $value->driver_name;
						    	} else{
							    foreach($all_custom_tyres as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='custom_tyresClicked(this.id,this.title)' class='custom_tyres' id='" . $row['custom_tyre_id'] . "'
							        title='".$row['custom_tyre_name'] . "'>" . $row['custom_tyre_name'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>
							
							$('#tyre_type').on('focus', function(){
								$('.tyre_status_holder').hide();
							});

                            $('#tyre_type').on('keydown', function(){
								$('#custom-list').show();
								$('.custom_tyre_holder').show();
							});

							$('#tyre_type').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#tyre_type_id").val("");
                                    $('.custom_tyre_holder').hide();
							    }

							    $('#custom-list').show();
							    $("#custom-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function custom_tyresClicked(tyre_type,value) {
                                $("#tyre_type").val(value);
							    $("#tyre_type_id").val(tyre_type);
							    //$("#assets_type").focus();
							    $('#custom-list').hide();
							}
							</script>

	                    </div>

	                    <div class="form-group">
	                    	<input id="tyre_status_type_id" name="tyre_status_type_id" hidden="true" value="<?php echo $tyre['tyre_status_type_id']; ?>" />
	                    	<label class="control-lable">Tyre Type: </label>
							<input id="status_type_name" class="form-control" value="<?php echo $tyre['status_type_name']; ?>"/>

							<div class="tyre_status_holder" style="border-radius: 5px;">
							    <ul id="status-list" class="dp-down" style="display:none; padding-top: 4px; padding-right: 1px; width: 91%; overflow: hidden; cursor: pointer">

							    <?php
							    if ( $all_tyre_status_types == null) 
							    	{	
							    		echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Custom Tyres Found</li>";
							    		
							        // echo $value->driver_name;
						    	} else{
							    foreach($all_tyre_status_types as $key => $row) {
							        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='statusClicked(this.id,this.title)' class='status' id='" . $row['tyres_status_type_id'] . "'
							        title='".$row['status_type_name'] . "'>" . $row['status_type_name'] . "</li>";
							        }
							    }
							    ?>
							    </ul>
							</div>
							<script>
							
							$('#status_type_name').on('focus', function(){
								$('.custom_tyre_holder').hide();
							});

                            $('#status_type_name').on('keydown', function(){
								$('#status-list').show();
								$('.tyre_status_holder').show();
							});

							$('#status_type_name').on('keyup', function () {
							    var value = $(this).val().trim();

							    if (value.length == 0) {
									$("#tyre_status_type_id").val("");
                                    $('.tyre_status_holder').hide();
							    }

							    $('#status-list').show();
							    $("#status-list >li").each(function () {
							        if($(this).text().toLowerCase().search(value) > -1) {
							            $(this).show();
							        }
							        else {
							            $(this).hide();
							        }
							    });
							});

							function statusClicked(status_type,value) {
                                $("#status_type_name").val(value);
							    $("#tyre_status_type_id").val(status_type);
							    //$("#assets_type").focus();
							    $('#status-list').hide();
							}
							</script>

	                    </div>
	                 
	                    <div class="form-group">
	                    	<label class="control-lable">Tyre Price: </label>
							<input id="tyre_price" name="tyre_price" class="form-control" value="<?php echo $tyre['tyre_price']; ?>"/>
						</div>

						<div class="form-group">
	                    	<label class="control-lable">Mileage Estimate: </label>
							<input id="mileage_est" name="mileage_est" class="form-control" value="<?php echo $tyre['mileage_est']; ?>"/>
						</div>

						<div class="form-group">
	                    	<label class="control-lable">Purchase Date: </label>
							<input id="purchase_date" name="purchase_date" class="form-control" value="<?php echo $tyre['purchase_date']; ?>"/>
						</div>

						<div class="form-group">
	                    	<label class="control-lable">Warranty Expiry Date: </label>
							<input id="warranty_expiry" name="warranty_expiry" class="form-control" value="<?php echo $tyre['warranty_expiry']; ?>" />
						</div>

						<script>

	                  		$('#serial_number').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#tyre_price').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#mileage_est').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#purchase_date').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                		$('#warranty_expiry').on('focus', function(){

	                			$('.custom_tyre_holder').hide();
	                			$('.tyre_status_holder').hide();
	                		});

	                	</script>

					</div>
	            </div>

	            <div class="panel-footer" align="right">
	            	<button class="btn btn-primary" type="submit" id="update-tyre">Update</button>
	            </div>
	            
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-users"></i> Tyres</h2>
				<br>
				<p>Manage tyres details and information. Assign tyres to assets, track tyre positions on tyres, mileage covered and insepctions.</p>

				<a href="<?php echo site_url('tms/view_tyres');?>" class="btn btn-success">View Tyres</a>
			</div>
		</div>
    </div>
</div> 

<script src="<?php echo  base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>  

<script>
   $(function () {

            $('#edit-tyre-form').on('submit' , function () {

            	var $this = $(this);

				$('#update-tyre').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-tyre').prop('disabled', true);

               swal({   

                title: "Info",   
                text: "Edit Tyre?",   
                type: "info",   
                showCancelButton: true,   
                closeOnConfirm: false, 
                allowOutsideClick: false,  
                showLoaderOnConfirm: true                            
                }, function(){
                	
	                $.ajax({
	                    method: 'post',
	                    url: '<?= base_url('index.php/tms/update_tyre') ?>',
	                    data: $this.serialize(),
                        success: function (response) {
                        	
                        	if (response == 1) {
	                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
	                        } else {
	                        	swal({   title: "Error",   text: "Failed to Update, Try again later",   type: "error",   confirmButtonText: "ok" });
	                        } 
	                        $('#update-tyre').html('Update');
	                		$('#update-tyre').prop('disabled', false);
	                     }
	                });
	                });

                $('#update-tyre').html('Update');
	            $('#update-tyre').prop('disabled', false);
                
                return false;     
            });
        });     
</script>
