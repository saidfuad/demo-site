<?php 

class Mdl_zones extends CI_Model{


	function get_zones ($company_id = null) {
		if($company_id != null) {
			$this->db->where('company_id', $company_id);
		}

		$this->db->where('status', 1);
		$this->db->where('del_date', NULL);

		$query = $this->db->get('itms_zones');

		return $query->result();
	}

	function get_vertices ($company_id = null) {
		if($company_id != null) {
			$this->db->where('company_id', $company_id);
		}

		$query = $this->db->get('itms_zones_vertices');

		return $query->result();
	}

	public function save_zone ($company_id, $data, $vertices) {

		if ($this->db->insert('itms_zones', $data)) {
			$zone_id = $this->db->insert_id();
			$res_vertices = $this->save_zone_vertices ($company_id, $zone_id, $vertices);

			if (!$res_vertices) {
				$this->db->delete('itms_zones', array('zone_id'=>$zone_id));

				$res = false;
			} else {
				$res = true;
			}
		} else {
			$res = false;
		}

		return $res;

	}

	public function save_zone_vertices ($company_id, $zone_id, $vertices) {
        $cordinates = array();
        foreach ($vertices as $key => $vertex) {
        	$vertex = str_replace("(","",$vertex);
        	$vertex = str_replace(")","",$vertex);

        	$data = array();
        	$cords = explode(',', $vertex);
        	$data['zone_id'] = $zone_id;
        	$data['company_id'] = $company_id;
        	$data['latitude'] = $cords[0];
        	$data['longitude'] = $cords[1];

        	array_push($cordinates, $data);
        }

        $values = '';
        //$add_uid = $this->session->userdata('user_id');

        foreach ($cordinates as $key => $cords) {
        	$values [] = "('".$cords['company_id']."', '".$cords['zone_id']."', '".$cords['latitude']."', '".$cords['longitude']."')";
        }

        $values = implode(',',$values);

        $res = $this->db->query("INSERT INTO itms_zones_vertices (company_id, zone_id, latitude, longitude) VALUES $values");

        return $res;


    }

    public function update_zone($data){

        $this->db->where('zone_id', $data['zone_id']);
        $query = $this->db->update('itms_zones', $data);

        if($query){
            echo 1;
        };
    }
	
}

?>
