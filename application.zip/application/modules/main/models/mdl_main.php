<?php

class Mdl_main extends CI_Model {

    function __construct() {
        parent::__construct();

        $this->user_id = $this->session->userdata('itms_user_id');
        $this->current_time = date("Y-m-d H:i:s");
    }

    function fetch_alerts($company_id = null, $viewed = null, $limit = null) {

        if ($company_id != null) {
            // $this->db->where('itms_alert_master.company_id', $company_id);
        }

        $current_user_id = $this->session->userdata('itms_userid');

        $whereUser = '';
        $limit = '';
        $viewed = '';

        if ($viewed != null) {
            $viewed = " AND viewed = $viewed ";
        }

        if ($limit != null) {
            $limit = " LIMIT 0," . $limit;
        }



        $query = $this->db->query("SELECT itms_alert_master.*, itms_assets.asset_id, itms_assets.assets_friendly_nm, itms_assets.assets_name, 
                                    CONCAT(itms_personnel_master.fname, ' ', itms_personnel_master.lname) as driver_name, itms_personnel_master.phone_no as driver_phone
                                    FROM 
                                        itms_alert_master
                                    LEFT JOIN itms_assets LEFT JOIN itms_personnel_master ON (itms_assets.personnel_id=itms_personnel_master.personnel_id) ON (itms_assets.asset_id=itms_alert_master.asset_id) 
                                    WHERE 
                                        itms_alert_master.del_date is null
                                    AND 
                                        itms_alert_master.company_id = $company_id
                                    AND 
                                        FIND_IN_SET(itms_alert_master.asset_id, (select group_concat(asset_id) from itms_alerts_contacts where user_id='$current_user_id'))
                                    {$viewed}
                                    OR 
                                        FIND_IN_SET(itms_assets.assets_group_id, (select group_concat(assets_group_id) from itms_assigned_groups where user_id='$current_user_id'))
                                    OR  
                                        FIND_IN_SET(itms_alert_master.asset_id, (select group_concat(asset_id) from itms_alerts_contacts where user_id='$current_user_id'))
                                    ORDER BY 
                                        id DESC {$limit}");

        return $query->result();
    }

    function update_pops($results) {
        $ids = implode(',', $results);

        $query = $this->db->query("UPDATE itms_alert_master SET pop_shown = 1 WHERE id IN ($ids)");
    }

    function fetch_report_vehicles($company_id = null) {
        $this->db->select('itms_assets.asset_id,itms_assets.assets_name,itms_assets.assets_friendly_nm');
        $this->db->from('itms_assets')
                ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
                ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
                ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
                ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');


        if ($this->session->userdata('protocal') <= 7 && $company_id != null) {
            $this->db->where('itms_assets.company_id', $company_id);
            $this->db->where('itms_assets.del_date IS NULL');
        }

        if ($this->session->userdata('protocal') < 7) {
            //$this->db->where('itms_assets.');
        }


        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    function fetch_report_dealers() {
        $this->db->select('dealer_id,dealer_name');
        $this->db->from('itms_dealer_master')
                ->where('company_id', $this->session->userdata('itms_company_id'));
        $this->db->order_by('dealer_name', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    function fetch_report_owners() {
        $this->db->select('owner_id,owner_name');
        $this->db->from('itms_owner_master')
                ->where('company_id', $this->session->userdata('itms_company_id'));
        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    function fetch_report_types() {
        $this->db->select('itms_reports.*');
        $this->db->from('itms_reports')
                ->join('itms_report_permissions', 'itms_reports.report_id = itms_report_permissions.report_id');
        $this->db->where('itms_report_permissions.user_id', $this->session->userdata('user_id'));

        $this->db->order_by('report_name', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    function fetch_drivers() {
        $this->db->select('ipm.personnel_id,ipm.fname,ipm.lname');
        $this->db->from('itms_personnel_master ipm')
                ->join('itms_roles ir', 'ipm.role_id = ir.role_id');
        $this->db->where('ipm.company_id', $this->session->userdata('itms_company_id'));

        $this->db->order_by('ipm.fname', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    function fetch_roles() {
        $this->db->select('ir.role_id,ir.role_name');
        $this->db->from('itms_roles ir');
        $this->db->where('ir.company_id', $this->session->userdata('itms_company_id'));

        $this->db->order_by('ir.role_name', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    function fetch_scheduled_reports(){
        $this->db->select("id,isr.report_name ,ir.report_name as report_type_name,daily,weekly,report_type_id,tab_one_ids,tab_two_ids,"
                . " format,schedule");
        $this->db->from('itms_reports_schedule isr');
        $this->db->join('itms_reports ir','ir.report_id = isr.report_type_id');
        $this->db->where('isr.del_date is null');
        $this->db->where('isr.company_id', $this->session->userdata('itms_company_id'));
        $this->db->group_by("isr.id");
        $query = $this->db->get();

        return $query->result();
    }
    
    function fetch_scheduled_report_by_id($id){
        $this->db->select("isr.report_name,email,report_type_id,tab_one_ids,tab_two_ids,"
                . " format,daily,weekly,DATE_FORMAT(start_period,'%d/%m/%Y %H:%i') as start_period,DATE_FORMAT(end_period,'%d/%m/%Y %H:%i') as end_period");
        $this->db->from('itms_reports_schedule isr');
        $this->db->where('isr.del_date IS NULL');
        $this->db->where('isr.company_id', $this->session->userdata('itms_company_id'));
        $this->db->where('isr.id', $id);
        $query = $this->db->get();

        return $query->result();
    }
    
    function fetch_company_subscriptions($company_id){
        
        $query = $this->db->query("SELECT itms_services.* , itms_services_subscriptions.start_date, 												itms_services_subscriptions.expiry_date FROM 																          itms_services_subscriptions
        JOIN  itms_services ON (itms_services_subscriptions.service_id = itms_services.service_id)
        WHERE 1 AND itms_services_subscriptions.company_id = '$company_id'");

        return $query->result(); 
    }
    
    function edit_company_name($data){
        $company_id = $this->session->userdata('itms_company_id');
        $query = $this->db->query("UPDATE itms_companies SET company_name= '".$data."' WHERE company_id='".$company_id."'");
        $this->session->set_userdata('company_name', $data);
        return $query;
    }
    
    function upload_company_logo($data){
        $company_id = $this->session->userdata('itms_company_id');
        $this->db->select('itms_companies.company_logo');
        $this->db->where('company_id', $company_id);
        $res = $this->db->update('itms_companies', $data);
        $this->session->set_userdata('company_logo', $data['company_logo']);
        return $res;
    }
    
    function delete_report_schedule($id){
        $del_uid = $this->session->userdata('itms_user_id');
        $del_date = date("Y-m-d H:i:s");
        $this->db->where('id',$id);
        $this->db->update('itms_reports_schedule',array('del_uid'=>$del_uid,'del_date'=>$del_date));
    }
}

?>