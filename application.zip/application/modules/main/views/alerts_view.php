<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($alerts)) {?>
                <div class="table-responsive">
                    <table class="table table-striped" id="dataTables-example">
                        <thead>
                            <tr>
                                <!--<th>#</th>-->
                                <th>Time</th>
                                <th>Issue</th>
                                <!--<th>Vehicle Name</th>
                                <th>Number Plate</th>
                                <th>Driver Name</th>-->
                                
                                <th width="45%">Alert Message</th>
                                <th width="15%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        $count = 1;
                        foreach ($alerts as $key => $value) { ?>
                           <tr class="gradeU">
                                <!--<td><?php echo $count; ?></td>-->
                                <td><?php echo $value->data_time; ?></td>
                                <td><?php echo $value->alert_header; ?></td>
                                <!--<td><a href="#"><?php echo $value->assets_friendly_nm; ?></a></td>
                                <td><?php echo $value->assets_name; ?></td>
                                <td><?php echo $value->fname .' '. $value->lname; ?></td>-->
                                <td><?php echo $value->alert_msg;  ?></td>
                                <td align="right">
                                    <button class="btn btn-default btn-xs">Location</button>
                                    <!--<button class="btn btn-success btn-xs">Call</button>-->
                                    <button class="btn btn-danger btn-xs">SMS</button>
                                </td>               
                            </tr>
                        <?php 
                            $count++;
                        }?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Status</h2>
                    <br>
                    <p>No Data Available</p> 
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable( {
                "order": [[ 3, "desc" ]]
        });
    });
</script>