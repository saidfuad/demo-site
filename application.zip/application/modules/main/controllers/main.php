<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

    function __construct() {

        parent::__construct();

        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }

        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
            redirect(home);
        }

        $this->load->model('mdl_main');
        $this->load->model('mpdf_main/mdl_reports');
    }

    public function refresh_alerts() {
        $results = $this->mdl_main->fetch_alerts($this->session->userdata('itms_company_id'));

        $this->load->library('timefactory');
        //echo json_encode($results);
        //$data = array('data'=>$results, 'views_not'=>);
        $count = 0;
        $popstu = array();

        //print_r('<pre>');
        //print_r($results);
        //$now = strtotime(date('Y-m-d H:i:s'));

        foreach ($results as $key => $alert) {
            if ($alert->viewed == 0) {
                $count++;
            }

            if ($alert->pop_shown == 0) {
                array_push($popstu, $alert->id);
            }

            $add_date = $alert->add_date;
            $add_unix_date = strtotime($add_date);

            /*$diff = $now - $add_unix_date;

            if ($diff > 86400) {
                $at = date('jS M Y H:i:s', $add_unix_date);
            } else {
                $at = $this->timefactory->secs_to_time($diff);
                $at = $at . 'ago';
            }$alert->add_date = $at; */
            
            //$alert->add_date = $add_unix_date;
            
        }

        if (sizeof($popstu)) {
            $this->mdl_main->update_pops($popstu);
        }

        $data = array('data' => $results, 'views_not' => $count);
        echo json_encode($data);
    }

    public function alerts_view() {
        $alerts = $this->mdl_main->fetch_alerts($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'main/alerts_view';
        $data['fa'] = 'fa fa-fw fa-exclamation-triangle';
        $data['title'] = 'ITMS Africa | Alerts';
        $data['content_title'] = 'Alerts';
        $data['content_subtitle'] = '';
        $data['alerts'] = $alerts;
        $data['content'] = 'main/alerts_view.php';
        $this->load->view('main/main.php', $data);
    }
    
    public function companydetails(){
        
        $data['company_subscriptions'] = $this->mdl_main->fetch_company_subscriptions($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'main/companydetails';
        $data['fa'] = 'fa fa-fw fa-info-circle';
        $data['title'] = 'ITMS Africa | Company Details';
        $data['content_title'] = 'Company Details';
        $data['content_subtitle'] = '';
        $data['content'] = 'main/company_details.php';
        $this->load->view('main/main.php', $data); 
    }
    
    public function edit_company_name(){
        
        $data = $this->input->post('company_name');
        $res = $this->mdl_main->edit_company_name($data);
        echo $res;   
    }
    
    public function upload_company_logo(){
        
        $data = array();
        $data['company_logo'] = ($this->session->userdata('company_logo') != '') ? $this->session->userdata('company_logo') :'user-default.png';
        $result = $this->mdl_main->upload_company_logo($data);
        
        echo $result;
        
    }

}
