<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    function __construct() {

        parent::__construct();

        $this->load->library('user_agent');
        $this->load->library('encrypt');
        $this->load->model('mdl_auth');
        $this->load->model('mdl_sessions');
        $this->load->library('emailsend');
    }

    public function index() {
        $this->load->view('login2');
    }

    public function authenticate() {


        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $encrypted_password = $this->encrypt->encode($password);

        $browser = $this->agent->browser();
        $platform = $this->agent->platform();

        /* $xml = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$this->mdl_sessions->getRealIpAddr());
          $country= $xml->geoplugin_countryName ;
          $city=$xml->geoplugin_city ;
          $lati=$xml->geoplugin_latitude;
          $longi=$xml->geoplugin_longitude;
          $browser=$this->agent->browser();
          $platform=$this->agent->platform();
          $ip = $_SERVER["REMOTE_ADDR"];
         */
        $country = '';
        $city = '';
        $ip = '';
        $browser = '';
        $platform = '';
        $lati = '';
        $longi = '';
        $datanya = array('ip_address' => $ip,
            'country_name' => "$country",
            'city_name' => "$city",
            'os_name' => $platform,
            'device' => $browser,
            'latitude' => $lati,
            'longitude' => $longi,
            'last_login_time' => date("Y-m-d H:i:s"),
            'user_id' => '',
            'add_date' => gmdate("Y-m-d H:i:s"),
            'comments' => '');

        $usernameExists = $this->mdl_auth->check_user_name($username);
        $emailExists = $this->mdl_auth->check_email($username);


        //print_r($emailExists);
        //exit;
        if ($usernameExists) {
            $user_id = $usernameExists['user_id'];
            $company_id = $usernameExists['company_id'];
            $field_name = 'username';
        } else if ($emailExists) {
            $user_id = $emailExists['user_id'];
            $company_id = $emailExists['company_id'];
            $field_name = 'email_address';
        } else {
            $datanya['comments'] = 'Username passed:' . $username;
            unset($datanya['last_login_time']);
            $this->mdl_auth->save_failed($datanya);
            echo json_encode(array('type' => 'error', 'title' => 'Access Denied', 'message' => 'Check username and or password and try again'));
            exit;
        }

        $isValid = false;
        $type = 'error';


        $user = $this->mdl_auth->auth('itms_users', $field_name, 'password', $username, $encrypted_password);

      

        if ($user) {
            if ($this->encrypt->decode($user['password']) == $password) {
                $isValid = true;
                $type = 'success';
            }
        }



        if ($isValid) {


            if ($user['protocal'] != 71) {

                //check if account/subscription has expired
                $validToDate = $this->mdl_auth->checkExpiryDate($user['user_id']);

                if ($validToDate == false) {
                    echo json_encode(array('type' => 'info', 'title' => 'Account Expired', 'message' => 'Your account subscription has expired'));
                    exit;
                }
                //check if user is allowed to access the system on the particular day   
                $validToDay = $this->mdl_auth->checkExpiryDay($user['user_id']);

                if ($validToDay == false) {
                    echo json_encode(array('type' => 'info', 'title' => 'Access Denied', 'message' => 'Sorry You can not access this system on this day. Contact Administrator for more Info'));
                    exit;
                }
            }

            $object_vars = array('user_id',
                'last_name',
                'email_address',
                'mobile_number',
                'first_name',
                'protocal',
                'global_admin',
                'change_password',
                'admin_id',
                'company_name',
                'usertype_id',
                'language',
                'timezone',
                'date_format',
                'menu_view',
                'report_view',
                'time_format',
                'currency_format',
                'language',
                'photo',
                'user_logo',
                'def_dash_view',
                'network_timeout',
                'show_owners',
                'refresh_time',
                'show_divisions',
                'company_name',
                'company_logo',
                'company_address_1',
                'company_address_2',
                'company_tel_1',
                'company_tel_2',
                'company_phone_no_1',
                'company_phone_no_2',
                'company_country_id',
                'company_status',
                'company_latitude',
                'company_longitude'
            );

            //$object_vars = array('user_id', 'last_name', 'first_name', 'global_admin', 'admin_id', 'usertype_id');
            ini_set('session.gc_maxlifetime', 10 * 60 * 60);
            $subsc = $this->mdl_auth->get_company_subscriptions($user['company_id']);
            $_SESSION['itms_userid'] = $user['user_id'];
            //$_SESSION['itms_user_id'] = $user['user_id'];
            $_SESSION['itms_protocal'] = $user['protocal'];
            $_SESSION['itms_company_id'] = $user['company_id'];
            $_SESSION['itms_company_subscriptions'] = $subsc['subscribed_services'];
            $_SESSION['itms_menu_permissions'] = $user['itms_menu_permissions'];
            $_SESSION['itms_current_city'] = (string) $city;
            $_SESSION['itms_current_country'] = (string) $country;



            $this->mdl_auth->set_session($user, $object_vars, array('openChatBoxes' => array(), 'is_admin' => TRUE, 'username' => $this->input->post('username')));
            $this->session->set_userdata('language', 'english');

            $this->mdl_auth->update_timestamp('itms_users', 'user_id', $user['user_id'], 'last_login', time());

            $new_session_data = array();
            //get last login time and set session data
            $sys_user_id = $this->session->userdata('user_id');

            $datanya['user_id'] = $sys_user_id;

            $new_session_data["sys_info_id"] = $this->mdl_auth->save($datanya);
            //save last insert id in session variable.
            $this->session->set_userdata('sys_info_id', $new_session_data['sys_info_id']);

            $SQL1 = "SELECT last_login_time FROM sys_information WHERE user_id = " . $this->session->userdata('user_id') . " order by add_date desc limit 1";
            $query1 = $this->db->query($SQL1);
            $i = 0;
            $row = $query1->row_array();

            $new_session_data['last_login_time'] = $row['last_login_time'];


            $this->session->set_userdata('last_login_time', $new_session_data['last_login_time']);


            if ($this->session->userdata('itms_protocal') == 71) {
                echo json_encode(array('type' => 'success', 'title' => 'Success', 'message' => 'redirect_admin'));
            } else if ($this->session->userdata('itms_protocal') <= 7) {
                if ($this->session->userdata('username') == "fso7137") {
                    echo json_encode(array('type' => 'success', 'title' => 'Success', 'message' => 'redirect_rfid'));
                } else if (in_array(4, explode(',',$this->session->userdata('itms_menu_permissions')))) {
                    echo json_encode(array('type' => 'success', 'title' => 'Success', 'message' => 'redirect_gps'));
                } else {
                     echo json_encode(array('type' => 'success', 'title' => 'Success', 'message' => 'redirect_home'));
                }
            }
        } else {
            $datanya['comments'] = 'Username passed:' . $username . 'and company_id: ' . $company_id;
            unset($datanya['last_login_time']);
            $this->mdl_auth->save_failed($datanya);
            echo json_encode(array('type' => 'error', 'title' => 'Access Denied', 'message' => 'Check username and or password and try again'));
            exit;
        }
    }

    function logout() {

        $last_login_time = '';
        $sys_id = $this->session->userdata('sys_info_id');
        $date = date("Y-m-d");
        $startDate = date("Y-m-d H:i:s");

        $SQL1 = "SELECT last_login_time FROM sys_information WHERE id ='" . $this->session->userdata('sys_info_id') . "'";
        $query1 = $this->db->query($SQL1);

        if ($query1->num_rows() > 0) {
            $i = 0;
            $row = $query1->result();
            $endDate = $row[0]->last_login_time;
            $diff_time = strtotime($startDate) - strtotime($endDate);

            $datanya = array('last_login_time' => $endDate, 'last_logout_time' => $startDate, 'duration_of_stay' => $diff_time);

            $this->mdl_auth->update_sys_info($sys_id, $datanya);
        }

        $this->session->sess_destroy();
        redirect('login');
    }
    
    function reset_password(){
        $this->load->view('reset');
    }
    
    function reset(){
        
        $email = $this->input->post('email');
        $emailExists = $this->mdl_auth->check_email($email);
        
        if ($emailExists) {
            
            $user_id = $emailExists['user_id'];
            $company_id = $emailExists['company_id'];
            
            $new_pass = uniqid();
            $encrypted_password = $this->encrypt->encode($new_pass);
            
            $data['user_id'] = $user_id;
            $data['company_id'] = $company_id;
            $data['password'] = $encrypted_password;
            
            $pass_reset = $this->mdl_auth->reset_password($data);
            
            if($pass_reset) {
                
                $new_password = $new_pass;
                $email_recipient = $email;
                $email_alert = $this->pass_reset_alert ($email_recipient, $new_password);
                
                echo 1;
            }   
            
        } else {
            echo -1;
        }  
    }
    
    function pass_reset_alert ($email_recipient, $new_password) {

        $to = array($email_recipient);
        $subj = "ITMS Company - User Password Reset";
        $url = "http://178.63.90.134/itmsafrica/assets/images/system/logo1.png";
        
        $message = '<div class="" style="margin-left:100px;width:500px; position:fixed; top:100px; left:30%;background:#f5f5f5;">
                        <div style="background:#101010;border-bottom:6px solid #18bc9c;padding:10px;text-align: center;">
                            <h1><img src="'.$url.'"></h1>
                        </div>
                        <div style="padding:20px;">
                            Dear User,<br><br>
                            Your ITMS user password has been reset.
                            You can access your account with your new login details below.
                            <br>
                            <br>
                            New Login Details<br>
                            Email : ' . $email_recipient . '<br>
                            Password: ' . $new_password . ' <br>
                            <br>
                            <br>
                            Verify carefully the Company information.
                            <br>
                            In case of any doubts, please feel free to contact ITMS Registrar.<br>
                            <a href="#">ITMSLive16@gmail.com</a> on or <a href="#">+254 (0)729 220 777</a>
                            <br>                        
                        </div>
                    </div>';

        return $this->send_email_message ($to, $subj, $message);
    }
    
    function send_email_message ($to, $subj, $message) {
        return $this->emailsend->send_email_message ($to, $subj, $message);
    }

}
