<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Consignments extends CI_Controller {

    function __construct() {

        parent::__construct();

        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }

        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
            redirect('home');
        }

        $this->load->model('mdl_consignments');
    }

    public function index() {

        $data['consignments'] = $this->mdl_consignments->get_all_consignments($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'consignments';
        $data['fa'] = 'fa fa-suitcase';
        $data['title'] = 'ITMS Africa | Consignments';
        $data['content_title'] = 'Consignments';
        $data['content_subtitle'] = '';
        $data['content'] = 'consignments.php';

        $this->load->view('main/main.php', $data);
    }

    public function create_consignment() {

        /* Begin Initialize Map Here */

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;

        /* End */

        $data['content_url'] = 'consignments/create_consignment';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Create Trip';
        $data['content_title'] = 'Create Trip';
        $data['content_subtitle'] = '';
        $data['content'] = 'consignments/create_consignment.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_consignment($consignment_id) {

        /* Begin Initialize Map Here */

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;

        /* End */

        $data['consignment'] = $this->mdl_consignments->get_consignment_by_id($consignment_id, $this->session->userdata('itms_company_id'));

        /*echo "<pre>";
        print_r($data);
        exit;*/

        $data['content_url'] = 'consignments/edit_consignment';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Edit Consignment';
        $data['content_title'] = 'Edit Consignment';
        $data['content_subtitle'] = '';
        $data['content'] = 'consignments/edit_consignment.php';
        $this->load->view('main/main.php', $data);
    }

    public function update_consignment(){
        $data = $this->input->post();

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        $this->mdl_consignments->update_consignment($data);
    }

    public function save_consignment(){

        $data = $this->input->post();

        if($data['consignment_name'] == "" ||
           $data['consignment_amount'] == "" ||
           $data['cargo_weight'] == "" ||
           $data['cargo_rate'] == ""){
            echo 77;
        }else{
            $data['company_id'] = $this->session->userdata('itms_company_id');
            $data['add_uid'] = $this->session->userdata('itms_userid');
            echo $this->mdl_consignments->save_consignment($data);
        }
    }

    public function save_consignee(){

        $data = $this->input->post();

        if($data['consignee_email'] == ""){
            echo 77;
        }elseif($data['consignee_phone_no'] == ""){
            echo 78;
        }else{
            $data['company_id'] = $this->session->userdata('itms_company_id');
            $data['add_uid'] = $this->session->userdata('itms_userid');
            echo $this->mdl_consignments->save_consignee($data);
        }
    }

}
