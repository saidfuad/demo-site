<?php

class Mdl_consignments extends CI_Model{

    function get_all_consignments($company_id=null){

        $this->db->select('itms_consignment_master.*');
		$this->db->from('itms_consignment_master');

		if($company_id != null) {
			$this->db->where('itms_consignment_master.company_id', $company_id);
		}

        //$this->db->where('itms_consignment_master.status', 0);
		$this->db->where('itms_consignment_master.del_date', NULL);
		$query = $this->db->get();

		return $query->result();

    }

    function get_consignments($company_id=null){

        $this->db->select('itms_consignment_master.*');
		$this->db->from('itms_consignment_master');

		if($company_id != null) {
			$this->db->where('itms_consignment_master.company_id', $company_id);
		}

        //$this->db->where('itms_consignment_master.status', 0);
		$this->db->where('itms_consignment_master.del_date', NULL);
		$query = $this->db->get();

		return $query->result_array();

    }

    function get_consignees($company_id=null){

        $this->db->select('itms_consignees_master.*');
		$this->db->from('itms_consignees_master');

		if($company_id != null) {
			$this->db->where('itms_consignees_master.company_id', $company_id);
		}

        $query = $this->db->get();
		return $query->result_array();

    }

    function get_consignment_by_id($consignment_id, $company_id=null){

        $this->db->select('itms_consignment_master.*');
		$this->db->from('itms_consignment_master');

		if($company_id != null) {
			$this->db->where('itms_consignment_master.company_id', $company_id);
		}

        //$this->db->where('itms_consignment_master.status', 0);
		$this->db->where('itms_consignment_master.del_date IS NULL');
		$this->db->where('itms_consignment_master.consignment_id', $consignment_id);
		$query = $this->db->get();

		return $query->row_array();

    }

    function update_consignment($data) {
        $this->db->where('consignment_id', $data['consignment_id']);
        $query = $this->db->update('itms_consignment_master', $data);

        if ($query) {
            echo true;
        }
        return false;
    }

    function update_consignee($data) {
        $this->db->where('consignee_id', $data['consignee_id']);
        $query = $this->db->update('itms_consignees_master', $data);

        if ($query) {
            echo true;
        }
        return false;
    }

    function save_consignment($data){

        if ($this->db->insert('itms_consignment_master', $data)) {
			$res = $this->db->insert_id();

		} else {
			$res = false;
		}

		return $res;
    }

    function save_consignee($data){

        if ($this->check_consignee_phone_number($data['consignee_phone_no'])) {
            $res = 79;
            return $res;
            exit;

        }elseif ($this->check_consignee_email($data['consignee_email'])) {
            $res = 80;
            return $res;
            exit;

        }elseif($this->db->insert('itms_consignees_master', $data)) {
			$res = $this->db->insert_id();

		} else {
			$res = false;
		}

		return $res;
    }

    function check_consignee_phone_number($phone_no) {
        $query = $this->db->get_where('itms_consignees_master', array('consignee_phone_no'=>$phone_no, 'company_id'=>$this->session->userdata('itms_company_id')));

        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }

    function check_consignee_email($email) {
        $query = $this->db->get_where('itms_consignees_master', array('consignee_email'=>$email, 'company_id'=>$this->session->userdata('itms_company_id')));

        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }
}
