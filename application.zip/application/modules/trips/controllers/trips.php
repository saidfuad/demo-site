<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Trips extends CI_Controller {

    function __construct() {

        parent::__construct();

        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }

        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
            redirect('home');
        }

        $this->load->model('mdl_trips');
        $this->load->model('consignments/mdl_consignments');
        $this->load->model('gps_tracking/mdl_gps_tracking');
        $this->load->model('settings/mdl_settings');
    }

    public function index($asset_id=null) {

        $data['trips'] = $this->mdl_trips->get_trips($asset_id, $this->session->userdata('itms_company_id'), null);

        $data['content_url'] = 'trips/view_trips';
        $data['fa'] = 'fa fa-circle-o';
        $data['title'] = 'ITMS Africa | Trips';
        $data['content_title'] = 'Trips';
        $data['content_subtitle'] = '';
        $data['content'] = 'trips/view_trips.php';
        $this->load->view('main/main.php', $data);
    }

    public function fetch_trips($asset_id) {

        $data['trips'] = $this->mdl_trips->get_trips($asset_id, $this->session->userdata('itms_company_id'));

        $data['content_url'] = 'trips/view_trips';
        $data['fa'] = 'fa fa-circle-o';
        $data['title'] = 'ITMS Africa | Trips';
        $data['content_title'] = 'Trips';
        $data['content_subtitle'] = '';
        $data['content'] = 'trips/view_trips.php';
        $this->load->view('main/main.php', $data);
    }

    public function create_trips() {
        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;

        $data['all_assets'] = $this->mdl_settings->getassets($this->session->userdata('itms_company_id'));
        $data['all_routes'] = $this->mdl_settings->getroutes($this->session->userdata('itms_company_id'));
        $data['all_clients'] = $this->mdl_settings->getclients($this->session->userdata('itms_company_id'));
        $data['all_consignments'] = $this->mdl_consignments->get_consignments($this->session->userdata('itms_company_id'));
        $data['all_consignees'] = $this->mdl_consignments->get_consignees($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'trips/create_trips';
        $data['fa'] = 'fa fa-map-marker';
        $data['title'] = 'ITMS Africa | Create Trips';
        $data['content_title'] = 'Create trips';
        $data['content_subtitle'] = 'Define custom trip';
        $data['content'] = 'trips/create_trip.php';

        $this->load->view('main/main.php', $data);
    }

    public function history(){

        $vehicleList = '';
        $vehicleTripsList = '';

        $vehicles = $this->mdl_gps_tracking->get_gps_vehicles($this->session->userdata('itms_company_id'));
        $trips = $this->mdl_trips->get_trips(null, $this->session->userdata('itms_company_id'), 0);

//        echo "<pre>";
//        print_r($trips);
//        exit;
//
        if(count($vehicles)) {

            foreach ($vehicles as $vehicle) {

                $txt= "";
                $txt = addslashes($vehicle->assets_name);

                if($vehicle->assets_friendly_nm != "")
                    $txt.="(".addslashes($vehicle->assets_friendly_nm).")";

                $vehicleNames[] = $txt;

                foreach ($trips as $trip) {

                    if($vehicle->asset_id == $trip->asset_id){

                        $consignment_name = '';
                        $consignment_name = addslashes($trip->consignment_name);

                        if($trip->consignment_name != "")
                        $consignment_name.="(".addslashes($trip->consignment_name).")";

                        $tripNames[] = $consignment_name;

                        $vehicleList .= "<li style='background:#2e2e2e'>".$vehicle->assets_name.' - '.addslashes($vehicle->assets_friendly_nm)."</li>";

                        $vehicleTripsList .="<li asset-id='".$vehicle->asset_id."' trip-id='".$trip->trip_id."'>".$trip->consignment_name.
                            "<br>".$trip->pickup_address.' - '.$trip->destination_address.
                            "<br><i>".$trip->status."</i></li>";
                    }

                }

            }
        }

        $data['vehicleList'] = $vehicleList;
        $data['vehicleTripsList'] = $vehicleTripsList;

        /*echo "<pre>";
        print_r($data);
        exit;*/

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') !=0)
        {
            $map_center = sprintf( "%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;

        $data['content_url'] = 'trips/history';
        $data['fa'] = 'fa fa-map-marker';
        $data['title'] = 'ITMS Africa | Trips History';
        $data['content_title'] = 'Trips History';
        $data['content_subtitle'] = '';
        $data['content'] = 'trips/trips_history.php';

        $this->load->view('main/main.php', $data);
    }

    public function save_trip () {
        $data = $this->input->post();
        $data ['tracking_no'] = strtotime(date("Y-m-d H:i:s"));
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('itms_userid');
        $data['add_date'] = date('Y-m-d H:i:s');

        echo $this->mdl_trips->save_trips($data);
    }

    public function start_trip () {
        $trip_id = $this->input->post("trip_id");
        echo $this->mdl_trips->start_trip($trip_id);
    }

    public function gps_track_points() {
        $asset_id = $this->input->post("asset_id");
        $trip_id = $this->input->post("trip_id");
        echo json_encode($this->mdl_trips->get_gps_points($asset_id, $trip_id));
    }

}
