<div class="modal fade" id="newClient" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title">Add New Client</h4>
      </div>
      <form id="add-client-form">
          <div class="modal-body">

            <div class="form-group">
                <label for="reservation">Client Name <sup>*</sup>:</label>
                <input class="form-control" type="text" name="client_name" id="client_name"/>
            </div>
            <div class="form-group">
                <label for="reservation">Phone <sup>*</sup>:</label>
            </div>
            <div class="input-group" style="margin-bottom: 20px; margin-top: -15px;">
                <span class="input-group-addon" id="basic-addon1">+254</span>
                <input type="text" class="form-control" aria-describedby="basic-addon1" name="phone_no" id="phone_no" placeholder="Phone Number: 712345678">
                <input type="hidden" class="form-control" name="phone_no_2" id="phone_no_2" />
            </div>
            <div class="form-group">
                <label for="reservation">Email <sup>*</sup>:</label>
                <input class="form-control" type="text" name="email" id="email"/>
            </div>
            <div class="form-group">
                <label for="reservation">Address:</label>
                <textarea class="form-control" type="text" name="address" id="address" rows="3"></textarea>
            </div>

          </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>

        $('#add-client-form').on('submit' , function () {

            var $this = $(this);

            if ($('#client_name').val().trim().length==0 || $('#phone_no').val().trim().length==0 || $('#email').val().trim().length==0) {
                swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
                return false;
            }

            var str1 = "+254";
            str2 = document.getElementById('phone_no').value;

            while( str2.charAt( 0 ) === '0' )
            str2 = str2.slice( 1 );

            var res = str1.concat(str2);
            $("#phone_no").val(res);
            $("#phone_no_2").val(res);

            var auto_num = $('#email').val().trim().length;

            $('#save-client').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-client').prop('disabled', true);

            if (res.length == 13){
                swal({
                title: "Info",
                text: "Add Client?",
                type: "info",
                showCancelButton: true,
                closeOnConfirm: false,
                allowOutsideClick: false,
                showLoaderOnConfirm: true
                }, function(){
                       $.ajax({
                          method: 'post',
                          url: '<?= base_url('index.php/clients/save_client') ?>',
                          data: $this.serialize(),
                          success: function (response) {
                              if (response==1) {

                                $('#add-client-form').find('input[type="text"]').val('');
                                $('#add-client-form').find('input[type="hidden"]').val('');
                                $('#add-client-form').find('select').val(0);
                                $('#add-client-form').find('textarea').val('');

                                location.reload();

                                swal({   title: "Info",   text: "Saved successfully",   type: "success",   confirmButtonText: "ok" });

                              } else if (response==77) {

                                  swal({   title: "Info",   text: "Phone number already exists",   type: "error",   confirmButtonText: "ok" });

                                  $('#save-client').html('Save');
                                  $('#save-client').prop('disabled', false);

                              } else if (response==78) {

                                  swal({   title: "Info",   text: "Email already exists",   type: "error",   confirmButtonText: "ok" });

                                  $('#save-client').html('Save');
                                  $('#save-client').prop('disabled', false);

                              } else if (response==0) {
                                  swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                              } else {
                                  swal({   title: "Info",   text: "Unknown error",   type: "error",   confirmButtonText: "ok" });
                              }

                              $('#save-client').html('Save');
                              $('#save-client').prop('disabled', false);
                           }
                      });
                });
            }else{

            	$('#save-client').html('Save');
            	$('#save-client').prop('disabled', false);

            	document.getElementById('phone_no').value="";
            	swal({   title: "Info",   text: "Wrong Phone number",   type: "error",   confirmButtonText: "ok" });
            }
            return false;
        });

</script>
