<link href="<?php echo base_url('assets/bootstrap-color-picker/src/bootstrap.colorpickersliders.css')?>" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
    var infowindow;
    var vehicle_markers = [];
    var landmark_markers = [];
    var pop_marker = [];
    var map_pop;
    var map;
    var iw_map;
    var new_landmark_markers = [];
    var new_landmark_circles = [];
    var newLatLng = '';
    var fillcolor = $("#full-popover").val();
    var range = parseFloat($("#landmark-radius").val());
    var countM = 0;
    var newLatLng = [];
    var landmark_circle_color = $('#full-popover').val();
    var marker;
    var infowindow;
    var infobox;
    var pick_icon;
    var dest_icon;

    function initMap() {
        map = new google.maps.Map(document.getElementById('map_canvas'), {
            center: {lat: <?= $map_lat; ?>, lng: <?= $map_long; ?>},
            zoom: 7,
            mapTypeId: google.maps.MapTypeId.HYBRID,
            heading: 90,
            tilt: 45,
              streetViewControl:true,
              streetViewControlOptions: {
                  style: google.maps.ZoomControlStyle.SMALL,
                  position: google.maps.ControlPosition.LEFT_CENTER
              },

              fullscreenControl: true,
              fullscreenControlOptions: {
                  style: google.maps.ZoomControlStyle.SMALL,
                  position: google.maps.ControlPosition.LEFT_CENTER
              },
              zoomControl: true,
              zoomControlOptions: {
                  style: google.maps.ZoomControlStyle.SMALL,
                  position: google.maps.ControlPosition.LEFT_CENTER
              },
        });

        var pickup_address_id = null;
        var destination_address_id = null;
        var travel_mode = google.maps.TravelMode.DRIVING;

        var directionsService = new google.maps.DirectionsService;
        directionsDisplay = new google.maps.DirectionsRenderer;

        directionsDisplay.setMap(map);

        var geocoder = new google.maps.Geocoder;

        function expandViewportToFitPlace(map, place) {
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);
            }
        }

        var input_pickup = /** @type {!HTMLInputElement} */(
                document.getElementById('pickup_address'));

        var input_destination = /** @type {!HTMLInputElement} */(
                document.getElementById('destination_address'));

        var types = document.getElementById('type-selector');

        var autocomplete1 = new google.maps.places.Autocomplete(input_pickup);
        autocomplete1.bindTo('bounds', map);

        var autocomplete2 = new google.maps.places.Autocomplete(input_destination);
        autocomplete2.bindTo('bounds', map);

        infowindow = new google.maps.InfoWindow();

        marker = new google.maps.Marker({
            map: map,
            anchorPoint: new google.maps.Point(0, 0)
        });

        autocomplete1.addListener('place_changed', function () {
            var place = autocomplete1.getPlace();
            expandViewportToFitPlace(map, place);
            get_place_pickup(place);

            pickup_address_id = place.place_id;
            generate_route(pickup_address_id, destination_address_id, travel_mode,
                    directionsService, directionsDisplay);
        });

        autocomplete2.addListener('place_changed', function () {
            var place = autocomplete2.getPlace();
            expandViewportToFitPlace(map, place);
            get_place_destination(place);

            destination_address_id = place.place_id;
            generate_route(pickup_address_id, destination_address_id, travel_mode,
                    directionsService, directionsDisplay);
        });

        function get_place_pickup(place) {
            infowindow.close();
            //marker.setVisible(false);

            if (!place.geometry) {
                //window.alert("Returned place contains no geometry");
                swal({title: "Place not found", text: 'Returned place contains no geometry', type: 'info'});
                return;
            }

            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);  // Why 17? Because it looks good.
            }

            landmark_circle_color = $('#full-popover').val();
            newLatLng = place.geometry.location;

            var address = '';
            if (place.address_components) {
                address = [
                    (place.address_components[0] && place.address_components[0].short_name || ''),
                    (place.address_components[1] && place.address_components[1].short_name || ''),
                    (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
            }

            if (place.name) {
                var place_name = place.name;
            } else {
                var place_name = place.address_components[0].short_name;
            }

            var sel_lat = place.geometry.location.lat;
            var sel_lng = place.geometry.location.lng;
            var lnd_mark = place_name;
            var addrs = address;

            var place_icon = "https://maps.gstatic.com/mapfiles/place_api/icons/shopping-71.png";

            if (place.icon) {
                place_icon = place.icon;
            }

            $("#pick_lat").val(sel_lat);
            $("#pick_lng").val(sel_lng);
            $("#pick_icon").val(place_icon);

            addMarker(newLatLng , place_icon);

        }

        function get_place_destination(place) {
            infowindow.close();
            //marker.setVisible(false);

            if (!place.geometry) {
                //window.alert("Returned place contains no geometry");
                swal({title: "Place not found", text: 'Returned place contains no geometry', type: 'info'});
                return;
            }

            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);  // Why 17? Because it looks good.
            }

            landmark_circle_color = $('#full-popover').val();
            newLatLng = place.geometry.location;

            var address = '';
            if (place.address_components) {
                address = [
                    (place.address_components[0] && place.address_components[0].short_name || ''),
                    (place.address_components[1] && place.address_components[1].short_name || ''),
                    (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
            }

            if (place.name) {
                var place_name = place.name;
            } else {
                var place_name = place.address_components[0].short_name;
            }

            var sel_lat = place.geometry.location.lat;
            var sel_lng = place.geometry.location.lng;
            var lnd_mark = place_name;
            var addrs = address;

            var place_icon = "https://maps.gstatic.com/mapfiles/place_api/icons/shopping-71.png";

            if (place.icon) {
                place_icon = place.icon;
            }

            $("#dest_lat").val(sel_lat);
            $("#dest_lng").val(sel_lng);
            $("#dest_icon").val(place_icon);

            addMarker(newLatLng , place_icon);

        }

        function generate_route(pickup_address_id, destination_address_id, travel_mode,
                         directionsService, directionsDisplay) {

            route = [];
            if (!pickup_address_id || !destination_address_id) {
                return;
            }
            directionsService.route({

              origin: {'placeId': pickup_address_id},
              destination: {'placeId': destination_address_id},
              travelMode: travel_mode
            }, function(response, status) {

                if (status === google.maps.DirectionsStatus.OK) {

                    directionsDisplay.setDirections(response);
                    raw_route = JSON.stringify(response);

                    var route_ = response.routes[0];
                    var legs = directionsDisplay.directions.routes[0].legs;
                    var legs_length = legs.length;
                    var steps = directionsDisplay.directions.routes[0].legs[0].steps;
                    var steps_length = steps.length;
                    var distance = directionsDisplay.directions.routes[0].legs[0].distance.text;
                    var distance_value = directionsDisplay.directions.routes[0].legs[0].distance.value;
                    var duration = directionsDisplay.directions.routes[0].legs[0].duration.text;
                    var duration_value = directionsDisplay.directions.routes[0].legs[0].duration.value;
                    var end_address = directionsDisplay.directions.routes[0].legs[0].end_address;
                    var end_latlng = directionsDisplay.directions.routes[0].legs[0].end_location;
                    var start_address = directionsDisplay.directions.routes[0].legs[0].start_address;
                    var start_latlng = directionsDisplay.directions.routes[0].legs[0].start_location;
                    var path = directionsDisplay.directions.routes[0].legs[0].steps[0].path;
                    var picked_points = [];
                    var route_path = [];

                    for (var i = 0; i < steps_length; i++) {
                        picked_points.push(JSON.stringify(steps[i].start_location));

                        $path = steps[i].path;
                        $path_length = $path.length;

                        for (var p = 0; p < $path_length; p++) {
                            route_path.push(JSON.stringify($path[p]));
                        }
                        //console.log(steps[i].start_location.lat+','+steps[i].start_location.lng);
                    }

                    route_data = {
                        start_address: start_address,
                        start_latlng: JSON.stringify(start_latlng),
                        end_address: end_address,
                        end_latlng: JSON.stringify(end_latlng),
                        distance:distance,
                        distance_value:distance_value,
                        duration:duration,
                        duration_value:duration_value,
                        picked_points:picked_points,
                        route_path: route_path
                    }

                } else {
                window.alert('Directions request failed due to ' + status);
              }


            });
        }

        map.addListener('click', function (event) {

            //marker.setVisible(false);
            //clearMarkers(new_landmark_markers);
            //clearCircles(new_landmark_circles);

            newLatLng = event.latLng;
            icon = "https://maps.gstatic.com/mapfiles/place_api/icons/shopping-71.png";
            pick_icon = icon;
            dest_icon = icon;

            var latitude = event.latLng.lat();
            var longitude = event.latLng.lng();
            //var landmark_name = $('#landmark_name').val();
            landmark_circle_color = $('#full-popover').val();
            //var landmark_image = $('#icon_path').val();
            var place_name = '';
            var address = '';

            if ($('#pickup-selected').val() == 0) {
                //alert(latitude);
                $("#pick_lat").val(latitude);
                $("#pick_lng").val(longitude);

            } else if ($('#destination-selected').val() == 0) {
                $("#dest_lat").val(latitude);
                $("#dest_lng").val(longitude);

            }

            var latlng = {lat: parseFloat(latitude), lng: parseFloat(longitude)};
            geocoder.geocode({'location': latlng}, function (results, status) {
                if (status === google.maps.GeocoderStatus.OK) {
                    if (results[0]) {

                        //alert('results');
                        place_name = results[0].address_components[1].long_name + " " + results[0].address_components[0].long_name;
                        //address = results[0].formatted_address;

                        if ($('#pickup-selected').val() == 0) {

                            $("#pickup_address").val(place_name);
                            $("#pickup-selected").val(1);
                            $("#pick-icon").val(pick_icon);

                        } else if ($('#destination-selected').val() == 0) {

                           $("#destination_address").val(place_name);
                           $('#destination-selected').val(1);
                           $("#dest-icon").val(icon);
                           $('.page-alert').html('<p align="center">Enter consignment details</p>');
                        }

                        addMarker(newLatLng , icon);
                    } else {
                        place_name = '';
                        address = '';

                        if ($('#pickup-selected').val() == 0) {
                            swal({title: "Info", text: 'Input pickup address: Could not get the Selected Place address', type: 'info'});
                            $('.page-alert').html('<p align="center">Select destination</p>');
                            $("#pick-icon").val(pick_icon);
                        } else if ($('#destination-selected').val() == 0) {
                            swal({title: "Info", text: 'Input destination address: Could not get the Selected Place address', type: 'info'});
                            $('.page-alert').html('<p align="center">Enter consignment details</p>');
                            $("#dest-icon").val(icon);
                        }
                        addMarker(newLatLng , icon);
                    }
                } else {
                    swal({title: "Info", text: 'Type address: Could not get the Selected Place address', type: 'success'});
                    place_name = '';
                    address = '';
                     if ($('#pickup-selected').val() == 0) {
                        swal({title: "Info", text: 'Input pickup address: Could not get the Selected Place address', type: 'info'});
                        $('.page-alert').html('<p align="center">Select destination</p>');
                        $("#pick-icon").val(pick_icon);
                    } else if ($('#destination-selected').val() == 0) {
                        swal({title: "Info", text: 'Input destination address: Could not get the Selected Place address', type: 'info'});
                        $('.page-alert').html('<p align="center">Enter consignment details</p>');
                        $("#dest-icon").val(icon);
                    }

                   addMarker(newLatLng , icon);
                }
            });

            //alert(place_name);

            ///place_name = "(" + place_name +")";


        });

        function show_marker(show) {
            marker.setPosition(newLatLng);
            marker.setVisible(true);
            if (show) {
                //https://maps.gstatic.com/mapfiles/place_api/icons/shopping-71.png
                marker.setIcon({
                    url: "https://maps.gstatic.com/mapfiles/place_api/icons/shopping-71.png",
                    size: new google.maps.Size(71, 71),
                    origin: new google.maps.Point(0, 0),
                    anchor: new google.maps.Point(17, 34),
                    scaledSize: new google.maps.Size(35, 35)
                });
            }

            range = parseFloat($("#landmark-radius").val());

            //addMarker(newLatLng, landmark_image, landmark_name);
            addCircle(newLatLng, landmark_circle_color);
        }

        iw_map = new google.maps.InfoWindow({
            content: ''
        });

        load_landmarks();

    }

    function load_landmarks() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('index.php/settings/get_company_landmarks') ?>",
            data: {company: 'this company'},
            success: function (data) {
                landmarks = JSON.parse(data);

                //alert(landmarks.length);
                if (landmarks.length > 0) {
                    for (var row in landmarks) {
                        if (landmarks[row].gmap_icon == 0) {
                            $icon = "<?= base_url('" + landmarks[row].icon_path+ "') ?>";
                        } else {
                            $icon = landmarks[row].icon_path;
                        }

                        $pos = {lat: parseFloat(landmarks[row].latitude, 10), lng: parseFloat(landmarks[row].longitude)};
                        //console.log(parseInt(landmarks[row].latitude, 10));
                        landmark_markers.push(new google.maps.Marker({
                            position: $pos,
                            map: map,
                            icon: $icon,
                            content: landmarks[row].landmark_name,
                        }));
                    }

                    var llength = landmark_markers.length;

                    for (var i = 0; i < llength; i++) {

                        $icn = landmark_markers[i].icon;

                        landmark_markers[i].setIcon(/** @type {google.maps.Icon} */({
                            url: $icn,
                            size: new google.maps.Size(71, 71),
                            origin: new google.maps.Point(0, 0),
                            anchor: new google.maps.Point(12, 24),
                            scaledSize: new google.maps.Size(24, 24)
                        }));

                        google.maps.event.addListener(landmark_markers[i], "mouseout", function (event) {
                            iw_map.close();
                        });

                        google.maps.event.addListener(landmark_markers[i], "click", function (event) {
                            map.setCenter(this.getPosition());
                            map.setZoom(15);
                            map.setTilt(45);

                            console.log(event.latLng.lat() + ',' + event.latLng.lng());

                        });

                        google.maps.event.addListener(landmark_markers[i], "mouseover", function (event) {
                            iw_map.setContent(this.get("content"));
                            iw_map.open(map, this);
                        });

                    }

                    if (llength) {
                        //fit_bounds();
                    }


                }

            }
        });
    }

    function rotate90() {
        var heading = map.getHeading() || 0;
        map.setHeading(heading + 90);
    }

    function autoRotate() {
        // Determine if we're showing aerial imagery.
        if (map.getTilt() !== 0) {
            window.setInterval(rotate90, 3000);
        }
    }


    function addMarker(location, icon) {

        //icon = "<?= base_url('" + icon + "') ?>";
        new_landmark_markers.push(new google.maps.Marker({
            position: location,
            map: map,
            icon: icon,
            scaledSize: new google.maps.Size(20, 20)

        }));

        map.setCenter(location);
        map.setZoom(17);  // Why 17? Because it looks good.


        assign_event();

    }

    function assign_event () {

        var countMarkers = new_landmark_markers.length;
        if (countMarkers > 0) {
            for (var i = 0; i < countMarkers; i++) {
                 new_landmark_markers[i].setIcon(({
                            url:new_landmark_markers[i].icon,
                            size: new google.maps.Size(71, 71),
                            origin: new google.maps.Point(0, 0),
                            anchor: new google.maps.Point(0, 0),
                            scaledSize: new google.maps.Size(24, 24)
                          }));

                google.maps.event.addListener(new_landmark_markers[i], "mouseout", function (event) {
                    iw_map.close();
                });

                google.maps.event.addListener(new_landmark_markers[i], "mouseover", function (event) {
                    iw_map.setContent(this.get("content"));
                    iw_map.open(map, this);
                });
            }
        }

    }


    function addCircle(location, color) {
        new_landmark_circles.push(new google.maps.Circle({
            strokeColor: "0.8",
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: fillcolor,
            fillOpacity: 0.4,
            map: map,
            center: location,
            radius: range * 1000
        }));


    }

    function clearMarkers(new_landmark_markers) {
        var countMarkers = new_landmark_markers.length;
        if (countMarkers > 0) {
            for (var i = 0; i < countMarkers; i++) {
                new_landmark_markers[i].setMap(null);
            }
        }
    }

    function clearCircles(new_landmark_circles) {
        var countCircles = new_landmark_circles.length;
        if (countCircles > 0) {
            for (var i = 0; i < countCircles; i++) {
                new_landmark_circles[i].setMap(null);
            }
        }
    }


    function fit_bounds() {
        var bounds = new google.maps.LatLngBounds();
        var vsize = landmark_markers.length;

        //console.log('Size:' + vehicle_markers.length);

        for (i = 0; i < vsize; i++) {
            bounds.extend(landmark_markers[i].getPosition());
        }

        map.fitBounds(bounds);
    }

    window.onload = function() {
        var asset = sessionStorage.getItem('asset');
        var asset_id = sessionStorage.getItem('asset_id');
        var driver_id = sessionStorage.getItem('driver_id');
        var client_id = sessionStorage.getItem('client_id');
        var client = sessionStorage.getItem('client');
        var consignment_id = sessionStorage.getItem('consignment_id');
        var consignment_name = sessionStorage.getItem('consignment_name');
        var consignee_id = sessionStorage.getItem('consignee_id');
        var consignee_name = sessionStorage.getItem('consignee_name');
        var pickup_address = sessionStorage.getItem('pickup_address');
        var pick_lat = sessionStorage.getItem('pick_lat');
        var pick_lng = sessionStorage.getItem('pick_lng');
        var destination_address = sessionStorage.getItem('destination_address');
        var dest_lat = sessionStorage.getItem('dest_lat');
        var dest_lng = sessionStorage.getItem('dest_lng');

        if (asset != null) $('#asset').val(asset);
        if (asset_id != null) $('#asset_id').val(asset_id);
        if (driver_id != null) $('#driver_id').val(driver_id);
        if (client_id != null) $('#client_id').val(client_id);
        if (client != null) $('#client').val(client);
        if (consignment_id != null) $('#consignment_id').val(consignment_id);
        if (consignment_name != null) $('#consignment_name').val(consignment_name);
        if (consignee_id != null) $('#consignee_id').val(consignee_id);
        if (consignee_name != null) $('#consignee_name').val(consignee_name);
        if (pickup_address != null) $('#pickup_address').val(pickup_address);
        if (pick_lat != null) $('#pick_lat').val(pick_lat);
        if (pick_lng != null) $('#pick_lng').val(pick_lng);
        if (destination_address != null) $('#destination_address').val(destination_address);
        if (dest_lat != null) $('#dest_lat').val(dest_lat);
        if (dest_lng != null) $('#dest_lng').val(dest_lng);
    }
</script>

<div class="container-fluid">
    <div class="row">
        <form id="form-create-consignment">
            <input type="hidden" value="0" id="pickup-selected" />
            <input type="hidden" value="0" id="destination-selected" />
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4>Create Trip ( <sup>*</sup> Required)</h4>
                    </div>
                    <div class="panel-body">

                        <div class="form-group">
                            <input id="asset_id" type="hidden" class="form-control clear-input"/>
                            <label class="control-lable">Choose Vehicle</label>
                            <input id="asset" name="asset" class="form-control clear-input"  autocomplete="off" />
                            <input type="hidden" id="driver_id" name="driver_id" class="form-control clear-input" />

                            <div class="assets_holder">
                                <ul id="asset-list">
                                <?php
                                if ( $all_assets == null){ ?>
                                    <script> $('.assets_holder').show(); $('.asset-list').show(); </script>
                                    <?php echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Vehicle Found</li>";
                                } else{
                                foreach($all_assets as $key => $row) {
                                    echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;' onclick=\"assetClicked(this.id,this.title, ".$row['personnel_id'].")\" class='types' driver= '".$row['personnel_id']."' id='" . $row['asset_id'] . "'
                                    title='".$row['asset_name'] . "' >" . $row['asset_name'] . "</li>";
                                    }
                                }
                                ?>
                                </ul>
                            </div>
                            <script>

                                $('#asset').on('focus', function () {
                                    $('.consignment_holder').hide();
                                    $('.consignee_holder').hide();
                                    $('.client_holder').hide();
                                });

                                $('#asset').on('keydown', function () {
                                    $('#asset-list').show();
                                    $('.assets_holder').show();
                                });

                                $('#asset').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    if (value.length == 0) {
                                        $("#asset_id").val("");
                                        $('.assets_holder').hide();
                                    }

                                    $('#asset-list').show();
                                    $("#asset-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function assetClicked(asset,value, driver_id) {
                                    //alert(driver_id);
                                    $("#asset").val(value);
                                    $("#asset_id").val(asset);
                                    $("#driver_id").val(driver_id);
                                    $("#asset").focus();
                                    $('#asset-list').hide();
                                }
                            </script>
                        </div>

                        <div class="form-group">
                            <input id="client_id" type="hidden" class="form-control clear-input"/>
                            <label class="control-lable">Choose Client<sup title="Required field">*</sup>:</label>
                            <input id="client" name="client" class="form-control clear-input" autocomplete="off"/>

                            <button type="button" id="store1" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#newClient">New Client
                                <span class='fa fa-plus'></span>
                            </button>

                            <div class="client_holder">
                                <ul id="client-list">
                                <?php
                                if ( $all_clients == null){ ?>
                                    <script> $('.client_holder').show(); $('.client-list').show(); </script>
                                    <?php echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Clients Found</li>";
                                } else{
                                foreach($all_clients as $key => $row) {
                                    echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;' onclick=\"clientClicked(this.id,this.title)\" class='types' id='" . $row['client_id'] . "'
                                    title='".$row['client_name'] . "' >" . $row['client_name'] . "</li>";
                                    }
                                }
                                ?>
                                </ul>
                            </div>
                            <script>

                                $('#client').on('focus', function () {
                                    $('.consignment_holder').hide();
                                    $('.assets_holder').hide();
                                    $('.consignee_holder').hide();
                                });

                                $('#client').on('keydown', function () {
                                    $('#client-list').show();
                                    $('.client_holder').show();
                                });

                                $('#client').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    if (value.length == 0) {
                                        $("#client_id").val("");
                                        $('.client_holder').hide();
                                    }

                                    $('#client-list').show();
                                    $("#client-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function clientClicked(client,value) {
                                    // alert(value);
                                    $("#client").val(value);
                                    $("#client_id").val(client);
                                    $("#client").focus();
                                    $('#client-list').hide();
                                }
                            </script>
                        </div>

                        <div class="form-group">
                            <input type="hidden" id="consignee_id" class="form-control clear-input"/>
                            <label for="reservation">Choose Consignee</label>
                            <input type="text" id="consignee_name" class="form-control clear-input"/>

                            <button type="button" id="store3" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#consigneeDetails">New Consignee
                                <span class='fa fa-plus'></span>
                            </button>

                            <div class="consignee_holder">
                                <ul id="consignee-list">
                                <?php
                                if ( $all_consignees == null){ ?>
                                    <script> $('.consignee_holder').show(); $('.consignee-list').show(); </script>
                                    <?php echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Consignees Found</li>";
                                } else{
                                foreach($all_consignees as $key => $row) {
                                    echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;' onclick=\"consigneeClicked(this.id,this.title)\" class='types' id='" . $row['consignee_id'] . "'
                                    title='".$row['consignee_name'] . "' >" . $row['consignee_name'] . "</li>";
                                    }
                                }
                                ?>
                                </ul>
                            </div>
                            <script>

                                $('#consignee_name').on('focus', function () {
                                    $('.client_holder').hide();
                                    $('.assets_holder').hide();
                                    $('.consignment_holder').hide();
                                });

                                $('#consignee_name').on('keydown', function () {
                                    $('#consignee-list').show();
                                    $('.consignee_holder').show();
                                });

                                $('#consignee_name').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    if (value.length == 0) {
                                        $("#consignee_id").val("");
                                        $('.consignee_holder').hide();
                                    }

                                    $('#consignee-list').show();
                                    $("#consignee-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function consigneeClicked(consignee, value) {
                                    $("#consignee_name").val(value);
                                    $("#consignee_id").val(consignee);
                                    $("#consignee_name").focus();
                                    $('#consignee-list').hide();
                                    $('#consignee_holder').hide();
                                }

                            </script>

                        </div>

                        <div class="form-group">
                            <input type="hidden" id="consignment_id" class="form-control clear-input"/>
                            <label for="reservation">Choose Consignment</label>
                            <input type="text" id="consignment_name" class="form-control clear-input"/>

                            <button type="button" id="store2" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#consignmentDetails">New Consignment
                                <span class='fa fa-plus'></span>
                            </button>

                            <div class="consignment_holder">
                                <ul id="consignment-list">
                                <?php
                                if ( $all_consignments == null){ ?>
                                    <script> $('.consignment_holder').show(); $('.consignment-list').show(); </script>
                                    <?php echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Consignments Found</li>";
                                } else{
                                foreach($all_consignments as $key => $row) {
                                    echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;' onclick=\"consignmentClicked(this.id,this.title)\" class='types' id='" . $row['consignment_id'] . "'
                                    title='".$row['consignment_name'] . "' >" . $row['consignment_name'] . "</li>";
                                    }
                                }
                                ?>
                                </ul>
                            </div>
                            <script>

                                $('#consignment_name').on('focus', function () {
                                    $('.client_holder').hide();
                                    $('.assets_holder').hide();
                                    $('.consignee_holder').hide();
                                });

                                $('#consignment_name').on('keydown', function () {
                                    $('#consignment-list').show();
                                    $('.consignment_holder').show();
                                });

                                $('#consignment_name').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    if (value.length == 0) {
                                        $("#consignment_id").val("");
                                        $('.consignment_holder').hide();
                                    }

                                    $('#consignment-list').show();
                                    $("#consignment-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function consignmentClicked(consignment, value) {
                                    $("#consignment_name").val(value);
                                    $("#consignment_id").val(consignment);
                                    $("#consignment_name").focus();
                                    $('#consignment-list').hide();
                                    $('#consignment_holder').hide();
                                }

                            </script>

                        </div>

                        <div class="form-group">
                            <label for="reservation">Choose Pickup Address</label>
                            <input class="form-control clear-input" id="pickup_address" type="text"/>
                            <input id="pick_lat" type="hidden" class="clear-input" />
                            <input id="pick_lng" type="hidden" class="clear-input" />
                            <input type="hidden" name="pick_icon clear-input" id="pick_icon" />
                            <script>
                                $('#pickup_address').on('focus', function () {
                                    $('.client_holder').hide();
                                    $('.assets_holder').hide();
                                    $('.consignment_holder').hide();
                                    $('.consignee_holder').hide();
                                });
                            </script>
                        </div>
                        <div class="form-group">
                            <label for="reservation">Choose Destination Address</label>
                            <input class="form-control clear-input" id="destination_address" type="text" />
                            <input id="dest_lat" type="hidden" class="clear-input"/>
                            <input id="dest_lng" type="hidden" class="clear-input"/>
                            <input type="hidden" name="dest_icon clear-input" id="dest_icon" />
                            <script>
                                $('#destination_address').on('focus', function () {
                                    $('.client_holder').hide();
                                    $('.assets_holder').hide();
                                    $('.consignment_holder').hide();
                                    $('.consignee_holder').hide();
                                });
                            </script>
                        </div>
                    </div>
                </div>
                <div class="panel-footer " align="right">
                    <input class="btn btn-success btn" type="submit" id="btn-create" value="Create Trip" />
                </div>
            </div>
        </form>
        <div class="col-md-6" >
            <div class="col-md-12" id='map_canvas' style="height:85vh"></div>
        </div>
    </div>
</div>
<!-- /.row -->

<?php include("new_client.php"); ?>
<?php include("new_consignment.php"); ?>
<?php include("new_consignee.php"); ?>

<script src="<?php echo base_url('assets/bootstrap-color-picker/src/bootstrap.colorpickersliders.js')?>"></script>

<script type="text/javascript">
    $(function () {

        function store_values(){

            sessionStorage.setItem('asset', asset);
            sessionStorage.setItem('asset_id', asset_id);
            sessionStorage.setItem('driver_id', driver_id);
            sessionStorage.setItem('client_id', client_id);
            sessionStorage.setItem('client', client);
            sessionStorage.setItem('consignment_id', consignment_id);
            sessionStorage.setItem('consignment_name', consignment_name);
            sessionStorage.setItem('consignee_id', consignee_id);
            sessionStorage.setItem('consignee_name', consignee_name);
            sessionStorage.setItem('pickup_address', pickup_address);
            sessionStorage.setItem('pick_lat', pick_lat);
            sessionStorage.setItem('pick_lng', pick_lng);
            sessionStorage.setItem('destination_address', destination_address);
            sessionStorage.setItem('dest_lat', dest_lat);
            sessionStorage.setItem('dest_lng', dest_lng);

        }

        $("#store1").on('click', function(){
            store_values();
        });
        $("#store2").on('click', function(){
            store_values();
        });
        $("#store3").on('click', function(){
            store_values();
        });

        $('#form-create-consignment').on('submit', function () {

            var $this = $(this);

            var asset = $('#asset').val().trim();
            var asset_id = $('#asset_id').val().trim();
            var driver_id = $("#driver_id").val().trim();

            var client_id = $('#client_id').val().trim();
            var client = $('#client').val().trim();

            var consignment_id = $('#consignment_id').val().trim();
            var consignment_name = $('#consignment_name').val().trim();

            var consignee_id = $('#consignee_id').val().trim();
            var consignee_name = $('#consignee_name').val().trim();

            var pickup_address = $('#pickup_address').val().trim();
            var pick_lat = $("#pick_lat").val();
            var pick_lng = $("#pick_lng").val();
            var pick_icon = $("#pick_icon").val();

            var destination_address = $('#destination_address').val().trim();
            var dest_lat = $("#dest_lat").val();
            var dest_lng = $("#dest_lng").val();
            var dest_icon = $("#dest_icon").val();

            if (pick_lat.length == 0 || dest_lat.length == 0) {
                swal({title: "Info", type: "info", text: "Please select pickup and destination locations"});
                return false;
            }

            if (asset_id.length == 0 || driver_id.length == 0 || client_id.length == 0 || client_name.length == 0 || consignee_id.length == 0 || consignee_name.length == 0 || consignment_id.length == 0 || consignment_name.length == 0) {
                swal({title: "Info", type: "info", text: "Please fill in the required fields"});
                return false;
            }

            swal({
                title: "Confirm",
                text: "Create Trip?",
                type: "info",
                showCancelButton: true,
                closeOnConfirm: false,
                allowOutsideClick: false,
                showLoaderOnConfirm: true,
                confirmButtonText: "Yes",
                closeOnConfirm: false,

                }, function(){
                    $.ajax({
                        type : "POST",
                        cache : false,

                        data : {asset_id: asset_id,
                                driver_id: driver_id,
                                client_id: client_id,
                                consignee_id: consignee_id,
                                consignment_id: consignment_id,
                                pickup_address:pickup_address,
                                pick_lat:pick_lat,
                                pick_lng:pick_lng,
                                pick_icon:pick_icon,
                                destination_address:destination_address,
                                end_lat:dest_lat,
                                end_lng:dest_lng,
                                dest_icon:dest_icon
                               },

                        url : "<?php echo base_url('index.php/trips/save_trip') ?>",
                        success: function(response) {

                            if (response==1) {
                                $('.clear-input').val('');
                                $('#destination-input').val('');

                                swal({title: "Info",text:'Consignment created successfully', type:'success'});

                            } else {
                                swal({title: "Error",text:'Error Creating Consignment, Try again.', type:'error'});

                            }
                        }

                    });

                });
        });
    });
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyBn6m_W3hRMPg5nDlmqsRkaO3kE1LZ1HX4&libraries=places,drawing&callback=initMap"></script>

<!--<script async defer src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyCfKP5H8r9ohlPjH_CbddIefMbeCirz7-U&libraries=places&callback=initMap"></script>-->
