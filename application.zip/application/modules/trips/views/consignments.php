<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <?php if (sizeof($consignments)) {?>
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('consignments/create_consignment').""; ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                New Consignment
            </a>
            <?php } ?>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($consignments)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Consignment</th>
                                <th>Amount</th>
                                <th>Cargo Weight</th>
                                <th>Cargo Rate</th>
                                <th>Consignee</th>
                                <th>Pickup Location</th>
                                <th>Destination</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php foreach ($consignments as $key => $value) { ?>
                           <tr class="gradeU">
                                <td><?php echo $value->consignment_name; ?></td>
                                <td><?php echo $value->consignment_amount; ?></td>
                                <td><?php echo $value->cargo_weight; ?></td>
                                <td><?php echo $value->cargo_rate; ?></td>
                                <td><?php echo $value->consignee_name." ("."+254".$value->consignee_phone_no.")"; ?></td>
                                <td><?php echo $value->pickup_address; ?></td>
                                <td><?php echo $value->destination_address; ?></td>
                                <td>
                                    <?php
                                        if($value->status == 0){
                                            echo "Pending Transport";
                                        }elseif($value->status == 1){
                                            echo "On Transit";
                                        }elseif($value->status == 2){
                                           echo "Delivered";
                                        }
                                    ?>
                               </td>
                                <td><?php echo "<a data-placement='top' data-toggle='tooltip' data-original-title='Edit Consignment'  href='".base_url('index.php/consignments/edit_consignment/'.$value->consignment_id)
                                                ."'class='btn btn-success btn-xs'><span class='fa fa-pencil'></span></a>
                                               "?></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-suitcase"></i> Consignments</h2>
                    <p>Manage Consignments for Various Clients</p>

                    <a href="<?php echo site_url('consignments/create_consignment');?>" class="btn btn-success">New Consignment</a>
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });

    $('a').tooltip();
</script>
