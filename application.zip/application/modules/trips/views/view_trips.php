<div id="container-fluid" id="page-wrapper">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('trips/create_trips').""; ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                Create Trip
            </a>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Tracking No</th>
                            <th>Vehicle</th>
                            <th>Client</th>
                            <th>Consignment</th>
                            <th>Pickup</th>
                            <th>Destination</th>
                            <th>Status</th>
                            <!--<th>Action</th>-->
                            
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $count = 1;
                    foreach ($trips as $key => $value) { ?>
                       <tr class="gradeU">
                            <td><?php echo $value->tracking_no; ?></td>
                            <td><?php echo $value->assets_name; ?><input type="hidden" class="driver-phone-holder" value="<?php echo $value->driver_phone; ?>"/>
                                <input type="hidden" class="driver-name-holder" value="<?php echo $value->driver_name; ?>"/>
                            </td>
                            <td><?php echo $value->client_name; ?><input type="hidden" class="client-phone-holder" value="<?php echo $value->client_phone; ?>"/></td>
                            <td><?php echo $value->consignment_name; ?></td>
                            <td><?php echo $value->pickup_address; ?></td>
                            <td><?php echo $value->destination_address; ?></td>
                            <td class="status-holder"><div class="<?php if ($value->status == "Not Started") { echo "trip_notstarted";} else if ($value->status == "In Progress") { echo "trip_progress";} else if ($value->status == "Completed"){ echo "trip_complete"; } else if ($value->status == "Cancelled") {echo "trip_cancelled";}?> "><?php echo $value->status; ?></div></td>
                            <!--<td>
                                <input type="hidden" class="trip-id-holder" value="<?php echo $value->trip_id; ?>"/>
                                <div class="btn-group pull-right">
                                  <button type="button" class="btn btn-default">Action</button>
                                  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                    <span class="caret"></span>
                                    <span class="sr-only">Toggle Dropdown</span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <?php if ($value->status == "Not Started") { echo '<li class="start-btn"><a href="#">Start</a></li>
                                        ';
                                    } ?>
                                    <li class="purge-btn"><a href="#">Cancel</a></li>
                                    <li><a href="#">Edit</a></li>
                                  </ul>
                                </div>
                            </td>-->
                        </tr>
                    <?php 
                        $count++;
                    }?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();


        $(".start-btn").on("click", function () {
            var trip_id = $(this).parent().parent().parent().find(".trip-id-holder").val();
            var $this = $(this);

            swal({   
               title: "Info",   
                text: "Start this trip?",   
                type: "info",   
                showCancelButton: true,   
                closeOnConfirm: false, 
                allowOutsideClick: false,  
                showLoaderOnConfirm: true, 
                //confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, Start it!",
                closeOnConfirm: false, 

                }, function(){
                    $.ajax({
                        type : "POST",
                        cache : false,
                        data : {trip_id:trip_id},
                        url : "<?php echo base_url('index.php/trips/start_trip') ?>",
                        success: function(response) {

                            //alert(response);
                            
                            if (response==1) {
                                $this.parent().parent().parent().parent().find('.status-holder').html('<button class="btn btn-sm btn-block btn-success">In Progress</button>');
                                $this.remove();
                                swal({title: "Info",text:'Trip Started: Driver and client(s) have been notified', type:'success'});
                            } else if (response=="unavailable") {
                                 swal({title: "Info",text:'The Vehicle is currently on another trip', type:'error'});
                            } else {
                                swal({title: "Info",text:'Sorry, Failed to start trip', type:'error'});
                                
                            }     
                        }
                        
                    });
                });

            return false;
        });
    });
</script>
