<div class="modal fade" id="consignmentDetails" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Enter Consignment Details</h4>
            </div>
            <form id="form-create-consignment">
                <div class="modal-body">

                    <div class="form-group">
                        <label for="reservation">Product Name</label>
                        <input type="text" required name="consignment_name" id="consignment_name" class="form-control"/>
                    </div>

                    <div class="form-group">
                        <label class="control-lable">Quantity<sup title="Required field">*</sup>:</label>
                        <input type="text" required id="consignment_amount" name="consignment_amount" class="form-control clear-input"/>
                    </div>

                    <div class="form-group">
                        <label class="control-lable">Rates (Kshs.)<sup title="Required field">*</sup>:</label>
                        <input type="text" required id="cargo_rate" name="cargo_rate" class="form-control clear-input"/>
                    </div>

                    <div class="form-group">
                        <label class="control-lable">Cargo Weight<sup title="Required field">*</sup>:</label>
                        <input type="text" required id="cargo_weight" name="cargo_weight" class="form-control clear-input"/>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">
    $(function () {

        $('#form-create-consignment').on('submit', function () {

            $this = $(this);

            swal({
                title: "Confirm",
                text: "Create Consignment?",
                type: "info",
                showCancelButton: true,
                closeOnConfirm: false,
                allowOutsideClick: false,
                showLoaderOnConfirm: true,
                confirmButtonText: "Yes",
                closeOnConfirm: false,

                }, function(){
                    $.ajax({
                        type : "POST",
                        cache : false,

                        data : $this.serialize,

                        url : "<?php echo base_url('index.php/consignments/save_consignment') ?>",
                        success: function(response) {

                            if (response==1) {

                                $("#form-create-consignment").find('input[type="text"]').val('');

                                swal({title: "Info",text:'Consignment created successfully', type:'success'});
                                location.reload();


                            } else if (response==77) {
                                swal({title: "Required",text:'Fill in the required fields', type:'info'});
                            } else {
                                swal({title: "Error",text:'Error Creating Consignment, Try again.', type:'error'});
                            }
                        }

                    });

                });

           // return false;
        });
    });
</script>
