<div class="modal fade" id="consigneeDetails" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Enter Consignee Details</h4>
            </div>
            <form id="form-create-consignee">

                <div class="modal-body">

                    <div class="form-group">
                        <label class="control-lable">Consignee Name<sup title="Required field">*</sup>:</label>
                        <input type="text" id="consignee_name" name="consignee_name" class="form-control"/>
                    </div>

                    <div class="form-group">
                        <label class="control-lable">Consignee Phone Number<sup title="Required field">*</sup>:</label>
                    </div>
                    <div class="input-group" style="margin-bottom: 20px; margin-top: -15px;">
                      <span class="input-group-addon" id="basic-addon1">+254</span>
                      <input type="text" id="consignee_phone_no" name="consignee_phone_no" class="form-control"/>
                    </div>

                    <div class="form-group">
                        <label class="control-lable">Consignee Email<sup title="Required field">*</sup>:</label>
                        <input type="email" id="consignee_email" name="consignee_email" class="form-control"/>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">
    $(function () {

        $('#form-create-consignee').on('submit', function () {

            var $this = $(this);

            swal({
                title: "Confirm",
                text: "Add Consignee?",
                type: "info",
                showCancelButton: true,
                closeOnConfirm: false,
                allowOutsideClick: false,
                showLoaderOnConfirm: true,
                confirmButtonText: "Yes",
                closeOnConfirm: false,

                }, function(){
                    $.ajax({
                        type : "POST",
                        cache : false,
                        data : $this.serialize(),

                        url : "<?php echo base_url('index.php/consignments/save_consignee') ?>",
                        success: function(response) {

                            if (response==1) {

                                $("#form-create-consignee").find('input[type="text"]').val('');

                                swal({title: "Info",text:'Consignee created successfully', type:'success'});
                                location.reload();

                            } else if (response==77) {
                                swal({title: "Check Email",text:'Email address cannot be empty', type:'info'});
                            } else if (response==78) {
                                swal({title: "Check Phone Number",text:'Phone number cannot be empty', type:'info'});
                            } else if (response==79) {
                                swal({title: "Check Phone Number",text:'Phone number already exists', type:'info'});
                            } else if (response==80) {
                                swal({title: "Check Email",text:'Email address already exists', type:'info'});
                            }
                        }

                    });

                });

           // return false;
        });
    });
</script>
