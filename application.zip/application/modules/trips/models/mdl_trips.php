<?php 

class Mdl_trips extends CI_Model{

    var $url = "http://178.63.90.134/itmsafrica/assets/images/system/logo1.png";
    var $tracking_link = "http://178.63.90.134/itmsafrica/index.php/freight/track";

	function get_trips ($asset_id, $company_id, $status) {
		
		$this->db->select('itms_trips.*, itms_assets.assets_name, itms_assets.assets_friendly_nm, CONCAT(itms_personnel_master.fname, " " , itms_personnel_master.lname) AS driver_name, itms_personnel_master.phone_no AS driver_phone, itms_client_master.client_name, itms_client_master.phone_no AS client_phone, itms_consignment_master.consignment_name, itms_consignees_master.consignee_name, itms_consignees_master.consignee_phone_no, itms_consignees_master.consignee_email');
		$this->db->from('itms_trips');
		$this->db->join('itms_personnel_master', 'itms_personnel_master.personnel_id=itms_trips.driver_id', 'left')
				->join('itms_client_master', 'itms_client_master.client_id=itms_trips.client_id', 'left')
                ->join('itms_assets', 'itms_assets.asset_id=itms_trips.asset_id', 'left')
                ->join('itms_consignment_master', 'itms_consignment_master.consignment_id=itms_trips.consignment_id', 'left')
            ->join('itms_consignees_master', 'itms_consignees_master.consignee_id=itms_trips.consignee_id', 'left');

		if($company_id != null) {
			$this->db->where('itms_trips.company_id', $company_id);
		}

		/*if($status != null) {
			$this->db->where('itms_trips.status', $status);
		}*/

        if($status != null) {
			$this->db->where('itms_trips.is_complete', $status);
		}

        if($asset_id != null) {
			$this->db->where('itms_trips.asset_id', $asset_id);
		}

		$this->db->where('itms_trips.del_date', NULL);
		$query = $this->db->get();

		return $query->result();
	}


	function save_trips($data) {
       
        $this->load->library('smssend');

        $query = $this->db->insert('itms_trips', $data);

        if ($query) {
        	$client = $this->get_client_by_id($data['client_id']);
        	$driver = $this->get_driver_by_id($data['driver_id']);
        	$client_res = array($client['phone_no']);
        	$driver_res = array($driver['phone_no']);
            $driver_name = $driver['fname'] ." " . $driver['lname'];
            
            $email_res =array($client['email']);
            $subj = 'Your Consignment trip has been scheduled';
            $client_message = "Dear Client. Your consignment trip has been scheduled. Once the trip starts you will receive your Tracking Number. Thank you for choosing " .$this->session->userdata('company_name');
            $driver_message = "Hello " .$driver_name . ". A new trip has been created.You will be notified once the trip is due to start";

            $message = $this->get_client_trip_created_message ($client['client_name'], $data['destination_address']);
                
            $res = $this->smssend->send_text_message ($client_res, $client_message);
            $res = $this->smssend->send_text_message ($driver_res, $driver_message);

            $email_alert = $this->send_email_alert ($client['email'], $subj, $message);

            $status = "Consignment trip created";
            $location = "N/A";
            $time = gmdate("Y-m-d H:i:s");

            $update_status = $this->update_freight_status($data['tracking_no'], $status, $location, $time);
        }
        
        return $query;
        
    }

    /*function start_trip ($trip_id) {
        $this->load->library('smssend');

        $trip = $this->get_trip_by_id($trip_id);

        $asset['route_id'] = $trip['route_id'];
        $asset['asset_id'] = $trip['asset_id'];
        $data['driver_id'] = $trip['driver_id'];
        $data['client_id'] = $trip['client_id'];
        $data['tracking_no'] = $trip['tracking_no'];
        $asset['trip_id'] = $trip ['trip_id'];
        $destination_address = $trip['destination_address'];
        $pickup_address = $trip['pickup_address'];
        $gps = $this->get_current_location($asset['asset_id']);
        $location = (sizeof($gps)) ? $gps['address'] :null;

        $tp['trip_id'] = $trip_id;
        $tp['status'] = "In Progress";

        if ($this->check_asset_availability($asset['asset_id'])) {
            return "unavailable";
            exit;
        }
            

        $return = false;

        if ($this->update_trip($tp)) {

            $return = true;

            $update_asset = $this->update_asset($asset);

            

            $client = $this->get_client_by_id($data['client_id']);
            $driver = $this->get_driver_by_id($data['driver_id']);
            $client_res = array($client['phone_no']);
            $driver_res = array($driver['phone_no']);
            $driver_name = $driver['fname'] ." " . $driver['lname'];
            
            $email_res =array($client['email']);
            $subj = 'Your Consignment trip has started : Tracking Number - '. $data['tracking_no'];
            $client_message = "Dear Client,
            Tracking No:". $data['tracking_no'] . ". To track your consignment, Go To: ".$this->tracking_link."/".$data['tracking_no'].". Thank you for choosing " .$this->session->userdata('company_name');
            $driver_message = "Dear Driver, 
            Your trip is due to start. Kindly head to the pickup station at: ".$pickup_address;

            $message = $this->get_client_trip_started_message ($client['client_name'], $data['tracking_no']);
                
            $res = $this->smssend->send_text_message ($client_res, $client_message);
            $res = $this->smssend->send_text_message ($driver_res, $driver_message);

            $email_alert = $this->send_email_alert ($client['email'], $subj, $message);

            //print_r($email_alert);

            $time = gmdate('Y-m-d H:i:s');
            
            $update_freight = $this->update_freight_status($data['tracking_no'], "Trip started", $location, $time) ;
        }

        return $return;
    }*/

    function get_client_trip_created_message ($client_name, $destination) {

        $message = '<div class="" style="margin-left:100px;width:500px; position:fixed; top:100px; left:30%;background:#f5f5f5;">
                        <div style="background:#101010;border-bottom:6px solid #18bc9c;padding:10px;text-align: center;">
                            <h1><img src="'.$this->url.'"></h1>
                        </div>
                        <div style="padding:20px;">

                            Dear Client - '.$client_name.',<br><br>
                            Your consignment trip to '.$destination.' has been created.
                            <br>
                            You will be notified of your freight tracking number once the trip begins
                            <br>
                            <br>

                            Thank you for choosing '.$this->session->userdata('company_name').'

                            <br><br>
                            In case of any query, please feel free to contact '.$this->session->userdata('company_name').' Help desk.<br>
                            <a href="#">'.$this->session->userdata('email_address').'</a> on or <a href="#">'.$this->session->userdata('mobile_number').'</a>
                            <br>                        
                        </div>
                    </div>';

        return $message;

    }

    /*function get_client_trip_started_message ($client_name, $tracking_no) {

        $message = '<div class="" style="margin-left:100px;width:500px; position:fixed; top:100px; left:30%;background:#f5f5f5;">
                        <div style="background:#101010;border-bottom:6px solid #18bc9c;padding:10px;text-align: center;">
                            <h1><img src="'.$this->url.'"></h1>
                        </div>
                        <div style="padding:20px;">

                            Dear Client - '.$client_name.',<br><br>
                            Your consignment trip to has started.
                            <br>
                            <b>Tracking Number</b> : '. $tracking_no.'
                            <br>
                            Use the following Link below to track your consignment:<br>
                            <a href="'.$this->tracking_link.'/'.$tracking_no.'">Track consignment</a>

                            <br>
                            <br>
                            Thank you for choosing '.$this->session->userdata('company_name').'

                            <br><br>
                            In case of any query, please feel free to contact '.$this->session->userdata('company_name').' Help desk.<br>
                            <a href="mailto:">'.$this->session->userdata('email_address').'</a> on or <a href="#">'.$this->session->userdata('mobile_number').'</a>
                            <br>                        
                        </div>
                    </div>';

        return $message;

    }*/

    function send_email_alert ($email, $subj, $message) {

        $this->load->library('emailsend');

        //$company_name = "test"; $mobile= "test"; $email = "makaweys@gmail.com";$password= "test";$address= "test";

        $to = array($email);
        $subj = $subj;
        $message = $message;

        return $this->emailsend->send_email_message ($to, $subj, $message);


    }

    public function update_asset($asset) {
        $this->db->where('asset_id', $asset['asset_id']);
        $res = $this->db->update('itms_assets', array('current_route'=>$asset['route_id'], 'current_trip'=>$asset['trip_id']));

        return $res;
    }

    public function update_trip($trip) {

        $trip_id = $trip['trip_id'];
        unset($trip['trip_id']);

        $this->db->where('trip_id', $trip_id);
        $res = $this->db->update('itms_trips', $trip);

        return $res;
    }

    public function get_trip_by_id($trip_id) {
        $this->db->select('itms_trips.*');
        $this->db->from('itms_trips');
        $this->db->where('itms_trips.trip_id', $trip_id);
        $query = $this->db->get();
       
        return $query->row_array();     
    }

    public function get_asset_by_id($asset_id) {
        $this->db->select('itms_assets.*');
        $this->db->from('itms_assets');
        $this->db->where('itms_assets.asset_id', $asset_id);
        $query = $this->db->get();
       
        return $query->row_array();     
    }

    public function get_current_location($asset_id) {
        $this->db->select('itms_last_gps_point.*');
        $this->db->from('itms_last_gps_point');
        $this->db->where('itms_last_gps_point.asset_id', $asset_id);
        $query = $this->db->get();
       
        return $query->row_array();  
    }
	

	public function get_client_by_id($client_id) {
		$this->db->select('itms_client_master.*');
        $this->db->from('itms_client_master');
        $this->db->where('itms_client_master.client_id', $client_id);
       	$query = $this->db->get();
       
        return $query->row_array();		
	}

	public function get_driver_by_id($driver_id) {
		$this->db->select('itms_personnel_master.*');
        $this->db->from('itms_personnel_master');
        $this->db->where('itms_personnel_master.personnel_id', $driver_id);
       	$query = $this->db->get();
       
        return $query->row_array();		
	}

    public function check_asset_availability($asset_id) {
       $asset =  $this->get_asset_by_id($asset_id);
       $trip = $this->get_trip_by_id($asset['current_trip']);

       if ($trip['status'] == "In Progress") {
            return true;
       }

       return false;

    }

	public function update_freight_status($tracking_no, $status, $location, $time) {
		return $this->db->insert('itms_freight_tracking', array('tracking_no'=>$tracking_no, 'status'=>$status, 'location'=>$location, 'date_time'=>$time));
	}

    public function get_gps_points($asset_id, $trip_id){

        $this->db->select('itms_trips.start_lat, itms_trips.start_lng, itms_trips.pick_lat, itms_trips.pick_lng, itms_trips.end_lat, itms_trips.end_lng, itms_gps_track_points.latitude AS stop_points_lat, itms_gps_track_points.longitude AS stop_points_lng');
		$this->db->from('itms_gps_track_points');
        $this->db->join('itms_trips', 'itms_trips.trip_id = itms_gps_track_points.trip_id', 'left');


        if($asset_id != null) {
			$this->db->where('itms_gps_track_points.asset_id', $asset_id);
		}

        if($trip_id != null) {
			$this->db->where('itms_gps_track_points.trip_id', $trip_id);
		}
		$query = $this->db->get();

		return $query->result();

    }
}

?>
