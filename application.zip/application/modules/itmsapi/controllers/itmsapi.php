<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class itmsapi extends REST_Controller {

    function __construct()
    {
        parent::__construct();

        /*
	$this->methods['gps_live_get']['limit'] = 1000; // 1000 requests per hour per user/key
        $this->methods['vehicles_get']['limit'] = 1000; // 1000 requests per hour per user/key
        $this->methods['personnel_get']['limit'] = 100; // 100 requests per hour per user/key
	*/

        $this->load->model('itms_api_model');
    }

    function authenticate_get()
    {
        if(!$this->get('username') || !$this->get('password'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->auth($this->get('username'), $this->get('password'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }

        //echo $data;
    }


    function vehicles_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_vehicles($this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }

        //echo $data;
    }
    
    
    function vehicle_details_get()
    {
        if(!$this->get('asset_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_vehicle_by_id( $this->get('asset_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }

    function gps_live_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_gps_live_data( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }


    function gps_live_refresh_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_gps_live_data( $this->get('company_id'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }

    function gps_vehicle_data_get()
    {
        if(!$this->get('device_id') && !$this->get('asset_id'))
        {
            $this->response('Parameters missing', 400);
        }
 
        $data = $this->itms_api_model->get_gps_vehicle_data ($this->get('asset_id'), $this->get('device_id'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }
    }

    function gps_vehicle_refresh_data_get()
    {
        if(!$this->get('device_id') && !$this->get('asset_id'))
        {
            $this->response('Parameters missing', 400);
        }
 
        $data = $this->itms_api_model->get_gps_vehicle_refresh_data ($this->get('asset_id'), $this->get('device_id'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }
    }

    function tpms_vehicle_data_get()
    {
        if(!$this->get('device_id') && !$this->get('asset_id'))
        {
            $this->response('Parameters missing', 400);
        }
 
        $data = $this->itms_api_model->get_tpms_vehicle_data ($this->get('asset_id'), $this->get('device_id'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }
    }

    function tpms_data_refresh_get()
    {
        if(!$this->get('device_id'))
        {
            $this->response('Parameters missing', 400);
        }
 
        $data = $this->itms_api_model->get_tpms_data ($this->get('device_id'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }
    }

	
    function alerts_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }

        if(!$this->get('user_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_alerts( $this->get('company_id'),  $this->get('user_id'));
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
             $this->response('No results', 404);
        }
    }
    
    
    function landmarks_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_landmarks( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response(NULL, 404);
        }
    }

    function zones_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_zones( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }

    function zones_vertices_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_zones_vertices( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }
    function personnel_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_personnel( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }

    function drivers_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_drivers( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }

    function owners_get()
    {
        if(!$this->get('company_id'))
        {
            $this->response(NULL, 400);
        }
 
        $data = $this->itms_api_model->fetch_owners( $this->get('company_id') );
         
        if($data)
        {
            $this->response($data, 200);
        }
 
        else
        {
            $this->response('No results', 404);
        }
    }
}