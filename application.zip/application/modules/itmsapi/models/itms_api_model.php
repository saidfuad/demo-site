<?php
class Itms_api_model extends CI_Model{
    
    var $company_id;
    var $current_time;


    function __construct () {
        parent::__construct();            
        
        $this->current_time = gmdate("Y-m-d H:i:s");
        $this->load->library('encrypt');
    }

    function auth($username, $password){
        $usernameExists = $this->check_user_name($username);
        $emailExists = $this->check_email($username);

        $encrypted_password = $this->encrypt->encode($password);

        if ($usernameExists) {
            $user_id = $usernameExists['user_id'];
            $company_id = $usernameExists['company_id'];
            $field_name = 'username';
        } else if ($emailExists) {
            $user_id = $emailExists['user_id'];
            $company_id = $emailExists['company_id'];
            $field_name = 'email_address';
        } else {
            return false;
            exit;
        }
        
        $user = $this->check_details('itms_users', $field_name, 'password', $username, $encrypted_password);
        $data = array();
        $data['company_id'] = $user['company_id'];
        $data['user_id'] = $user['user_id'];
        $data['protocal'] = $user['protocal'];
        $data['description']  = "Protocal field is the access level 7:for admin with all permissions; 5 for users with limited permissions on company profile";

        if ($user) {
            if ($this->encrypt->decode($user['password']) == $password) {
                return $data;
            } else {
                return false;
            }
        }

        return false;
    }

    public function check_user_name($user_name) {
        $res = $this->db->query("select * from itms_users where username='$user_name' and del_date is null and status=1");
        
        if($res->num_rows() > 0 ) {
            $row = $res -> row_array(); 
            return $row; 
        } else {
            return false;
        }
        
    }

    public function check_email($email) {
        $res = $this->db->query("select * from itms_users where email_address like '$email' and del_date is null and status=1");
        if($res->num_rows()>0) {
            $row = $res ->row_array(); 
            return $row; 
        } else {
            return $res->result();
        }
        
    }

    function check_details ($table, $user_field, $pass_field, $user_value, $pass_value){
        $this->db->select($table.'.*, itms_companies.company_name,itms_companies.company_logo,itms_companies.company_address_1,itms_companies.company_address_2,itms_companies.company_tel_1,itms_companies.company_tel_2,itms_companies.company_phone_no_1,itms_companies.company_phone_no_2,itms_companies.company_country_id,itms_companies.company_status,itms_companies.company_latitude,itms_companies.company_longitude, 
                                group_concat(itms_menu_permissions.menu_id) as itms_menu_permissions');
        $this->db->where($table.'.'.$user_field, $user_value);
        $this->db->where($table.'.status', 1);
        $this->db->where($table.'.del_date', NULL);
        $this->db->join('itms_companies', 'itms_companies.company_id='.$table.'.company_id', 'inner');
        $this->db->join('itms_menu_permissions', 'itms_menu_permissions.user_id='.$table.'.user_id', 'left');
        $query = $this->db->get($table);
        
        //return $this->db->last_query();
        //exit;
        if ($query->num_rows() == 1) {
            return $query->row_array();
        }
        else {
            return false;
        }
    }


    

    function fetch_vehicles ($company_id=null) {
	    $this->db->select('itms_assets.asset_id, itms_assets.device_id,itms_assets.assets_friendly_nm, 
                            itms_assets.assets_name, itms_assets.no_of_axles, itms_assets.no_of_tyres, 
                                    itms_assets.axle_tyre_config, itms_assets.paired, itms_assets.paired_asset_id,
                                    itms_assets.paired_asset_device_id, itms_assets.paired_asset_axles, itms_assets.paired_asset_axle_tyre_config, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name, itms_assets_categories.assets_cat_image, 
                                    itms_assets_types.assets_type_id, itms_assets_types.assets_type_nm, 
                                        itms_personnel_master.personnel_id AS driver_id, 
                                        CONCAT(itms_personnel_master.fname, " ", itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name, itms_assets.no_of_axles');
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
            

        
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }
	
	
        $this->db->where('itms_assets.del_date IS NULL');
        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
	
    }
     
    function fetch_vehicle_by_id ($asset_id) {
	    $this->db->select('itms_assets.asset_id, itms_assets.device_id,itms_assets.assets_friendly_nm, 
                            itms_assets.assets_name, itms_assets.no_of_axles, itms_assets.no_of_tyres, 
                                    itms_assets.axle_tyre_config, itms_assets.paired, itms_assets.paired_asset_id,
                                    itms_assets.paired_asset_device_id, itms_assets.paired_asset_axles, itms_assets.paired_asset_axle_tyre_config, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        CONCAT(itms_personnel_master.fname, " ", itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name');
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id','left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
        
        $this->db->where('asset_id', $asset_id);
       
        
        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();
       
        return $query->row_array();
    }

    function fetch_gps_live_data ($company_id=null, $owner_id=null, $type_id=null, $cat_id=null, $query=null) {
        $this->db->select('itms_assets.asset_id, itms_assets.assets_name, itms_last_gps_point.latitude, 
                                itms_last_gps_point.longitude, itms_last_gps_point.ignition,
                                    itms_last_gps_point.speed, itms_assets.runtime,
                                    itms_last_gps_point.address, itms_assets.no_of_axles, itms_assets.no_of_tyres, itms_assets.axle_tyre_config, itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_name, itms_last_gps_point.dt');
        $this->db->from('itms_last_gps_point')
            ->join('itms_assets', 'itms_assets.device_id=itms_last_gps_point.device_id','left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id','left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
        
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        if($owner_id!=null && $owner_id!=0) {
            $this->db->where('itms_assets.owner_id', $owner_id);
        }

        if($type_id!=null && $type_id!=0) {
            $this->db->where('itms_assets.assets_type_id', $type_id);
        }

        if($cat_id!=null && $cat_id!=0) {
            $this->db->where('itms_assets.assets_category_id', $cat_id);
        }

        if($query!=null && $query!="") {
            $this->db->like('itms_assets.assets_friendly_nm', $query, 'both');
            $this->db->or_like('itms_assets.assets_name', $query, 'both');
        }

        
        $query = $this->db->get();
       
         return $query->result();
    }

    function get_gps_vehicle_data ($asset_id=null, $device_id=null) {
        $this->db->select('itms_assets.asset_id, itms_assets.device_id, itms_assets.current_trip, itms_assets.current_route, itms_assets.assets_name, itms_assets.assets_friendly_nm,
                                itms_last_gps_point.latitude, itms_last_gps_point.longitude, itms_last_gps_point.ignition,
                                    itms_last_gps_point.speed, itms_assets.runtime,
                                    itms_last_gps_point.address, itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_name, itms_last_gps_point.dt, itms_trips.*');

        //, itms_routes.raw_route

        $this->db->from('itms_assets')
            ->join('itms_last_gps_point', 'itms_last_gps_point.device_id = itms_assets.device_id', 'left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id','left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left')
            ->join('itms_trips', 'itms_trips.trip_id = itms_assets.current_trip', 'left')
            ->join('itms_routes', 'itms_routes.route_id = itms_assets.current_route', 'left');
        
        if ($asset_id!=null || $asset_id!="") {
            $this->db->where('itms_assets.asset_id', $asset_id);
        } else if ($device_id!=null || $device_id!="") {
            $this->db->where('itms_assets.device_id', $device_id);
        }
        
        $query = $this->db->get();

        
        /*print_r('<pre>');
        print_r($query->row_array());
        exit;*/
        

        $res = array();
        
        $data = $query->row_array();
        $res['vehicle_info'] = $data;
        $device_id = $data['device_id'];
        $trip_id = $data['current_trip'];

        
        $res['gps_hist'] = $this->get_current_trip_points($device_id, $trip_id);

        return $res;
    }

    function get_current_trip_points($device_id, $trip_id) {
        $this->db->select('itms_gps_track_points.latitude, itms_gps_track_points.longitude, itms_gps_track_points.address');
        $this->db->from('itms_gps_track_points');
        $this->db->where('device_id', $device_id);
        $this->db->where('trip_id', $trip_id);

        $query = $this->db->get();

        return $query->result();
    }

     function get_gps_vehicle_refresh_data ($asset_id=null, $device_id=null) {
        $this->db->select('itms_last_gps_point.latitude, itms_last_gps_point.longitude, itms_last_gps_point.ignition,
                                    itms_last_gps_point.speed, itms_assets.runtime,
                                    itms_last_gps_point.address,itms_last_gps_point.dt');

        //, itms_routes.raw_route

        $this->db->from('itms_last_gps_point')
            ->join('itms_assets', 'itms_last_gps_point.device_id = itms_assets.device_id', 'left');
            
        if ($asset_id!=null || $asset_id!="") {
            $this->db->where('itms_assets.asset_id', $asset_id);
        } else if ($device_id!=null || $device_id!="") {
            $this->db->where('itms_assets.device_id', $device_id);
        }
        
        $query = $this->db->get();

        return $query->result();
    }

    function get_tpms_vehicle_data ($asset_id, $device_id) {
        $this->db->select('itms_assets.asset_id, itms_assets.device_id, itms_assets.assets_name, 
                                itms_assets.assets_friendly_nm, itms_assets.no_of_axles, itms_assets.no_of_tyres, 
                                    itms_assets.axle_tyre_config, itms_assets.paired, itms_assets.paired_asset_id,
                                    itms_assets.paired_asset_device_id, itms_assets.paired_asset_axles, itms_assets.paired_asset_axle_tyre_config,
                                    itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_name');
        $this->db->from('itms_assets')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
        
        $this->db->where('itms_assets.device_id', $device_id);
        $query = $this->db->get();

        /*print_r('<pre>');
        print_r($query->row_array());
        exit;*/       

        $res = array();        
        $data = $query->row_array();
        $res['vehicle_info'] = $data;
        
        $res['tpms_data'] = $this->get_tpms_data($device_id);

        return $res;
    }

    function get_tpms_data($device_id) {
        $this->db->select('itms_tpms_live.*');
        $this->db->from('itms_tpms_live')
            ->where('itms_tpms_live.device_id', $device_id); //Pick all towing vehicles, dont pull the trailers already paired
        $this->db->order_by('tyre_number', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }


    function fetch_landmarks ($company_id=null) {
            
        if ($company_id!=null) {
            $whereCompany = "AND company_id='".$company_id."'";
        }

        $q = "SELECT * 
                FROM itms_landmarks 
                WHERE 1
                AND status=1 
                    {$whereCompany}
                AND del_date is null ORDER BY landmark_name ASC ";

        $query = $this->db->query($q);
        return $query->result();
        
    }

    function fetch_zones ($company_id = null) {
        if($company_id != null) {
            $this->db->where('company_id', $company_id);
        }

        $this->db->where('status', 1);
        $this->db->where('del_date', NULL);

        $query = $this->db->get('itms_zones');

        return $query->result();
    }

    function fetch_zones_vertices ($company_id = null) {
        if($company_id != null) {
            $this->db->where('company_id', $company_id);
        }

        $query = $this->db->get('itms_zones_vertices');

        return $query->result();
    }

    function fetch_alerts ($company_id = null, $userid = null) {
        
        if ($userid!=null) {
           $current_user_id = $userid;
        }

       
        
        $whereUser='';
        $limit ='';
        $viewed = '';

        $query = $this->db->query("SELECT itms_alert_master.*, itms_assets.asset_id, itms_assets.assets_friendly_nm, itms_assets.assets_name, 
                                    CONCAT(itms_personnel_master.fname, ' ', itms_personnel_master.lname) as driver_name, itms_personnel_master.phone_no as driver_phone
                                    FROM 
                                        itms_alert_master
                                    LEFT JOIN itms_assets LEFT JOIN itms_personnel_master ON (itms_assets.personnel_id=itms_personnel_master.personnel_id) ON (itms_assets.asset_id=itms_alert_master.asset_id) 
                                    WHERE 
                                        itms_alert_master.del_date is null
                                    AND 
                                        itms_alert_master.company_id = $company_id
                                    AND 
                                        FIND_IN_SET(itms_alert_master.asset_id, (select group_concat(asset_id) from itms_alerts_contacts where user_id='$current_user_id'))
                                    {$viewed}
                                    OR 
                                        FIND_IN_SET(itms_assets.assets_group_id, (select group_concat(assets_group_id) from itms_assigned_groups where user_id='$current_user_id'))
                                    OR  
                                        FIND_IN_SET(itms_alert_master.asset_id, (select group_concat(asset_id) from itms_alerts_contacts where user_id='$current_user_id'))
                                    ORDER BY 
                                        id DESC {$limit}");
        
        return $query->result();
        
    }

    function fetch_personnel ($company_id=null, $role_id=null, $user_id=null){
        $whereCompany ='';
        $whereUser = "";
        $whereRole = "";
        if ($company_id!=null) {
            $whereCompany = " AND itms_personnel_master.company_id = '".$company_id."' ";
        }

        if ($user_id!=null) {
            $whereUser = " AND itms_personnel_master.add_uid = '".$user_id."' ";
        }

        if ($role_id!=null) {
            $whereRole = " AND itms_personnel_master.role_id = '".$role_id."' ";
        }

        $SQL="SELECT itms_personnel_master.*, itms_roles.role_name from itms_personnel_master 
                INNER JOIN 
                    itms_roles ON(itms_personnel_master.role_id = itms_roles.role_id) 
                    WHERE 1 
                        {$whereCompany} 
                        {$whereUser} 
                        {$whereRole}";

        $rarr=$this->db->query($SQL);
        return $rarr->result();
    }

    function fetch_drivers ($company_id=null) {
        
	$this->db->select('itms_personnel_master.*, itms_roles.role_name');
        $this->db->from('itms_personnel_master')
                ->join('itms_roles', 'itms_roles.role_id=itms_personnel_master.role_id')
                ->where('itms_roles.role_name', 'driver');

                if ($company_id!=null) {
                    $this->db->where('itms_personnel_master.company_id', $company_id);
                }

        $this->db->order_by('fname', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function fetch_owners ($company_id=null) {
        $this->db->select('itms_owner_master.*');
        $this->db->from('itms_owner_master');
        $this->db->where('itms_owner_master.del_date IS NULL');
        
           if ($company_id!=null) {
                $this->db->where('itms_owner_master.company_id', $company_id);
           }

        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

}