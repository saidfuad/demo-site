<input id="credit_farmers_cash" hidden/>
<input id="credit_farmers_cash2" class="form-control" />

<div class="cont-holder">
    <ul id="farmers-list" style="display: none; padding-top: 10px; padding-right: 5px; width: 100%; overflow: hidden; cursor: pointer">
    <?php
    foreach($all_credit_farmers as $row) {
        echo "<li onclick='farmerClicked(this.id,this.title)' id='" . $row['fid'] . "'
        title='".$row['fname'] . " " . $row['lname']."'>" . $row['fname'] . "
        " . $row['lname'] . " " . $row['gen_id'] . "</li>";
        }
    ?>
    </ul>
</div>
<script>

$('#credit_farmers_cash2').on('keyup', function () {
    var value = $(this).val().trim();
    $('#farmers-list').show();
    $("#farmers-list >li").each(function () {
        if($(this).text().toLowerCase().search(value) > -1) {
            $(this).show();
        }
        else {
            $(this).hide();
        }
    });
});

function farmerClicked(fid,value) {
// alert(value);
    $("#credit_farmers_cash2").val(value);

    $("#credit_farmers_cash").val(fid);
    $('#farmers-list').hide();
}
</script>