<script type="text/javascript">
  var infowindow;
  var vehicle_markers = [];
  var landmark_markers = [];
  var pop_marker = [];
  var map_pop;
  var map;
  var iw_map;
  var zones = [];
  var routes = [];
  var directionsService;
  var directionsDisplay;
  var vehiclePath;
  var vehiclePaths = [];
  var apiKey = 'AIzaSyBn6m_W3hRMPg5nDlmqsRkaO3kE1LZ1HX4';
  //local : AIzaSyBn6m_W3hRMPg5nDlmqsRkaO3kE1LZ1HX4
  //remote : AIzaSyCfKP5H8r9ohlPjH_CbddIefMbeCirz7-U

 

  function initMap() {
    map = new google.maps.Map(document.getElementById('map_canvas'), {
      center: {lat: <?= $map_lat; ?>, lng: <?= $map_long; ?>},
      zoom: 18,
      mapTypeId: google.maps.MapTypeId.HYBRID,
      heading: 90,
      tilt: 45
    });

        


     iw_map = new google.maps.InfoWindow({
        content: ''
      });

      infowindow = new google.maps.InfoWindow({
        content: ''
      });

    

     load_landmarks();

     load_zones();

     //load_routes();

  }

  function load_landmarks () {
         $.ajax({
            type: "POST",
            url: "<?php echo base_url('index.php/settings/get_company_landmarks') ?>",
            data : {company:'this company'},
            success: function(data) {
                landmarks = JSON.parse(data);

                //alert(landmarks.length);
                if(landmarks.length > 0) { 
                  for (var row in landmarks) {
                        if(landmarks[row].gmap_icon == 0) {
                            $icon = "<?= base_url('" + landmarks[row].icon_path+ "')?>";
                        } else {
                            $icon = landmarks[row].icon_path;
                        }
                    $pos = {lat:parseFloat(landmarks[row].latitude, 10), lng: parseFloat(landmarks[row].longitude)};
                    //console.log(parseInt(landmarks[row].latitude, 10));
                      landmark_markers.push(new google.maps.Marker({
                            position: $pos,
                            map: map,
                            icon: $icon, 
                            content:landmarks[row].landmark_name,
                            scaledSize: new google.maps.Size(20, 20),
                      }));
                  }

                  var llength =landmark_markers.length;

                  for (var i=0; i<llength; i++) { 
                          landmark_markers[i].setIcon(({
                            url:landmark_markers[i].icon,
                            size: new google.maps.Size(71, 71),
                            origin: new google.maps.Point(0, 0),
                            anchor: new google.maps.Point(12, 24),
                            scaledSize: new google.maps.Size(24, 24)
                          }));

                      google.maps.event.addListener(landmark_markers[i], "mouseout", function(event) {
                        iw_map.close();
                      });

                      google.maps.event.addListener(landmark_markers[i], "click", function(event) {
                        map.setCenter(this.getPosition());
                        map.setZoom(15);
                        map.setTilt(45);

                        console.log(event.latLng.lat() +',' + event.latLng.lng());
                        
                      });
                      
                      google.maps.event.addListener(landmark_markers[i], "mouseover", function(event) {
                          iw_map.setContent(this.get("content"));
                          iw_map.open(map, this);
                      });

                  }
              } 

            }
        });
  }

  function load_zones () {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('index.php/gps_tracking/get_company_zones') ?>",
            data : {company:'this company'},
            success: function(data) {
                data = JSON.parse(data);
                mapCords = [];

                size_zones = data.zones.length;
                size_vertices = data.vertices.length


                if (size_zones > 0) {
                  for (var zone in data.zones) {
                    
                    var zona = [];
                    for (var vertex in data.vertices) {
                       if (data.vertices[vertex].zone_id == data.zones[zone].zone_id) {
                            //$zona.push({lat:data.vertices[vertex].latitude, lng:data.vertices[vertex].longitude});
                            zona.push(new google.maps.LatLng(
                                        parseFloat(data.vertices[vertex].latitude),
                                        parseFloat(data.vertices[vertex].longitude)
                                ));
                       }

                        mapCords.push(new google.maps.LatLng(
                            parseFloat(data.vertices[vertex].latitude),
                            parseFloat(data.vertices[vertex].longitude)
                        ));
                    }

                    zones.push( new google.maps.Polygon({
                                  paths: zona,
                                  strokeColor: data.zones[zone].zone_color,
                                  strokeOpacity: 0.8,
                                  strokeWeight: 2,
                                  fillColor: data.zones[zone].zone_color,
                                  fillOpacity: 0.35,
                                  zone:data.zones[zone].zone_name,
                                  address: data.zones[zone].address 
                                }));

                     zones[zones.length-1].setMap(map);

                      google.maps.event.addListener(zones[zones.length-1], 'mouseover', function(event) {
                        var contentString = "<strong>Zone</strong>:" + this.zone + "<br><strong>Address</strong>: " + this.address;
                        //alert(contentString);
                        iw_map.setContent(contentString);
                        iw_map.setPosition(event.latLng);
                        iw_map.open(map);
                      });

                      google.maps.event.addListener(zones[zones.length-1], 'mouseout', function(event) {
                        iw_map.close();
                      });

                  }

              }
            }
        });
    }

  function load_routes () {

      $.ajax({
            type: "POST",
            url: "<?php echo base_url('index.php/gps_tracking/get_company_map_display_routes') ?>",
            data : {company:'this company'},
            success: function(data) {
                response = JSON.parse(data);

                for (var row in response) {
                  //alert(JSON.parse(response[row].raw_route));
                  $route = response[row].raw_route;
                  if ($route.length !=0) {
                      directionsDisplay.setDirections(JSON.parse($route));
                  }
                  
                }

                //directionsDisplay.setDirections(response);
            }
            });


      return false;    
  }


  function rotate90 () {
    var heading = map.getHeading() || 0;
    map.setHeading(heading + 90);
  }

  function autoRotate() {
    // Determine if we're showing aerial imagery.
    if (map.getTilt() !== 0) {
      window.setInterval(rotate90, 3000);
    }
  }




</script>

<style type="text/css">
  #map-pop {
    display:none;
    display:none;
    position:fixed;
    right:50px;
    top:55px;
    left:300px;
    width:55%;
    border: 1px solid #303641;
    /*border:2px solid #eee;*/
    z-index:3000;
    border-radius:0px;
    background: #fff;
    border-radius:5px;
  }
  .live-vehicle-list {
    width:100%;
    background:;
    padding:0px;
  }

  

  .live-vehicle-list li:first-child {
    border-top: 1px solid #ddd;
  }
  .live-vehicle-list li {
      height:30px;
      border-bottom:1px solid #ddd;
      list-style-type:none;
      width:100%;
      overflow-y:hidden;
      vertical-align:middle;
      padding:5px 5px 5px 10px;
      color:#333;
      cursor: pointer;
      font-size:13px;
  }
  .live-vehicle-list li:hover {
      background:#f5f5f5;
      color:#333;
  }
  .live-vehicle-list li a{
      text-decoration: none;
      color:#fff;
  }

  .blinking-toggle {
    background:#18bc9c !important;
  }

  .more {
    background-color: #18bc9c;
    color: #fff;
    border: solid 2px #eee;
    width: 260px;
    border-radius: 5px;
    text-transform: uppercase;
    text-underline-position: left;
    margin-top: 7px;
    padding: 5px;
    /*padding-bottom: 5px;*/
  }

</style>

<?php foreach ($vehicle as $value) { ?>

<div class="container-fluid fleet-view">
    <div class="row" ng-app>
        <!-- Sidebar -->
        <!--div class="col-md-3 fleet-sidebar">
            <div class="panel fleet-panel panel-blockquote panel-border-info right">
                <div class="panel-body">
                
                    <!-- Car image -->
                    <!--div class="text-center fleet-img">
                        <img width="200" height="200" src="../../../uploads/vehicles/128/<?php echo $value->vehicle_image ?>" alt="" class="img-rounded">
                    </div>
                    
                    <!-- Title/Car name -->
                    <!--h3 class="sidebar-title text-center"><?php echo $value->assets_friendly_nm; ?></h3>


                </div>
            </div>
        </div-->
        <!-- Sidebar -->
           <!-- Content -->
        <div class="col-md-12 fleet-content">
            <!-- Content Panel -->
            <div class="panel fleet-panel  panel-info panel-blockquote">
                <div class="panel-body">
                    <!-- Fleet title -->
                    <h1 id="fleet-car-title"><i class="fa fa-car"></i> <?php echo $value->assets_friendly_nm; ?></h1>
                    <div class="separator bottom"></div>

                    <!-- Details Content -->
                    <div class="row">
                        <div class="col-md-4">
                            <!-- Details -->
                            <div class="panel panel-blockquote panel-border-success left" id="fleet-car-details">
                                <div class="panel-heading">
                                    <h3 class="panel-title" style="color: #fff; margin-top: 3px"><i class="fa fa-info-circle fa-fw"></i> Details</h3>
                                    <!-- Panel Menu -->
                                    <!--<div class="panel-menu">
                                        <button type="button" data-action="minimize" class="btn btn-default btn-action btn-xs tooltips hidden-xs hidden-sm" data-original-title="Minimize" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-angle-down"></i></button>
                                        <button type="button" data-action="reload" class="btn btn-default btn-action btn-xs tooltips" data-original-title="Reload" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-refresh"></i></button>
                                        <button type="button" data-action="settings" class="btn btn-default btn-action btn-xs tooltips dropdown-toggle hidden-xs hidden-sm" data-toggle="dropdown" data-original-title="" title=""><i class="fa fa-cog"></i></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="#"><i class="fa fa-comment"></i> Add a note</a></li>
                                            <li><a href="#"><i class="fa fa-tasks"></i> Add to Tasks</a></li>
                                            <li><a href="#"><i class="fa fa-map-marker"></i> Pin to TaskBar</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#"><i class="fa fa-refresh"></i> Reload Content</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#"><i class="fa fa-bell"></i> Alert(s) <input type="checkbox" class="switcher pull-right" /></a></li>
                                            <li><a href="#"><i class="fa fa-lock"></i> Privacy <input type="checkbox" class="switcher pull-right" checked /></a></li>
                                        </ul>
                                        <button type="button" data-action="close" class="btn btn-warning btn-action btn-xs tooltips" data-original-title="Remove" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-times"></i></button>
                                    </div>-->
                                    <!-- Panel Menu -->
                                </div>
                                <div class="panel-body">
                                    <table class="table table-striped table-hover">
                                        <tbody>
                                            <tr>
                                            <td>
                                                <div class="text-left fleet-img">
                                                <img width="50" height="50" src="../../../uploads/vehicles/64/<?php echo $value->vehicle_image ?>" alt="" class="img-rounded">
                                                </div>
                                            </td>
                                            <td>
                                                <n>Owner: </n>
                                                <b><?php echo $value->owner_name; ?></b><br>
                                                <n>Plate No.: </n>
                                                <b><?php echo $value->assets_name; ?></b>
                                            </td>
                                                
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left"><b></b></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Date Added</td>
                                                <td><?php echo $value->add_date; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left col-md-3">Name</td>
                                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Category</td>
                                                <td><?php echo $value->assets_cat_name; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Type</td>
                                                <td><?php echo $value->assets_type_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left col-md-3">Driver</td>
                                                <td><?php if (strlen($value->driver_name)!=0 || $value->driver_name != 0) {echo $value->driver_name;} else { echo 'Not Assigned';} ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Driver Phone</td>
                                                <td><?php echo "+254".$value->phone_no; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Device ID</td>
                                                <td><?php if (strlen($value->device_id)!=0) {echo $value->device_id;} else { echo 'Not Set';} ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Device S/N</td>
                                                <td><?php echo $value->serial_no; ?></td>
                                            </tr>
                                            <!-- <tr>
                                                <td class="text-muted text-left">Make</td>
                                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">NO. Of tyres</td>
                                                <td>
                                                    <small><?php echo $value->no_of_tyres; ?></small>
                                                </td>
                                            </tr> -->
                                            <!-- <tr>
                                                <td class="text-muted text-left">License Plate</td>
                                                <td><?php echo $value->assets_name; ?></td>
                                            </tr> -->
                                            <!-- <tr>
                                                <td class="text-muted text-left">Max Speed</td>
                                                <td><?php echo $value->max_speed_limit; ?></td>
                                            </tr> -->
                                            <!-- <tr>
                                                <td class="text-muted text-left">Max Fuel Capacity</td>
                                                <td><?php echo $value->max_fuel_capacity; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Max Fuel Litres</td>
                                                <td><?php echo $value->max_fuel_liters; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-left">Fuel Type</td>
                                                <td><span class="text-muted">Not Set</span></td>
                                            </tr> -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-md-8">
                            <!-- Stats -->

                            <div class="row">
                                <!-- Service Reminders -->
                                <div class="col-md-12">
                                    <div class="panel panel-square">
                                        <div class="panel-heading panel-info clearfix">
                                            <h3 class="panel-title">Current Location</h3>
                                        </div>
                                        <div class="panel-body fleet-issues">
                                            <div class="row">
                                                <div class="col-sm-12 map-zone" id="map-zone" style="height:300px;">
                            
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <!-- Renewal Reminders -->
                                <div class="col-md-6">
                                    <div class="panel panel-square">
                                        <div class="panel-heading panel-info clearfix">
                                            <h3 class="panel-title">Maximum Speed</h3>
                                        </div>
                                        <div class="panel-body fleet-issues">
                                            <div class="row">
                                                <div class="col-sm-4 text-center">
                                                    <b><h1 class="success">
                                                        <?php
                                                        if($max_day['max_speed_today'] > 0){
                                                            echo $max_day['max_speed_today'];
                                                        }else{
                                                            echo 0;
                                                        }
                                                        ?>
                                                        <small> km/h</small></h1>
                                                    <span class="caption">Today</span></b>
                                                </div>
                                                <div class="col-sm-4 text-center">
                                                    <b><h1 class="success">
                                                        <?php
                                                            if($max_week['max_speed_week'] > 0){
                                                                echo $max_week['max_speed_week'];
                                                        }else{
                                                              echo 0;
                                                            }
                                                        ?>
                                                        <small> km/h</small></h1>
                                                    <span class="caption">Weekly</span></b>
                                                </div>
                                                <div class="col-sm-4 text-center">
                                                    <b><h1 class="success">
                                                        <?php
                                                            if($max_month['max_speed_month'] > 0){
                                                                echo $max_month['max_speed_month'];
                                                        }else{
                                                              echo 0;
                                                            }
                                                        ?>
                                                        <small> km/h</small></h1>
                                                    <span class="caption">Monthly</span></b>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Renewal Reminders -->
                                <div class="col-md-6">
                                    <div class="panel panel-square">
                                        <div class="panel-heading panel-info clearfix">
                                            <h3 class="panel-title">Distance Travelled</h3>
                                        </div>
                                        <div class="panel-body fleet-issues">
                                            <div class="row">
                                                <div class="col-sm-4 text-center">
                                                    <b><h1 class="success">
                                                        <?php
                                                            if($max_day['distance_today'] > 0){
                                                                echo $max_day['distance_today'];
                                                        }else{
                                                              echo 0;
                                                            }
                                                        ?>
                                                        <small> km</small></h1>
                                                    <span class="caption">Today</span></b>
                                                </div>
                                                <div class="col-sm-4 text-center">
                                                    <b><h1 class="success">
                                                        <?php
                                                            if($max_week['distance_week'] > 0){
                                                                echo $max_week['distance_week'];
                                                        }else{
                                                              echo 0;
                                                            }
                                                        ?>
                                                        <small> km</small></h1>
                                                    <span class="caption">Weekly</span></b>
                                                </div>
                                                <div class="col-sm-4 text-center">
                                                    <b><h1 class="success">
                                                        <?php
                                                            if($max_month['distance_month'] > 0){
                                                                echo $max_month['distance_month'];
                                                        }else{
                                                              echo 0;
                                                            }
                                                        ?>
                                                        <small> km</small></h1>
                                                    <span class="caption">Monthly</span></b>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-square" id="fleet-car-stats">
                                <div class="panel-heading panel-info clearfix">
                                    <h3 class="panel-title">Stats</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="media media-info">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-road"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading">
                                                        <?php
                                                            if($vehicle_top_speed['top_speed'] > 0){
                                                                echo $vehicle_top_speed['top_speed'];
                                                            }else{
                                                                echo 0;
                                                            }
                                                        ?>
                                                        <small> km/h</small>
                                                    </div>
                                                    <div class="caption">Vehicle Top Speed</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="media media-warning">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-tint"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading"><?php echo $value->max_fuel_liters; ?></div>
                                                    <div class="caption">Maximum Fuel Litres</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="media media-info">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-wrench"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading">Trips</div>
                                                    <?php if ($value->no_of_trips > 0) {?>
                                                    <div class="caption"><a href="<?php echo base_url('index.php'); echo "/trips/fetch_trips/$value->asset_id" ?>"><?php echo $value->no_of_trips; ?> View Trips</a></div>
                                                    <?php }else{ ?>
                                                    <div class="caption">No Trips</div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="media media-danger">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-tint"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading"><?php echo $value->no_of_tyres; ?> tyres</div>
                                                    <div class="caption"><a href="<?php echo base_url('index.php/tms'); echo "/assign_tyre?asset=$value->asset_id" ?>">Assign Tyres</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Issues -->

                            <!--<div class="panel panel-square">
                                <div class="panel-heading panel-info clearfix">
                                    <h3 class="panel-title">Issues</h3>
                                </div>
                                <div class="panel-body fleet-issues">
                                    <div class="row">
                                        <div class="col-sm-4 text-center">
                                            <h1 class="success">5</h1>
                                            <span class="caption">Open</span>
                                        </div>
                                        <div class="col-sm-4 text-center">
                                            <h1 class="success">0</h1>
                                            <span class="caption">Overdue</span>
                                        </div>
                                        <div class="col-sm-4 text-center">
                                            <h1 class="info">3</h1>
                                            <span class="caption">Resolved</span>
                                        </div>
                                    </div>
                                </div>
                            </div>-->


                        </div>
                    </div>
<?php }?>
                </div>
            </div>
        </div>
        <!-- //. Content -->
    </div>
    <!-- /.row -->
</div>
