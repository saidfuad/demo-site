<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css') ?>" rel="stylesheet" />

<script>

    // Run on page load
    window.onload = function() {

        var vehname = sessionStorage.getItem('vehname');
        var plate = sessionStorage.getItem('plate');
        var vehtypeid = sessionStorage.getItem('vehtypeid');
        var vehtype = sessionStorage.getItem('vehtype');
        var vehcatid = sessionStorage.getItem('vehcatid');
        var vehcat = sessionStorage.getItem('vehcat');
        var ownerid = sessionStorage.getItem('ownerid');
        var owner = sessionStorage.getItem('owner');
        var personid = sessionStorage.getItem('personid');
        var person = sessionStorage.getItem('person');

        if (vehname != null) $('#assets_friendly_nm').val(vehname);
        if (plate != null) $('#assets_name').val(plate);
        if (vehtypeid != null) $('#assets_type_id').val(vehtypeid);
        if (vehtype != null) $('#assets_type').val(vehtype);
        if (vehcatid != null) $('#assets_category_id').val(vehcatid);
        if (vehcat != null) $('#assets_category').val(vehcat);
        if (ownerid != null) $('#owner_id').val(ownerid);
        if (owner != null) $('#owners').val(owner);
        if (personid != null) $('#personnel_id').val(personid);
        if (person != null) $('#personnel').val(person);

    }

</script>

<div class="container-fluid">
    <div class="row">
        <form id="add-vehicle-form">
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Basic Details (<span style="text-transform:lowercase"><sup title="Required field">*</sup> Required fields</span>)
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label for="reservation">Vehicle Name <sup title="Required field">*</sup>:</label>
                            <input class="form-control" type="text" name="assets_friendly_nm" id="assets_friendly_nm" />
                        </div>
                        <div class="form-group">
                            <label for="reservation">Plate Number <sup title="Required field">*</sup>:</label>
                            <input class="form-control" type="text" name="assets_name" id="assets_name" />
                        </div>
                        <script>

                            $('#assets_friendly_nm').on('focus', function(){
								$('.assets_type_holder').hide();
								$('.assets_category_holder').hide();
								$('.owners_holder').hide();
								$('.personnel_holder').hide();
							});

							$('#assets_name').on('focus', function(){
								$('.assets_type_holder').hide();
								$('.assets_category_holder').hide();
								$('.owners_holder').hide();
								$('.personnel_holder').hide();
							});

                        </script>

                        <div class="form-group">
                            <input id="assets_type_id" name="assets_type_id" hidden="true" />
                            <label class="control-lable">Vehicle Type</label>
                            <input id="assets_type" class="form-control" />

                            <div class="assets_type_holder">
                                <ul id="types-list">

                                    <?php
                                    if ($all_types == null) {
                                        ?> <script>$('#types-list').show();$('.assets_type_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Types Found</li>";

                                        // echo $value->driver_name;
                                    } else {
                                        foreach ($all_types as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;' onclick='typeClicked(this.id,this.title)' class='types' id='" . $row['assets_type_id'] . "'
							        title='" . $row['assets_type_nm'] . "'>" . $row['assets_type_nm'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#assets_type').on('focus', function () {
                                    $('.assets_category_holder').hide();
                                    $('.owners_holder').hide();
                                    $('.personnel_holder').hide();
                                });

                                $('#assets_type').on('keydown', function () {
                                    $('#types-list').show();
                                    $('.assets_type_holder').show();
                                });

                                $('#assets_type').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    if (value.length == 0) {
                                        $("#assets_type_id").val("");
                                        $('.assets_type_holder').hide();
                                    }


                                    $('.dp-down').hide();
                                    $('#types-list').show();
                                    $("#types-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function typeClicked(assets_type, value) {
                                    // alert(value);
                                    $("#assets_type").val(value);
                                    $("#assets_type_id").val(assets_type);
                                    $("#assets_type").focus();
                                    $('#types-list').hide();
                                }
                            </script>
                        </div>
                        <!-- <div class="form-group">
                            <label for="reservation">Vehicle Category <sup title="Required field">*</sup>:</label>
                            <select class="form-control" name="assets_category_id" id="assets_category_id">
                                    <option value="0">--Select--</option>
                        <?php echo $categoryOpt; ?>
                                                    </select>
                        </div> -->

                        <div class="form-group">
                            <input id="assets_category_id" name="assets_category_id" hidden="true" />
                            <label class="control-lable">Vehicle Category</label>
                            <input id="assets_category" class="form-control" />

                            <div class="assets_category_holder">
                                <ul id="category-list">

                                    <?php
                                    if ($all_categories == null) {
                                        ?> <script>$('#category-list').show();$('.assets_category_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Categories Found</li>";

                                        // echo $value->driver_name;
                                    } else {
                                        foreach ($all_categories as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='categoryClicked(this.id,this.title)' class='types' id='" . $row['assets_category_id'] . "'
							        title='" . $row['assets_cat_name'] . "'>" . $row['assets_cat_name'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#assets_category').on('focus', function () {
                                    $('.assets_type_holder').hide();
                                    $('.owners_holder').hide();
                                    $('.personnel_holder').hide();
                                });

                                $('#assets_category').on('keydown', function () {
                                    $('#category-list').show();
                                    $('.assets_category_holder').show();
                                });

                                $('#assets_category').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    $('.dp-down').hide();

                                    if (value.length == 0) {
                                        $('#assets_category_id').val("");
                                        $('.assets_category_holder').hide();
                                    }

                                    $('#category-list').show();
                                    $("#category-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function categoryClicked(assets_category, value) {
                                    // alert(value);
                                    $("#assets_category").val(value);
                                    $("#assets_category_id").val(assets_category);
                                    $("#assets_category").focus();
                                    $('#category-list').hide();
                                }
                            </script>
                        </div>
                        <!-- <div class="form-group">
                            <label for="reservation">Owner <sup title="Required field">*</sup>:</label>
                            <select class="form-control" name="owner_id" id="owner_id">
                                    <option value="0">--Select--</option>
                        <?php echo $ownerOpt; ?>
                                                    </select>
                        </div> -->
                        <div class="form-group">
                            <input id="owner_id" name="owner_id" hidden="true" />
                            <label class="control-lable">Assign Owner</label>
                            <input id="owners" class="form-control" />
                            <button type="button" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#newOwner">New Owner
                                <span class='fa fa-plus'></span>
                            </button>

                            <div class="owners_holder">
                                <ul id="owners-list">

                                    <?php
                                    if ($all_owners == null) {
                                        ?> <script>$('#owners-list').show();$('.owners_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Owners Found</li>";
                                    } else {
                                        foreach ($all_owners as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='ownersClicked(this.id,this.title)' class='types' id='" . $row['owner_id'] . "'
							        title='" . $row['owner_name'] . "'>" . $row['owner_name'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#owners').on('focus', function () {
                                    $('.assets_category_holder').hide();
                                    $('.assets_type_holder').hide();
                                    $('.personnel_holder').hide();
                                });

                                $('#owners').on('keydown', function () {
                                    $('#owners-list').show();
                                    $('.owners_holder').show();
                                });

                                $('#owners').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    $('.dp-down').hide();

                                    if (value.length == 0) {
                                        $('#owner_id').val("");
                                        $('.owners_holder').hide();
                                    }


                                    $('#owners-list').show();
                                    $("#owners-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function ownersClicked(owners, value) {
                                    // alert(owners);
                                    $("#owners").val(value);
                                    $("#owner_id").val(owners);
                                    $("#owners").focus();
                                    $('#owners-list').hide();
                                }
                            </script>
                        </div>
                        <!-- <div class="form-group">
                            <label for="reservation">Assign Driver:</label>
                            <select class="form-control" name="personnel_id" id="personnel_id">
                                    <option value="0">--Select--</option>
                        <?php echo $driverOpt; ?>
                                                    </select>
                        </div> -->

                        <div class="form-group">
                            <input id="personnel_id" name="personnel_id" hidden="true" />
                            <label class="control-lable">Assign Driver</label>
                            <input id="personnel" class="form-control" />
                            <button type="button" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#newDriver">New Driver
                                <span class='fa fa-plus'></span>
                            </button>

                            <div class="personnel_holder">
                                <ul id="personnel-list">
                                    <?php
                                    if ($all_drivers == null) {
                                        ?> <script>$('#personnel-list').show();$('.personnel_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Drivers Found</li>";
                                    } else {
                                        foreach ($all_drivers as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='driverClicked(this.id,this.title)' class='types' id='" . $row['personnel_id'] . "'
							        title='" . $row['driver_name'] . "'>" . $row['driver_name'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#personnel').on('focus', function () {
                                    $('.assets_category_holder').hide();
                                    $('.assets_type_holder').hide();
                                    $('.owners_holder').hide();
                                });

                                $('#personnel').on('keydown', function () {
                                    $('#personnel-list').show();
                                    $('.personnel_holder').show();
                                });

                                $('#personnel').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    $('.dp-down').hide();

                                    if (value.length == 0) {
                                        $('#personnel_id').val("");
                                        $('.personnel_holder').hide();
                                    }

                                    $('#personnel-list').show();
                                    $("#personnel-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function driverClicked(personnel, value) {
                                    // alert(value);
                                    $("#personnel").val(value);
                                    $("#personnel_id").val(personnel);
                                    $("#personnel").focus();
                                    $('#personnel-list').hide();
                                }
                            </script>
                        </div>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Vehicle Settings
                    </div>
                    <div class="panel-body">

                        <div class="form-group">
                            <label for="reservation">Odometer Reading:</label>
                            <input class="form-control" type="number" name="km_reading" id="km_reading" />
                        </div>
                        <div class="form-group">
                            <label for="reservation">Maximum Fuel Liters:</label>
                            <input class="form-control" type="number" name="max_fuel_liters" id="max_fuel_liters"/>
                        </div>
                        <div class="form-group">
                            <label for="reservation">Maximum Speed Limit:</label>
                            <input class="form-control" type="number" name="max_speed_limit" id="max_speed_limit"/>
                        </div>

                    </div>
                </div>
                <div class="panel-footer " align="right">
                    <button class="btn btn-primary" type="submit" id="save-vehicle">Save </button>
                </div>


            </div>
        </form>
        <div class="col-md-6 col-lg-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Upload Vehicle Image
                </div>
                <div class="panel-body">
                    <div id="dropzone">
                        <form action="<?php echo base_url('index.php/upload_images/upload_vehicle_image') ?>" class="dropzone" id="dropzone-container">
                            <div class="fallback">
                                <input name="file" type="file" multiple />
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-12 bg-crumb" align="center">
                <h2><i class="fa fa-car"></i> Vehicles</h2>
                <br>
                <p>Manage Vehicles and begin monitoring your assets Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

                <a href="<?php echo site_url('vehicles'); ?>" class="btn btn-success">View Vehicles</a>	
            </div>

        </div>

    </div>
</div> 

<?php include("new_owner.php"); ?>
<?php include("new_driver.php"); ?>

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js') ?>"></script>  

<script>

    $(function () {

        $('#add-vehicle-form').on('submit', function () {

            var $this = $(this);

            if ($('#assets_friendly_nm').val().trim().length == 0 || $('#assets_name').val().trim().length == 0 ||
                    $('#assets_type_id').val().trim() == 0 || $('#assets_category_id').val().trim() == 0 ||
                    $('#owner_id').val().trim() == 0) {
                swal({title: "Info", text: "Fill in all required fields ( * )", type: "info", confirmButtonText: "ok"});
                return false;
            }

            $('#save-vehicle').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-vehicle').prop('disabled', true);

            swal({
                title: "Info",
                text: "Add Vehicle?",
                type: "info",
                showCancelButton: true,
                closeOnConfirm: false,
                allowOutsideClick: false,
                showLoaderOnConfirm: true
            }, function () {
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/vehicles/save_vehicle') ?>',
                    data: $this.serialize(),
                    success: function (response) {
                        if (response == 1) {
                            $('#add-vehicle-form').find('input[type="text"]').val('');
                            $('#add-vehicle-form').find('select').val(0);

                            sessionStorage.setItem('vehname', $('#assets_friendly_nm').val());
                            sessionStorage.setItem('plate', $('#assets_name').val());
                            sessionStorage.setItem('vehtypeid', $('#assets_type_id').val());
                            sessionStorage.setItem('vehtype', $('#assets_type').val());
                            sessionStorage.setItem('vehcatid', $('#assets_category_id').val());
                            sessionStorage.setItem('vehcat', $('#assets_category').val());
                            sessionStorage.setItem('ownerid', $('#owner_id').val());
                            sessionStorage.setItem('owner', $('#owners').val());
                            sessionStorage.setItem('personid', $('#personnel_id').val());
                            sessionStorage.setItem('person', $('#personnel').val());

                            swal({title: "Info", text: "Saved successfully", type: "success", confirmButtonText: "ok"});
                        } else if (response == 0) {
                            swal({title: "Error", text: "Failed, Try again later", type: "error", confirmButtonText: "ok"});
                        } else if (response == 77) {
                            swal({title: "Info", text: "A vehicle with that plate number already exists", type: "error", confirmButtonText: "ok"});
                        }

                        $('#save-vehicle').html('Save');
                        $('#save-vehicle').prop('disabled', false);
                    }
                });
            });

            $('#save-vehicle').html('Save');
            $('#save-vehicle').prop('disabled', false);

            return false;
        });

    });
</script> 
