<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-vehicle-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Basic Details (<span style="text-transform:lowercase"><sup title="Required field">*</sup> Required fields</span>)
	                </div>
	                <div class="panel-body">
	                    
	                    <input class="form-control" type="hidden" name="asset_id" id="asset_id" value="<?php echo $vehicle['asset_id']; ?>" />
	                    <div class="form-group">
	                        <label for="reservation">Vehicle Name <sup title="Required field">*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_friendly_nm" id="assets_friendly_nm" value="<?php echo $vehicle['assets_friendly_nm']; ?>" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Plate Number <sup title="Required field">*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_name" id="assets_name" value="<?php echo $vehicle['assets_name']; ?>" />
	                    </div>

	                    <script>
	                    	$('#assets_friendly_nm').on('focus', function(){
								$('.assets_type_holder').hide();
								$('.assets_category_holder').hide();
								$('.owners_holder').hide();
								$('.personnel_holder').hide();
							});

							$('#assets_name').on('focus', function(){
								$('.assets_type_holder').hide();
								$('.assets_category_holder').hide();
								$('.owners_holder').hide();
								$('.personnel_holder').hide();
							});
	                    </script>

	                    <div class="form-group">
	                    	<input id="assets_type_id" name="assets_type_id" hidden="true" value="<?php echo $vehicle['assets_type_id']; ?>" />
	                    	<label class="control-lable">Vehicle Type</label>
							<input id="assets_type" class="form-control" value="<?php echo $vehicle['assets_type_nm']; ?>"/>

							<div class="assets_type_holder">
                                <ul id="types-list">

                                    <?php
                                    if ($all_types == null) {
                                        ?> <script>$('#types-list').show();$('.assets_type_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Types Found</li>";

                                        // echo $value->driver_name;
                                    } else {
                                        foreach ($all_types as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;' onclick='typeClicked(this.id,this.title)' class='types' id='" . $row['assets_type_id'] . "'
							        title='" . $row['assets_type_nm'] . "'>" . $row['assets_type_nm'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#assets_type').on('focus', function () {
                                    $('.assets_category_holder').hide();
                                    $('.owners_holder').hide();
                                    $('.personnel_holder').hide();
                                });

                                $('#assets_type').on('keydown', function () {
                                    $('#types-list').show();
                                    $('.assets_type_holder').show();
                                });

                                $('#assets_type').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    if (value.length == 0) {
                                        $("#assets_type_id").val("");
                                        $('.assets_type_holder').hide();
                                    }


                                    $('.dp-down').hide();
                                    $('#types-list').show();
                                    $("#types-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function typeClicked(assets_type, value) {
                                    // alert(value);
                                    $("#assets_type").val(value);
                                    $("#assets_type_id").val(assets_type);
                                    $("#assets_type").focus();
                                    $('#types-list').hide();
                                }
                            </script>
	                    </div>
	                    <!-- <div class="form-group">
	                        <label for="reservation">Vehicle Category <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="assets_category_id" id="assets_category_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $categoryOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<input id="assets_category_id" name="assets_category_id" hidden="true" value="<?php echo $vehicle['assets_category_id']; ?>" />
	                    	<label class="control-lable">Vehicle Category</label>
							<input id="assets_category" class="form-control" value="<?php echo $vehicle['assets_cat_name']; ?>" />

							<div class="assets_category_holder">
                                <ul id="category-list">

                                    <?php
                                    if ($all_categories == null) {
                                        ?> <script>$('#category-list').show();$('.assets_category_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Categories Found</li>";

                                        // echo $value->driver_name;
                                    } else {
                                        foreach ($all_categories as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='categoryClicked(this.id,this.title)' class='types' id='" . $row['assets_category_id'] . "'
							        title='" . $row['assets_cat_name'] . "'>" . $row['assets_cat_name'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#assets_category').on('focus', function () {
                                    $('.assets_type_holder').hide();
                                    $('.owners_holder').hide();
                                    $('.personnel_holder').hide();
                                });

                                $('#assets_category').on('keydown', function () {
                                    $('#category-list').show();
                                    $('.assets_category_holder').show();
                                });

                                $('#assets_category').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    $('.dp-down').hide();

                                    if (value.length == 0) {
                                        $('#assets_category_id').val("");
                                        $('.assets_category_holder').hide();
                                    }

                                    $('#category-list').show();
                                    $("#category-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function categoryClicked(assets_category, value) {
                                    // alert(value);
                                    $("#assets_category").val(value);
                                    $("#assets_category_id").val(assets_category);
                                    $("#assets_category").focus();
                                    $('#category-list').hide();
                                }
                            </script>
	                    </div>
	                    <!-- <div class="form-group">
	                        <label for="reservation">Owner <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="owner_id" id="owner_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $ownerOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<input id="owner_id" name="owner_id" hidden="true" value="<?php echo $vehicle['owner_id'] ?>" />
	                    	<label class="control-lable">Assign Owner</label>
							<input id="owners" class="form-control" value="<?php echo $vehicle['owner_name']; ?>"/>

							<button type="button" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#newOwner">New Owner
                                <span class='fa fa-plus'></span>
                            </button>

							<div class="owners_holder">
                                <ul id="owners-list">

                                    <?php
                                    if ($all_owners == null) {
                                        ?> <script>$('#owners-list').show();$('.owners_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Owners Found</li>";
                                        // echo $value->driver_name;
                                    } else {
                                        foreach ($all_owners as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='ownersClicked(this.id,this.title)' class='types' id='" . $row['owner_id'] . "'
							        title='" . $row['owner_name'] . "'>" . $row['owner_name'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#owners').on('focus', function () {
                                    $('.assets_category_holder').hide();
                                    $('.assets_type_holder').hide();
                                    $('.personnel_holder').hide();
                                });

                                $('#owners').on('keydown', function () {
                                    $('#owners-list').show();
                                    $('.owners_holder').show();
                                });

                                $('#owners').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    $('.dp-down').hide();

                                    if (value.length == 0) {
                                        $('#owner_id').val("");
                                        $('.owners_holder').hide();
                                    }


                                    $('#owners-list').show();
                                    $("#owners-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function ownersClicked(owners, value) {
                                    // alert(owners);
                                    $("#owners").val(value);
                                    $("#owner_id").val(owners);
                                    $("#owners").focus();
                                    $('#owners-list').hide();
                                }
                            </script>
	                    </div>
	                    <!--div class="form-group">
	                        <label for="reservation">Assign Driver:</label>
	                        <select class="form-control" name="personnel_id" id="personnel_id">
	                        	<option value="0">Select</option -->
							  	<!--?php echo $driverOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<input id="personnel_id" name="personnel_id" hidden="true" value="<?php echo $vehicle['personnel_id']; ?>" />
	                    	<label class="control-lable">Assign Driver</label>
							<input id="personnel" class="form-control" value="<?php echo $vehicle['driver_name']; ?>"/>

							<button type="button" style="float: right; margin-top: -28px; margin-right: 5px" class='btn btn-success btn-xs' data-toggle="modal" data-target="#newDriver">New Driver
                                <span class='fa fa-plus'></span>
                            </button>
                            
							<div class="personnel_holder">
                                <ul id="personnel-list">

                                    <?php
                                    if ($all_drivers == null) {
                                        ?> <script>$('#personnel-list').show();$('.personnel_holder').show();</script> <?php
                                        echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;border-bottom:1px solid #eee;'>No Drivers Found</li>";

                                        // echo $value->driver_name;
                                    } else {
                                        foreach ($all_drivers as $key => $row) {
                                            echo "<li style='list-style:none;padding-top:4px;margin-left:-20px;' onclick='driverClicked(this.id,this.title)' class='types' id='" . $row['personnel_id'] . "'
							        title='" . $row['driver_name'] . "'>" . $row['driver_name'] . "</li>";
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <script>

                                $('#personnel').on('focus', function () {
                                    $('.assets_category_holder').hide();
                                    $('.assets_type_holder').hide();
                                    $('.owners_holder').hide();
                                });

                                $('#personnel').on('keydown', function () {
                                    $('#personnel-list').show();
                                    $('.personnel_holder').show();
                                });

                                $('#personnel').on('keyup', function () {
                                    var value = $(this).val().trim();

                                    $('.dp-down').hide();

                                    if (value.length == 0) {
                                        $('#personnel_id').val("");
                                        $('.personnel_holder').hide();
                                    }

                                    $('#personnel-list').show();
                                    $("#personnel-list >li").each(function () {
                                        if ($(this).text().toLowerCase().search(value) > -1) {
                                            $(this).show();
                                        }
                                        else {
                                            $(this).hide();
                                        }
                                    });
                                });

                                function driverClicked(personnel, value) {
                                    // alert(value);
                                    $("#personnel").val(value);
                                    $("#personnel_id").val(personnel);
                                    $("#personnel").focus();
                                    $('#personnel-list').hide();
                                }
                            </script>
	                    </div>
	                    
					</div>
	            </div>

	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Vehicle Settings
	                </div>
	                <div class="panel-body">
	                    
	                     <div class="form-group">
	                        <label for="reservation">Odometer Reading:</label>
	                        <input class="form-control" type="text" name="km_reading" id="km_reading" value="<?php echo $vehicle['km_reading']; ?>" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Maximum Fuel Liters:</label>
	                        <input class="form-control" type="number" name="max_fuel_liters" id="max_fuel_liters" value="<?php echo $vehicle['max_fuel_liters']; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Maximum Speed:</label>
	                        <input class="form-control" type="number" name="max_speed_limit" id="max_speed_limit"  value="<?php echo $vehicle['max_speed_limit']; ?>"/>
	                    </div>
	                    
					</div>
	            </div>
	            <div class="panel-footer " align="right">
	            	<button class="btn btn-primary" type="submit" id="update-vehicle">Update </button>
	            </div>

	            
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="panel panel-default">
                <div class="panel-heading">
                    Upload Vehicle Image
                </div>
                <div class="panel-body">
                    <div id="dropzone">
				    	<form action="<?php echo base_url('index.php/upload_images/upload_vehicle_image') ?>" class="dropzone" id="dropzone-container">
				    		<div class="fallback">
				    	    	<input name="file" type="file" multiple />
				    	  	</div>
				    	</form>
				    </div>
                </div>
            </div>

            <!--<div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-car"></i> Vehicles</h2>
				<br>
				<p>Manage Vehicles and begin monitoring your assets Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

				<a href="<1?php echo site_url('vehicles/groups');?>" class="btn btn-success">View Groups</a>	
			</div>-->

		</div>

    </div>
</div> 

<?php include("new_owner.php"); ?>
<?php include("new_driver.php"); ?>

<script src="<?php echo  base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>  

<script>
   $(function () {

            $('#edit-vehicle-form').on('submit' , function () {

            	var $this = $(this);

				$('#update-vehicle').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-vehicle').prop('disabled', true);

               // alert ("yes");
               swal({   

                title: "Info",   
                text: "Edit Vehicle?",   
                type: "info",   
                showCancelButton: true,   
                closeOnConfirm: false, 
                allowOutsideClick: false,  
                showLoaderOnConfirm: true                            
                }, function(){
	                $.ajax({
	                    method: 'post',
	                    url: '<?=base_url('index.php/vehicles/update_vehicle') ?>',
	                    data: $this.serialize(),
                        success: function (response) {
                        	if (response) {
	                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
	                        } else {
	                        	swal({   title: "Error",   text: "Failed to Update, Try again later",   type: "error",   confirmButtonText: "ok" });
	                        } 
	                        $('#update-vehicle').html('Update');
	                		$('#update-vehicle').prop('disabled', false);
	                     }
	                });
	                });

                $('#update-vehicle').html('Update');
	            $('#update-vehicle').prop('disabled', false);
                
                return false;     
            });
        });     
</script>
