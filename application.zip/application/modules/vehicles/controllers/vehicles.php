<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicles extends CI_Controller {

	function __construct() {

        parent::__construct();
		
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
		
		if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

		if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

        $this->load->model('mdl_vehicles');
        $this->load->model('mdl_categories');
        $this->load->model('mdl_types');
        $this->load->model('mdl_owners');
        $this->load->model('settings/mdl_settings');
        $this->load->model('personnel/mdl_personnel');

    }

	public function index() {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
        
        // die(print_r($data));

        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';   
        
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicles';
        $data['content_title'] = 'Vehicles';
        $data['content_subtitle'] = 'vehicles list, owners and status';
        $data['content'] = 'vehicles/view_vehicles.php';
        $this->load->view('main/main.php', $data);
    }

    public function fetch_vehicles () {
        return $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
    }
   public function drive () {
        $query = $this->mdl_vehicles->get_driver($this->session->userdata('itms_company_id'));
        // echo $query;
        print_r($query);       
    }
    public function fetch () {
        $value = array();
        if ($data=$this->mdl_vehicles->get_vehicle()) {
            $value['vehicle']=$data;
        }
         $this->load->view('view_vehicle', $value);
    }

    public function fetch_vehicle ($asset_id) {

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') !=0)
        {
            $map_center = sprintf( "%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;
        
        $company_id = $this->session->userdata('itms_company_id');
        $data['vehicle'] = $this->mdl_vehicles->get_vehicle($asset_id, $company_id);
        $data['vehicle_top_speed'] = $this->mdl_vehicles->get_vehicle_top_speed($asset_id);
        $data['max_day'] = $this->mdl_vehicles->get_vehicle_max_day($asset_id);
        $data['max_week'] = $this->mdl_vehicles->get_vehicle_max_week($asset_id);
        $data['max_month'] = $this->mdl_vehicles->get_vehicle_max_month($asset_id);

        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicle';
        $data['content_title'] = 'Vehicle';
        $data['content_subtitle'] = 'Vehicle Details';
        $data['content'] = 'vehicles/view_vehicle.php';
        $this->load->view('main/main.php', $data);
        
    }
    function delete_vehicle($asset_id){
        $this->mdl_vehicles->delete_vehicle($asset_id);
        header('location:'.base_url('index.php/vehicles'));
    }
    function datetime(){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        echo $t;
    }
    public function edit_vehicle ($asset_id) {
        
        $data['vehicle'] = $this->mdl_vehicles->get_vehicle_by_id($asset_id);

        $data['all_types'] = $this->mdl_vehicles->get_vehicle_type($this->session->userdata('itms_company_id'));
        $data['all_owners'] = $this->mdl_vehicles->get_vehicle_owner($this->session->userdata('itms_company_id'));
        $data['all_categories'] = $this->mdl_vehicles->get_vehicle_categories($this->session->userdata('itms_company_id'));
        $data['all_drivers'] = $this->mdl_vehicles->get_vehicle_drivers($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Edit Vehicle';
        $data['content_title'] = 'Edit Vehicle Details';
        $data['content_subtitle'] = 'Vehicle Details';

        $data['content'] = 'vehicles/edit_vehicle.php';
        $this->load->view('main/main.php', $data);
    }

    public function update_vehicle () {
        $data = $this->input->post();

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        $this->mdl_vehicles->update_vehicle($data);
    }

    public function get_vehicle_by_id () {
        $asset_id = $this->input->post('asset_id');

        $res = $this->mdl_vehicles->get_vehicle_by_id($asset_id);
        echo json_encode($res);
    }

    public function add_vehicle () {

        $data['all_types'] = $this->mdl_vehicles->get_vehicle_type($this->session->userdata('itms_company_id'));
        $data['all_owners'] = $this->mdl_vehicles->get_vehicle_owner($this->session->userdata('itms_company_id'));
        $data['all_categories'] = $this->mdl_vehicles->get_vehicle_categories($this->session->userdata('itms_company_id'));
        $data['all_drivers'] = $this->mdl_vehicles->get_vehicle_drivers($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'vehicles/add_vehicle';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Vehicle';
        $data['content_title'] = 'Add Vehicle';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_vehicle.php';
        $this->load->view('main/main.php', $data);
    }

    public function save_vehicle () {
        $data = $this->input->post();
        // $t = $this->input->post('assets_type_id');
        // $c = $this->input->post('assets_category_id');
        // $o = $this->input->post('owner_id');
        // $p = $this->input->post('personnel_id');

        // $name = explode(" ", "$p");
        // $name1 = $name[0];
        // $name2 = $name[1];

        // $t1 = $this->db->query('SELECT assets_type_id FROM itms_assets_types WHERE assets_type_nm = "'.$t.'"');
        // $t2 = $t1->result_array();
        // $t3 = $t2[0]['assets_type_id'];

        // $c1 = $this->db->query('SELECT assets_category_id FROM itms_assets_categories WHERE assets_cat_name = "'.$c.'"');
        // $c2 = $c1->result_array();
        // $c3 = $c2[0]['assets_category_id'];

        // $o1 = $this->db->query('SELECT owner_id FROM itms_owner_master WHERE owner_name = "'.$o.'"');
        // $o2 = $o1->result_array();
        // $o3 = $o2[0]['owner_id'];

        // $p1 = $this->db->query('SELECT personnel_id FROM itms_personnel_master WHERE fname = "'.$name1.'" AND lname = "'.$name2.'"');
        // $p2 = $p1->result_array();
        // $p3 = $p2[0]['personnel_id'];

        // $data = array('asset_id' => $this->input->post('asset_id'),
        //               'assets_friendly_nm' => $this->input->post('assets_friendly_nm'),
        //               'assets_name' => $this->input->post('assets_name'),
        //               'assets_type_id' => $t3,
        //               'assets_category_id' => $c3, 
        //               'owner_id' => $o3, 
        //               'personnel_id' => $p3, 
        //               'km_reading' => $this->input->post('km_reading'),
        //               'max_fuel_liters' => $this->input->post('max_fuel_liters'), 
        //               'max_speed_limit' => $this->input->post('max_speed_limit'));
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        echo $this->mdl_vehicles->save_vehicle($data);
    }

    function save_tyre_axle_config () {
        $data = $this->input->post();
        $minmax = $data['minmax'];
        unset($data['minmax']);

        /* DO NOT REMOVE THIS */
        $tyre_num = $data['axle_tyre_config'];
        $tyre_vals = explode('-', $tyre_num);
        $axle = 1;
        $tyre_axle=0;
        /* OR ELSE */

        $pressure_vals = explode(',', $minmax);
        $axle_pressure_conf = array();

        foreach ($pressure_vals as $key => $value) {
            $pr = explode(';', $value);
            $conf['company_id'] = $this->session->userdata('itms_company_id');
            $conf['asset_id'] = $data['asset_id'];
            $conf['axle_no'] = $axle;
            $conf['min_pressure'] = $pr[0];
            $conf['max_pressure'] = $pr[1];
            $conf['tyrenos'] = $tyre_vals[$tyre_axle];
            $axle++;
            $tyre_axle++;

            array_push($axle_pressure_conf, $conf);
        }

        echo $this->mdl_vehicles->save_tyre_axle_config($data, $axle_pressure_conf);
    }

    public function fetch_landmarks () {
        $data['landmark'] = $this->mdl_vehicles->get_landmarks($this->session->userdata('itms_company_id'));

        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicle';
        $data['content_title'] = 'Vehicle';
        $data['content_subtitle'] = 'Vehicle Details';
        $data['content'] = 'vehicles/view_landmarks.php';
        $this->load->view('main/main.php', $data);
    }
    // end of landmark function

    public function groups() {
        $data ['groups'] = $this->mdl_vehicles->get_groups($this->session->userdata('itms_company_id'));
        
        $data['content_btn']= '<a href="'.site_url('vehicles/add_group').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Group</a>';    
        
        $data['content_url'] = 'vehicles/groups';
        $data['fa'] = 'fa fa-sitemap';
        $data['title'] = 'ITMS Africa | Vehicle Groups';
        $data['content_title'] = 'Vehicle Groups';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/view_groups.php';
        $this->load->view('main/main.php', $data);
    }

    public function add_group () {
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_group';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Group';
        $data['content_title'] = 'Add Group';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_group.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_group () {
        $data ['groups'] = $this->mdl_vehicles->edit_groups($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_group';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Group';
        $data['content_title'] = 'Add Group';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/edit_group.php';
        $this->load->view('main/main.php', $data);
    }

    public function save_vehicle_group () {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        
        
        echo $this->mdl_vehicles->save_group($data);
        
        
    }

    function delete_group($group_id){
        $this->mdl_vehicles->delete_group($group_id);
        header('location:'.base_url('index.php/vehicles/groups'));
    }

    function update_vehicle_group(){
        $data = array('group_id' => $this->input->post('group_id'),
                      'group_name' => $this->input->post('group_name'), 
                      'group_description' => $this->input->post('group_description'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        
        $this->mdl_vehicles->update_group_vehicle($data);
    }
    
    public function add_owner () {
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_owner';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Owner';
        $data['content_title'] = 'Add Owner';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_owner.php';
        $this->load->view('main/main.php', $data);
    }

    public function add_dealer () {
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_dealer';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Dealer';
        $data['content_title'] = 'Add Dealer';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_dealer.php';
        $this->load->view('main/main.php', $data);
    }

    public function categories() {
        $data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/categories';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | vehicles Categories';
        $data['content_title'] = 'vehicles Categories';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/categories.php';
        $this->load->view('main/main.php', $data);
    }


    public function types() {
        $data ['types'] = $this->mdl_types->get_all_types($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/types';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | vehicles Types';
        $data['content_title'] = 'vehicles Types';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/types.php';
        $this->load->view('main/main.php', $data);
    }


    public function owners() {
        $data['owners'] = $this->mdl_owners->get_all_owners($this->session->userdata('itms_company_id'));

        $data['content_btn']= '<a href="'.site_url('vehicles/add_owner').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Owners</a>';
        $data['content_url'] = 'vehicles/owners';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicle Owners';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/owners.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_owner() {
        $data['owners'] = $this->mdl_owners->get_owner($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'vehicles/owners';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicle Owners';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/edit_owners.php';
        $this->load->view('main/main.php', $data);
    }

    function delete_owner($owner_id){
        $this->mdl_vehicles->delete_owner($owner_id);
        header('location:'.base_url('index.php/owners'));
    }

    public function update_owners() {
        $data = array('owner_name' => $this->input->post('owner_name'),
                      'phone_no' => $this->input->post('phone_no'),
                      'email' => $this->input->post('email'), 
                      'address' => $this->input->post('address'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        
        $this->mdl_owners->update_owner($data);
    }


    public function vehicles_pairing() {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));

        $optVehicle = '';
        foreach($data['vehicles'] as $key=>$vehicle) {
            $optVehicle .= '<option value="'.$vehicle->asset_id.'">'.$vehicle->assets_friendly_nm.'</option>';
        }

        $data['optVehicles'] = $optVehicle;
        $data['content_url'] = 'vehicles/vehicles_pairing';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicles Pairing';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/vehicles_pairing.php';
        $this->load->view('main/main.php', $data);
    }

    public function tyre_axle_configurations() {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
        $data['all_assets'] = $this->mdl_settings->getassets($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/tyre_axle_configurations';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Tyre Axle Configurations';
        $data['content_title'] = 'Axle and Tyre Settings';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/tyre_axle_configurations.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_drivers_select () {
        $drivers = $this->mdl_vehicles->get_drivers();

        $select_box = "<select>";
        
        if (sizeof($drivers)) {
           foreach ($drivers as $driver) {
                $select_box .= "<option value='" . $driver->personnel_id . "'>" . $driver->fname . " " . $driver->lname. "</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    public function get_owners_select () {
        $owners = $this->mdl_vehicles->get_owners();

        $select_box = "<select>";
        
        if (sizeof($owners)) {
           foreach ($owners as $owner) {
                $select_box .= "<option value='" . $owner->owner_id . "'>" . $owner->owner_name ."</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    public function get_categories_select () {
        $categories = $this->mdl_vehicles->get_categories();

        $select_box = "<select>";
        
        if (sizeof($categories)) {
           foreach ($categories as $category) {
                $select_box .= "<option value='" . $category->assets_category_id . "'>" . $category->assets_cat_name . "</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    public function get_types_select () {
        $types = $this->mdl_vehicles->get_types();

        $select_box = "<select>";
        
        if (sizeof($types)) {
           foreach ($types as $type) {
                $select_box .= "<option value='" . $type->assets_type_id . "'>" . $type->assets_type_nm . "</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    

}
