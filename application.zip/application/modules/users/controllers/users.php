<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct() {

        parent::__construct();

        $this->load->model('mdl_users');

    }

    public function index(){
    	$data ['users'] = $this->mdl_users->get_users($this->session->userdata('itms_company_id'));
        var_dump($data);
        die();
        // $data['content_btn']= '<a href="'.site_url('users').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Group</a>';    
        $data['content_url'] = 'users';
        $data['fa'] = 'fa fa-sitemap';
        $data['title'] = 'ITMS Africa | View Users';
        $data['content_title'] = 'View Users';
        $data['content_subtitle'] = '';
        $data['content'] = 'users';
        $this->load->view('main/main.php', $data);
    }

}