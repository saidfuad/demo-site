<?php

class Mdl_users extends CI_Model{

    function __construct () {
        parent::__construct();
    }

    function get_users () {
        $query = $this->db->get('itms_users');
        $this->db->where('company_id',2);
        $this->db->order_by('username', 'ASC');

        return $query->result();

    }
}