<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Vehicle Name</th>
                            <th>Plate Number</th>
                            <th>Status</th>
                            <th>Issue</th>
                            <!--<th>Current Location</th>-->
                            <th>Update</th>
                            <th class="hidden">diff</th>
                            <th>Driver Contact</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($vehicles as $key => $value) { ?>
                       <tr class="gradeU">
                            <td><?php echo $value->assets_friendly_nm; ?></td>
                            <td><?php echo $value->assets_name; ?></td>
                            <td>
                                <?php

                                    $status = explode(',', $value->tyre_status);
                                    $status = array_filter(array_unique($status));
                                    $diff_array = array('Normal');

                                    if (in_array('Tire leak', $status)) {
                                       echo '<label class="label label-danger blink">Alert</label>'; 
                                       $state = array_diff($status, $diff_array);
                                       $state = implode(',', $state);
                                    } else if (in_array('Loss of signal', $status) || in_array('Battery Low Voltage', $status)) {
                                        echo '<label class="label label-Warning blink">Warning</label>';
                                        $state = array_diff($status, $diff_array);
                                        $state = implode(',', $state); 
                                    } else {
                                        echo '<label class="label label-success">Normal</label>';
                                        $state = implode(',', $status);  
                                    }

                                    //echo implode(',', $status);
                                ?>
                            
                            </td>
                            <td>
                                <?php

                                    echo $state;
                                ?>
                            </td>
                            <td><?php //echo $value->norm_date;?><span am-time-ago="<?php echo $value->posted_date;?>"></span></td>
                            <td class="hidden"><?php echo $value->diff;?></td>
                            <!--<td><?php echo 'Mariakani, Mombasa';?></td>-->
                            <td><?php if ($value->driver_name != "") {echo $value->driver_name . ' (<a href="#">' . $value->driver_phone. '</a>)';} else { echo 'Not Assigned';} ?></td>
                            <td>
                                <button class="btn btn-primary btn-xs asset-li" id=""
                                        attr-asset-id="<?php echo $value->asset_id;?>"
                                        attr-asset-device-id="<?php echo $value->device_id;?>"
                                            attr-asset-name="<?php echo $value->assets_friendly_nm;?>"
                                                attr-asset-plate-no="<?php echo $value->assets_name;?>"
                                                    attr-asset-type="<?php echo $value->assets_type_nm;?>"
                                                        attr-asset-category="<?php echo $value->assets_cat_name;?>"
                                                            attr-driver-name="<?php echo $value->driver_name;?>"
                                                                attr-driver-phone="<?php echo $value->driver_phone;?>"
                                                                    attr-asset-image="<?php echo $value->assets_image_path;?>"
                                                                        attr-asset-axles="<?php echo $value->no_of_axles;?>"
                                                                            attr-asset-axle-config="<?php echo $value->axle_tyre_config;?>"
                                                                                attr-asset-paired="<?php echo $value->paired;?>"
                                                                                    attr-asset-paired-id="<?php echo $value->paired_asset_id;?>"
                                                                                    attr-asset-paired-device-id="<?php echo $value->paired_asset_device_id;?>"
                                                                                        attr-asset-paired-axle-no="<?php echo $value->paired_asset_axles;?>"
                                                                                            attr-asset-paired-at-config="<?php echo $value->paired_asset_axle_tyre_config;?>"
                                                >View</button>
                                <button class="btn btn-info btn-xs">Send Alert</button>
                            </td>
                        </tr>
                    <?php }?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div> 

<div class="panel-diagnostics" id="panel-diagnostics">
            <div class="panel-heading">
                <span>Vehicle</span> - <span id="panel-asset-name"></span>
                <button class="btn btn-sm btn-success header-btn-1" id="btn-print-vd">Print Status</button>
                <span class="close cx" id="close-pd"><b>&times;</b></span>
            </div>
            <div class="row vinfo-area" id="vinfo-area">
                <div class="col-md-12 col-sm-12">
                    <div class="col-md-4 top-info-div ">
                        <!-- User Card Mini - Right Profile Image -->
                        <div class="user-card-mini row div-wd-info">
                            <div class="col-md-12 col-sm-12 col-xs-12 text-center " id="pressure-status-area">
                                <h4>Warning</h4>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="col-md-4 top-info-div">
                        <!-- User Card Mini - Right Profile Image -->
                        <div class="user-card-mini row bgf5">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <p>
                                    Driver ID: <i id="diag-driver-id"></i><br>
                                    Driver Name: <i id="diag-driver-name"></i><br>
                                    Driver Phone: <i id="diag-driver-phone"></i><br>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 top-info-div">
                        <!-- User Card Mini - Right Profile Image -->
                        <div class="user-card-mini row bgf5">
                            <div class="col-md-12 col-sm-12 col-xs-12 ">
                                <p>
                                    
                                    Vehicle ID: <i id="diag-vehicle-id"></i> <br>
                                    Vehicle type: <i id="diag-vehicle-type"></i><br>
                                    Trailer ID: <i id="diag-trailer-id"></i><br>
                                </p>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div id="bg-vehicle-area" class="col-md-offset-1 col-md-10 col-sm-10">
                
                </div>
                
                    
            </div>
            <div  class="panel-footer">
                <div class="row" id="info-div" style="overflow-y:scroll; max-height:280px;">
                    <!--<div class="col-md-12 ttl-tyre-info">
                        <h4>Tyre Information</h4>
                        <button class="btn btn-sm btn-primary btn-sm header-btn-1" id="btn-print-vd">Print Status</button>
                    </div> -->
                                      
                </div>
            </div>  
            
        </div>
                
    
    <div id="tyre-info-div">
        <div class="row">
            <span class="col-sm-6 col-md-6"><h2 id="pressure-info"></h2></span>
            <span class="col-sm-6 col-md-6"><h2 id="temperature-info"></h2></span>
            <span class="col-sm-12 col-md-12">Condition</span>
            <span class="col-sm-12 col-md-12 btn btn-block" id="status-info"></span>
            <span class="col-sm-12 col-md-12" id="axle-info"></span>
            <span class="col-sm-12 col-md-12" id="tyre-info"></span>
            
        </div>
    </div>
    
    
<script type="text/javascript">
    $(function () {

        
        
        $('.asset-li').on('click', function () {
            $("#pressure-status-area").html("<h4><i class='fa fa-spinner fa-spin fa-2x' style='color:#18bc9c;'></i></h4>");
            $("#bg-vehicle-area").html('<h3 style="text-align:center;margin-top:50px;"><i class="fa fa-spinner fa-spin fa-2x" style="color:#18bc9c;"></i></h3>');

            var vehicleA_id = $(this).attr('attr-asset-id');
            var vehicleB_id = $(this).attr('attr-asset-paired-id');

            var deviceA_id = $(this).attr('attr-asset-device-id');
            var deviceB_id = $(this).attr('attr-asset-paired-device-id');

            var paired = $(this).attr('attr-asset-paired-id');
            var axlesA = parseInt($(this).attr('attr-asset-axles'));
            var axlesB = parseInt($(this).attr('attr-asset-paired-axle-no'));

            //If paired total axles = towing vehicle axles + trailer axles
            var total_axles = axlesA + axlesB;

            

            /*put the axles and tyres numbers and pattern in arrays. Single tyre S, twin tyre T, 
            single retractable SR and twin retractable TR*/
            var patternA = $(this).attr('attr-asset-axle-config').split('-').filter(Boolean);
            var patternB = $(this).attr('attr-asset-paired-at-config').split('-').filter(Boolean);

            /*Verify if axles and tyres configurations have been set so as to render the diagnostics image,
            with the correct number of tyres and axles*/
            if (axlesA == 0) {
                swal({   title: "Info",   text: "Set the vehicle axles and tyres configurations",   type: "error",   confirmButtonText: "ok" });
                return false;
            } 

            if (paired!=0) {
                if (axlesB == 0) {
                    swal({   title: "Info",   text: "Set the trailers' axles and tyres configurations",   type: "error",   confirmButtonText: "ok" });
                    return false;
                }
            }

            var completePattern = patternA.concat(patternB);

            //alert(completePattern.length);
            //Display the panel if above conditions have been met.
            $('#bg-vehicle-area').html('');
            $('#panel-diagnostics').fadeOut(500);
            $('#panel-diagnostics').fadeIn(1000);
            $('.overshadow').fadeIn(1000);
            $('#bg-vehicle-area').html('');

            var asset_name = $(this).attr('attr-asset-name');
            var asset_type = $(this).attr('attr-asset-type');
            var asset_driver_name = $(this).attr('attr-driver-name');
            var asset_driver_phone = $(this).attr('attr-driver-phone');
            var vehicle_axles = total_axles;

            //Divs to render axles and tyres 2
            var axle_divs_two = ['<div class="col-sm-7 col-md-7 axle-div"></div>', '<div class="col-sm-5 col-md-5 axle-div"></div>'];
            var axle_divs_three = ['<div class="col-sm-3 col-md-3 axle-div"></div>', '<div class="col-sm-4 col-md-4 axle-div"></div>', '<div class="col-sm-5 col-md-5 axle-div"></div>'];
            
            //axle and tyres images.
            var styre_axle = "<img src='<?php echo base_url()?>/assets/images/itms/normal-axle.png' alt='axle' class='v-axle'/>";
            var dtyre_axle = "<img src='<?php echo base_url()?>/assets/images/itms/double-tyre-axle.png' alt='axle' class='v-axle'/>";
            var no_of_axle_divs = 2;
            var divs_to_append = axle_divs_two;
            
            //Render some info about the  vehicle on the diagnostic panel
            $('#panel-asset-name').html(asset_name);
            $('#diag-vehicle-id').html(asset_name);
            $('#diag-vehicle-type').html(asset_type);
            $('#diag-driver-id').html(asset_driver_name);
            $('#diag-driver-name').html(asset_driver_name);
            $('#diag-driver-phone').html(asset_driver_phone);
            
            //Check the number axles to determine which vehicle image & how many divs to append to hold the axles
            if (vehicle_axles > 5) {
                no_of_axle_divs = 3;
                divs_to_append = axle_divs_three;
                $('#bg-vehicle-area').css({'background': 'url("<?php echo base_url()?>/assets/images/itms/trailer.png") no-repeat'});
            } if (vehicle_axles > 3) {
                no_of_axle_divs = 3;
                divs_to_append = axle_divs_three;
                $('#bg-vehicle-area').css({'background': 'url("<?php echo base_url()?>/assets/images/itms/lorry6.png") no-repeat'});
            } else {
                $('#bg-vehicle-area').css({'background': 'url("<?php echo base_url()?>/assets/images/itms/lorry2.png") no-repeat'});
            }
            
            //appending divs first on top of the vehicle image
            for (var i = 0; i < no_of_axle_divs; i++) {
                $('#bg-vehicle-area').append(divs_to_append[i]) 
            }
            
            //append axles on the divs depending on the set and pattern of the tyres on each axle.
            //NOTE:The completePattern Variable 
            count = 1;
            lap = 1;

            if (vehicle_axles == 2) {
                $container = [1,2];
            } else if (vehicle_axles == 3) {
                $container = [1,2,2];
            } else if (vehicle_axles == 4) {
                $container = [1,2,3,3];
            } else if (vehicle_axles == 5) {
                $container = [1,2,2,3,3];
            } else if (vehicle_axles == 6) {
                $container = [1,2,2,3,3,3];
            } else if (vehicle_axles == 7) {
                $container = [1,2,2,2,3,3,3];
            } 
            
            for (var i = 0; i < vehicle_axles; i++) {

                if (completePattern[i] == 'S' || completePattern[i] == 'SR') {
                    $axle_image = styre_axle;
                } else if (completePattern[i] == 'T' || completePattern[i] == 'TR') {
                    $axle_image = dtyre_axle;
                }

                var count = $container[i];
                                
                $('#bg-vehicle-area').find('.axle-div:nth-child('+count+')').append($axle_image);   
            }
            
            //give the axles ids 
            var appended_axles = $('#bg-vehicle-area').find('.v-axle');
            var size_appended_axles = appended_axles.length;
            
            for (var i = 0; i < size_appended_axles; i++) {
                var numb = i+1;
                $(appended_axles[i]).attr("id","X"+numb);
            }
            
            
            $.ajax({
                    type    : "POST",
                    cache   : false,
                    data : {deviceA_id:deviceA_id, deviceB_id:deviceB_id, asset_id:vehicleA_id},
                    url     : "<?php echo base_url()?>index.php/tpms/get_tpms_info",
                    success: function(response) {
                         data = JSON.parse(response);
                        var count_danger = 0;
                        var count_warning = 0;
                        var tyre_inf = 'Pressure Normal';
                        var count_tyres = 1;
                        var info_class = 'btn-primary';
                        var $or_status = "Status missing";

                        var info = data.info;
                        var p_config = data.pressure_config;



                        if (info.length == 0) {
                            swal({   title: "Info",   text: "No Tyre Information was recieved for this vehicle",   type: "info",   confirmButtonText: "ok" });
                            return false;
                        }

                        $('#info-div').find('.lbl-info').remove();

                        for (var row in info) {
                            $axle = info[row].axle;
                            $tyre = info[row].tyre;
                            $tyre_id = info[row].tyre_id;
                            $pressure = parseFloat(info[row].pressure);
                            $temperature = parseFloat(info[row].temperature);
                            $or_status = info[row].status;

                            console.log($axle);

                            var min_pressure = 100;
                            var max_pressure = 130;

                            for (var p in p_config) {
                              if($axle == 'X'+p_config[p].axle_no) {
                                  min_pressure = parseFloat(p_config[p].min_pressure);
                                  max_pressure = parseFloat(p_config[p].max_pressure);
                              }
                            }

                            console.log(min_pressure);
                            console.log(max_pressure);
                            
                            if ($pressure < min_pressure) {
                                $tyre_type = 'warning-tyre.png';
                                count_warning++;
                                tyre_inf = 'Low Pressure';
                                info_class = 'btn-warning';
                            } else if ($pressure > max_pressure){
                                $tyre_type = 'danger-tyre.png';
                                 tyre_inf = 'High Pressure';
                                 info_class = 'btn-danger';
                                count_danger++;
                            } else {
                                $tyre_type = 'normal-tyre.png';
                                tyre_inf = 'Pressure Normal';
                                info_class = 'btn-primary';
                            }
                            
                            
                            
                            var axle_position = $('#'+$axle).position();
                            //console.log($tyre_id);

                            if (axle_position!=undefined) {
                                $left = axle_position.left + 'px';
                            
                                        
                            //alert($tyre);                                           
                            $tyre_img = '<img src="<?php echo base_url()?>/assets/images/itms/'+$tyre_type+'" alt="tyre" style="left:'+$left+'" class="info-tyre" id="'+$tyre_id+'" tyre="'+$tyre+'" axle="'+$axle+'" pressure="'+$pressure+'" temperature="'+$temperature+'">';
                            $('#bg-vehicle-area').find('#'+$axle).parent().append($tyre_img);
                            $('#bg-vehicle-area').find('#'+$axle).parent().append($tyre_img);

                            $('#info-div').append('<div class="col-md-6 lbl-info" tyr="'+$tyre_id+'">' +
                                                        '<label class="btn btn-xs '+info_class+ ' ' + $tyre +'"> '+count_tyres+' </label> ' + $pressure + ' PSI - ' + tyre_inf +   
                                                  '</div>');
                            count_tyres++;
                            }
                        }

                        if (count_danger > 0 && count_warning > 0) {
                            $('.div-wd-info').removeClass('bg-critical').removeClass('bg-warning').addClass('bg-critical');
                            $("#pressure-status-area").html("<h3>Tyre(s) Over & Under pressure</h3><p>"+$or_status+"</p>");
     
                        } else if (count_danger > 0) {
                            $('.div-wd-info').removeClass('bg-critical').removeClass('bg-warning').addClass('bg-critical');
                            $("#pressure-status-area").html("<h4>Tyre(s) Over pressure</h4><p>"+$or_status+"</p>");
     
                        } else if (count_warning > 0) {
                            $('.div-wd-info').removeClass('bg-critical').removeClass('bg-warning').addClass('bg-warning');
                            $("#pressure-status-area").html("<h4 style='color:#cacc00'>Tyre(s) Under pressure</h4><p style='color:#cacc00'>"+$or_status+"</p>");
                        }
                    }
                
                }); 
            
            
            
        });

        $(document).on('mouseenter', '.lbl-info', function(e) {
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
            $(this).addClass('info-highlighted');

            var id_ = $(this).attr('tyr');

            $('#bg-vehicle-area').find('.info-tyre').removeClass('blink_');
            $('#bg-vehicle-area').find('#'+id_).addClass('blink_');

        });

        $(document).on('mouseleave', '.lbl-info', function() {
           $('#info-div').find('.lbl-info').removeClass('info-highlighted');
           $('#bg-vehicle-area').find('.info-tyre').removeClass('blink_');
            
        });
        

        
        $(document).on('mouseenter', '.info-tyre', function(e) {
             $('#tyre-info-div').stop().hide();
            var pressure = $(this).attr('pressure');
            var temperature = $(this).attr('temperature');
            var axle = $(this).attr('axle');
            var tyre = $(this).attr('tyre');
            var status = 'Normal';
            var btn_type = 'btn-primary';
            if (temperature < 50 || pressure < 50 || temperature >78 || pressure > 78) {
                status = 'Critical';
                btn_type = 'btn-danger';
            } else if (temperature < 60 || pressure < 60 || temperature >70 || pressure > 70){
                status = 'Warning';
                btn_type = 'btn-warning';
            }
            
            var left = parseInt(e.pageX) + 10;
            var top = parseInt(e.pageY) + 10;
            
            
            
            //alert();
            $('#tyre-info-div').find('#pressure-info').html(pressure+'<sup>PSI</sup>');
            $('#tyre-info-div').find('#temperature-info').html(temperature+'<sup>0C</sup>');
            $('#tyre-info-div').find('#status-info').html(status).removeClass('btn-danger').removeClass('btn-warning').addClass(btn_type);
            $('#tyre-info-div').find('#axle-info').html('Axle : '+axle);
            $('#tyre-info-div').find('#tyre-info').html('Tyre : '+tyre);
            $('#tyre-info-div').stop().show().css({'left':left+'px', 'top':top+'px'});
            
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
            $('#info-div').find('.'+tyre).parent().addClass('info-highlighted');


        });
        
        $(document).on('mouseleave', '.info-tyre', function() {
            $('#tyre-info-div').stop().hide();
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
        });
        
        $('#btn-print-vd').on('click', function () {
            //alert();
            var asset = $('#panel-asset-name').html();
            var driver = $('#diag-driver-name').html();
            var phone = $('#diag-driver-phone').html();

            var content = $('#info-div').html();
            var class_ = $('#panel-diagnostics').attr('class');
            var id_ = $('#panel-diagnostics').attr('id');
            
            $.ajax({
                    type    : "POST",
                    cache   : false,
                    data : {asset:asset, content:content, class_:class_, id_:id_, driver:driver, phone:phone},
                    url     : "<?php echo base_url()?>index.php/mpdf_main/print_vehicle_tpms",
                    success: function(response) {
                       // alert(response);
                        var win = window.open("<?php echo base_url()?>Exports/" + response, '_blank');
                        /*if(win){
                            //Browser has allowed it to be opened
                            win.focus();
                        }else{
                            //Broswer has blocked it
                            swal({title:'Blocked!!',   text:'Please allow popups for this site',   type:'error',   confirmButtonText: "Close" });
                        }*/
                    }
                });

            return false;
        });


    });
</script>   

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable({
            "order": [[5, "asc" ]]
        });
    });
</script>

