<div class="container-fluid">
    <div class="row fleet-content">
        <!--<div class="col-lg-12" style="margin-bottom:40px;">
            <!--<div class="row">
                <div class="col-md-4">
                   
                    <div class="user-card-mini row bg-green">
                        <div class="col-md-4 col-sm-4 col-xs-4 text-center">
                            <i class="fa fa-car fa-4x"></i>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-8">
                           <h2>0<br>Vehicles</h2>
                        </div>
                        
                    </div>
                   
                </div>
                <div class="col-md-4">
                    
                    <div class="user-card-mini row bg-blue">
                        <div class="col-md-4 col-sm-4 col-xs-4 text-center">
                            <i class="fa fa-user fa-4x"></i>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-8">
                           <h2>0<br>Users</h2>
                        </div>
                        
                    </div>
                   
                </div>
                
                <div class="col-md-4">
                   
                    <div class="user-card-mini row bg-red">
                        <div class="col-md-4 col-sm-4 col-xs-4 text-center">
                            <i class="fa fa-users fa-4x"></i>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-8">
                           <h2>0<br>Personnel</h2>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            <hr>
        </div>-->



        <div class="col-lg-6">
            <div class="row">
                <div class="col-md-6">
                    <div class="panel panel-square">
                        <div class="panel-heading panel-info clearfix">
                            <h3 class="panel-title">Issues</h3>
                        </div>
                        <div class="panel-body fleet-issues">
                            <div class="row">
                                <div class="col-sm-6 text-center">
                                    <h1 class="success">3</h1>
                                    <span class="caption">Critical</span>
                                </div>
                                <div class="col-sm-6 text-center">
                                    <h1 class="warning">1</h1>
                                    <span class="caption">Warnings</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Service Reminders -->
                <div class="col-md-6">
                    <div class="panel panel-square">
                        <div class="panel-heading panel-info clearfix">
                            <h3 class="panel-title">Service Reminders</h3>
                        </div>
                        <div class="panel-body fleet-issues">
                            <div class="row">
                                <div class="col-sm-6 text-center">
                                    <h1 class="success">3</h1>
                                    <span class="caption">Open</span>
                                </div>
                                <div class="col-sm-6 text-center">
                                    <h1 class="warning">1</h1>
                                    <span class="caption">Overdue</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>

           
            <div class="row">
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Service Costs
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="service-costs"></div>
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Tyre Costs
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="fuel-costs"></div>
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>


            
        </div>

        <div class="col-lg-6">
            <div class="panel panel-default">
                <div class="panel-heading padding padding-all">
                    Vehicles
                </div>
                <!-- /.panel-heading -->

                <div class="panel-body" style="max-height: 250px; overflow-y: scroll;"><?php foreach ($vehicle as $value) { ?>
                    <table class="table table-hover table-striped">
                      <tbody>
                        <tr>
                          <td width="10%"><img src="<?php echo base_url('assets/images/photos/car1.jpg')?>" class="img-circle img-vehicle" /></td>
                          <td>
                            <?php echo $value->assets_name; ?><br />
                            <a href="#" data-toggle="tooltip" data-container="body" data-placement="top" title="View stats of this vehicle" title="View stats of this vehicle"><i class="fa fa-area-chart"></i>
                            </a>&nbsp;|&nbsp;
                            <i class="fa fa-dashboard"></i>
                            <a href="#" data-toggle="tooltip" data-container="body" data-placement="top" title="Edit odometer" title="Edit odometer">153,745</a> km
                            &nbsp;|&nbsp;
                            <a href="#" data-toggle="tooltip" data-container="body" data-placement="top" title="Current Location" title="Current Location">Likoni, Mombasa</a>
                            </td>
                          <td class="text-right">
                            <!-- <a  href="#" data-toggle="tooltip" data-container="body" data-placement="top" title="View this vehicle" title="View this vehicle"><i class="fa fa-eye"></i>
                            </a> -->&nbsp;
                            <?php echo "<a class='text-muted edit-comment btn btn-info btn-xs' href='".base_url('index.php/vehicles/fetch_vehicle/'.$value->asset_id)."' data-container='body' data-placement='top' title='View this vehicle'  title='View this vehicle'><span class='fa fa-eye'></span></a>"?>
                          </td>
                        </tr><?php }?>
                        
                      </tbody>
                    </table>
                </div>                        
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->



            
        </div>
    </div>
    <!-- /.row --> 
</div>



<!-- Page-Level Plugin Scripts - Dashboard -->
    <script src="<?php echo base_url('assets/js/plugins/morris/raphael-2.1.0.min.js')?>"></script>
    
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js')?>"></script>
    
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.time.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js')?>"></script>
    <script src="<?php echo base_url('assets/js/demo/fleet_dashboard.js')?>"></script>