<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form>
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   TPMS Devices Integration
	                </div>
	                <div class="panel-body">
	                    
	                    <div class="form-group">
	                        <label for="reservation">Select Vehicle:</label>
	                        <select class="form-control" type="text" name="asset_id" id="asset_id" required="required">
	                        </select>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Select Axle:</label>
	                        <select class="form-control" type="text" name="axle_no" id="axle_no" required="required">
	                        </select>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Select Tyre:</label>
	                        <select class="form-control" type="text" name="tyre" id="tyre_no" required="required">
	                        </select>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Available TPMS Devices:</label>
	                         <select class="form-control" type="text" name="device_id" id="device_id" required="required">
	                        </select>
	                    </div>
	                    						                    
	                </div>
	                
	            </div>
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit">Integrate</button>
                </div>

	           
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
		</div>

    </div>
</div> 

<!--<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>-->
    