<?php 

class Mdl_tpms extends CI_Model{

    function get_vehicles_data ($company_id=null) {
        $this->db->select("itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        CONCAT(itms_personnel_master.fname, ' ' ,itms_personnel_master.lname) AS driver_name,
                                            itms_personnel_master.phone_no AS driver_phone,
                                                itms_owner_master.owner_id, itms_owner_master.owner_name,
                                                    (select group_concat(status) from itms_tpms_live where device_id=itms_assets.device_id) AS tyre_status,
                                                    (select date_recieved from itms_tpms_live where device_id=itms_assets.device_id order by id desc limit 1) AS date_recs");;
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left')
            //->join('itms_tpms_live', 'itms_tpms_live.device_id=itms_assets.device_id')
            ->where('paired!=', 2); //Pick all towing vehicles, dont pull the trailers already paired

        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('itms_assets.company_id', $this->session->userdata('itms_company_id'));
        }

        $this->db->where('itms_assets.personnel_id!=0');
        $this->db->order_by('date_recs', 'DESC');
        $query = $this->db->get();

        /*print_r('<pre>');
        print_r($query->result());
        exit;
        */

        return $query->result();
    }



    function get_tpms_data ($device_id=null) {
        $this->db->select('itms_tpms_live.*, itms_assets.no_of_tyres, itms_assets.axle_tyre_config');
        $this->db->from('itms_tpms_live')
            ->join('itms_assets', 'itms_assets.device_id=itms_tpms_live.device_id')
            ->where('itms_tpms_live.device_id', $device_id); //Pick all towing vehicles, dont pull the trailers already paired
        $this->db->order_by('tyre_number', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }

    function get_axle_pressure_config ($asset_id=null) {
        $this->db->select('itms_axle_pressure_config.*');
        $this->db->from('itms_axle_pressure_config');
        $this->db->where('asset_id', $asset_id);
        $query = $this->db->get();
       
        return $query->result();
    }


    function save_tpms_live_data($data) {
        $query = 0;

        foreach ($data as $key => $tyre) {
           if($this->check_if_tyre_saved($tyre)) {
                //update
                $this->db->where(array('device_id'=>$tyre['device_id'], 'tyre_number'=>$tyre['tyre_number']));
                $query = $this->db->update('itms_tpms_live', $tyre);
           } else {
                //insert
                $query = $this->db->insert('itms_tpms_live', $tyre);
           }

           if ($query) {
                $query++;
           }
        }

        return $query;
        
    }


    function check_if_tyre_saved($tyre) {

       $query = $this->db->get_where('itms_tpms_live', array('device_id'=>$tyre['device_id'], 'tyre_number'=>$tyre['tyre_number']));

       if ($query->num_rows() > 0) {
            return true;
       }
       return false;
        
    }
                
}

?>
