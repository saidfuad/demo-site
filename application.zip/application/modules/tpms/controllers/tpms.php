<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Tpms extends CI_Controller {
    function __construct() {

        parent::__construct();
        
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
        
        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

        $this->load->model('mdl_tpms');
       
    }

    public function index() {
        $data['vehicle'] = $this->mdl_tpms->get_vehicles_data($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'tpms';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TPMS Dashboard';
        $data['content_title'] = 'TPMS Dashboard';
        $data['content_subtitle'] = '';
        $data['content'] = 'tpms/tpms_dashboard.php';
        $this->load->view('main/main.php', $data);
    }

    public function telematics() {
        
        /*$this->load->library('timefactory');
        
        $count = 0;
        $popstu = array();

        //print_r('<pre>');
        //print_r($results);
        $now = strtotime(date('Y-m-d H:i:s'));

        $vehicles = array();

        foreach ($data['vehicles'] as $key=>$alert) {
            $add_date = $alert->date_recs;
            $add_unix_date = strtotime($add_date);

            $diff = $now - $add_unix_date;

            $at = $this->timefactory->secs_to_time ($diff) ;
                
            if ($diff > 86400) {
                $at = date('jS M Y H:i:s', $add_unix_date) . ' (' .$at . ' ago)';;
            } else {
                $at = $at . ' ago';
            }
 
            $alert->posted_date = $at;
            $alert->diff = $diff;

            array_push($vehicles, $alert);

        }
        $data['vehicles'] = $vehicles;*/

       /* print_r('<pre>');
        print_r($data['vehicles']);
        exit;
        */

        $data['vehicles'] = $this->mdl_tpms->get_vehicles_data($this->session->userdata('itms_company_id'));
        
        $vehicles = array();
        
        foreach ($data['vehicles'] as $key=>$alert) {
            
            $add_date = $alert->date_recs;
            
            $add_unix_date = strtotime($add_date);
            
            $alert->posted_date = $add_unix_date*1000;
            $alert->norm_date = $add_date;
            
            array_push($vehicles, $alert);
            
        }
        
        $data['vehicles'] = $vehicles;

        $data['content_url'] = 'tpms/telematics';
        $data['fa'] = 'fa fa-circle-o-notch';
        $data['title'] = 'ITMS Africa | TPMS';
        $data['content_title'] = 'TPMS';
        $data['content_subtitle'] = '';
        $data['content'] = 'tpms/telematics.php';
        $this->load->view('main/main.php', $data);
    }


    public function tpms_devices_integration () {
        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['content_url'] = 'tpms/tpms_devices_integration';
        $data['fa'] = 'fa fa-university';
        $data['title'] = 'ITMS Africa | TPMS Devices Integration';
        $data['content_title'] = 'TPMS Devices Integration';
        $data['content_subtitle'] = '';
        $data['content'] = 'tpms/tpms_devices_integration.php';
        $this->load->view('main/main.php', $data);
    }

    function get_tpms_info () {
        $data = $this->input->post();

        $dataA = $this->mdl_tpms->get_tpms_data($data['deviceA_id']);
        $dataB = $this->mdl_tpms->get_tpms_data($data['deviceB_id']);

        $asset_id = $data['asset_id'];

        $no_of_tyres = $dataA[0]->no_of_tyres;
        $pattern = $dataA[0]->axle_tyre_config;

        $pattern = explode('-', $pattern);

         $arrayAxles = array('X1'=>'1,2' , 
                            'X2'=>'3,4,5,6', 
                            'X3'=>'7,8,9,10', 
                            'X4'=>'11,12,13,14', 
                            'X5'=>'15,16,17,18', 
                            'X6'=>'19,20,21,22', 
                            'X7'=>'23,24,25,26', 
                            );


        $tpmsData = array();
        $arrayIds = array('1,2','3,4,5,6','7,8,9,10','11,12,13,14','15,16,17,18','19,20,21,22','23,24,25,26'); 
                            

        $new_axle_array = array();
        $ids = array();

        foreach($pattern as $k=>$p) {

            if ($p == 'S' && $k>0) {
                $tyre_pos = $arrayIds[$k];
                $values  = explode(',', $tyre_pos);
                $values = $values[0].','.$values[3];
                $x = $k+1;
            } else if ($p == 'T' && $k>0) {
                $values = $arrayIds[$k];
                $x = $k+1;
            } else {
                $values = '1,2';
                $x = $k+1;
            }

            $new_axle_array['X'.$x] = $values;
            array_push($ids,$values);


        }

        $ids = implode(',', $ids);
        $ids = explode(',', $ids);

        foreach ($dataA as $key => $tyre) {
            $data = array ();
            $sAxle = '';
            if (array_key_exists($key, $ids)) {

                $id = $ids[$key];
                foreach($arrayAxles as $a=>$axle) {
                    $axls = explode(',', $axle);
                    if (in_array($id, $axls)) {
                        $sAxle = $a;
                    }
                    //exit;
                }
                
                $data['device_id'] = $tyre->device_id;
                $data['axle'] = $sAxle;
                $data['tyre_id'] = 'T'.$id;
                $data['tyre'] = 'T'.$tyre->tyre_number;
                $data['pressure'] = $tyre->psi;
                $data['temperature'] = $tyre->temperature;
                $data['status'] = $tyre->status;


                array_push($tpmsData, $data);
            }
        }

        /*print_r('<pre>');
        print_r($tpmsData);
        exit;*/

        $axle_pressure = $this->mdl_tpms->get_axle_pressure_config($asset_id);

        echo json_encode(array('pressure_config'=>$axle_pressure, 'info'=>$tpmsData));
        
        /*$min = 30;
        $max = 99;
        $rand_one = rand($min,$max);
        $rand_two = rand($min,$max);
        $rand_three = rand($min,$max);
        
        $array_info = array(
                            array('vehicle_id'=>4, 'device_id'=>1, 'axle'=>'X1','tyre'=>'T1', 'pressure'=>$rand_one, 'temperature' =>$rand_one),
                            array('vehicle_id'=>4, 'device_id'=>2, 'axle'=>'X1','tyre'=>'T2', 'pressure'=>$rand_three, 'temperature' =>$rand_three),
                            array('vehicle_id'=>4, 'device_id'=>3, 'axle'=>'X2','tyre'=>'T5', 'pressure'=>$rand_two, 'temperature' =>$rand_two)
                            
                            );*/
        
    }

    


    function save_tpms_data () {
        $hexString="55  AA  01  3B  42  08  8F
        55  AA  02  3F  42  08  88
        55  AA  03  11  41  08  A4
        55  AA  04  13  41  08  A1
        55  AA  05  13  40  08  A1
        55  AA  06  11  41  08  A1
        55  AA  07  12  40  08  A2
        55  AA  08  1C  40  08  A3
        55  AA  09  13  41  08  AC
        55  AA  0A  13  40  08  AE
        55  AA  0B  12  41  08  AF
        55  AA  0C  13  41  08  A9
        55  AA  0D  13  41  08  A8
        55  AA  0E  13  41  08  AB
        55  AA  0F  13  41  08  AA
        55  AA  10  12  40  08  B5
        55  AA  11  13  40  08  B5
        55  AA  12  11  41  08  B5
        55  AA  13  14  41  08  B1
        55  AA  14  12  41  08  B0
        55  AA  15  14  42  08  B4
        55  AA  16  13  40  08  B2
        55  AA  17  00  00  00  E8
        55  AA  18  00  00  00  E7
        55  AA  19  00  00  00  E6
        55  AA  1A  00  00  00  E5
        ";
        $hexString = trim($hexString);
        $hexString = preg_replace('/\s+/', ' ', $hexString);
        $hexString = str_replace("  ","",$hexString);
        $hexString = str_replace(" ","",$hexString);




        $tyres = str_split($hexString, 14);


        $newTyres = array();

        $keys = array('sync1', 'sync2', 'tyre_number', 'psi', 'temperature', 'status', 'check_sum');

        foreach ($tyres as $k=>$tyre) {
            $info = str_split($tyre, 2);
            $data = array();
            $count = 0;

            

            if (sizeof($info)==sizeof($keys)) {

                foreach ($info as $v=>$hex) {



                    $bin=pack('H*',$hex);
                    $bytes = unpack('C*', $bin);
                    
                    $value = $bytes[1];
                    $key = $keys[$v];

                    if ($v==3) {
                        $data['pressure_decimal'] = $value;
                        $data['kpa'] = round($value/0.1818 , 2);
                        $data['bar'] = round(($data['kpa'] - 100)/100, 2);
                        $psi = round($data['bar'] * 14.5);
                        $value=$psi;
                    }

                    if ($v==4) {
                        $data['temperature_decimal'] = $value;
                        $degrees = $value - 50;
                        $value = $degrees;
                    }

                    if ($v==5) {
                        if ($hex == 0) {
                            $status = 'Normal';
                        } else if ($hex == 8) {
                            $status = 'Tire leak';
                        } else if ($hex == 10) {
                            $status = 'Battery Low Voltage';
                        } else if ($hex == 20) {
                            $status = 'Loss of signal';
                        } else if ($hex == 18) {
                            $status = 'Tire leak, Battery Low Voltage';
                        } else if ($hex == 30) {
                            $status = 'Battery Low Voltage, Loss of signal';
                        } else if ($hex == 28) {
                            $status = 'Tire leak, Loss of signal';
                        } else if ($hex == 38) {
                            $status = 'Tire leak, Battery Low Voltage, Loss of signal';
                        }

                        $value = $status;
                    }

                    $data[$key] = $value;

                    $count++;
                }
            }

            array_push($newTyres, $data);

        }



        $finalTyres = array();
        foreach ($newTyres as $key => $value) {
            $value['device_id'] = '359710048219167';
            unset($value['sync1']);
            unset($value['sync2']);

            array_push($finalTyres, $value);
        }


        $this->mdl_tpms->save_tpms_live_data($finalTyres);


        print_r('<pre>');
        print_r ($finalTyres);
        exit;
    }







    

}
?>