<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Freight extends CI_Controller {
    function __construct() {

        parent::__construct();
       
        $this->load->model('mdl_freight');
        $this->load->library('emailsend');
    }

    public function track () {

        $tracking_no = $this->uri->segment(3);

        //$this->load->library('googlemaps');
        $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
        $map_lat = '-4.0434771';
        $map_long = '39.6682065';
        
        $coords = array();
        $data = array();
        $vehicleNames = array();
        $categoryOpt = '';
        $categoryList = '';
        $typeOpt = '';
        $typeList = '';
        $groupOpt = '';
        $groupsList = '';    
        $ownerOpt = '';
        $ownersList = '';
        $vehicleList = '';


        $vehicles = $this->mdl_freight->get_vehicle_gps ($tracking_no);
        
        if(count($vehicles)) {
            foreach ($vehicles as $vehicle) {
                $txt="";
                $txt = addslashes($vehicle->assets_name);
                if($vehicle->assets_friendly_nm!="")
                    $txt.="(".addslashes($vehicle->assets_friendly_nm).")";
                $vehicleNames[] =$txt;
                $vehicleList .= "<li asset-id='".$vehicle->asset_id."'>".$vehicle->assets_name.' - '.addslashes($vehicle->assets_friendly_nm)."</li>";
            }
        }

        $tracking_info = $this->mdl_freight->get_tracking_history ($tracking_no);

        
        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;
        $data['vehicleList'] = $vehicleList;
        $data['tracking_no'] = $tracking_no;
        $data['tracking_info'] = $tracking_info;
        
        $data['content_url'] = 'freight';
        $data['fa'] = 'fa fa-map-marker';
        $data['title'] = 'ITMS Africa | Freight';
        $data['content_title'] = 'Consignment Tracking';
        $data['content_subtitle'] = 'Track your cargo';
        $data['content'] = 'freight/freight.php';
       
	    $this->load->view('freight/main.php', $data);
	}


    public function get_company_landmarks () {
        $tracking_no = $this->input->post('tracking_no');
        $trip = $this->mdl_freight->get_trip_info ($tracking_no);

        $data = $this->mdl_freight->get_landmarks($trip['company_id']);

        echo json_encode($data);
    }

    public function get_trip_route () {
        $tracking_no = $this->input->post('tracking_no');
        $trip = $this->mdl_freight->get_trip_info ($tracking_no);

        $data = $this->mdl_freight->get_route_details ($trip['route_id']);

        echo json_encode($data);
    }

    public function get_company_zones () {
        $tracking_no = $this->input->post('tracking_no');
        $trip = $this->mdl_freight->get_trip_info ($tracking_no);
        $zones = $this->mdl_freight->get_zones($trip['company_id']);
        $vertices = $this->mdl_freight->get_vertices($trip['company_id']);

        $data['zones'] = $zones;
        $data['vertices'] = $vertices;

        echo json_encode($data);
    }

    public function get_company_map_display_routes () {
        $data = $this->mdl_gps_tracking->get_map_display_routes($this->session->userdata('itms_company_id'));
        echo json_encode($data);
    }

    public function refresh_grid () {
        $tracking_no = $this->input->post('tracking_no');
        
        $vehicles = $this->mdl_freight->get_vehicle_gps ($tracking_no);

        $res = array('vehicles'=>$vehicles);

        echo json_encode($res);
    }


    function get_vehicle_details () {
        $asset_id = $this->input->post('asset_id');
        $device_id = $this->input->post('device_id');

        $data = $this->mdl_gps_tracking->get_gps_vehicle_data($asset_id, $device_id);

        /*print_r('<pre>');
        print_r($data);
        exit;
*/
        echo json_encode($data);
    }

    public function filter_grid () {
        $owner_id = $this->input->post('owner');
        $type_id = $this->input->post('type');
        $cat_id = $this->input->post('cat');
        $group_id = $this->input->post('group');

        $vehicles = $this->mdl_gps_tracking->get_gps_vehicles ($this->session->userdata('itms_company_id'), $owner_id, $type_id, $cat_id, $group_id);

        $res = array('vehicles'=>$vehicles);



        echo json_encode($res);
    }

}
?>