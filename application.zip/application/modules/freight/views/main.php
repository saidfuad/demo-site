<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>

<html lang="en" class="no-js">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

    <title><?php echo $title?></title>
    
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,500,700,500italic,700italic,900,900italic,300,300italic,100italic,100' rel='stylesheet' type='text/css'>
    
    <!-- Begin Page Progress Bar Files -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/plugins/pace-0.5.1/pace.min.js')?>"></script>
    <link href="<?php echo base_url('assets/js/plugins/pace-0.5.1/themes/pace-theme-minimal.css')?>" rel="stylesheet">
    
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="<?php echo base_url('assets/icons/font-awesome/css/font-awesome.css')?>" rel="stylesheet">
    <!-- Themify Icons -->
    <link href="<?php echo base_url('assets/icons/themify/themify-icons.css')?>" rel="stylesheet">
    <!-- IonIcons Pack -->
    <link href="<?php echo base_url('assets/icons/ionicons-2.0.1/css/ionicons.min.css')?>" rel="stylesheet">
    <!-- Awesome Bootstrap Checkboxes -->
    <link href="<?php echo base_url('assets/css/awesome-bootstrap-checkbox.css')?>" rel="stylesheet">
    <!-- Page-Level Plugin CSS - Dashboard -->
    <link href="<?php echo base_url('assets/css/plugins/morris/morris.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/plugins/timeline/timeline.css')?>" rel="stylesheet">
    <!-- Date Range Picker Stylesheet -->
    
    <link href="<?php echo base_url('assets/css/styles/default.css')?>" type="text/css" rel="stylesheet" id="style_color" />


    <!-- Style LESS -->
    <link href="<?php echo base_url('assets/less/animate.less?1436965415')?>" rel="stylesheet/less" />
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/system/logo1.png">
    <link href="<?php echo base_url('assets/bootstrap-color-picker/src/bootstrap.colorpickersliders.css')?>" rel="stylesheet" type="text/css" media="all">
    <link href="<?php echo base_url('assets/css/styles/custom.css')?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/sweetalert.css') ?>" rel="stylesheet">



    <script src="<?php echo base_url('assets/js/jquery-2.1.4.min.js')?>"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/tinycolor/0.11.1/tinycolor.min.js"></script>
    <script src="<?php echo base_url('assets/bootstrap-color-picker/src/bootstrap.colorpickersliders.js')?>"></script>
    
    <script src="<?php echo base_url('assets/angular.min.js') ?>"></script>
    <!--<script src="<?php echo base_url('assets/locale.js') ?>"></script>-->
    <script src="<?php echo base_url('assets/moment.js') ?>"></script>
    <script src="<?php echo base_url('assets/angular_moment.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/app.js') ?>"></script>
    
    <!-- Date Range Picker -->
    <!--<link rel="stylesheet" href="<?php echo base_url('assets/daterangepicker.css') ?>" type="text/css" media="screen" />
    <script src="<?php echo base_url('assets/daterangepicker.js') ?>"></script>
    -->
    <!-- Include Required Prerequisites -->
    <script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
    <!--<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>-->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap/latest/css/bootstrap.css" />

    <!-- Include Date Range Picker -->
    <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/bootstrap-datetimepicker.min.js') ?>"></script>
    


    <!--<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap-datetimepicker.min.css') ?>" />
    <link href="<?php echo base_url('assets/css/plugins/daterangepicker/daterangepicker-bs3.css')?>" rel="stylesheet">
    <script src="<?php echo base_url('assets/js/plugins/daterangepicker/moment.min.js')?>"></script>
   
    

</head>

<body ng-app="app">

    <div id="wrapper">
        
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0;">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle pull-left margin left" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="?page=index">
                    <div style="padding-top:13px; font-size:18px; font-weight:300;width:100%; color: #18bc9c; overflow:hidden; height:50px; "><?php echo "ITMS Africa"; ?></div>
                </a>
                
            </div>
            <!-- /.navbar-header -->

            <!-- MEGA MENU -->
            

            <h4 style="margin-top:15px; margin-left:100px !important; "><?php echo $content_subtitle .":".$tracking_no; ?></h4>
            <!-- // MEGA MENU -->
        </nav>
        <!-- /.navbar-static-top -->


        <nav id="menu" class="navbar-default navbar-fixed-side hidden-xs" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    
                </ul>
                <!-- /#side-menu -->
            </div>
            <!-- /.sidebar-collapse -->

          

            
        </nav>
        <!-- /.navbar-static-side -->

    <div id="page-wrapper" class="">
        <div class="page-header">
            <div class="row">
                <div class="col-sm-6 col-md-6 ">
                    <h3 class="heading">
                        <i class="fa <?php echo $fa; ?> animated flip"></i> <?php echo $content_title; ?> <!--<span class="sub-heading"><?php echo $content_subtitle; ?></span>-->
                    </h3>
                </div>
                <!--<div class="col-sm-6 col-md-6 ">
                    <span class="hr-content pull-right">
                        <?php if (isset($content_btn)) { echo $content_btn; } ?>
                    </span>    
                </div>-->
           </div>
        </div>
        
        <?php $this->load->view($content);?>

    </div>
    <div class="page-alert" style="z-index: 10000;"></div>
    <!-- /#page-wrapper -->
                
    </div>
             
            <!--Reports panel-->
        
    <!-- footer -->
    <footer class="footer">
        <p>&copy; <?php echo date('Y')?> ITMS AFRICA, ALL RIGHTS RESERVED.</p>
    </footer>

    <!-- Element to pop up -->
    <div id="element_to_pop_up" class="alert-popup" style="z-index: 10000; top:100px;">Content of popup</div> 

    <script src="<?php echo base_url('assets/js/plugins/jquery-cookie/jquery.cookie.js')?>"></script>

    <div class="overshadow"></div>

    <!-- jQuery easing | Script -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <!-- Sparkline | Script -->
    <script src="<?php echo base_url('assets/js/plugins/sparklines/jquery.sparkline.js')?>"></script>
    <!-- Easy Pie Charts | Script -->
    <script src="<?php echo base_url('assets/js/plugins/easy-pie/jquery.easypiechart.min.js')?>"></script>
    <!-- Date Range Picker | Script -->
     <!-- BlockUI for reloading panels and widgets -->
    <script src="<?php echo base_url('assets/js/plugins/block-ui/jquery.blockui.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery-ui.custom.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/holder.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/nicescroll/jquery.nicescroll.min.js')?>"></script> 
    <!-- Init Scripts - Include with every page -->
    <script src="<?php echo base_url('assets/js/init.js')?>"></script>
    <script src="<?php echo base_url('assets/sweetalert.min.js') ?>"></script>      
    <script src="<?php echo base_url('assets/js/jquery.bpopup.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/daterangepicker/daterangepicker.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/select2/select2.js')?>"></script>
    
    <script type="text/javascript">
        $(function () {

            
            $(".navbar-fixed-side").hover(function(){
                    $(this).animate({"width":"250px"}, 0);
                    $("#page-wrapper").animate({"margin-left":"250px"}, 1000);
                    $(".menu-name").delay(800).fadeIn(100)
                }, function(){
                    $(this).animate({"width":"70px"}, 0);
                    $("#page-wrapper").animate({"margin-left":"70px"}, 1000);
                    $(".nav-second-level").removeClass("in");
                    $(".menu-name").fadeOut(500);
            });
            
        });
    </script>       
</body>

</html>