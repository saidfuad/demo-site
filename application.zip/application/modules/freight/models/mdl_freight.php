<?php 
class Mdl_freight extends CI_Model{
    var $user;
    var $current_time;


    function __construct () {
        parent::__construct();
            
        $this->user_id      = $this->session->userdata('itms_user_id');
        $this->current_time = date("Y-m-d H:i:s");
    }

    function get_trip_info ($tracking_no) {
        $query = $this->db->get_where('itms_trips', array('tracking_no'=>$tracking_no));
        $trip = $query->row_array();

        return $trip;
    }

    function get_vehicle_gps ($tracking_no) {
        //$this->db->where('tracking_no', $tracking_no);
        
        $trip = $this->get_trip_info($tracking_no);
        $vehicle_location = $this->get_vehicle_gps_data($trip['asset_id']);  

        return $vehicle_location;      
    }

    function get_vehicle_gps_data($asset_id) {
        $this->db->select('itms_last_gps_point.*, itms_assets.*, itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name');
        $this->db->from('itms_last_gps_point')
            ->join('itms_assets', 'itms_assets.device_id=itms_last_gps_point.device_id','left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left');
        
        $this->db->where('itms_assets.asset_id', $asset_id);
               
        $query = $this->db->get();
       
        return $query->result();
    }

    function get_landmarks ($company_id=null) {
            
        if ($company_id!=null) {
            $whereCompany = "AND company_id='".$company_id."'";
        }

        $q = "SELECT * 
                FROM itms_landmarks 
                WHERE 1
                AND status=1 
                    {$whereCompany}
                AND del_date is null ORDER BY landmark_name ASC ";

        $query = $this->db->query($q);
        return $query->result();
        
    }

    function get_route_details ($route_id) {
            
        $whereRoute = "AND route_id='".$route_id."'";
        
        $q = "SELECT * 
                FROM itms_routes 
                WHERE 1
                AND status=1 
                    {$whereRoute}";

        $query = $this->db->query($q);
        return $query->result();
        
    }

    function get_tracking_history($tracking_no) {
        $this->db->where('tracking_no', $tracking_no);
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('itms_freight_tracking');        

        return $query->result();
    }

    function get_gps_vehicle_data ($asset_id, $device_id) {
        $this->db->select('itms_assets.asset_id, itms_assets.assets_friendly_nm, itms_assets.assets_name, itms_assets.current_route, itms_assets.current_trip, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name, itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, itms_assets.paired_asset_id, itms_assets.no_of_axles, itms_assets.paired_asset_axles, itms_assets.axle_tyre_config, itms_assets.paired_asset_axle_tyre_config,itms_assets.paired_asset_device_id,
                        itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                            concat(itms_personnel_master.fname, " " , itms_personnel_master.lname) AS driver_name,
                                itms_personnel_master.phone_no AS driver_phone, itms_trips.*,
                                    itms_owner_master.owner_id, itms_owner_master.owner_name, itms_last_gps_point.*');
        $this->db->from('itms_assets')
            ->join('itms_last_gps_point', 'itms_last_gps_point.device_id = itms_assets.device_id', 'left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id','left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left')
            ->join('itms_trips', 'itms_trips.trip_id = itms_assets.current_trip', 'left');
        
        
        $this->db->where('itms_assets.asset_id', $asset_id);
        $query = $this->db->get();

        $res = array();
        
        $data = $query->row_array();
        $res['vehicle_info'] = $data;
        $trip_id = $data['current_trip']; 
        $route_id = $data['current_route'];
        $res['route_data']  = NULL;
        if ($route_id != NULL || $route_id != "") {
             $res['route_data'] = $this->get_route_by_id($route_id);
        }      
        $res['gps_hist'] = $this->get_current_trip_points($device_id, $trip_id);

        return $res;        
    }

    function get_zones ($company_id = null) {
        if($company_id != null) {
            $this->db->where('company_id', $company_id);
        }

        $this->db->where('status', 1);
        $this->db->where('del_date', NULL);

        $query = $this->db->get('itms_zones');

        return $query->result();
    }

    function get_vertices ($company_id = null) {
        if($company_id != null) {
            $this->db->where('company_id', $company_id);
        }

        $query = $this->db->get('itms_zones_vertices');

        return $query->result();
    }

    function get_current_trip_points($device_id, $trip_id) {
        $this->db->select('*');
        $this->db->from('itms_gps_track_points');
        $this->db->where('device_id', $device_id);
        $this->db->where('trip_id', $trip_id);

        $query = $this->db->get();

        return $query->result();
    }


    function get_route_by_id($route_id) {
        $this->db->select('*');
        $this->db->from('itms_routes');
        $this->db->where('route_id', $route_id);

        $query = $this->db->get();

        return $query->row_array();
    }

    public function get_devices($company_id=null, $user_id=null) {
        $this->db->where('itms_assets.status',1);
        $this->db->where('itms_assets.del_date',null);
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        $whereUser='';

        if ($user_id!=null) {
            $whereUser = " AND find_in_set(id, (SELECT assets_ids FROM user_assets_map where user_id = $user)) ";
        }
        
        $query = $this->db->query("select asset_id, assets_name, device_id, assets_friendly_nm 
                                    from 
                                        itms_assets 
                                    where status=1 AND del_date is null 
                                    {$whereUser}
                                    order by 
                                        assets_name asc");
        
        return $query->result();
    }

    public function get_vehicles_status($company_id, $user_assets=null) {
        
        if ($company_id!=null) {
            $this->db->where('itms_alert_master.company_id', $company_id);
        }

       $current_user_id = $this->session->userdata('itms_userid');

       //echo $current_user_id;
       //exit;

        $whereUser='';
        /*
        if ($us{$whereUser}er_id!=null) {
            $whereUser = " AND find_in_set(id, (SELECT assets_ids FROM user_assets_map where user_id = $user)) ";
        }
        */

        $query = $this->db->query("SELECT itms_last_gps_point.*,itms_assets.assets_name, itms_assets.assets_friendly_nm, 
                                                    itms_personnel_master.fname, itms_personnel_master.lname,itms_personnel_master.phone_no
                                    FROM 
                                        itms_last_gps_point
                                    LEFT JOIN itms_assets LEFT JOIN itms_personnel_master ON (itms_assets.personnel_id=itms_personnel_master.personnel_id) ON (itms_assets.device_id=itms_last_gps_point.device_id) 
                                    WHERE 
                                        FIND_IN_SET(itms_assets.asset_id, (select group_concat(asset_id) from itms_alerts_contacts where user_id='$current_user_id'))
                                    OR 
                                        FIND_IN_SET(itms_assets.asset_id, (select group_concat(asset_id) from itms_assets where add_uid='$current_user_id'))
                                    ORDER BY 
                                        id DESC");
        
        return $query->result();
    }

    function get_vehicles_owners ($company_id=null) {
        $this->db->select('itms_owner_master.*');
        $this->db->from('itms_owner_master');
        
        if ($company_id!=null) {
            $this->db->where('itms_owner_master.company_id', $company_id);
        }

        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }
    
    function get_vehicles_categories ($company_id=null) {
        $this->db->select('itms_assets_categories.*');
        $this->db->from('itms_assets_categories');
        
        if ($company_id!=null) {
            //$this->db->where('itms_assets_categories.company_id', $company_id);
        }

        
        $this->db->order_by('assets_cat_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }
    
    function get_vehicles_types ($company_id=null) {
        $this->db->select('itms_assets_types.*');
        $this->db->from('itms_assets_types');
       
        if ($company_id!=null) {
            //$this->db->where('itms_assets_types.company_id', $company_id);
        }

        $this->db->order_by('assets_type_nm', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }

    function get_vehicles_groups ($company_id=null) {
        $this->db->select('itms_assets_groups.*');
        $this->db->from('itms_assets_groups');
       
        if ($company_id!=null) {
            $this->db->where('itms_assets_groups.company_id', $company_id);
        }

        $this->db->order_by('assets_group_nm', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getAutoRefreshSettings(){
        $user_id = $this->session->userdata('itms_user_id');
        
        $SQL="select auto_refresh_setting from itms_users where user_id = '".$user_id."'";
        $query = $this->db->query($SQL);
        return $query->row();
    }
    public function getOnscreenAlertSettings(){
        $user_id = $this->session->userdata('itms_user_id');
        
        $SQL="select onscreen_alert from itms_users where user_id = '".$user_id."'";
        $query = $this->db->query($SQL);
        return $query->row();
    }

    

    function get_routes ($company_id=null) {
        if ($company_id!=null) {
           $this->db->where('company_id', $company_id); 
        }

        $this->db->select('route_id, route_name, route_color, duration, distance, start_address, end_address');
        $this->db->from('itms_routes');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_map_display_routes ($company_id=null) {
        if ($company_id!=null) {
           $this->db->where('company_id', $company_id); 
        }

        $this->db->select('*');
        $this->db->from('itms_routes');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_trips ($company_id=null) {
        
        $this->db->select("itms_trips.*, itms_assets.assets_friendly_nm, itms_assets.assets_name, itms_assets.device_id,
            (itms_personnel_master.fname + ' ' +itms_personnel_master.lname) AS driver_name ,itms_personnel_master.phone_no AS driver_phone, itms_client_master.client_name as client");
        $this->db->from('itms_trips');
        $this->db->join('itms_assets', 'itms_assets.asset_id=itms_trips.asset_id');
        $this->db->join('itms_personnel_master', 'itms_personnel_master.personnel_id=itms_trips.driver_id', 'left');
        $this->db->join('itms_client_master', 'itms_client_master.client_id=itms_trips.client_id', 'left');

        if ($company_id!=null) {
           $this->db->where('itms_trips.company_id', $company_id); 
        }
        
        $this->db->order_by('itms_trips.trip_id', 'DESC');
        $query = $this->db->get();

        return $query->result();        
    }

    

    
}
?>