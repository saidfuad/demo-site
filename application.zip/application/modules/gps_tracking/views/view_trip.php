<link href="<?php echo base_url('assets/bootstrap-color-picker/src/bootstrap.colorpickersliders.css')?>" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
    var infowindow;
    var vehicle_markers = [];
    var landmark_markers = [];
    var pop_marker = [];
    var map_pop;
    var map;
    var iw_map;
    var new_landmark_markers = [];
    var new_landmark_circles = [];
    var newLatLng = '';
    var fillcolor = '#337ab7';
    var range = parseFloat($("#landmark-radius").val());
    var countM = 0;
    var newLatLng = [];
    var landmark_circle_color = $('#full-popover').val();
    var marker;
    var infowindow;
    var infobox;

    function initMap() {
        map = new google.maps.Map(document.getElementById('map_canvas'), {
            center: {lat: <?= $map_lat; ?>, lng: <?= $map_long; ?>},
            zoom: 8,
            mapTypeId: google.maps.MapTypeId.HYBRID,
            heading: 90,
            tilt: 45
        });


        var geocoder = new google.maps.Geocoder;

        var input = /** @type {!HTMLInputElement} */(
                document.getElementById('pac-input'));

        var types = document.getElementById('type-selector');
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(types);

        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);



        infowindow = new google.maps.InfoWindow();


        marker = new google.maps.Marker({
            map: map,
            anchorPoint: new google.maps.Point(0, -29)
        });

        autocomplete.addListener('place_changed', function () {
            var place = autocomplete.getPlace();
            get_place(place);
        });

        function get_place(place) {
            infowindow.close();
            marker.setVisible(false);

            if (!place.geometry) {
                //window.alert("Returned place contains no geometry");
                swal({title: "Place not found", text: 'Returned place contains no geometry', type: 'info'});
                return;
            }

            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(15);  // Why 17? Because it looks good.
            }

            marker.setIcon(/** @type {google.maps.Icon} */({
                url: place.icon,
                size: new google.maps.Size(71, 71),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(17, 34),
                scaledSize: new google.maps.Size(35, 35)
            }));

            landmark_circle_color = fillcolor;
            newLatLng = place.geometry.location;

            show_marker(false);



            var address = '';
            if (place.address_components) {
                address = [
                    (place.address_components[0] && place.address_components[0].short_name || ''),
                    (place.address_components[1] && place.address_components[1].short_name || ''),
                    (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
            }

            if (place.name) {
                var place_name = place.name;
            } else {
                var place_name = place.address_components[0].short_name;
            }

            var sel_lat = place.geometry.location.lat;
            var sel_lng = place.geometry.location.lng;
            var lnd_mark = place_name;
            var addrs = address;

            if (place.icon) {
                var place_icon = place.icon;
                $('#gmap_icon').val(1);
                $("#icon_path").val(place.icon);
            } else {
                $('#gmap_icon').val(0);
                $("#icon_path").val('');
            }


            $("#input-latitude").val(sel_lat);
            $("#input-longitude").val(sel_lng);
            $("#destination_address").val(lnd_mark);
            //$("#address").val(addrs);


            $(".page-alert").children("p").html("You have <strong>selected</strong>  " + place.name);


            infowindow.setContent('<div><strong>' + place_name + '</strong><br>' + address);
            infowindow.open(map, marker);

        }

        // Sets a listener on a radio button to change the filter type on Places
        // Autocomplete.
        function setupClickListener(id, types) {
            var radioButton = document.getElementById(id);
            radioButton.addEventListener('click', function () {
                autocomplete.setTypes(types);
            });
        }

        setupClickListener('changetype-all', []);
        setupClickListener('changetype-address', ['address']);
        setupClickListener('changetype-establishment', ['establishment']);
        setupClickListener('changetype-geocode', ['geocode']);


        map.addListener('click', function (event) {

            marker.setVisible(false);
            clearMarkers(new_landmark_markers);
            clearCircles(new_landmark_circles);

            newLatLng = event.latLng;

            var latitude = event.latLng.lat();
            var longitude = event.latLng.lng();
            //var landmark_name = $('#landmark_name').val();
            landmark_circle_color = fillcolor;
            //var landmark_image = $('#icon_path').val();
            var place_name = '';
            var address = '';

            $("#end_lat").val(event.latLng.lat());
            $("#end_lng").val(event.latLng.lng());


            var latlng = {lat: parseFloat(latitude), lng: parseFloat(longitude)};
            geocoder.geocode({'location': latlng}, function (results, status) {
                if (status === google.maps.GeocoderStatus.OK) {
                    if (results[0]) {
                        place_name = results[0].address_components[1].long_name + " " + results[0].address_components[0].long_name;
                        address = results[0].formatted_address;

                        $("#destination_address").val(place_name);

                        alert(place_name);
                        //$("#address").val(address);
                        //get_place(place);
                        //alert(JSON.stringify(results[0]));
                        show_marker(true);
                    } else {
                        swal({title: "Info", text: 'Could not get the Selected Place address', type: 'success'});
                        place_name = '';
                        address = '';
                        show_marker(true);
                    }
                } else {
                    swal({title: "Info", text: 'Could not get the Selected Place address', type: 'success'});
                    place_name = '';
                    address = '';

                    show_marker(true);
                }
            });

            //alert(place_name);

            ///place_name = "(" + place_name +")";

            $(".page-alert").children("p").html("You have <strong>selected</strong> the position on the <strong>marker</strong> ");
        });

        function show_marker(show) {
            marker.setPosition(newLatLng);
            marker.setVisible(true);
            if (show) {
                marker.setIcon({
                    url: "https://maps.gstatic.com/mapfiles/place_api/icons/geocode-71.png",
                    size: new google.maps.Size(71, 71),
                    origin: new google.maps.Point(0, 0),
                    anchor: new google.maps.Point(17, 34),
                    scaledSize: new google.maps.Size(35, 35)
                });
            }

            range = parseFloat($("#landmark-radius").val());

            //addMarker(newLatLng, landmark_image, landmark_name);
            addCircle(newLatLng, landmark_circle_color);
        }

        iw_map = new google.maps.InfoWindow({
            content: ''
        });

        //load_landmarks();

    }

    function load_landmarks() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('index.php/settings/get_company_landmarks') ?>",
            data: {company: 'this company'},
            success: function (data) {
                landmarks = JSON.parse(data);

                //alert(landmarks.length);
                if (landmarks.length > 0) {
                    for (var row in landmarks) {
                        if (landmarks[row].gmap_icon == 0) {
                            $icon = "<?= base_url('" + landmarks[row].icon_path+ "') ?>";
                        } else {
                            $icon = landmarks[row].icon_path;
                        }

                        $pos = {lat: parseFloat(landmarks[row].latitude, 10), lng: parseFloat(landmarks[row].longitude)};
                        //console.log(parseInt(landmarks[row].latitude, 10));
                        landmark_markers.push(new google.maps.Marker({
                            position: $pos,
                            map: map,
                            icon: $icon,
                            content: landmarks[row].landmark_name,
                        }));
                    }

                    var llength = landmark_markers.length;

                    for (var i = 0; i < llength; i++) {

                        $icn = landmark_markers[i].icon;

                        landmark_markers[i].setIcon(/** @type {google.maps.Icon} */({
                            url: $icn,
                            size: new google.maps.Size(71, 71),
                            origin: new google.maps.Point(0, 0),
                            anchor: new google.maps.Point(12, 24),
                            scaledSize: new google.maps.Size(24, 24)
                        }));

                        google.maps.event.addListener(landmark_markers[i], "mouseout", function (event) {
                            iw_map.close();
                        });

                        google.maps.event.addListener(landmark_markers[i], "click", function (event) {
                            map.setCenter(this.getPosition());
                            map.setZoom(15);
                            map.setTilt(45);

                            console.log(event.latLng.lat() + ',' + event.latLng.lng());

                        });

                        google.maps.event.addListener(landmark_markers[i], "mouseover", function (event) {
                            iw_map.setContent(this.get("content"));
                            iw_map.open(map, this);
                        });

                    }

                    if (llength) {
                        fit_bounds();
                    }


                }

            }
        });
    }

    function rotate90() {
        var heading = map.getHeading() || 0;
        map.setHeading(heading + 90);
    }

    function autoRotate() {
        // Determine if we're showing aerial imagery.
        if (map.getTilt() !== 0) {
            window.setInterval(rotate90, 3000);
        }
    }


    function addMarker(location, icon, landmark_name) {

        icon = "<?= base_url('" + icon + "') ?>";
        new_landmark_markers.push(new google.maps.Marker({
            position: location,
            map: map,
            //icon: icon,
            content: landmark_name,
            scaledSize: new google.maps.Size(20, 20)

        }));

        addCircle(location);

        google.maps.event.addListener(new_landmark_markers[0], "mouseout", function (event) {
            iw_map.close();
        });

        google.maps.event.addListener(new_landmark_markers[0], "click", function (event) {
            swal({title: "Info", text: 'Landmark Created successfully', type: 'success'});
        });

        google.maps.event.addListener(new_landmark_markers[0], "mouseover", function (event) {
            iw_map.setContent(this.get("content"));
            iw_map.open(map, this);
        });
    }


    function addCircle(location) {
        new_landmark_circles.push(new google.maps.Circle({
            strokeColor: "0.8",
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: fillcolor,
            fillOpacity: 0.4,
            map: map,
            center: location,
            radius: 0.1 * 1000
        }));


    }

    function clearMarkers(new_landmark_markers) {
        var countMarkers = new_landmark_markers.length;
        if (countMarkers > 0) {
            for (var i = 0; i < countMarkers; i++) {
                new_landmark_markers[i].setMap(null);
            }
        }
    }

    function clearCircles(new_landmark_circles) {
        var countCircles = new_landmark_circles.length;
        if (countCircles > 0) {
            for (var i = 0; i < countCircles; i++) {
                new_landmark_circles[i].setMap(null);
            }
        }
    }

    function fit_bounds() {
        var bounds = new google.maps.LatLngBounds();
        var vsize = landmark_markers.length;

        //console.log('Size:' + vehicle_markers.length);

        for (i = 0; i < vsize; i++) {
            bounds.extend(landmark_markers[i].getPosition());
        }

        map.fitBounds(bounds);
    }

</script>

<script type="text/javascript">
    $(function () {


    });
</script>

<style>

    .controls {
        margin-top: 10px;
        border: 1px solid transparent;
        border-radius: 2px 0 0 2px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        height: 32px;
        outline: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
    }

    #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 300px;
    }

    #pac-input:focus {
        border-color: #4d90fe;
    }

    .pac-container {
        font-family: Roboto;
    }

    #type-selector {
        color: #fff;
        background-color: #4d90fe;
        padding: 5px 11px 0px 11px;
    }

    #type-selector label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
    }
</style>

<div class="container-fluid fleet-view">
    <div class="row">
        <div class="col-md-4" style="height:100%">
            <div class="col-md-12 bg-crumb" >
                <?php if (sizeof($trip)) { foreach ($trip as $key => $value) { ?>
                    <div class="panel fleet-panel panel-blockquote">
                        <h3 id="fleet-car-title"><i class="fa fa-info-circle"></i> Trip Details</h3>  
                        <div class="panel panel-blockquote panel-border-success left" id="fleet-trip-details">
                            <div class="panel-body">
                                <table class="table table-striped table-hover">
                                    <tbody>
                                        <tr>
                                            <td class="text-muted text-right"><b>Trip Name:</b></td>
                                            <td><b><?php echo $value->trip_name; ?></b></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted text-right col-md-3">Driver:</td>
                                            <td><?php echo $value->client_name; ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted text-right col-md-3">Vehicle:</td>
                                            <td><?php echo $value->client_name; ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted text-right col-md-3">Client Name:</td>
                                            <td><?php echo $value->client_name; ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted text-right col-md-3">Consignment:</td>
                                            <td><?php echo $value->consignment; ?></td>
                                        </tr>
                                            
                                        <?php if ($value->is_complete == 0) {}elseif ($value->is_complete == 1) {?>
                                            <tr>
                                                <td class="text-muted text-right"><b>Readings</b></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">Start Time</td>
                                                <td><?php echo $value->start_time; ?></td>
                                            </tr>
                                        <?php }else { ?>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">End Time</td>
                                                <td><?php echo $value->end_time; ?></td>
                                            </tr>
                                        <?php } ?>
                                        
                                        <?php if ($value->is_complete == 0) {}elseif ($value->is_complete == 1) {?>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">Start Reading</td>
                                                <td><?php echo $value->start_km_reading." Km"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">Distance Travelled</td>
                                                <td><?php echo $value->distance_travelled." Km"; ?></td>
                                            </tr>
                                        <?php }else { ?>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">Final Reading</td>
                                                <td><?php echo $value->end_km_reading." Km"; ?></td>
                                            </tr>
                                        <?php } ?>
                                        
                                        <tr>
                                            <td class="text-muted text-right"><b>Status</b></td>
                                            <td><?php if ($value->is_complete == 0) {
                                                        echo "<a class='btn btn-danger btn-xs'>Not Started</a>"; 
                                                    }else if ($value->is_complete == 1) {
                                                        echo "<a class='btn btn-warning btn-xs'>In Progress</a>"; 
                                                    }else {
                                                        echo "<a class='btn btn-success btn-xs'>Completed</a>";
                                                    } ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted text-right"></td>
                                            <td><?php if ($value->is_complete == 0) {
                                                        echo "<a href='".base_url('index.php/gps_tracking/start_trip/'.$value->trip_id)
                                                    ."'class='btn btn-success'>Start Trip</a>"; 
                                                    } 
                                                ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php }} ?>
            </div>  
        </div>  
        <div class="col-md-8" >
            <input id="pac-input" class="controls" type="text"
                   placeholder="Enter a location">
            <div id="type-selector" class="controls">
                <input type="radio" name="type" id="changetype-all" checked="checked">
                <label for="changetype-all">All</label>

                <input type="radio" name="type" id="changetype-establishment">
                <label for="changetype-establishment">Establishments</label>

                <input type="radio" name="type" id="changetype-address">
                <label for="changetype-address">Addresses</label>

                <input type="radio" name="type" id="changetype-geocode">
                <label for="changetype-geocode">Geocodes</label>
            </div>
            <div class="col-md-12" id='map_canvas' style="height:540px"></div>

        </div>       
        <!-- //. Content -->
    </div>
    <!-- /.row -->
</div>        

<script type="text/javascript">

    $(function () {
        
        $('#landmark-radius').on('keyup change', function () {

            var radius = parseFloat($(this).val().trim());
            
            clearCircles(new_landmark_circles);

            if (!$.isNumeric(radius) || radius == 0) {
                clearCircles(new_landmark_circles);
            } else {
                range = radius;
                addCircle(newLatLng);
            }
        });

    });
</script>
<script src="<?php echo base_url('assets/bootstrap-color-picker/src/bootstrap.colorpickersliders.js')?>"></script>

<script async defer src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyBn6m_W3hRMPg5nDlmqsRkaO3kE1LZ1HX4&libraries=places,drawing&callback=initMap"></script>
<!-- 
<script async defer src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyCfKP5H8r9ohlPjH_CbddIefMbeCirz7-U&libraries=places&callback=initMap">
  </script>-->