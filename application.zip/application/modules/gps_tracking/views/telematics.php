<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($status)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Vehicle Name</th>
                                <th>Number Plate</th>
                                <th>Driver Name</th>
                                <th>Status</th>
                                <!--<th>Ignition</th>-->
                                <th>Speed</th>
                                <th>Address</th>
                                <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($status as $key => $value) { ?>
                           <tr class="gradeU">
                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                <td><?php echo $value->assets_name; ?></td>
                                <td><a href="#"><?php echo $value->fname . ' ' . $value->lname; ?></a></td>
                                <td><?php if($value->speed == 0 || $value->ignition = 1) {
                                			   echo 'Idle';
                                	 	   } else if($value->speed == 0 || $value->ignition = 0) {
                                				echo 'Parked';
                                	 	   } else if($value->speed > 0) {
                                				echo 'Moving';
                                	 	   }
                                ?></td>
                                <!--<td><?php if($value->ignition = 1) {
                                			   echo 'ON';
                                	 	   } else if($value->ignition = 0) {
                                				echo 'OFF';
                                	 	   } 
                                ?></td>-->
                                <td><?php echo $value->speed . ' Kmh'; ?></td>
                                <td><?php echo $value->address; ?></td>
                                <td><!--<button class="btn btn-success btn-xs">Call</button>--><button class="btn btn-danger btn-xs">Send SMS</button></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Status</h2>
                    <br>
                    <p>No Data Available</p> 
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>
