<?php echo $map['js']; ?>
<script>
  var infowindow;
  var vehicle_markers = [];
  var landmark_markers = [];
  var pop_marker = [];
  var map_pop;


</script>

<style type="text/css">
  #map-pop {
    display:none;
    position: fixed;
    z-index: 4000;
    width:50%;
    height:100%;
    top:0px;
    right:0px;
    box-shadow:5px 5px 5px #333;
    background:#fff;
    border:1px solid #ccc;
  }

</style>
<input type="hidden" id="refresh-session" class="" value="0" />
<input type="hidden" id="refresh-interval" class="" value="<?php if (isset($_SESSION['refresh_time'])) {echo $_SESSION['refresh_time'];} else {echo 15;} ?>" />
<div class="container-fluid fleet-view">
    <div class="row">
        <div class="col-md-12">
            <br>
            <div class="col-md-12 bg-crumb">
                <div class="form-inline" role="form">
                  <div class="form-group">
                     <!--<label for="owners">Owners:</label>-->
                    <select class="form-control filter-map" name="select-owners" id="select-owners">
                        <option value="0">All Owners <i class="fa fa-home"></i></option>
                        <?php echo $ownerOpt;?>
                    </select>
                  </div>
                  <div class="form-group">
                     <!--<label>Types: </label>-->
                    <select class="form-control filter-map" name="select-types" id="select-types">
                        <option value="0">All Types</option>
                        <?php echo $typeOpt;?>
                    </select>
                  </div>
                  <div class="form-group">
                    <!--<label>Categories: </label>-->
                    <select class="form-control filter-map" name="select-categories" id="select-categories">
                        <option value="0">All Categories</option>
                        <?php echo $categoryOpt;?>
                    </select>
                  </div>
                  <!--<div class="form-group">
                    
                    <select class="form-control" name="select-areas" id="select-areas">
                        <option value="0">All Areas</option>
                        
                    </select>
                  </div>-->
                  <!--<div class="form-group">
                     <!--<label>Routes: </label>
                    <select class="form-control filter-map" name="select-routes" id="select-routes">
                        <option value="0">All Routes</option>
                        
                    </select>
                  </div>-->
                  <!--<div class="form-group">
                    <select class="form-control" name="select-landmarks" id="select-landmarks">
                        <option value="0">All Landmarks</option>
                        <?php echo $landmarkOpt;?>
                    </select>
                  </div>-->
                  <div class="form-group pull-right">
                    <label>Search: </label>
                    <input class="form-control" name="vehicle-search" id="vehicle-search" placeholder="vehicle name/no. plate"/>
                  </div>
                  
                </div>
            </div>    
           
        </div>       
        <div class="col-md-12">
            <div class="" style="background:#eee;border-bottom:2px solid #aaa">
              <div class="col-md-6">
                 <div class="form-inline" role="form">
                  <div class="form-group">
                     <label>Refresh after:</label>
                     <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="15" 
                        <?php if ($_SESSION['refresh_time']==15) {?>checked<?php } ?>> 15 secs  &nbsp;&nbsp;&nbsp;&nbsp;  
                  </div>
                  <div class="form-group">
                     <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="30"
                      <?php if ($_SESSION['refresh_time']==30) {?>checked<?php } ?>> 30 secs &nbsp;&nbsp;&nbsp;&nbsp; 
                  </div>
                  <div class="form-group">
                     <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="45"
                      <?php if ($_SESSION['refresh_time']==45) {?>checked<?php } ?>> 45 secs &nbsp;&nbsp;&nbsp;&nbsp; 
                  </div>
                </div>  
              </div>
              <div class="col-md-6">
                 <div class="form-inline" role="form">
                  <div class="form-group">
                     <label>Status</label>
                     <img src="<?php echo base_url('assets/images/gps/marker-normal.png'); ?>" class="legend-marker"/> Moving
                  </div>
                  <div class="form-group">
                     <img src="<?php echo base_url('assets/images/gps/marker-warning.png'); ?>" class="legend-marker"/> Idle
                  </div>
                  <div class="form-group">
                     <img src="<?php echo base_url('assets/images/gps/marker-danger.png'); ?>" class="legend-marker"/> Parked
                  </div>
                </div>  
              </div>
            </div>
        </div>
        <div class="col-md-12">
            <?php echo $map['html']; ?>
        </div>       
        <!-- //. Content -->
    </div>
    <!-- /.row -->
</div> 

          <div id="map-pop">
            <div class="panel panel-default">
                <div class="panel-heading panel-info clearfix">
                    <h4 class="panel-title">Vehicle Details<button class="close" id="close-map-pop">&times;</button></h4>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="text-center fleet-img">
                                <img width="100%" height="80" src="<?php echo base_url('assets/images/photos/car2.jpg')?>" alt="" class="img-rounded">
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <span class="caption">Vehicle Name: </span><span id="pop-v-name"></span><br>
                            <span class="caption">Plate No: </span><span id="pop-n-plate"></span><br>
                            <span class="caption">Driver Name: </span><span id="pop-d-name"></span><br>
                            <span class="caption">Driver Phone: </span><span id="pop-d-phone"></span><br>
                             <br>
                        </div>
                        <div class="col-sm-5">
                            <span class="caption">Trip Name: </span><span id="pop-t-name"></span><br>
                            <span class="caption">From: </span><span id="pop-from"></span><br>
                            <span class="caption">Destination: </span><span id="pop-destination"></span><br>
                            <span class="caption">Cargo: </span><span id="pop-cargo"></span><br>
                             <br>
                        </div>
                        <br>
                        <div class="col-sm-12">
                            <div class="col-sm-6">
                              <span class="caption"><strong>Start Time: </strong></span> <span id="pop-s-time"></span>

                            </div>
                            <div class="col-sm-6">
                                <span class="caption"><strong>Arrival Time:</strong></span><span id="pop-e-time"></span>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
                <div class="col-sm-12 map-zone" id="map-zone" style="height:550px;">
                            
                </div>
    <!--                <div class="col-sm-4" id="directions-panel" style="height:350px;border:3px solid #ccc;overflow-y:scroll">
                            
                </div>-->
            </div>
        </div>       

<script type="text/javascript">
  $(function () {


      var refresh_interval = parseFloat($('#refresh-interval').val()) * 1000;
      var refresh = setInterval(function(){ refresh_vehicle_locations(2); }, refresh_interval);
      
      //console.log(markers_map.length);
      refresh_vehicle_locations(1);

      $('.radio-rt').on('click', function () {
        //alert($(this).attr('data-time'));

        $('#refresh-interval').val($(this).attr('data-time'));

        refresh_interval = parseFloat($('#refresh-interval').val()) * 1000;
        //alert(refresh_interval);
        clearInterval(refresh);
        refresh=null;
        refresh = setInterval(function(){ refresh_vehicle_locations(2); }, refresh_interval);
        display_alert('Refreshing in ' + refresh_interval/1000 + ' Seconds');
        hideAlert();
      
      });


      
      var count = 0;
     
      function refresh_vehicle_locations (times) {
          var owner = $('#select-owners').val();
          var type = $('#select-types').val();
          var cat = $('#select-categories').val();
          var query = $('#vehicle-search').val().trim();

          var refresh_session = parseInt($('#refresh-session').val(), 10);
          display_alert('Refreshing...');
          
          if (times > 1) {
            clearVehicleMarkers();
          }
          
          
          $('#refresh-session').val(refresh_session + 1);


          //return false;

          $.ajax({
                  type    : "POST",
                  cache   : false,
                  data : {owner:owner, type:type, cat:cat, query:query},
                  url     : "<?php echo base_url('index.php/gps_tracking/refresh_grid') ?>",
                  success: function(response) {
                      res = JSON.parse(response);
                      var message = [];  
                      var LatLngList = []; 

                      //alert(res.vehicles.length);
                      
                      for(var vehicle in res.vehicles) {

                          $asset_id = res.vehicles[vehicle].asset_id;
                          $device_id = res.vehicles[vehicle].device_id;

                          if(parseInt(res.vehicles[vehicle].ignition) === 1 && parseInt(res.vehicles[vehicle].speed) > 0 && parseInt(res.vehicles[vehicle].speed) < parseInt(res.vehicles[vehicle].max_speed_limit)) {
                              $icon = "<?= base_url('assets/images/gps/marker-normal.png') ?>";
                              $speed_message = "Vehicle Moving Normally";
                              //message.push($speed_message);
                          } else if (parseInt(res.vehicles[vehicle].ignition) ===1 && parseInt(res.vehicles[vehicle].speed) === 0) {
                              $icon = "<?= base_url('assets/images/gps/marker-warning.png') ?>";
                              $speed_message = "Vehicle is idle";
                              message.push($speed_message);
                          } else if (parseInt(res.vehicles[vehicle].speed) > parseInt(res.vehicles[vehicle].max_speed_limit)) {
                              $icon = "<?= base_url('assets/images/gps/marker-warning.png') ?>";
                              $speed_message = "Overspeeding";
                              message.push($speed_message);
                              } else if (parseInt(res.vehicles[vehicle].ignition) === 0 ) {
                              $icon = "<?= base_url('assets/images/gps/marker-danger.png') ?>";
                              $speed_message = "Vehicle has stopped";
                              message.push($speed_message);
                          }

                          $time = res.vehicles[vehicle].tm; 

                          $date = res.vehicles[vehicle].dt;
                          $date = $date.split(" ");
                          $date = $date[0];
                          $date = new Date($date +" "+$time);

                          if ( res.vehicles[vehicle].ignition === 1) {
                            $ignition = '<button class="btn btn-success btn-xs">On</button>';
                          } else {
                            $ignition = '<button class="btn btn-default btn-xs">Off</button>';
                          }

                          $vehicle_name = res.vehicles[vehicle].assets_name;
                          $position = {lat: parseFloat(res.vehicles[vehicle].latitude), lng: parseFloat(res.vehicles[vehicle].longitude)};
                          //$icon = "<?= base_url('assets/images/gps/normals.png') ?>";
                          $marker_type = 'vehicle';
                          $title = 'Vehicle Name: ' + res.vehicles[vehicle].assets_friendly_nm + ' <br>Plate No.:' + res.vehicles[vehicle].assets_name +' <br>Ignition: ' + $ignition +' <br>Speed: ' + res.vehicles[vehicle].speed + "Kmh <br>Address: " + res.vehicles[vehicle].address + "<br>Date: " + $date;

                          addMarker($marker_type, $title, $position, $icon, $asset_id, $device_id);
                          //  Make an array of the LatLng's of the markers you want to show
                          
        
                      } 


                      for (var i=0; i<vehicle_markers.length; i++) {
                          google.maps.event.addListener(vehicle_markers[i], "mouseout", function(event) {
                            iw_map.close();
                          });

                          google.maps.event.addListener(vehicle_markers[i], "click", function(event) {
                            map.setCenter(this.getPosition());
                            map.setZoom(15);
                            map.setTilt(45);

                            $('#map-pop').fadeIn(1000);

                            get_vehicle_details (this.asset_id, this.device_id, this.content, this.icon);
                            
                          });
                          
                          google.maps.event.addListener(vehicle_markers[i], "mouseover", function(event) {
                              iw_map.setContent(this.get("content"));
                              iw_map.open(map, this);
                          });

                          google.maps.event.addListener(vehicle_markers[i], "doubleclick", function(event) {
                              alert();
                          });
                      }


                      

                      hideAlert();

                      fit_bounds();

                  }
                  
              });

        ///hideAlert();


      }

      function get_vehicle_details (asset_id, device_id, content, icon) {

        //alert(asset_id);
         
          $.ajax({
                  type    : "POST",
                  cache   : false,
                  dataType:'JSON',
                  data : {asset_id:asset_id, device_id:device_id},
                  url     : "<?php echo base_url('index.php/gps_tracking/get_vehicle_details') ?>",
                  success: function(response) {
                      //alert();
                      //res = JSON.parse(response);
                      $('#pop-v-name').html(response.vehicle_info.assets_friendly_nm);
                      $('#pop-n-plate').html(response.vehicle_info.assets_name);
                      $('#pop-d-name').html(response.vehicle_info.driver_name);
                      $('#pop-d-phone').html(response.vehicle_info.driver_phone);
                      $('#pop-t-name').html(response.vehicle_info.trip_name);

                      $('#pop-s-time').html(response.vehicle_info.start_time);
                      $('#pop-e-time').html(response.vehicle_info.end_time);

                      $position = {lat: parseFloat(response.vehicle_info.latitude), lng: parseFloat(response.vehicle_info.longitude)};
                      $wypt = parseFloat(response.vehicle_info.latitude)+','+parseFloat(response.vehicle_info.longitude);
                      var waypts = [];
                      //var checkboxArray = document.getElementById('waypoints');
          
                      for (var point in response.gps_hist) {
                          loc = parseFloat(response.gps_hist[point].latitude) + ',' + parseFloat(response.gps_hist[point].longitude);
                          //loc = response.gps_hist[point].address;
                          waypts.push(loc);
                      }

                      var wpt_len = waypts.length;
                      var slots = Math.floor(wpt_len/6);
                      var new_waypts = [];

                      //alert(slots);
                      
                      for (var i=0; i<wpt_len; i++) {
                          if (i===0 || (i%slots===0)) {
                               new_waypts.push({
                                    location: waypts[i],
                                    stopover: true
                                });
                          }
                      }


                      /*
                      new_waypts.push({
                                    location: $wypt,
                                    stopover: true
                                });

*/

                      //alert(new_waypts.length);
                      /*return false;*/

                     
                      var directionsService = new google.maps.DirectionsService;
                      var directionsDisplay = new google.maps.DirectionsRenderer;

                      map_pop = new google.maps.Map(document.getElementById('map-zone'), {
                                center: $position,
                                zoom: 8
                            });  
                      console.log($position.lat +','+ $position.lng);
                      pop_marker.push(new google.maps.Marker({
                              position: $position,
                              map: map_pop,
                              icon: icon, 
                              content:content,
                              animation: google.maps.Animation.DROP,
                              asset_id:asset_id,
                              device_id:device_id
                      }));       
                         
                      directionsDisplay.setMap(map_pop);
                      calculateAndDisplayRoute(directionsService, directionsDisplay, new_waypts);
                  }

                });
      }

      function calculateAndDisplayRoute(directionsService, directionsDisplay, waypts) {
                len = waypts.length;
                len = len - 1;

                //alert(waypts[0].location);
                //return false;
                directionsService.route({
                  origin:waypts[0].location,
                  destination: waypts[len].location,
                  waypoints: waypts,
                  optimizeWaypoints: true,
                  travelMode: google.maps.TravelMode.DRIVING
                }, function(response, status) {
                  if (status === google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(response);
                    var route = response.routes[0];
                   /* var summaryPanel = document.getElementById('directions-panel');
                    summaryPanel.innerHTML = '';
                    // For each route, display summary information.
                    for (var i = 0; i < route.legs.length; i++) {
                      var routeSegment = i + 1;
                      summaryPanel.innerHTML += '<b>Route Segment: ' + routeSegment +
                          '</b><br>';
                      summaryPanel.innerHTML += route.legs[i].start_address + ' to ';
                      summaryPanel.innerHTML += route.legs[i].end_address + '<br>';
                      summaryPanel.innerHTML += route.legs[i].distance.text + '<br><br>';
                    }*/
                  } else {
                    window.alert('Directions request failed due to ' + status);
                  }
                });

        //fit_bounds_pop();
      }

      function addMarker(type, title, location, image,asset_id, device_id) {
               
        vehicle_markers.push(new google.maps.Marker({
              position: location,
              map: map,
              icon: image, 
              content:title,
              animation: google.maps.Animation.DROP,
              asset_id:asset_id,
              device_id:device_id
        }));
        
      }

      function fit_bounds () {
        var bounds = new google.maps.LatLngBounds();
        var vsize = vehicle_markers.length;

        //console.log('Size:' + vehicle_markers.length);
        
        for(i=0; i<vsize; i++) {
            bounds.extend(vehicle_markers[i].getPosition());
        }

        map.fitBounds(bounds);
      }

      function fit_bounds_pop () {
        var bounds = new google.maps.LatLngBounds();
        
        for(i=0;i<pop_marker.length;i++) {
            bounds.extend(pop_marker[i].getPosition());
        }

        map_pop.fitBounds(bounds);
      }

      function display_alert(Message) {
          $('.page-alert').html('<p align="center">'+Message+'</p>');
          $('.page-alert').animate({right:'10px'}, 2000);
      }

      function hideAlert() {
          $('.page-alert').animate({right:'-600px'}, 2000);
      }

      function clearVehicleMarkers () {
        var vMarkers = vehicle_markers.length;
        console.log('to be cleared' + vMarkers);
        if (vMarkers>0) {
            for (var i = 0; i < vMarkers; i++) {
                vehicle_markers[i].setMap(null);
                console.log('clearing');
            }
        }
        
        console.log('final size: ' + vehicle_markers.length);
      }

      function clearAllMarkers () {
        var countMarkers = markers_map.length;
        if (countMarkers>0) {
            for (var i = 0; i < countMarkers; i++) {
                markers_map[i].setMap(null);

            }
        }
      }


      $('#vehicle-search').keyup(function() {
          var no_of_v = vehicle_markers.length;
          var query = $(this).val().trim();
          var myValRe = new RegExp(query, 'i');

          //console.log(no_of_v);

          if (query.length) {
              
              for (var i=0; i<no_of_v; i++) {
                  var lookup_text = vehicle_markers[i].title;
                  //console.log(lookup_text + '        ' +query);
                  if (lookup_text.match(myValRe)) {
                      vehicle_markers[i].setVisible(true);
                  } else {
                      console.log('no match');
                      console.log(i);
                      vehicle_markers[i].setVisible(false);
                  }

                 
              }
          }    
         
      });


      $('#vehicle-search').keyup(function() {
          var no_of_v = vehicle_markers.length;
          var query = $(this).val().trim();
          var myValRe = new RegExp(query, 'i');

          //console.log(no_of_v);

          if (query.length) {
              
              for (var i=0; i<no_of_v; i++) {
                  var lookup_text = vehicle_markers[i].title;
                  //console.log(lookup_text + '        ' +query);
                  if (lookup_text.match(myValRe)) {
                      vehicle_markers[i].setVisible(true);
                  } else {
                      console.log('no match');
                      console.log(i);
                      vehicle_markers[i].setVisible(false);
                  }

                 
              }
          }    
         
      });

      $('.filter-map').change(function() {
          $('#vehicle-search').val('');
          var filter = $(this).val();
          var owner = $('#select-owners').val();
          var type = $('#select-types').val();
          var cat = $('#select-categories').val();

          filter_grid(owner, type, cat);
         
      });

      function filter_grid (owner, type, cat) {
          display_alert('Searching...');

          clearVehicleMarkers();
          
          $.ajax({
                  type    : "POST",
                  cache   : false,
                  data : {owner:owner, type:type, cat:cat},
                  url     : "<?php echo base_url('index.php/gps_tracking/filter_grid') ?>",
                  success: function(response) {
                      res = JSON.parse(response);
                      var message = [];  
                      var LatLngList = []; 
                      
                      for(var vehicle in res.vehicles) {

                          if(res.vehicles[vehicle].ignition === 1 && res.vehicles[vehicle].speed > 0 && res.vehicles[vehicle].speed < res.vehicles[vehicle].max_speed_limit) {
                              $icon = "<?= base_url('assets/images/gps/marker-normal.png') ?>";
                              $speed_message = "Vehicle Moving Normally";
                              //message.push($speed_message);
                          } else if (res.vehicles[vehicle].ignition ===1 && res.vehicles[vehicle].speed === 0) {
                              $icon = "<?= base_url('assets/images/gps/marker-warning.png') ?>";
                              $speed_message = "Vehicle is idle";
                              message.push($speed_message);
                          } else if (res.vehicles[vehicle].speed > res.vehicles[vehicle].max_speed_limit) {
                              $icon = "<?= base_url('assets/images/gps/marker-warning.png') ?>";
                              $speed_message = "Overspeeding";
                              message.push($speed_message);
                          } else if (res.vehicles[vehicle].ignition === 0 ) {
                              $icon = "<?= base_url('assets/images/gps/marker-danger.png') ?>";
                              $speed_message = "Vehicle has stopped";
                              message.push($speed_message);
                          }

                          $time = res.vehicles[vehicle].tm; 

                          $date = res.vehicles[vehicle].dt;
                          $date = $date.split(" ");
                          $date = $date[0];
                          $date = new Date($date +" "+$time);

                          if ( res.vehicles[vehicle].ignition === 1) {
                            $ignition = '<button class="btn btn-success btn-xs">On</button>';
                          } else {
                            $ignition = '<button class="btn btn-default btn-xs">Off</button>';
                          }

                          $vehicle_name = res.vehicles[vehicle].assets_name;
                          $position = {lat: parseFloat(res.vehicles[vehicle].latitude), lng: parseFloat(res.vehicles[vehicle].longitude)};
                          //$icon = "<?= base_url('assets/images/gps/normals.png') ?>";
                          $marker_type = 'vehicle';
                          $title = 'Vehicle Name: ' + res.vehicles[vehicle].assets_friendly_nm + ' <br>Plate No.:' + res.vehicles[vehicle].assets_name +' <br>Ignition: ' + $ignition +' <br>Speed: ' + res.vehicles[vehicle].speed + "Kmh <br>Date: " + $date;

                          addMarker($marker_type, $title, $position, $icon);
                          //  Make an array of the LatLng's of the markers you want to show
                          
        
                      } 


                      for (var i=0; i<vehicle_markers.length; i++) {
                          google.maps.event.addListener(vehicle_markers[i], "mouseout", function(event) {
                            iw_map.close();
                          });

                          google.maps.event.addListener(vehicle_markers[i], "click", function(event) {
                            map.setCenter(this.getPosition());
                            map.setZoom(15);
                            map.setTilt(45);

                            $('#map-pop').fadeIn(1000);

                            get_vehicle_details (this.asset_id, this.device_id, this.content, this.icon);
                            
                          });
                          
                          google.maps.event.addListener(vehicle_markers[i], "mouseover", function(event) {
                              iw_map.setContent(this.get("content"));
                              iw_map.open(map, this);
                          });

                          google.maps.event.addListener(vehicle_markers[i], "doubleclick", function(event) {
                              alert();
                          });
                      }


                      hideAlert();

                      fit_bounds();

                  }
                  
              });

        ///hideAlert();
      }


      $('#close-map-pop').click(function () { $('#map-pop').fadeOut(1000);});
});
  
</script>