<div class="container-fluid fleet-view">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($trips)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Trip Name</th>
                                <th>Vehicle</th>
                                <th>Client</th>
                                <th>Start Address</th>
                                <th>Destination</th>
                                <th>Consignment</th>
                                <th>Driver Name</th>
                                <th>Status</th>
                                <th>Distance Travelled</th>
                                <th>ACTION</th> 
                            </tr>

                        </thead>
                        <tbody>
                        <?php 
                            $count = 1;

                        foreach ($trips as $key => $value) { ?>
                           <tr class="gradeU">
                                <td><?php echo $count; ?></td>
                                <td><?php echo $value->trip_name ?></td>
                                <td><?php echo $value->assets_name; ?></td>
                                <td><?php echo $value->client; ?></td>
                                <td><?php echo $value->start_address; ?></td>
                                <td><?php echo $value->destination_address; ?></td>
                                <td><?php echo $value->consignment; ?></td>
                                <td><i><?php if ($value->driver_name == 0 || $value->driver_name=="") {echo "Not Set"; } else {echo $value->driver_name;} ?></i></td>
                                <td><i><?php if ($value->is_complete == 0) {echo "Not started"; } else if ($value->is_complete == 1) {echo "In Progress"; } else {echo "Completed";} ?></i></td>
                                <td><?php echo $value->distance_travelled; ?></td>
                                <td><?php if($value->is_complete == 0){
                                                echo "<a href='".base_url('index.php/gps_tracking/start_trip/'.$value->trip_id)
                                                    ."'class='btn btn-success btn-xs'>Start Trip</a>";
                                            }/*else if($value->is_complete == 1){
                                                echo "<a class='btn btn-warning btn-xs'>Started</a>";
                                            }*/
                                        echo "<a href='".base_url('index.php/gps_tracking/view_trip/'.$value->trip_id)
                                        ."'class='btn btn-info btn-xs'>View Trip</a>"; ?></td> 
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <!-- <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Vehicles</h2>
                    <br>
                    <p>Manage Vehicles and begin monitoring your assets Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

                    <a href="<?php echo site_url('vehicles/add_vehicle');?>" class="btn btn-success">Add Vehicles</a> 
                </div> -->
            <?php } ?>

            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>
