<script src="<?php echo base_url('assets/angular_moment.min.js') ?>"></script>
<script src="<?php echo base_url('assets/app.js') ?>"></script>
<script type="text/javascript">
    var infowindow;
    var vehicle_markers = [];
    var landmark_markers = [];
    var pop_marker = [];
    var map_pop;
    var map;
    var iw_map;
    var zones = [];
    var routes = [];
    var directionsService;
    var directionsDisplay;
    var vehiclePath;
    var vehiclePaths = [];
    var apiKey = 'AIzaSyCfKP5H8r9ohlPjH_CbddIefMbeCirz7-U';
    var polylines = [];
    //local : AIzaSyBn6m_W3hRMPg5nDlmqsRkaO3kE1LZ1HX4
    //remote : AIzaSyCfKP5H8r9ohlPjH_CbddIefMbeCirz7-U
    function initMap() {
        map = new google.maps.Map(document.getElementById('map_canvas'), {
            center: {
                lat: <?= $map_lat; ?>
                , lng: <?= $map_long; ?>
            }
            , zoom: 18
            , mapTypeId: google.maps.MapTypeId.ROADMAP
            , heading: 90
            , tilt: 45
            , streetViewControl: true
            , streetViewControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL
                , position: google.maps.ControlPosition.RIGHT_CENTER
            }
            , fullscreenControl: true
            , fullscreenControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL
                , position: google.maps.ControlPosition.RIGHT_CENTER
            }
            , zoomControl: true
            , zoomControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL
                , position: google.maps.ControlPosition.RIGHT_CENTER
            }
        , });
        iw_map = new google.maps.InfoWindow({
            content: ''
        });
        infowindow = new google.maps.InfoWindow({
            content: ''
        });
        load_landmarks();
        load_zones();
        //load_routes();
    }

    function load_landmarks() {
        $.ajax({
            type: "POST"
            , url: "<?php echo base_url('index.php/settings/get_company_landmarks') ?>"
            , data: {
                company: 'this company'
            }
            , success: function (data) {
                landmarks = JSON.parse(data);
                //alert(landmarks.length);
                if (landmarks.length > 0) {
                    for (var row in landmarks) {
                        if (landmarks[row].gmap_icon == 0) {
                            $icon = "<?= base_url('" + landmarks[row].icon_path + "')?>";
                        }
                        else {
                            $icon = landmarks[row].icon_path;
                        }
                        $pos = {
                            lat: parseFloat(landmarks[row].latitude, 10)
                            , lng: parseFloat(landmarks[row].longitude)
                        };
                        //console.log(parseInt(landmarks[row].latitude, 10));
                        landmark_markers.push(new google.maps.Marker({
                            position: $pos
                            , map: map
                            , icon: $icon
                            , content: landmarks[row].landmark_name
                            , scaledSize: new google.maps.Size(20, 20)
                        , }));
                    }
                    var llength = landmark_markers.length;
                    for (var i = 0; i < llength; i++) {
                        landmark_markers[i].setIcon(({
                            url: landmark_markers[i].icon
                            , size: new google.maps.Size(71, 71)
                            , origin: new google.maps.Point(0, 0)
                            , anchor: new google.maps.Point(12, 24)
                            , scaledSize: new google.maps.Size(24, 24)
                        }));
                        google.maps.event.addListener(landmark_markers[i], "mouseout", function (event) {
                            iw_map.close();
                        });
                        google.maps.event.addListener(landmark_markers[i], "click", function (event) {
                            map.setCenter(this.getPosition());
                            map.setZoom(15);
                            map.setTilt(45);
                            console.log(event.latLng.lat() + ',' + event.latLng.lng());
                        });
                        google.maps.event.addListener(landmark_markers[i], "mouseover", function (event) {
                            iw_map.setContent(this.get("content"));
                            iw_map.open(map, this);
                        });
                    }
                }
            }
        });
    }

    function load_zones() {
        $.ajax({
            type: "POST"
            , url: "<?php echo base_url('index.php/gps_tracking/get_company_zones') ?>"
            , data: {
                company: 'this company'
            }
            , success: function (data) {
                data = JSON.parse(data);
                mapCords = [];
                size_zones = data.zones.length;
                size_vertices = data.vertices.length
                if (size_zones > 0) {
                    for (var zone in data.zones) {
                        var zona = [];
                        for (var vertex in data.vertices) {
                            if (data.vertices[vertex].zone_id == data.zones[zone].zone_id) {
                                //$zona.push({lat:data.vertices[vertex].latitude, lng:data.vertices[vertex].longitude});
                                zona.push(new google.maps.LatLng(parseFloat(data.vertices[vertex].latitude), parseFloat(data.vertices[vertex].longitude)));
                            }
                            mapCords.push(new google.maps.LatLng(parseFloat(data.vertices[vertex].latitude), parseFloat(data.vertices[vertex].longitude)));
                        }
                        zones.push(new google.maps.Polygon({
                            paths: zona
                            , strokeColor: data.zones[zone].zone_color
                            , strokeOpacity: 0.8
                            , strokeWeight: 2
                            , fillColor: data.zones[zone].zone_color
                            , fillOpacity: 0.35
                            , zone: data.zones[zone].zone_name
                            , address: data.zones[zone].address
                        }));
                        zones[zones.length - 1].setMap(map);
                        google.maps.event.addListener(zones[zones.length - 1], 'mouseover', function (event) {
                            var contentString = "<strong>Zone</strong>:" + this.zone + "<br><strong>Address</strong>: " + this.address;
                            //alert(contentString);
                            iw_map.setContent(contentString);
                            iw_map.setPosition(event.latLng);
                            iw_map.open(map);
                        });
                        google.maps.event.addListener(zones[zones.length - 1], 'mouseout', function (event) {
                            iw_map.close();
                        });
                    }
                }
            }
        });
    }

    function load_routes() {
        $.ajax({
            type: "POST"
            , url: "<?php echo base_url('index.php/gps_tracking/get_company_map_display_routes') ?>"
            , data: {
                company: 'this company'
            }
            , success: function (data) {
                response = JSON.parse(data);
                for (var row in response) {
                    //alert(JSON.parse(response[row].raw_route));
                    $route = response[row].raw_route;
                    if ($route.length != 0) {
                        directionsDisplay.setDirections(JSON.parse($route));
                    }
                }
                //directionsDisplay.setDirections(response);
            }
        });
        return false;
    }

    function rotate90() {
        var heading = map.getHeading() || 0;
        map.setHeading(heading + 90);
    }

    function autoRotate() {
        // Determine if we're showing aerial imagery.
        if (map.getTilt() !== 0) {
            window.setInterval(rotate90, 3000);
        }
    }
</script>
<style>
    .controls {
        position: absolute;
        top: 64px;
        left: -16px;
        height: 32px;
        width: 232px;
        outline: none;
        z-index: 1000;
    }
    
    #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 300px;
    }
    
    #pac-input:focus {
        border-color: #4d90fe;
    }
    
    .pac-container {
        font-family: Roboto;
    }
    
    #type-selector {
        color: #fff;
        background-color: #131b26;
        text-transform: uppercase;
        line-height: 24px;
        font-size: 13px;
        margin-bottom: 6px;
        list-style: none;
        box-shadow: 0 0 0 0;
        padding: 6px;
        text-align: center;
    }
    
    #toggle-vehicles {
        color: #fff;
        cursor: pointer;
        position: absolute;
        top: 10px;
        margin-left: 10px;
        transition: .3s ease-in all;
    }
    
    #toggle-vehicles:hover {
        color: #c1d72e;
        transition: .2s ease-in all;
    }
    
    #map-pop {
        display: none;
        position: absolute;
        top: 40px;
        left: 5%;
        width: 95%;
        border: 1px solid #303641;
        /*border:2px solid #eee;*/
        z-index: 3000;
        border-radius: 0px;
        background: #fff;
        border-radius: 5px;
    }
    
    .live-vehicle-list {
        opacity: 0;
        width: 100%;
        max-height: 300px;
        overflow-y: scroll;
        background: #c1d72e;
        transition: .4s ease all;
    }
    
    .live-vehicle-list li {
        height: 32px;
        list-style-type: none;
        width: 100%;
        overflow-y: hidden;
        vertical-align: middle;
        text-align: center;
        padding: 8px;
        color: rgba(19, 27, 38, .58);
        cursor: pointer;
        font-size: 13px;
        text-transform: uppercase;
    }
    
    .live-vehicle-list li span {
        margin-right: 8px;
        font-size: 13px;
        color: rgba(19, 27, 38, .4);
    }
    
    .live-vehicle-list li:hover {
        color: rgba(19, 27, 38, 1);
    }
    
    .live-vehicle-list li a {
        text-decoration: none;
        color: #fff;
    }
    
    .form-search {
        opacity: 0;
        padding: 8px;
        background: #c1d72e;
        transition: .4s ease all;
    }
    
    #vehicle-search {
        background: rgba(19, 27, 38, .2);
        border: none;
        height: 28px;
        color: #fff;
    }
    
    .blinking-toggle {
        background: #18bc9c !important;
    }
    
    .more {
        background-color: #18bc9c;
        color: #fff;
        border: solid 2px #eee;
        width: 260px;
        border-radius: 5px;
        text-transform: uppercase;
        text-underline-position: left;
        margin-top: 7px;
        padding: 5px;
        /*padding-bottom: 5px;*/
    }
    
    .control-bar {
        position: absolute;
        background: rgba(0, 0, 0, 0.8);
        left: 0px;
        right: 0px;
        bottom: 0px;
        height: 60px;
        padding-top: 15px;
        color: #fff;
    }
    
    #vehicle-search::-webkit-input-placeholder {
        color: #fff;
        letter-spacing: 1px;
    }
    
    #vehicle-search::-moz-placeholder {
        /* Firefox 18- */
        color: #fff;
        letter-spacing: 1px;
    }
    
    #vehicle-search::-moz-placeholder {
        /* Firefox 19+ */
        color: #fff;
        letter-spacing: 1px;
    }
    
    #vehicle-search::-ms-input-placeholder {
        color: #fff;
        letter-spacing: 1px;
    }
    
    textarea:focus,
    input[type="text"]:focus,
    input[type="password"]:focus,
    input[type="datetime"]:focus,
    input[type="datetime-local"]:focus,
    input[type="date"]:focus,
    input[type="month"]:focus,
    input[type="time"]:focus,
    input[type="week"]:focus,
    input[type="number"]:focus,
    input[type="email"]:focus,
    input[type="url"]:focus,
    input[type="search"]:focus,
    input[type="tel"]:focus,
    input[type="color"]:focus,
    .uneditable-input:focus {
        border-color: rgba(126, 239, 104, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.0) inset, 0 0 8px rgba(126, 239, 104, 0);
        outline: 0 none;
    }
</style>
<input type="hidden" id="refresh-session" class="" value="0" />
<input type="hidden" id="refresh-interval" class="" value="600" />
<div class="container-fluid fleet-view" style="background:#101010; padding:0px 10px 0 10px !important">
    <div class="row" style="margin-top: -50px;">
        <!---->
        <div class="col-md-12" style="margin-top:50px;">
            <div class="row">
                <div class="controls" id="map-vehicle-zone">
                    <ul> <span id="toggle-vehicles" class="fa fa-m fa-bars"></span>
                        <li id="type-selector"> &nbsp; &nbsp; Click to show all vehicles</li>
                        <div class="form-search">
                            <input class="form-control" name="vehicle-search" id="vehicle-search" placeholder="vehicle name/no. plate" /> </div>
                        <ul class="live-vehicle-list" style="max-height:100%;padding:0px !important;overflow-y:auto;">
                            <?php echo $vehicleList; ?>
                        </ul>
                    </ul>
                </div>
                <script>
                    $("#toggle-vehicles").on('click', function () {
                        if ($("#toggle-vehicles").hasClass("fa-bars")) {
                            $("#toggle-vehicles").removeClass("fa-bars");
                            $("#toggle-vehicles").addClass("fa-times");
                            var selector = document.getElementById("type-selector").innerHTML = "Hide all vehicles";
                            $(".live-vehicle-list").css({
                                opacity: 1
                            });
                            $(".form-search").css({
                                opacity: 1
                            });
                        }
                        else {
                            $("#toggle-vehicles").removeClass("fa-times");
                            $("#toggle-vehicles").addClass("fa-bars");
                            var selector = document.getElementById("type-selector").innerHTML = " &nbsp; &nbsp; Click to show all vehicles";
                            $(".live-vehicle-list").css({
                                opacity: 0
                            });
                            $(".form-search").css({
                                opacity: 0
                            });
                        }
                    });
                </script>
                <div class="col-md-12" style="height:705px">
                    <div id="map_canvas" class="row" style="height:100%"></div>
                    <div class="control-bar">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="" style="">
                                    <div class="col-md-2">
                                        <div class="form-inline" role="form">
                                            <div class="form-group">
                                                <input class="" id="view_vehicle" type="checkbox" name="hide" checked="checked">
                                                <label> Vehicles List</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-inline" role="form">
                                            <div class="form-group">
                                                <label>Refresh after:</label>
                                                <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="15" <?php if ($_SESSION[ 'refresh_time']==16) {?>checked
                                                <?php } ?>> 15 secs </div>
                                            <div class="form-group">
                                                <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="30" <?php if ($_SESSION[ 'refresh_time']==30) {?>checked
                                                <?php } ?>> 30 secs </div>
                                            <div class="form-group">
                                                <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="45" <?php if ($_SESSION[ 'refresh_time']==45) {?>checked
                                                <?php } ?>> 45 secs </div>
                                            <div class="form-group">
                                                <input class="form-control radio-rt" type="radio" name="refresh-secs" data-time="600" checked>disabled </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-inline" role="form" style="margin-top:5px">
                                            <div class="form-group col-sm-3"> <img src="<?php echo base_url('assets/images/gps/marker-normal.png'); ?>" class="legend-marker" /> Moving </div>
                                            <div class="form-group  col-sm-3"> <img src="<?php echo base_url('assets/images/gps/marker-idle.png'); ?>" class="legend-marker" /> Idle </div>
                                            <div class="form-group  col-sm-3"> <img src="<?php echo base_url('assets/images/gps/marker-warning.png'); ?>" class="legend-marker" /> parked </div>
                                            <div class="form-group  col-sm-3"> <img src="<?php echo base_url('assets/images/gps/marker-danger.png'); ?>" class="legend-marker" /> Overspeeding </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //. Content -->
    </div>
    <!-- /.row -->
</div>
<div id="map-pop" class="panel-diagnostics">
    <div class="panel panel-default">
        <div class="panel-heading panel-info clearfix">
            <h4 class="panel-title">History Playback <span style="margin-left: 30%;text-transform: none; font-size:15px;color:#18bc9c;">Last time data recieved : <span id="pop-time-recieved" style="font-size:15px;color:#ccc;"></span></span><button class="close" id="close-map-pop">&times;</button></h4> </div>
        <div class="panel-body">
            <div class="row" style="border-bottom:2px solid #eee;">
                <!--<div class="col-sm-1">
                            <div class="text-center fleet-img">
                                <img width="100%" height="80" src="<?php echo base_url('assets/images/photos/car2.jpg')?>" alt="" class="img-rounded">
                            </div>
                        </div>-->
                <div class="col-sm-4 img-rounded">
                    <div class="user-card-mini row div-wd-info">
                        <div class="col-md-12 col-sm-12 col-xs-12 text-center " id="pressure-status-area">
                            <h3><i class="fa fa-spinner fa-spin fa-2x" style="color:#fff !important;"></i></h3>
                            <!--<p><i></i></p>-->
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 img-rounded">
                    <div class="user-card-mini row">
                        <div class="col-md-12 col-sm-12 col-xs-12"> Vehicle Name: <i id="pop-v-name"></i>
                            <br> Plate No: <i id="pop-n-plate"></i>
                            <br> Driver Name: <i id="pop-d-name"></i>
                            <br> Driver Phone: <i id="pop-d-phone"></i> </div>
                    </div>
                    <br> </div>
                <div class="col-sm-4 img-rounded">
                    <div class="user-card-mini row">
                        <div class="col-md-12 col-sm-12 col-xs-12"> Trip Name: <i id="pop-t-name"></i>
                            <br> Route: <i id="pop-route"></i>
                            <br> Distance: <i id="pop-distance"></i>
                            <br> Current address: <i id="pop-address"></i> </div>
                    </div>
                    <br> </div>
            </div>
            <div class="row">
                <div class="col-sm-12" style="border-top:1px solid #eee;padding:5px;background: #f2f2f2;">
                    <div class="col-sm-4"> <span class="caption"><strong>Start Time: </strong></span> <span id="pop-s-time"></span> </div>
                    <div class="col-sm-4"> <span class="caption"><strong>Estimated Time: </strong></span><span id="pop-e-time"></span> </div>
                    <div class="col-sm-4"> <span class="caption"><strong>Estimated Arrival Time: </strong></span><span id="pop-a-time"></span> </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5 map-zone" id="map-zone" style="height:450px;border-right:7px solid #ccc;">
                    <h3 style="text-align:center;margin-top:200px;"><i class="fa fa-spinner fa-spin fa-2x"></i></h3> </div>
                <div class="col-sm-7" style="height:450px;">
                    <div id="bg-vehicle-area" class="col-md-offset-1 col-md-10 col-sm-10">
                        <h3 style="text-align:center;margin-top:40px;"><i class="fa fa-spinner fa-spin fa-2x"></i></h3> </div>
                    <div class="col-md-12" id="info-div" style="overflow-y:scroll; height:200px;background:#f5f5f5;border-radius:5px 0 0 5px;">
                        <!--<div class="col-md-12 ttl-tyre-info">
                                      <h4>Tyre Information</h4>
                                      <button class="btn btn-sm btn-primary btn-sm header-btn-1" id="btn-print-vd">Print Status</button>
                                  </div> --></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="tyre-info-div">
    <div class="row"> <span class="col-sm-6 col-md-6"><h2 id="pressure-info"></h2></span> <span class="col-sm-6 col-md-6"><h2 id="temperature-info"></h2></span> <span class="col-sm-12 col-md-12">Condition</span> <span class="col-sm-12 col-md-12 btn btn-block" id="status-info"></span> <span class="col-sm-12 col-md-12" id="axle-info"></span> <span class="col-sm-12 col-md-12" id="tyre-info"></span> </div>
</div>
<script type="text/javascript">
    $(function () {
        var refresh_interval = parseFloat($('#refresh-interval').val()) * 1000;
        var refresh = setInterval(function () {
            refresh_vehicle_locations(2);
        }, refresh_interval);
        //console.log(markers_map.length);
        refresh_vehicle_locations(1);
        $('.radio-rt').on('click', function () {
            //alert($(this).attr('data-time'));
            $('#refresh-interval').val($(this).attr('data-time'));
            refresh_interval = parseFloat($('#refresh-interval').val()) * 1000;
            //alert(refresh_interval);
            clearInterval(refresh);
            refresh = null;
            refresh = setInterval(function () {
                refresh_vehicle_locations(2);
            }, refresh_interval);
            if (refresh_interval != 600000) {
                display_alert('Refreshing in ' + refresh_interval / 1000 + ' Seconds');
                hideAlert();
            }
        });
        var count = 0;

        function refresh_vehicle_locations(times) {
            var query = $('#vehicle-search').val().trim();
            var refresh_session = parseInt($('#refresh-session').val(), 10);
            display_alert('Refreshing Map');
            if (times > 1) {
                clearVehicleMarkers();
            }
            $('#refresh-session').val(refresh_session + 1);
            //return false;
            $.ajax({
                type: "POST"
                , cache: false
                , data: {
                    query: query
                }
                , url: "<?php echo base_url('index.php/gps_tracking/refresh_grid') ?>"
                , success: function (response) {
                    res = JSON.parse(response);
                    var message = [];
                    var LatLngList = [];
                    //alert(res.vehicles.length);
                    for (var vehicle in res.vehicles) {
                        $asset_id = res.vehicles[vehicle].asset_id;
                        $device_id = res.vehicles[vehicle].device_id;
                        if (parseInt(res.vehicles[vehicle].ignition) == 1 && parseInt(res.vehicles[vehicle].speed) > 0 && parseInt(res.vehicles[vehicle].speed) < parseInt(res.vehicles[vehicle].max_speed_limit)) {
                            $icon = "<?= base_url('assets/images/gps/marker-normal.png') ?>";
                            $fill_color = "#00ff00";
                            $speed_message = "Moving Normally";
                            //message.push($speed_message);
                        }
                        else if (parseInt(res.vehicles[vehicle].ignition) == 1 && parseInt(res.vehicles[vehicle].speed) == 0) {
                            $icon = "<?= base_url('assets/images/gps/marker-idle.png') ?>";
                            $fill_color = "#0000ff";
                            $speed_message = "Idle";
                            message.push($speed_message);
                        }
                        else if (parseInt(res.vehicles[vehicle].speed) > parseInt(res.vehicles[vehicle].max_speed_limit)) {
                            $icon = "<?= base_url('assets/images/gps/marker-danger.png') ?>";
                            $fill_color = "#ff0000";
                            $speed_message = "Overspeeding";
                            message.push($speed_message);
                        }
                        else if (parseInt(res.vehicles[vehicle].ignition) == 0 && parseInt(res.vehicles[vehicle].speed) == 0) {
                            $icon = "<?= base_url('assets/images/gps/marker-warning.png') ?>";
                            $fill_color = "#ffff00";
                            $speed_message = "Parked";
                            message.push($speed_message);
                        }
                        $time = res.vehicles[vehicle].tm;
                        $date = res.vehicles[vehicle].dt;
                        $date = $date.split(" ");
                        $date = $date[0];
                        $date = new Date($date + " " + $time);
                        if (parseInt(res.vehicles[vehicle].ignition) == 1) {
                            $ignition = '<button class="btn btn-success btn-xs">On</button>';
                        }
                        else {
                            $ignition = '<button class="btn btn-default btn-xs">Off</button>';
                        }
                        $direction = res.vehicles[vehicle].angle_dir;
                        $vehicle_name = res.vehicles[vehicle].assets_name;
                        $position = {
                            lat: parseFloat(res.vehicles[vehicle].latitude)
                            , lng: parseFloat(res.vehicles[vehicle].longitude)
                        };
                        //$icon = "<?= base_url('assets/images/gps/normals.png') ?>";
                        $marker_type = 'vehicle';
                        /*$title = 'Vehicle Name: ' + res.vehicles[vehicle].assets_friendly_nm + ' <br>Plate No.:' + res.vehicles[vehicle].assets_name +' <br>Ignition: ' + $ignition +' <br>Speed: ' + res.vehicles[vehicle].speed + " Kmh <br>Near address: " + res.vehicles[vehicle].address + "<br>Status: <span style='color:" + $fill_color + "'>" + $speed_message + "</span><br>Date: " + $date + "<br> <p class='more'><b> Click Vehicle Icon For More Details"+"</b></p>";*/
                        /*$title =
                            '<br><b>Vehicle Name: </b><div style="float:right; margin-right: 26px;">' + res.vehicles[vehicle].assets_friendly_nm +
                            '</div><br><b>Plate No.: </b><div style="float:right; margin-right: 26px;">' + res.vehicles[vehicle].assets_name +
                            '</div><br><b>Ignition: </b><div style="float:right; margin-right: 26px;">' + $ignition +
                            '</div><br><b>Speed: </b><div style="float:right; margin-right: 26px;">' + res.vehicles[vehicle].speed +
                            '</div><br><b>Kmh <br>Near address:  </b><div style="float:right; margin-right: 26px;">' + res.vehicles[vehicle].address +
                            '</div><br><b>Date: </b><div style="float:right; margin-right: 26px;">' + $date +
                            '</div><br><center><p class='more'><b> Click Vehicle Icon For More Details'+'</b></p></center>';
                        */
                        $title = '<br><b>Vehicle Name:</b><div style="float:right;">' + res.vehicles[vehicle].assets_friendly_nm + '</div><br><b>Plate No.:</b><div style="float:right;">' + res.vehicles[vehicle].assets_name + '</div><br><b>Ignition:</b><div style="float:right;">' + $ignition + '</div><br><b>Speed:</b><div style="float:right;">' + res.vehicles[vehicle].speed + ' Km/h' + '</div><br><b>Address:</b><div style="float:right; margin-right: 6px;">' + res.vehicles[vehicle].address + '</div><br><center><p class="more"><b> Click Icon For More Details' + '</b></p></center>';
                        $asset_name = res.vehicles[vehicle].assets_name + " - " + res.vehicles[vehicle].assets_friendly_nm;
                        addMarker($marker_type, $title, $position, $icon, $fill_color, $asset_id, $device_id, $asset_name, $direction);
                        //  Make an array of the LatLng's of the markers you want to show
                    }
                    for (var i = 0; i < vehicle_markers.length; i++) {
                        google.maps.event.addListener(vehicle_markers[i], "mouseout", function (event) {
                            iw_map.close();
                        });
                        google.maps.event.addListener(vehicle_markers[i], "click", function (event) {
                            var posl = this.getPosition();
                            console.log(event.latLng.lat() + ',' + event.latLng.lng());
                            map.setCenter(posl);
                            map.setZoom(15);
                            map.setTilt(45);
                            $('#map-pop').fadeIn(1000);
                            $('.overshadow').fadeIn(1000);
                            get_vehicle_details(this.asset_id, this.device_id, this.content, this.icon, this.fill, this.direction, posl);
                        });
                        google.maps.event.addListener(vehicle_markers[i], "mouseover", function (event) {
                            iw_map.setContent(this.get("content"));
                            iw_map.open(map, this);
                        });
                        google.maps.event.addListener(vehicle_markers[i], "doubleclick", function (event) {
                            alert();
                        });
                    }
                    hideAlert();
                    if (res.vehicles.length) {
                        fit_bounds();
                    }
                }
            });
        }

        function get_vehicle_details(asset_id, device_id, content, icon, fill, direction, posl) {
            //alert(asset_id);
            $("#map-zone").html('<h3 style="text-align:center;margin-top:200px;"><i class="fa fa-spinner fa-spin fa-2x" style="color:#18bc9c;"></i></h3>');
            $("#bg-vehicle-area").html('<h3 style="text-align:center;margin-top:50px;"><i class="fa fa-spinner fa-spin fa-2x" style="color:#18bc9c;"></i></h3>');
            $("#pressure-status-area").html("<h3><i class='fa fa-spinner fa-spin fa-2x' style='color:#18bc9c;'></i></h3>");
            $.ajax({
                type: "POST"
                , cache: false
                , dataType: 'JSON'
                , data: {
                    asset_id: asset_id
                    , device_id: device_id
                }
                , url: "<?php echo base_url('index.php/gps_tracking/get_vehicle_details') ?>"
                , success: function (response) {
                    //res = JSON.parse(response);
                    //alert(response.vehicle_info.assets_friendly_nm);
                    $('#pop-v-name').html(response.vehicle_info.assets_friendly_nm);
                    $('#pop-n-plate').html(response.vehicle_info.assets_name);
                    $('#pop-d-name').html(response.vehicle_info.driver_name);
                    $('#pop-d-phone').html(response.vehicle_info.driver_phone);
                    $('#pop-t-name').html(response.vehicle_info.trip_name);
                    $route_nm = "Not Defined";
                    $distnc = "Not Available";
                    $durtn = "Not Available";
                    $st_time = "History for the past 24hrs";
                    if (response.route_data) {
                        $route_nm = response.route_data.route_name;
                        $distnc = response.route_data.distance;
                        $durtn = response.route_data.duration;
                        $st_time = response.vehicle_info.start_time;
                    }
                    console.log("Add date: " + response.gps_hist);
                    $('#pop-route').html($route_nm);
                    $('#pop-distance').html($distnc);
                    $('#pop-address').html(response.vehicle_info.address);
                    $('#pop-time-recieved').html(response.vehicle_info.add_date);
                    var paired = response.vehicle_info.paired_asset_id;
                    var axlesA = response.vehicle_info.no_of_axles;
                    var axlesB = response.vehicle_info.paired_asset_axles;
                    var patternA = response.vehicle_info.axle_tyre_config;
                    var patternB = response.vehicle_info.paired_asset_axle_tyre_config;
                    var deviceB_id = response.vehicle_info.paired_asset_device_id;
                    LoadTpmsData(asset_id, device_id, deviceB_id, paired, axlesA, axlesB, patternA, patternB);
                    //var dateFormat = require('dateformat');
                    var start_d = new Date(response.vehicle_info.start_time);
                    //dateFormat(start_d, "dddd, mmmm dS, yyyy, h:MM:ss TT");
                    $('#pop-s-time').html($st_time);
                    $('#pop-e-time').html($durtn);
                    $device_id = response.vehicle_info.device_id;
                    console.log(start_d);
                    $direction = response.vehicle_info.angle_dir;
                    $position = new google.maps.LatLng(parseFloat(response.vehicle_info.latitude), parseFloat(response.vehicle_info.longitude));
                    $wypt = new google.maps.LatLng(parseFloat(response.vehicle_info.latitude), parseFloat(response.vehicle_info.longitude));
                    var $path = [];
                    var $path2 = [];
                    for (var point in response.gps_hist) {
                        loc = new google.maps.LatLng(parseFloat(response.gps_hist[point].latitude), parseFloat(response.gps_hist[point].longitude));
                        loc2 = parseFloat(response.gps_hist[point].latitude) + ',' + parseFloat(response.gps_hist[point].longitude)
                            //loc = response.gps_hist[point].address;
                        $path.push(loc);
                        $path2.push(loc2);
                    }
                    $path.push($wypt);
                    directionsDisplay = new google.maps.DirectionsRenderer;
                    map_pop = new google.maps.Map(document.getElementById('map-zone'), {
                        center: $position
                        , zoom: 8
                    });
                    var directionsService = new google.maps.DirectionsService;
                    directionsDisplay = new google.maps.DirectionsRenderer;
                    directionsDisplay.setMap(map_pop);
                    if (response.route_data) {
                        //alert('route');
                        $route = response.route_data.raw_route;
                        directionsDisplay.setDirections(JSON.parse($route));
                    }
                    if (parseFloat($direction) != false) {
                        $direction = $direction;
                    }
                    else {
                        $direction = 0;
                    }
                    //console.log($position.lat +','+ $position.lng);
                    pop_marker.push(new google.maps.Marker({
                        position: $position
                        , map: map_pop
                        , icon: {
                            path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                            , strokeColor: '#101010'
                            , strokeWeight: 1
                            , fillColor: fill
                            , fillOpacity: 1
                            , rotation: direction
                            , anchor: new google.maps.Point(0, 0)
                            , scale: 4
                        }
                        , content: content
                        , animation: google.maps.Animation.DROP
                        , asset_id: asset_id
                        , device_id: device_id
                    }));
                    map_pop.setCenter($position);
                    displayVehiclePath($device_id, $path);
                }
            });
        }

        function displayVehiclePath(device_id, path) {
            clearVehiclePaths();
            //alert();
            for (var i = 0; i < path.length; i++) {
                vehiclePaths.push(new google.maps.Marker({
                    position: path[i]
                    , icon: {
                        path: google.maps.SymbolPath.CIRCLE
                        , strokeColor: '#F00'
                        , fillColor: '#F00'
                        , fillOpacity: 1, //caledSize:20,
                        scale: 2
                    }
                    , draggable: false
                    , map: map_pop
                    , zIndex: 4
                }));
            }
            /*// Snap a user-created polyline to roads and draw the snapped path
              var pathValues = path;
              var pathLength = path.length;
              var newPath = pathValues;

              if(pathLength > 100) {
                newPath = [];
                var interval = Math.round(pathLength/100);

                for (var i = 0; i < pathLength; i++) {
                  if(newPath.length == 99) {
                    break;
                  }

                  newPath.push(pathValues[i]);


                  i = i + interval;
                }

                //newPath.push(pathValues[pathLength - 1]);

              }

              /*for (var i = 0; i < path.length; i++) {
                pathValues.push(path[i].lat + ',' + path[i].lng);
              }

              alert(JSON.stringify(path.getAt(0)));




              
              //alert(pathValues.join('|'));

              $.get('https://roads.googleapis.com/v1/snapToRoads', {
                interpolate: true,
                key: apiKey,
                path: newPath.join('|')
              }, function(data) {


                processSnapToRoadResponse(data);
                drawSnappedPolyline();
                //getAndDrawSpeedLimits();
              });*/
        }
        // Store snapped polyline returned by the snap-to-road method.
        function processSnapToRoadResponse(data) {
            snappedCoordinates = [];
            placeIdArray = [];
            for (var i = 0; i < data.snappedPoints.length; i++) {
                var latlng = new google.maps.LatLng(data.snappedPoints[i].location.latitude, data.snappedPoints[i].location.longitude);
                snappedCoordinates.push(latlng);
                placeIdArray.push(data.snappedPoints[i].placeId);
            }
        }
        // Draws the snapped polyline (after processing snap-to-road response).
        function drawSnappedPolyline() {
            var snappedPolyline = new google.maps.Polyline({
                path: snappedCoordinates
                , strokeColor: 'green'
                , strokeWeight: 6
            });
            snappedPolyline.setMap(map_pop);
            polylines.push(snappedPolyline);
        }

        function clearVehiclePaths() {
            for (var i = 0; i < vehiclePaths.length; i++) {
                vehiclePaths[i].setMap(null);
            }
        }

        function addMarker(type, title, location, image, fill_col, asset_id, device_id, asset_name, direction) {
            if (parseFloat(direction) != false) {
                direction = parseFloat(direction);
            }
            else {
                direction = 0;
            }
            /*vehicle_markers.push(new google.maps.Marker({
                  position: location,
                  map: map,
                  icon: {
                          url: image,
                          rotation:direction,
                         // anchor: new google.maps.Point(0,-32),
                        },
                  content:title,
                  animation: google.maps.Animation.DROP,
                  asset_id:asset_id,
                  device_id:device_id,
                  vehicle_name: asset_name,
                  direction:direction

            }));*/
            vehicle_markers.push(new google.maps.Marker({
                position: location
                , map: map
                , icon: {
                    path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                    , strokeColor: '#101010'
                    , strokeWeight: 1
                    , fillColor: fill_col
                    , fillOpacity: 1
                    , rotation: direction
                    , anchor: new google.maps.Point(0, 0)
                    , scale: 5
                }
                , content: title
                , animation: google.maps.Animation.DROP
                , asset_id: asset_id
                , device_id: device_id
                , fill: fill_col
                , vehicle_name: asset_name
                , direction: direction
            }));
            /*if (parseFloat(direction) != false) {
               // Create the polyline and add the symbol via the 'icons' property.
               vehicle_markers.push(new google.maps.Marker({
                     position: location,
                     icon: {
                       path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                       scale:3,
                       rotation:direction,
                       anchor: new google.maps.Point(0,0)
                     },
                     map: map,
                     content:title,
                     animation: google.maps.Animation.DROP,
                     asset_id:asset_id,
                     device_id:device_id,
                     vehicle_name: asset_name,
                     optimized: false,
                     zIndex: 5
               }));
             }*/
        }

        function fit_bounds() {
            var bounds = new google.maps.LatLngBounds();
            var vsize = vehicle_markers.length;
            //console.log('Size:' + vehicle_markers.length);
            for (i = 0; i < vsize; i++) {
                bounds.extend(vehicle_markers[i].getPosition());
            }
            map.fitBounds(bounds);
        }

        function fit_bounds_pop() {
            var bounds = new google.maps.LatLngBounds();
            for (i = 0; i < pop_marker.length; i++) {
                bounds.extend(pop_marker[i].getPosition());
            }
            map_pop.fitBounds(bounds);
        }

        function display_alert(Message) {
            $('.page-alert').html('<p align="center">' + Message + '</p>');
            $('.page-alert').animate({
                right: '10px'
            }, 2000);
        }

        function hideAlert() {
            $('.page-alert').animate({
                right: '-600px'
            }, 2000);
        }

        function clearVehicleMarkers() {
            var vMarkers = vehicle_markers.length;
            console.log('to be cleared' + vMarkers);
            if (vMarkers > 0) {
                for (var i = 0; i < vMarkers; i++) {
                    vehicle_markers[i].setMap(null);
                    console.log('clearing');
                }
            }
            console.log('final size: ' + vehicle_markers.length);
        }

        function clearAllMarkers() {
            var countMarkers = markers_map.length;
            if (countMarkers > 0) {
                for (var i = 0; i < countMarkers; i++) {
                    markers_map[i].setMap(null);
                }
            }
        }
        var togle = setInterval(function () {
            toggle_blink();
        }, 1000);

        function toggle_blink() {
            if ($('.live-vehicle-list').find('.blinking')) {
                $('.blinking').toggleClass('blinking-toggle');
            }
        }
        $('#vehicle-search').keyup(function () {
            var no_of_v = vehicle_markers.length;
            var query = $(this).val().trim();
            var myValRe = new RegExp(query, 'i');
            var vehicle_lis = $('.live-vehicle-list').find('li');
            var vli_length = vehicle_lis.length;
            $('.live-vehicle-list').find('li').removeClass('blinking');
            //console.log(no_of_v);
            if (query.length) {
                for (var i = 0; i < no_of_v; i++) {
                    var lookup_text = vehicle_markers[i].vehicle_name;
                    //console.log(lookup_text + '        ' +query);
                    if (lookup_text.match(myValRe)) {
                        vehicle_markers[i].setVisible(true);
                        fit_bounds();
                    }
                    else {
                        vehicle_markers[i].setVisible(false);
                        fit_bounds();
                    }
                }
                for (var i = 0; i < vli_length; i++) {
                    var lookup_tex = $(vehicle_lis[i]).html();
                    console.log(lookup_tex + '        ' + query);
                    if (lookup_tex.match(myValRe)) {
                        //$(vehicle_lis[i]).show();
                        $(vehicle_lis[i]).addClass('blinking');
                    }
                    else {
                        //$(vehicle_lis[i]).hide();
                        $(vehicle_lis[i]).removeClass('blinking');
                        $(vehicle_lis[i]).removeClass('blinking-toggle');
                    }
                }
            }
        });
        $('.live-vehicle-list').on('click', 'li', function () {
            var no_of_v = vehicle_markers.length;
            var asset_id = $(this).attr('asset-id');
            //console.log(no_of_v);
            for (var i = 0; i < no_of_v; i++) {
                var vid = vehicle_markers[i].asset_id;
                //console.log(lookup_text + '        ' +query);
                if (vid == asset_id) {
                    vehicle_markers[i].setVisible(true);
                    var posl = vehicle_markers[i].getPosition();
                    window.setTimeout(function () {
                        map.panTo(posl);
                        map.setZoom(30);
                    }, 1000);
                    //window.setInterval(rotate90, 3000);
                    //fit_bounds();
                }
                else {
                    console.log('No asset with that id on the map');
                    vehicle_markers[i].setVisible(false);
                    //fit_bounds();
                }
            }
        });
        $('.filter-map').change(function () {
            $('#vehicle-search').val('');
            var filter = $(this).val();
            var owner = $('#select-owners').val();
            var type = $('#select-types').val();
            var cat = $('#select-categories').val();
            var group = $("#select-groups").val();
            filter_grid(owner, type, cat, group);
        });

        function filter_grid(owner, type, cat, group) {
            display_alert('Searching Map');
            clearVehicleMarkers();
            $.ajax({
                type: "POST"
                , cache: false
                , data: {
                    owner: owner
                    , type: type
                    , cat: cat
                    , group: group
                }
                , url: "<?php echo base_url('index.php/gps_tracking/filter_grid') ?>"
                , success: function (response) {
                    res = JSON.parse(response);
                    var message = [];
                    var LatLngList = [];
                    //alert(res.vehicles.length);
                    for (var vehicle in res.vehicles) {
                        $asset_id = res.vehicles[vehicle].asset_id;
                        $device_id = res.vehicles[vehicle].device_id;
                        if (parseInt(res.vehicles[vehicle].ignition) == 1 && parseInt(res.vehicles[vehicle].speed) > 0 && parseInt(res.vehicles[vehicle].speed) < parseInt(res.vehicles[vehicle].max_speed_limit)) {
                            $icon = "<?= base_url('assets/images/gps/marker-normal.png') ?>";
                            $fill_color = "#00ff00";
                            $speed_message = "Vehicle Moving Normally";
                            //message.push($speed_message);
                        }
                        else if (parseInt(res.vehicles[vehicle].ignition) == 1 && parseInt(res.vehicles[vehicle].speed) == 0) {
                            $icon = "<?= base_url('assets/images/gps/marker-idle.png') ?>";
                            $fill_color = "#0000ff";
                            $speed_message = "Vehicle is idle";
                            message.push($speed_message);
                        }
                        else if (parseInt(res.vehicles[vehicle].speed) > parseInt(res.vehicles[vehicle].max_speed_limit)) {
                            $icon = "<?= base_url('assets/images/gps/marker-danger.png') ?>";
                            $fill_color = "#ff0000";
                            $speed_message = "Overspeeding";
                            message.push($speed_message);
                        }
                        else if (parseInt(res.vehicles[vehicle].ignition) == 0) {
                            $icon = "<?= base_url('assets/images/gps/marker-warning.png') ?>";
                            $fill_color = "#00ff00";
                            $speed_message = "Vehicle has stopped";
                            message.push($speed_message);
                        }
                        $time = res.vehicles[vehicle].tm;
                        $date = res.vehicles[vehicle].dt;
                        $date = $date.split(" ");
                        $date = $date[0];
                        $date = new Date($date + " " + $time);
                        if (res.vehicles[vehicle].ignition == 1) {
                            $ignition = '<button class="btn btn-success btn-xs">On</button>';
                        }
                        else {
                            $ignition = '<button class="btn btn-default btn-xs">Off</button>';
                        }
                        $vehicle_name = res.vehicles[vehicle].assets_name;
                        $position = {
                            lat: parseFloat(res.vehicles[vehicle].latitude)
                            , lng: parseFloat(res.vehicles[vehicle].longitude)
                        };
                        //$icon = "<?= base_url('assets/images/gps/normals.png') ?>";
                        $marker_type = 'vehicle';
                        $title = 'Vehicle Name: ' + res.vehicles[vehicle].assets_friendly_nm + ' <br>Plate No.:' + res.vehicles[vehicle].assets_name + ' <br>Ignition: ' + $ignition + ' <br>Speed: ' + res.vehicles[vehicle].speed + "Kmh <br>Near address: " + res.vehicles[vehicle].address + "<br>Date: " + $date;
                        addMarker($marker_type, $title, $position, $icon, $fill_color, $asset_id, $device_id);
                        //  Make an array of the LatLng's of the markers you want to show
                    }
                    for (var i = 0; i < vehicle_markers.length; i++) {
                        google.maps.event.addListener(vehicle_markers[i], "mouseout", function (event) {
                            iw_map.close();
                        });
                        google.maps.event.addListener(vehicle_markers[i], "click", function (event) {
                            var posl = this.getPosition();
                            console.log(event.latLng.lat() + ',' + event.latLng.lng());
                            map.setCenter(posl);
                            map.setZoom(15);
                            map.setTilt(45);
                            $('#map-pop').fadeIn(1000);
                            get_vehicle_details(this.asset_id, this.device_id, this.content, this.icon, posl);
                        });
                        google.maps.event.addListener(vehicle_markers[i], "mouseover", function (event) {
                            iw_map.setContent(this.get("content"));
                            iw_map.open(map, this);
                        });
                        google.maps.event.addListener(vehicle_markers[i], "doubleclick", function (event) {
                            alert();
                        });
                    }
                    hideAlert();
                    if (res.vehicles.length) {
                        fit_bounds();
                    }
                }
            });
            ///hideAlert();
        }

        function LoadTpmsData(asset_id, deviceA_id, deviceB_id, paired, axlesA, axlesB, patternA, patternB) {
            var vehicleA_id = asset_id;
            var vehicleB_id = null;
            var deviceA_id = deviceA_id;
            var deviceB_id = deviceB_id;
            var paired = paired;
            var axlesA = parseInt(axlesA);
            var axlesB = parseInt(axlesB);
            //If paired total axles = towing vehicle axles + trailer axles
            var total_axles = axlesA; // + axlesB;
            // alert(axlesA);
            // alert(axlesA);
            /*put the axles and tyres numbers and pattern in arrays. Single tyre S, twin tyre T, 
            single retractable SR and twin retractable TR*/
            var patternA = patternA.split('-').filter(Boolean);
            var patternB = patternB.split('-').filter(Boolean);
            /*Verify if axles and tyres configurations have been set so as to render the diagnostics image,
            with the correct number of tyres and axles*/
            if (axlesA == 0) {
                swal({
                    title: "Info"
                    , text: "Set the vehicle axles and tyres configurations"
                    , type: "error"
                    , confirmButtonText: "ok"
                });
                return false;
            }
            if (paired != 0) {
                if (axlesB == 0) {
                    swal({
                        title: "Info"
                        , text: "Set the trailers' axles and tyres configurations"
                        , type: "error"
                        , confirmButtonText: "ok"
                    });
                    return false;
                }
            }
            var completePattern = patternA; //.concat(patternB);
            //alert(completePattern.length);
            //Display the panel if above conditions have been met.
            $('#bg-vehicle-area').html('');
            /*$('#panel-diagnostics').fadeOut(500);
            $('#panel-diagnostics').fadeIn(1000);
            $('.overshadow').fadeIn(1000);
            $('#bg-vehicle-area').html('');
            */
            var vehicle_axles = total_axles;
            //Divs to render axles and tyres 2
            var axle_divs_two = ['<div class="col-sm-7 col-md-7 axle-div"></div>', '<div class="col-sm-5 col-md-5 axle-div"></div>'];
            var axle_divs_three = ['<div class="col-sm-2 col-md-2 axle-div"></div>', '<div class="col-sm-4 col-md-4 axle-div"></div>', '<div class="col-sm-6 col-md-6 axle-div"></div>'];
            //axle and tyres images.
            var styre_axle = "<img src='<?php echo base_url()?>/assets/images/itms/normal-axle.png' alt='axle' class='v-axle'/>";
            var dtyre_axle = "<img src='<?php echo base_url()?>/assets/images/itms/double-tyre-axle.png' alt='axle' class='v-axle'/>";
            var no_of_axle_divs = 2;
            var divs_to_append = axle_divs_two;
            //Render some info about the  vehicle on the diagnostic panel
            /*$('#panel-asset-name').html(asset_name);
            $('#diag-vehicle-id').html(asset_name);
            $('#diag-vehicle-type').html(asset_type);
            $('#diag-driver-id').html(asset_driver_name);
            $('#diag-driver-name').html(asset_driver_name);
            $('#diag-driver-phone').html(asset_driver_phone);
            */
            //Check the number axles to determine which vehicle image & how many divs to append to hold the axles
            if (vehicle_axles > 5) {
                no_of_axle_divs = 3;
                divs_to_append = axle_divs_three;
                $('#bg-vehicle-area').css({
                    'background': 'url("<?php echo base_url()?>/assets/images/itms/trailer.png") no-repeat'
                });
            }
            if (vehicle_axles > 3) {
                no_of_axle_divs = 3;
                divs_to_append = axle_divs_three;
                $('#bg-vehicle-area').css({
                    'background': 'url("<?php echo base_url()?>/assets/images/itms/lorry6.png") no-repeat'
                });
            }
            else {
                $('#bg-vehicle-area').css({
                    'background': 'url("<?php echo base_url()?>/assets/images/itms/lorry2.png") no-repeat'
                });
            }
            //appending divs first on top of the vehicle image
            for (var i = 0; i < no_of_axle_divs; i++) {
                $('#bg-vehicle-area').append(divs_to_append[i])
            }
            //append axles on the divs depending on the set and pattern of the tyres on each axle.
            //NOTE:The completePattern Variable 
            count = 1;
            lap = 1;
            if (vehicle_axles == 2) {
                $container = [1, 2];
            }
            else if (vehicle_axles == 3) {
                $container = [1, 2, 2];
            }
            else if (vehicle_axles == 4) {
                $container = [1, 2, 3, 3];
            }
            else if (vehicle_axles == 5) {
                $container = [1, 2, 2, 3, 3];
            }
            else if (vehicle_axles == 6) {
                $container = [1, 2, 2, 3, 3, 3];
            }
            else if (vehicle_axles == 7) {
                $container = [1, 2, 2, 2, 3, 3, 3];
            }
            for (var i = 0; i < vehicle_axles; i++) {
                if (completePattern[i] == 'S' || completePattern[i] == 'SR') {
                    $axle_image = styre_axle;
                }
                else if (completePattern[i] == 'T' || completePattern[i] == 'TR') {
                    $axle_image = dtyre_axle;
                }
                var count = $container[i];
                $('#bg-vehicle-area').find('.axle-div:nth-child(' + count + ')').append($axle_image);
            }
            //give the axles ids 
            var appended_axles = $('#bg-vehicle-area').find('.v-axle');
            var size_appended_axles = appended_axles.length;
            for (var i = 0; i < size_appended_axles; i++) {
                var numb = i + 1;
                $(appended_axles[i]).attr("id", "X" + numb);
            }
            $.ajax({
                type: "POST"
                , cache: false
                , data: {
                    deviceA_id: deviceA_id
                    , deviceB_id: deviceB_id
                    , asset_id: vehicleA_id
                }
                , url: "<?php echo base_url()?>index.php/tpms/get_tpms_info"
                , success: function (response) {
                    data = JSON.parse(response);
                    var count_danger = 0;
                    var count_warning = 0;
                    var tyre_inf = 'Pressure Normal';
                    var count_tyres = 1;
                    var info_class = 'btn-primary';
                    var $or_status = "Status missing";
                    var info = data.info;
                    var p_config = data.pressure_config;
                    if (info.length == 0) {
                        swal({
                            title: "Info"
                            , text: "No Tyre Information was recieved for this vehicle"
                            , type: "info"
                            , confirmButtonText: "ok"
                        });
                        return false;
                    }
                    $('#info-div').find('.lbl-info').remove();
                    for (var row in info) {
                        $axle = info[row].axle;
                        $tyre = info[row].tyre;
                        $tyre_id = info[row].tyre_id;
                        $pressure = parseFloat(info[row].pressure);
                        $temperature = parseFloat(info[row].temperature);
                        $or_status = info[row].status;
                        console.log($axle);
                        var min_pressure = 100;
                        var max_pressure = 130;
                        for (var p in p_config) {
                            if ($axle == 'X' + p_config[p].axle_no) {
                                min_pressure = parseFloat(p_config[p].min_pressure);
                                max_pressure = parseFloat(p_config[p].max_pressure);
                            }
                        }
                        console.log(min_pressure);
                        console.log(max_pressure);
                        if ($pressure < min_pressure) {
                            $tyre_type = 'warning-tyre.png';
                            count_warning++;
                            tyre_inf = 'Low Pressure';
                            info_class = 'btn-warning';
                        }
                        else if ($pressure > max_pressure) {
                            $tyre_type = 'danger-tyre.png';
                            tyre_inf = 'High Pressure';
                            info_class = 'btn-danger';
                            count_danger++;
                        }
                        else {
                            $tyre_type = 'normal-tyre.png';
                            tyre_inf = 'Pressure Normal';
                            info_class = 'btn-primary';
                        }
                        var axle_position = $('#' + $axle).position();
                        //console.log($tyre_id);
                        if (axle_position != undefined) {
                            $left = axle_position.left + 'px';
                            //alert($tyre);                                           
                            $tyre_img = '<img src="<?php echo base_url()?>/assets/images/itms/' + $tyre_type + '" alt="tyre" style="left:' + $left + '" class="info-tyre" id="' + $tyre_id + '" tyre="' + $tyre + '" axle="' + $axle + '" pressure="' + $pressure + '" temperature="' + $temperature + '">';
                            $('#bg-vehicle-area').find('#' + $axle).parent().append($tyre_img);
                            $('#bg-vehicle-area').find('#' + $axle).parent().append($tyre_img);
                            $('#info-div').append('<div class="col-md-6 lbl-info" tyr="' + $tyre_id + '">' + '<label class="btn btn-xs ' + info_class + ' ' + $tyre + '"> ' + count_tyres + ' </label> ' + $pressure + ' PSI - ' + tyre_inf + '</div>');
                            count_tyres++;
                        }
                    }
                    if (count_danger > 0 && count_warning > 0) {
                        $('.div-wd-info').removeClass('bg-critical').removeClass('bg-warning').addClass('bg-critical');
                        $("#pressure-status-area").html("<h3>Tyre(s) Over & Under pressure</h3><p>" + $or_status + "</p>");
                    }
                    else if (count_danger > 0) {
                        $('.div-wd-info').removeClass('bg-critical').removeClass('bg-warning').addClass('bg-critical');
                        $("#pressure-status-area").html("<h3>Tyre(s) Over pressure</h3><p>" + $or_status + "</p>");
                    }
                    else if (count_warning > 0) {
                        $('.div-wd-info').removeClass('bg-critical').removeClass('bg-warning').addClass('bg-warning');
                        $("#pressure-status-area").html("<h3 style='color:#cacc00'>Tyre(s) Under pressure</h3><p style='color:#cacc00'>" + $or_status + "</p>");
                    }
                }
            });
        }
        $(document).on('mouseenter', '.lbl-info', function (e) {
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
            $(this).addClass('info-highlighted');
            var id_ = $(this).attr('tyr');
            $('#bg-vehicle-area').find('.info-tyre').removeClass('blink_');
            $('#bg-vehicle-area').find('#' + id_).addClass('blink_');
        });
        $(document).on('mouseleave', '.lbl-info', function () {
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
            $('#bg-vehicle-area').find('.info-tyre').removeClass('blink_');
        });
        $(document).on('mouseenter', '.info-tyre', function (e) {
            $('#tyre-info-div').stop().hide();
            var pressure = $(this).attr('pressure');
            var temperature = $(this).attr('temperature');
            var axle = $(this).attr('axle');
            var tyre = $(this).attr('tyre');
            var status = 'Normal';
            var btn_type = 'btn-primary';
            if (temperature < 50 || pressure < 50 || temperature > 78 || pressure > 78) {
                status = 'Critical';
                btn_type = 'btn-danger';
            }
            else if (temperature < 60 || pressure < 60 || temperature > 70 || pressure > 70) {
                status = 'Warning';
                btn_type = 'btn-warning';
            }
            var left = parseInt(e.pageX) + 10;
            var top = parseInt(e.pageY) + 10;
            //alert();
            $('#tyre-info-div').find('#pressure-info').html(pressure + '<sup>PSI</sup>');
            $('#tyre-info-div').find('#temperature-info').html(temperature + '<sup>0C</sup>');
            $('#tyre-info-div').find('#status-info').html(status).removeClass('btn-danger').removeClass('btn-warning').addClass(btn_type);
            $('#tyre-info-div').find('#axle-info').html('Axle : ' + axle);
            $('#tyre-info-div').find('#tyre-info').html('Tyre : ' + tyre);
            $('#tyre-info-div').stop().show().css({
                'left': left + 'px'
                , 'top': top + 'px'
            });
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
            $('#info-div').find('.' + tyre).parent().addClass('info-highlighted');
        });
        $(document).on('mouseleave', '.info-tyre', function () {
            $('#tyre-info-div').stop().hide();
            $('#info-div').find('.lbl-info').removeClass('info-highlighted');
        });
        $(".page-header").hide();
        $('#view_vehicle').on('click', function () {
            //var checked = $(this).attr('checked');
            if ($(this).is(':checked')) {
                $('#map-vehicle-zone').fadeIn(1000);
            }
            else {
                $('#map-vehicle-zone').fadeOut(1000);
            }
        });
        $('#close-map-pop').click(function () {
            $('#map-pop').fadeOut(1000);
            $('.overshadow').fadeOut(1000);
        });
    });
</script>
<!--<script async defer src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyBn6m_W3hRMPg5nDlmqsRkaO3kE1LZ1HX4&libraries=places,drawing&callback=initMap">
</script>-->
<script async defer src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyCfKP5H8r9ohlPjH_CbddIefMbeCirz7-U&libraries=places,drawing&callback=initMap">
    </script>