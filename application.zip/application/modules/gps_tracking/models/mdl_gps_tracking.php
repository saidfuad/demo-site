<?php 
class Mdl_gps_tracking extends CI_Model{
    var $user;
    var $current_time;


    function __construct () {
        parent::__construct();
            
        $this->user_id      = $this->session->userdata('itms_user_id');
        $this->current_time = date("Y-m-d H:i:s");
    }

    function get_gps_vehicles ($company_id=null, $owner_id=null, $type_id=null, $cat_id=null, $group_id=null, $query=null) {
        $this->db->select('itms_last_gps_point.*, itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name');
        $this->db->from('itms_last_gps_point')
            ->join('itms_assets', 'itms_assets.device_id=itms_last_gps_point.device_id','left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id','left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
        
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        if($owner_id!=null && $owner_id!=0) {
            $this->db->where('itms_assets.owner_id', $owner_id);
        }

        if($type_id!=null && $type_id!=0) {
            $this->db->where('itms_assets.assets_type_id', $type_id);
        }

        if($cat_id!=null && $cat_id!=0) {
            $this->db->where('itms_assets.assets_category_id', $cat_id);
        }

        if($group_id!=null && $group_id!=0) {
            $this->db->where('itms_assets.assets_group_id', $group_id);
        }

        if($query!=null && $query!="") {
            $this->db->like('itms_assets.assets_friendly_nm', $query, 'both');
            $this->db->or_like('itms_assets.assets_name', $query, 'both');
        }

        
        $query = $this->db->get();
       
         return $query->result();

        //print_r('<pre>');
        //print_r($query->result());
        //exit;
    }

    function get_gps_vehicle_data ($asset_id, $device_id) {
        $this->db->select('itms_assets.asset_id, itms_assets.assets_friendly_nm, itms_assets.assets_name, itms_assets.current_route, itms_assets.current_trip, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name, itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, itms_assets.paired_asset_id, itms_assets.no_of_axles, itms_assets.paired_asset_axles, itms_assets.axle_tyre_config, itms_assets.paired_asset_axle_tyre_config,itms_assets.paired_asset_device_id,
                        itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                            concat(itms_personnel_master.fname, " " , itms_personnel_master.lname) AS driver_name,
                                itms_personnel_master.phone_no AS driver_phone, itms_trips.*,
                                    itms_owner_master.owner_id, itms_owner_master.owner_name, itms_last_gps_point.*');
        $this->db->from('itms_assets')
            ->join('itms_last_gps_point', 'itms_last_gps_point.device_id = itms_assets.device_id', 'left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id','left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left')
            ->join('itms_trips', 'itms_trips.trip_id = itms_assets.current_trip', 'left');
        
        
        $this->db->where('itms_assets.asset_id', $asset_id);
        $query = $this->db->get();

        $res = array();
        
        $data = $query->row_array();
        $res['vehicle_info'] = $data;
        $trip_id = $data['current_trip']; 
        $route_id = $data['current_route'];
        $res['route_data']  = NULL;
        if ($route_id != NULL || $route_id != "") {
            $res['route_data'] = $this->get_route_by_id($route_id);
        } else {
            //$res['route_data'] = $this->get_history_playback($asset_id);
        }   

        $res['gps_hist'] = $this->get_current_trip_points($device_id, $trip_id);

        return $res;        
    }

    function get_zones ($company_id = null) {
        if($company_id != null) {
            $this->db->where('company_id', $company_id);
        }

        $this->db->where('status', 1);
        $this->db->where('del_date', NULL);

        $query = $this->db->get('itms_zones');

        return $query->result();
    }

    function get_vertices ($company_id = null) {
        if($company_id != null) {
            $this->db->where('company_id', $company_id);
        }

        $query = $this->db->get('itms_zones_vertices');

        return $query->result();
    }

    function get_current_trip_points($device_id, $trip_id) {
        $this->db->select('*');
        $this->db->from('itms_gps_track_points');
        $this->db->where('device_id', $device_id);
        
        if ($trip_id!=null || $trip_id != "") {
            $this->db->where('trip_id', $trip_id);
        } else {
            //$this->db->where('DATE(fixture_date) >= DATE_SUB(NOW(), INTERVAL 24 HOUR)');
            $this->db->where('add_date >= DATE_SUB(NOW(), INTERVAL 24 HOUR)');
            
        }
        

        $query = $this->db->get();

        return $query->result();
    }


    function get_route_by_id($route_id) {
        $this->db->select('*');
        $this->db->from('itms_routes');
        $this->db->where('route_id', $route_id);

        $query = $this->db->get();

        return $query->row_array();
    }

    public function get_devices($company_id=null, $user_id=null) {
        $this->db->where('itms_assets.status',1);
        $this->db->where('itms_assets.del_date',null);
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        $whereUser='';

        if ($user_id!=null) {
            $whereUser = " AND find_in_set(id, (SELECT assets_ids FROM user_assets_map where user_id = $user)) ";
        }
        
        $query = $this->db->query("select asset_id, assets_name, device_id, assets_friendly_nm 
                                    from 
                                        itms_assets 
                                    where status=1 AND del_date is null 
                                    {$whereUser}
                                    order by 
                                        assets_name asc");
        
        return $query->result();
    }

    public function get_vehicles_status($company_id, $user_assets=null) {
        
        if ($company_id!=null) {
            $this->db->where('itms_alert_master.company_id', $company_id);
        }

       $current_user_id = $this->session->userdata('itms_userid');

       //echo $current_user_id;
       //exit;

        $whereUser='';
        /*
        if ($us{$whereUser}er_id!=null) {
            $whereUser = " AND find_in_set(id, (SELECT assets_ids FROM user_assets_map where user_id = $user)) ";
        }
        */

        $query = $this->db->query("SELECT itms_last_gps_point.*,itms_assets.assets_name, itms_assets.assets_friendly_nm, 
                                                    itms_personnel_master.fname, itms_personnel_master.lname,itms_personnel_master.phone_no
                                    FROM 
                                        itms_last_gps_point
                                    LEFT JOIN itms_assets LEFT JOIN itms_personnel_master ON (itms_assets.personnel_id=itms_personnel_master.personnel_id) ON (itms_assets.device_id=itms_last_gps_point.device_id) 
                                    WHERE 
                                        FIND_IN_SET(itms_assets.asset_id, (select group_concat(asset_id) from itms_alerts_contacts where user_id='$current_user_id'))
                                    OR 
                                        FIND_IN_SET(itms_assets.asset_id, (select group_concat(asset_id) from itms_assets where add_uid='$current_user_id'))
                                    ORDER BY 
                                        id DESC");
        
        return $query->result();
    }

    function get_vehicles_owners ($company_id=null) {
        $this->db->select('itms_owner_master.*');
        $this->db->from('itms_owner_master');
        
        if ($company_id!=null) {
            $this->db->where('itms_owner_master.company_id', $company_id);
        }

        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }
    
    function get_vehicles_categories ($company_id=null) {
        $this->db->select('itms_assets_categories.*');
        $this->db->from('itms_assets_categories');
        
        if ($company_id!=null) {
            //$this->db->where('itms_assets_categories.company_id', $company_id);
        }

        
        $this->db->order_by('assets_cat_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }
    
    function get_vehicles_types ($company_id=null) {
        $this->db->select('itms_assets_types.*');
        $this->db->from('itms_assets_types');
       
        if ($company_id!=null) {
            //$this->db->where('itms_assets_types.company_id', $company_id);
        }

        $this->db->order_by('assets_type_nm', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }

    function get_vehicles_groups ($company_id=null) {
        $this->db->select('itms_assets_groups.*');
        $this->db->from('itms_assets_groups');
       
        if ($company_id!=null) {
            $this->db->where('itms_assets_groups.company_id', $company_id);
        }

        $this->db->order_by('assets_group_nm', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    public function getAutoRefreshSettings(){
        $user_id = $this->session->userdata('itms_user_id');
        
        $SQL="select auto_refresh_setting from itms_users where user_id = '".$user_id."'";
        $query = $this->db->query($SQL);
        return $query->row();
    }
    public function getOnscreenAlertSettings(){
        $user_id = $this->session->userdata('itms_user_id');
        
        $SQL="select onscreen_alert from itms_users where user_id = '".$user_id."'";
        $query = $this->db->query($SQL);
        return $query->row();
    }

    

    function get_routes ($company_id=null) {
        if ($company_id!=null) {
           $this->db->where('company_id', $company_id); 
        }

        $this->db->select('route_id, route_name, route_color, duration, distance, start_address, end_address');
        $this->db->from('itms_routes');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_map_display_routes ($company_id=null) {
        if ($company_id!=null) {
           $this->db->where('company_id', $company_id); 
        }

        $this->db->select('*');
        $this->db->from('itms_routes');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_trips ($asset_id=null, $company_id=null) {
        
        $this->db->select("itms_trips.*, itms_assets.assets_friendly_nm, itms_assets.assets_name, itms_assets.device_id,
            (itms_personnel_master.fname + ' ' +itms_personnel_master.lname) AS driver_name ,itms_personnel_master.phone_no AS driver_phone, itms_client_master.client_name as client");
        $this->db->from('itms_trips');
        $this->db->join('itms_assets', 'itms_assets.asset_id=itms_trips.asset_id');
        $this->db->join('itms_personnel_master', 'itms_personnel_master.personnel_id=itms_trips.driver_id', 'left');
        $this->db->join('itms_client_master', 'itms_client_master.client_id=itms_trips.client_id', 'left');

        if ($company_id!=null) {
           $this->db->where('itms_trips.company_id', $company_id); 
        }
        
        if ($asset_id!=null) {
           $this->db->where('itms_trips.asset_id', $asset_id);
        }

        $this->db->order_by('itms_trips.trip_id', 'DESC');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_landmarks ($company_id=null) {
            
        if ($company_id!=null) {
            $whereCompany = "AND company_id='".$company_id."'";
        }

        $q = "SELECT * 
                FROM itms_landmarks 
                WHERE 1
                AND status=1 
                    {$whereCompany}
                AND del_date is null ORDER BY landmark_name ASC ";

        $query = $this->db->query($q);
        return $query->result();
        
    }

    function get_landmark_by_id($landmark_id, $company_id=null){

        $this->db->select('itms_landmarks.*');
        $this->db->from('itms_landmarks');

        if ($company_id!=null) {
            $this->db->where('itms_landmarks.company_id', $company_id);
        }
        $this->db->where('itms_landmarks.landmark_id=', $landmark_id);
        $query = $this->db->get();
        return $query->row_array();

    }

    function get_zone_by_id($zone_id, $company_id=null){

        $this->db->select('itms_zones.*');
        $this->db->from('itms_zones');

        if ($company_id!=null) {
            $this->db->where('itms_zones.company_id', $company_id);
        }
        $this->db->where('itms_zones.zone_id=', $zone_id);
        $query = $this->db->get();
        return $query->row_array();

    }

    function delete_landmark($landmark_id){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql="UPDATE itms_landmarks SET del_date = '".$t."' WHERE landmark_id ='".$landmark_id."'";
        $this->db->query($sql);
    }

    function edit_landmark(){
        
    }

    function update_landmark(){
        
    }
    

    function get_all_categories ($company_id = null) {
             
        $this->db->select('itms_assets_categories.*');
        $this->db->from('itms_assets_categories');
           if ($company_id!=null) {
                $this->db->where('itms_assets_categories.company_id', $company_id);
           }
        $this->db->order_by('assets_cat_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function get_personnel ($company_id=null, $role_id=null, $user_id=null){
        $whereCompany ='';
        $whereUser = "";
        $whereRole = "";
        if ($company_id!=null) {
            $whereCompany = " AND itms_personnel_master.company_id = '".$company_id."' ";
        }

        if ($user_id!=null) {
            $whereUser = " AND itms_personnel_master.add_uid = '".$user_id."' ";
        }

        if ($role_id!=null) {
            $whereRole = " AND itms_personnel_master.role_id = '".$role_id."' ";
        }

        $SQL="SELECT itms_personnel_master.*, itms_roles.role_name from itms_personnel_master 
                INNER JOIN 
                    itms_roles ON(itms_personnel_master.role_id = itms_roles.role_id) 
                    WHERE 1 
                        {$whereCompany} 
                        {$whereUser} 
                        {$whereRole}";

        $rarr=$this->db->query($SQL);
        return $rarr->result();
    }
    
    function get_all_types ($company_id = null) {
       
        $this->db->select('itms_assets_types.*');
        $this->db->from('itms_assets_types');
           if ($company_id!=null) {
                $this->db->where('itms_assets_types.company_id', $company_id);
           }

        $this->db->order_by('assets_type_nm', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function get_all_devices ($company_id = null) {
       
        $this->db->select('itms_devices.*');
        $this->db->from('itms_devices');
           if ($company_id!=null) {
                $this->db->where('itms_devices.company_id', $company_id);
           }

        $this->db->order_by('device_id', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function get_all_assets ($company_id = null) {
       
        $this->db->select('itms_assets.*');
        $this->db->from('itms_assets');
           if ($company_id!=null) {
                $this->db->where('itms_assets.company_id', $company_id);
           }

        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function save_trips($data) {
        
        $query = $this->db->insert('itms_trips', $data);
        
        return $query;
        
    }
    
    function start_trip($trip_id){
        
        $this->db->select("itms_trips.is_complete");
        $this->db->from('itms_trips');
        $this->db->where('itms_trips.trip_id=', $trip_id);
        
        $sql = $this->db->get();
        $add = $sql->result_array();
        $t=$add[0]["is_complete"];

        if ($t == "0") {
            
            $s = "1";
            $sql="UPDATE itms_trips SET is_complete = '".$s."' WHERE trip_id ='".$trip_id."'";
            $this->db->query($sql);
        }
    }
    
    function view_trip($trip_id){
        
        $this->db->select('itms_trips.*,
        itms_client_master.client_name, itms_client_master.phone_no, itms_client_master.address');
        
        $this->db->from('itms_trips');
        $this->db->join("itms_client_master", "itms_client_master.client_id = itms_trips.client_id");
        
        $this->db->where('itms_trips.trip_id=', $trip_id);
        $query = $this->db->get();
       
        return $query->result();
        
    }
    
    function s_vehicle() {
       $query = $this->db->get('itms_landmarks');

        return $query->result(); 
    }

    public function getdriver($keyword) {   
        $this->db->select('CONCAT(itms_assets.assets_friendly_nm, " ", itms_assets.assets_name) AS driver_name');
        $this->db->order_by('asset_id', 'DESC');
        $this->db->like("assets_name", $keyword);
        $this->db->where('company_id',$this->session->userdata('itms_company_id'));
        // $this->db->like();
        return $this->db->get('itms_assets')->result_array();
    }

    public function getclient($keyword) {   
        $this->db->select('itms_client_master.client_name');
        $this->db->order_by('client_id', 'DESC');
        $this->db->like("client_name", $keyword);
        $this->db->where('company_id',$this->session->userdata('itms_company_id'));
        // $this->db->like();
        return $this->db->get('itms_client_master')->result_array();
    }

    public function getroute($keyword) {   
        $this->db->select('itms_routes.route_name');
        $this->db->order_by('route_id', 'DESC');
        $this->db->like("route_name", $keyword);
        $this->db->where('company_id',$this->session->userdata('itms_company_id'));
        // $this->db->like();
        return $this->db->get('itms_routes')->result_array();
    }

    public function get_device(){
        $assigned = 0;
        $this->db->where('assigned', $assigned);
        $query = $this->db->get('itms_devices');
        return $query->result();
    }

    public function get_vehicle(){
        $this->db->where('device_id IS NULL');
        $query = $this->db->get('itms_assets');
        return $query->result();
    }
}
?>
