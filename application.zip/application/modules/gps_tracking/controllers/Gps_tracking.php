<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Gps_tracking extends CI_Controller {
    function __construct() {

        parent::__construct();
        
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
        
        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

        $this->load->model('mdl_gps_tracking');
       $this->load->library('emailsend');
    }

    function send_email () {
        $to =array('makaweys@gmail.com');
        $subj = 'test';
        $message = "ITMS Registration Successful. \n\n
                                Username : email \nPassword : pass";

        $this->emailsend->send_email_message ($to, $subj, $message);
    }


    public function index() {

        //$this->load->library('googlemaps');

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') !=0)
        {
            $map_center = sprintf( "%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $coords = array();
        $data = array();
        $vehicleNames = array();
        $categoryOpt = '';
        $categoryList = '';
        $typeOpt = '';
        $typeList = '';
        $groupOpt = '';
        $groupsList = '';    
        $ownerOpt = '';
        $ownersList = '';
        $vehicleList = '';


        $vehicles = $this->mdl_gps_tracking->get_gps_vehicles($this->session->userdata('itms_company_id'));
        
        if(count($vehicles)) {
            foreach ($vehicles as $vehicle) {
                $txt="";
                $txt = addslashes($vehicle->assets_name);
                if($vehicle->assets_friendly_nm!="")
                    $txt.="(".addslashes($vehicle->assets_friendly_nm).")";
                $vehicleNames[] =$txt;
                $vehicleList .= "<li asset-id='".$vehicle->asset_id."'><span class='fa fa-car'></span>&nbsp;".$vehicle->assets_name.' - '.addslashes($vehicle->assets_friendly_nm)."</li>";
            }
        }

        $categories = $this->mdl_gps_tracking->get_vehicles_categories($this->session->userdata('itms_company_id'));
        if(count($categories)) {
            foreach ($categories as $cat) {
                $categoryOpt .= "<option value='".$cat->assets_category_id."'>".addslashes($cat->assets_cat_name)."</option>";
                $categoryList .= "<li assets-category-id='".$cat->assets_category_id."'><a href=''>".addslashes($cat->assets_cat_name)."</a></li>";
            }
        }

        $types = $this->mdl_gps_tracking->get_vehicles_types($this->session->userdata('itms_company_id'));
        if(count($types)) {
            foreach ($types as $type) {
                $typeOpt .= "<option value='".$type->assets_type_id."'>".addslashes($type->assets_type_nm)."</option>";
                $typeList .= "<li assets-category-id='".$type->assets_type_id."'><a href=''>".addslashes($type->assets_type_nm)."</a></li>";
            }
        }

        $owners = $this->mdl_gps_tracking->get_vehicles_owners($this->session->userdata('itms_company_id'));
        foreach ($owners as $owner)
        {
            $ownerOpt .= "<option value='".$owner->owner_id."'>".$owner->owner_name."</option>";
            $ownersList .= "<li data-id='".$owner->owner_id."'><a href=''>".addslashes($owner->owner_name)."</a></li>";
        }

        $groups = $this->mdl_gps_tracking->get_vehicles_groups($this->session->userdata('itms_company_id'));
        foreach ($groups as $group)
        {
            $groupOpt .= "<option value='".$group->assets_group_id."'>".$group->assets_group_nm."</option>";
            $groupsList .= "<li data-id='".$group->assets_group_id."'><a href=''>".addslashes($group->assets_group_nm)."</a></li>";
        }

        $rows = $this->mdl_gps_tracking->get_landmarks($this->session->userdata('itms_company_id'));
        $lmarks = $rows;
        $landmarks = array();
        $landmarkOpt ='';
        $landmarkList = '';
        
        if(count($rows) > 0){
            foreach ($rows as $row) {
                $landmarks[] = $row;
                $landmarkOpt .= "<option value='l-".$row->landmark_id."'>".addslashes($row->landmark_name)."</option>";
                $landmarkList .= "<li landmark-data-id='".$row->landmark_id."'><a href=''>".addslashes($row->landmark_name)."</a></li>";
            }
        }

        
        /*$vehiclesStatus = $this->mdl_gps_tracking->get_vehicles_status($this->session->userdata('itms_company_id'));
        
        $running="";
        $parked="";
        $out_of_network="";
        $device_fault="";
        $total="";

        if(count($vehiclesStatus)){
            foreach ($vehiclesStatus as $status) {
               
            }
        }*/

        $rows = $this->mdl_gps_tracking->get_devices($this->session->userdata('itms_company_id'));
        $d_assets_cmb="";
        $countAssets=count($rows);
        
        if(count($rows)) {
            foreach ($rows as $row) {
                $d_assets_cmb.="<option value='".$row->asset_id."'>";
                $d_assets_cmb.=$row->assets_name." (".$row->device_id.")";
                $d_assets_cmb.="</option>";
            }
        }
		
		
        
        /*$display_settings = array();
        
        $rows=$this->home_model->getUserDisplay_Settings();
        $display_settings=$rows;
        $this->session->set_userdata($display_settings);
       

        $data['usr_assets_cmb']=$d_assets_cmb;
        $data['usr_assets_cmb_count']=$countAssets;
       
        
        $row = $this->home_model->getServiceExpiryAlertBeforeDays();
        $days_before = $row->data_value;
        
        $row = $this->home_model->getRemainingDays();
        $remaining_days = $row->days;
        $expiry_date = $row->to_date;
        $data['msg'] = '';
        
        if($remaining_days <= $days_before && $remaining_days != "" ){
             $data['msg'] = "Your account expires on ".date($this->session->userdata('date_format'), strtotime($expiry_date))." [$remaining_days days remain]";
        }
        
        */

              
        //$location_with_tag = $this->mdl_gps_tracking->tag_setting($this->session->userdata('itms_company_user_id'));
       // $refreshSettings = $this->mdl_gps_tracking->getAutoRefreshSettings();
        //$onScr = $this->mdl_gps_tracking->getOnscreenAlertSettings();
        
        /*$marker = array();
        $marker['position'] = $this->session->userdata('company_latitude').','. $this->session->userdata('company_longitude');
        $this->googlemaps->add_marker($marker);
        */

        //$landmarks = $this->mdl_landmarks->get_landmarks($this->session->userdata('itms_company_id'));
        
        //print_out_landmarks
       /* if(count($lmarks) > 0) {
            $marker = array();
            $circle = array();


            $i=0;
            foreach ($lmarks as $row) {
                $position = sprintf( "%f, %f", $row->latitude, $row->longitude);
                $marker['position'] = $position;
                $marker['title'] = $row->landmark_name;
                $marker['icon'] = base_url($row->icon_path);
                $marker['infowindow_content'] = $row->landmark_name;
                $marker['icon_scaledSize'] = '20,20';
                $marker['onmouseout'] = 'iw_map.close();';
                $marker['onmouseover'] = '  iw_map.setContent(this.get("content"));
                                            iw_map.open(map, this);';
        
                $this->googlemaps->add_marker($marker);

            }
        }

        */
        

        //$data['map'] = $this->googlemaps->create_map();
        
        //$data['location_with_tag']=$location_with_tag;
        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;
        //$data['landmarks'] = $landmarks;
        //$data['lmarks'] = $lmarks;
        $data['vehicleList'] = $vehicleList;
        $data['landmarkOpt'] = $landmarkOpt;
        $data['landmarkList'] = $landmarkList;
        $data['vehicleNames'] = $vehicleNames;
        $data['categoryOpt'] = $categoryOpt;
        $data['categoryList'] = $categoryList;
        $data['typeOpt'] = $typeOpt;
        $data['typeList'] = $typeList;
        $data['groupOpt'] = $groupOpt;
        $data['groupList'] = $groupsList;
        $data['ownerOpt'] = $ownerOpt;
        $data['ownersList'] = $ownersList;
        //$data['auto_refresh_setting'] = $refreshSettings->auto_refresh_setting;
        //$data['onscreen_alert'] = $onScr->onscreen_alert;

        $data['content_url'] = 'gps_tracking';
        $data['fa'] = 'fa fa-map-marker';
        $data['title'] = 'ITMS Africa | GPS Tracking';
        $data['content_title'] = 'GPS Tracking';
        $data['content_subtitle'] = 'Vehicle Automated Location Surveillance';
        $data['content'] = 'gps_tracking/gps_home2.php';
       
	    //exit;
	   
        $this->load->view('main/main.php', $data);
		
		
    }


    public function get_company_landmarks () {
        $data = $this->mdl_gps_tracking->get_landmarks($this->session->userdata('itms_company_id'));

        echo json_encode($data);
    }

    public function get_company_zones () {
        $zones = $this->mdl_gps_tracking->get_zones($this->session->userdata('itms_company_id'));
        $vertices = $this->mdl_gps_tracking->get_vertices($this->session->userdata('itms_company_id'));

        $data['zones'] = $zones;
        $data['vertices'] = $vertices;

        echo json_encode($data);
    }

    public function get_company_map_display_routes () {
        $data = $this->mdl_gps_tracking->get_map_display_routes($this->session->userdata('itms_company_id'));

        //foreach ($data as $key => $value) {
            
           /* $route_data = $data['raw_route'];

            if ($route_data!='') {
                $route_data = json_decode($route_data, true);
                $routes = $route_data['routes'];

                foreach ($routes as $key => $route) {
                    $legs = $route['legs'];

                    foreach ($legs as $key => $leg) {
                        $steps = $leg['steps'];

                        foreach ($steps as $key => $step) {
                            $path = $step['path'];

                            foreach ($path as $key => $cord) {
                                print_r('<pre>');
                                print_r($data);
                                exit;
                            }
                            
                        }
                    }
                }

                

            }*/

            
        //}

        echo json_encode($data);
    }

    public function refresh_grid () {

        $owner_id = $this->input->post('owner');
        $type_id = $this->input->post('type');
        $cat_id = $this->input->post('cat');
        $group_id = $this->input->post('group');
        $query = $this->input->post('query');

        
        $vehicles = $this->mdl_gps_tracking->get_gps_vehicles ($this->session->userdata('itms_company_id'), $owner_id, $type_id, $cat_id, $group_id, $query);

        $res = array('vehicles'=>$vehicles);

        echo json_encode($res);
    }


    function get_vehicle_details () {
        $asset_id = $this->input->post('asset_id');
        $device_id = $this->input->post('device_id');

        $data = $this->mdl_gps_tracking->get_gps_vehicle_data($asset_id, $device_id);

        /*print_r('<pre>');
        print_r($data);
        exit;
*/
        echo json_encode($data);
    }

    public function filter_grid () {
        $owner_id = $this->input->post('owner');
        $type_id = $this->input->post('type');
        $cat_id = $this->input->post('cat');
        $group_id = $this->input->post('group');

        $vehicles = $this->mdl_gps_tracking->get_gps_vehicles ($this->session->userdata('itms_company_id'), $owner_id, $type_id, $cat_id, $group_id);

        $res = array('vehicles'=>$vehicles);



        echo json_encode($res);
    }

    public function telematics () {
        $status = $this->mdl_gps_tracking->get_vehicles_status('', '');

        /*print_r('<pre>');
        print_r($status);
        exit;
        */

        $data['content_url'] = 'gps_tracking/telematics';
        $data['fa'] = 'fa fa-file-text';
        $data['title'] = 'ITMS Africa | GPS Status';
        $data['content_title'] = 'GPS Status';
        $data['content_subtitle'] = '';
        $data['status'] = $status;
        $data['content'] = 'gps_tracking/telematics.php';
        $this->load->view('main/main.php', $data);
    }

    public function zones() {
        $data['zones'] = $this->mdl_gps_tracking->get_zones($this->session->userdata('itms_company_id'));

        // var_dump($data);
        // die();
        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['content_url'] = 'gps_tracking/zones';
        $data['fa'] = 'fa fa-location-arrow';
        $data['title'] = 'ITMS Africa | Zones';
        $data['content_title'] = 'Zones';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/zones.php';
        $this->load->view('main/main.php', $data);
    }

    public function routes() {
        $data['routes'] = $this->mdl_gps_tracking->get_routes($this->session->userdata('itms_company_id'));
        // var_dump($data);
        // die();
        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['content_url'] = 'gps_tracking/routes';
        $data['fa'] = 'fa fa-road';
        $data['title'] = 'ITMS Africa | Routes';
        $data['content_title'] = 'Routes';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/routes.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_route($route_id){
        $data['routes'] = $this->mdl_gps_tracking->get_route_by_id($route_id);

        //echo "<pre>";
        //print_r($data);
        //exit;

        $data['content_url'] = 'gps_tracking/edit_route';
        $data['fa'] = 'fa fa-road';
        $data['title'] = 'ITMS Africa | Edit Route';
        $data['content_title'] = 'Edit Route';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/edit_route.php';
        $this->load->view('main/main.php', $data);

    }

    public function create_trip() {
if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;


        $data['content_url'] = 'gps_tracking/create_trip';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Create Trips';
        $data['content_title'] = 'Create Trips';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/create_trip.php';
        $this->load->view('main/main.php', $data);
    }

    public function getroute(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_gps_tracking->getroute($keyword);      
        echo json_encode($data);
    }

    public function routes1(){
        $word=$this->input->get('route_id');

        // die();   
        //$sql = $this->db->query('SELECT start_address FROM itms_routes WHERE route_name = "'.$word.'"');
        $this->db->select('start_address,end_address')
        ->from('itms_routes')
        ->where('route_name',$word)
        ->where('company_id',$this->session->userdata('itms_company_id'));
        $query = $this->db->get();
        echo json_encode($query->result_array());
    }

    public function save_trips () {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');

        echo $this->mdl_gps_tracking->save_trips($data);
    }
    
    public function start_trip ($trip_id) {
     
        $this->mdl_gps_tracking->start_trip($trip_id);
        header('location:'.base_url('index.php/gps_tracking/trips'));
        
    }
    
    public function view_trip ($trip_id) {
        
        $data['trip'] = $this->mdl_gps_tracking->view_trip($trip_id);

        $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
        $map_lat = '-4.0434771';
        $map_long = '39.6682065';
        
        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;
        
        $data['content_url'] = 'gps_tracking/view_trip';
        $data['fa'] = 'fa fa-paper-plane';
        $data['title'] = 'ITMS Africa | View Trip';
        $data['content_title'] = 'View Trip';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/view_trip.php';
        $this->load->view('main/main.php', $data);
    }

    public function trips() {
        
        $data['content_btn']= '<a href="'.site_url('gps_tracking/create_trip').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Create Trip</a>';

        $asset_id = null;

        if(isset($_REQUEST['asset'])){
            $asset_id = $_REQUEST['asset'];
        }

        $data['trips'] = $this->mdl_gps_tracking->get_trips($asset_id, $this->session->userdata('itms_company_id'));

        $data['content_url'] = 'gps_tracking/trips';
        $data['fa'] = 'fa fa-paper-plane';
        $data['title'] = 'ITMS Africa | Trips';
        $data['content_title'] = 'Trips';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/trips.php';
        $this->load->view('main/main.php', $data);
    }

    public function landmarks () {
        
        $data['landmarks'] = $this->mdl_gps_tracking->get_landmarks($this->session->userdata('itms_company_id'));
        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['content_url'] = 'gps_tracking/landmarks';
        $data['fa'] = 'fa fa-university';
        $data['title'] = 'ITMS Africa | Landmarks';
        $data['content_title'] = 'Landmarks';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/landmarks.php';
        $this->load->view('main/main.php', $data);
    }


    public function gps_devices_integration () {
        $deviceOpt = '';
        $deviceList = '';    
        $vehicleOpt = '';
        $vehicleList = '';

        $devices = $this->mdl_gps_tracking->get_device($this->session->userdata('itms_company_id'), $role_id=2, $user_id=null);
        foreach ($devices as $device)
        {
            $deviceOpt .= "<option value='".$device->id."'>".$device->device_id."</option>";
            // $deviceList .= "<li data-id='".$device->id."'><a href=''>".addslashes($device->device_id)."</a></li>";
        }

        $vehicles = $this->mdl_gps_tracking->get_vehicle($this->session->userdata('itms_company_id'), $role_id=2, $user_id=null);
        foreach ($vehicles as $vehicle)
        {
            $vehicleOpt .= "<option value='".$vehicle->asset_id."'>".$vehicle->assets_name."</option>";
            // $vehicleList .= "<li data-id='".$vehicle->asset_id."'><a href=''>".addslashes($vehicle->assets_name)."</a></li>";
        }

        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['deviceOpt'] = $deviceOpt;
        $data['vehicleOpt'] = $vehicleOpt;
        $data['content_url'] = 'gps_tracking/gps_devices_integration';
        $data['fa'] = 'fa fa-university';
        $data['title'] = 'ITMS Africa | GPS Devices Integration';
        $data['content_title'] = 'GPS Devices Integration';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/gps_devices_integration.php';
        $this->load->view('main/main.php', $data);
    }

    public function integrate(){
        $dev = $this->input->post('device_id');
        $veh = $this->input->post('asset_id');

        $device = $this->db->query('SELECT device_id FROM itms_devices WHERE id = "'.$dev.'"');
        $devi = $device->result_array();
        $dei = $devi[0]["device_id"];

        $this->db->query('UPDATE itms_assets SET device_id = "'.$dei.'" WHERE asset_id = "'.$veh.'"');

        $this->db->query('UPDATE itms_devices SET assigned = 1 WHERE id = "'.$dev.'"');
    }

    public function delete_landmark($landmark_id){
        $this->mdl_gps_tracking->delete_landmark($landmark_id);
        header('location:'.base_url('index.php/gps_tracking/landmarks'));
    }

    public function fetch_landmark(){
        $data['vehicle'] = $this->mdl_gps_tracking->get_landmark($this->session->userdata('itms_company_id'));

        $data['content_btn']= '<a href="'.site_url('settings/create_landmarks').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['content_url'] = 'settings/create_landmarks';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Landmark';
        $data['content_title'] = 'Landmark';
        $data['content_subtitle'] = 'Landmark Details';
        $data['content'] = 'settings/view_landmark.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_landmark($landmark_id){
        $this->load->library('googlemaps');
        $this->load->model('settings/mdl_landmarks');

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') !=0)
        {
            $map_center = sprintf( "%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
        } else {
            $map_center = sprintf( "%f, %f", ' -4.0434771', '39.6682065');
        }

        $config['center'] = $map_center;
        $config['zoom'] = '12';
        $config['map_width'] = '100%';
        $config['map_height'] = '600';
        $config['trafficOverlay'] = TRUE;
        $config['onclick'] = '  countM++;
                                clearMarkers();
                                clearCircles();

                                if ($("#landmark-radius").val().trim().length==0 || !$.isNumeric(parseFloat($("#landmark-radius").val().trim()))) {
                                    $("#landmark-radius").val(1)
                                } 

                                newLatLng = event.latLng;
                                fillcolor = $("#full-popover").val();
                                range = parseFloat($("#landmark-radius").val());

                                addCircle(newLatLng);
                                addMarker(newLatLng);

                                $("#input-latitude").val(event.latLng.lat());
                                $("#input-longitude").val(event.latLng.lng());

                                $(".page-alert").children("p").html("You have <strong>selected</strong> the position on the <strong>marker</strong>");
                                
                                ';

        $this->googlemaps->initialize($config);

        $marker = array();
        $marker['position'] = $this->session->userdata('company_latitude').','. $this->session->userdata('company_longitude');
        $this->googlemaps->add_marker($marker);
        
        $deviceGrp = "";
        
        $rows = $this->mdl_landmarks->get_landmarks($this->session->userdata('itms_company_id'));
        $coords = array();
        
        if(count($rows) > 0) {
            foreach ($rows as $row) {
                $row->name=str_replace(array("\n",'\n\r'), " ", addslashes($row->landmark_name));
                $row->address=str_replace(array("\n",'\n\r'), " ", addslashes($row->address));
                $row->comments=str_replace(array("\n",'\n\r'), " ", addslashes($row->comments));
                $coords[] = sprintf( "%f, %f", $row->latitude, $row->longitude);
            }
        }
        $data['coords'] = $coords;
        
        
        
        
                
        $rows = $this->mdl_landmarks->getIconPaths();
        $images = '';

        foreach ($rows as $row) {
            $images .= '<li title="'.base_url().'/'.$row->image_path.'" value="'.$row->image_path.'">
                            <img src="'.base_url().'/'.$row->image_path.'" alt="landmark image" />
                        </li>';
        }

        
        
        
        $rows = $this->mdl_landmarks->getAllCoord($this->session->userdata('itms_company_id'));
        
        $opt_latlng="";
        if(count($rows) > 0) {
        $i=0;
            foreach ($rows as $row) {
                if($row['latitude']!='' || $row['latitude']!=null){
                    $opt_latlng.="<option value='".$row['latitude'].",".$row['longitude']."'>".addslashes($row['assets_name'])."</option>";
                }
                else{
                    $opt_latlng.="<option value='0,0'>".addslashes($row['assets_name'])."</option>";
                }
            }
        }

        $landmarks = $this->mdl_landmarks->get_landmarks($this->session->userdata('itms_company_id'));
        
        
        if(count($landmarks) > 0) {
            $marker = array();
            $circle = array();

            $i=0;
            foreach ($landmarks as $row) {
                $position = sprintf( "%f, %f", $row->latitude, $row->longitude);
                $marker['position'] = $position;
                $this->googlemaps->add_marker($marker);

                $circle['center'] = $position;
                $circle['radius'] = $row->radius;
                $circle['fillColor'] = $row->landmark_circle_color;
                $circle['fillOpacity'] = 0.35;
                $this->googlemaps->add_circle($circle);
            }
        }

        $data['map'] = $this->googlemaps->create_map();
        $data['live_combo'] = $opt_latlng;
        
        $data['landmark_images'] = $images;

        $data['fetch_landmark'] = $this->mdl_gps_tracking->get_landmark_by_id($landmark_id);

        $data['content_url'] = 'landmarks';
        $data['fa'] = 'fa fa-pencil';
        $data['title'] = 'ITMS Africa | Edit landmark';
        $data['content_title'] = 'Edit Landmark';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/edit_landmark.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_zone($zone_id){
        
        $data['fetch_zone'] = $this->mdl_gps_tracking->get_zone_by_id($zone_id);

        $data['content_url'] = 'landmarks';
        $data['fa'] = 'fa fa-pencil';
        $data['title'] = 'ITMS Africa | Edit Zone';
        $data['content_title'] = 'Edit Zone';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_tracking/edit_zone.php';
        $this->load->view('main/main.php', $data);

    }

    public function test(){
        $t = $this->mdl_gps_tracking->s_vehicle();

        var_dump($t);
    }

    public function getdriver(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_gps_tracking->getdriver($keyword);      
        echo json_encode($data);
    }

    public function getclient(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_gps_tracking->getclient($keyword);      
        echo json_encode($data);
    }
}
?>
