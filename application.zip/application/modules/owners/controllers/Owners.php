<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Owners extends CI_Controller {

    function __construct() {

        parent::__construct();
        
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }

        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
           redirect('home');
        }

        $this->load->model('mdl_owners');

       
    }

    public function index() {

        $data['owners'] = $this->mdl_owners->get_owners($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'vehicles/owners';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicle Owners';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/owners.php';
        $this->load->view('main/main.php', $data);
    }

    public function save_owner () {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['add_date'] = date('Y-m-d H:i:s');

        echo $this->mdl_owners->save_owner($data);
    }

    public function update_owner () {
        $data = array('owner_id' => $this->input->post('owner_id'),
                      'owner_name' => $this->input->post('owner_name'), 
                      'phone_no' => $this->input->post('phone_no'),
                      'email' => $this->input->post('email'),
                      'address' => $this->input->post('address'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
                
        echo $this->mdl_owners->update_owner($data);
    }

    

}
