<?php 

class Mdl_owners extends CI_Model{


    function get_owners ($company_id=null) {
        // $this->db->select('itms_owner_master.*, itms_assets.asset_id');

        // $this->db->from('itms_owner_master')
        // ->join('itms_assets', 'itms_assets.owner_id = itms_owner_master.owner_id');
        $this->db->select('*');
        $this->db->from('itms_owner_master');
        //$this->db->join('itms_assets', 'itms_assets.owner_id = itms_owner_master.owner_id','left');

        $this->db->where('itms_owner_master.del_date IS NULL');
          
       if ($company_id != null) {
            $this->db->where('itms_owner_master.company_id', $company_id);
       }

        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function save_owner ($data) {
        if ($this->check_owner_phone_number($data['phone_no'])) {
            return 77;
            exit;
        }

        if ($this->check_owner_email($data['email'])) {
            return 78;
            exit;
        }

        $query = $this->db->insert('itms_owner_master', $data);

        if ($query) {
            //$this->session->set_userdata('vehicle_image', '');
            return true;
        }
        
        return false;
        
    }
    function update_owner ($data) {
        $this->db->where('owner_id', $data['owner_id']);
        $this->db->update('itms_owner_master', $data);
    }

    function check_owner_phone_number($phone_no) {
        $query = $this->db->get_where('itms_owner_master', array('phone_no'=>$phone_no));
        
        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }

    function check_owner_email($email) {
        $query = $this->db->get_where('itms_owner_master', array('email'=>$email));
        
        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }
	
	
}

?>
