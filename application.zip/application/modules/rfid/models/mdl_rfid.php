<?php 
class Mdl_rfid extends CI_Model{
    var $user;
    var $current_time;


    function __construct () {
        parent::__construct();
            
        $this->user_id      = $this->session->userdata('itms_user_id');
        $this->current_time = date("Y-m-d H:i:s");
    }


    function get_gps_vehicles ($company_id=null, $query=null) {

    	$device_ids = $this->db->query("SELECT group_concat(device_id) AS device_ids FROM itms_rfid_subjects WHERE status='in progress'");
    	$device_ids = $device_ids->row_array();
    	$device_ids = $device_ids['device_ids'];
    	$device_ids = explode(',', $device_ids);

    	$this->db->select('itms_last_gps_point.*, itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name');
        $this->db->from('itms_last_gps_point')
            ->join('itms_assets', 'itms_assets.device_id=itms_last_gps_point.device_id','left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id','left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');

        $this->db->where_in("itms_last_gps_point.device_id", $device_ids);
        
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

        
        if($query!=null && $query!="") {
            $this->db->like('itms_assets.assets_friendly_nm', $query, 'both');
            $this->db->or_like('itms_assets.assets_name', $query, 'both');
        }

        
        $query = $this->db->get();
       
         return $query->result();

        //print_r('<pre>');
        //print_r($query->result());
        //exit;
    }


    function fetch_grid_vehicles ($company_id=null) {

    	$device_ids = $this->db->query("SELECT group_concat(device_id) AS device_ids FROM itms_rfid_subjects WHERE status='in progress'");
    	$device_ids = $device_ids->row_array();
    	$device_ids = $device_ids['device_ids'];
    	$device_ids = explode(',', $device_ids);


    	$this->db->select('itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        (itms_personnel_master.fname + " " +itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name');
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id','left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');

        $this->db->where_in("itms_assets.device_id", $device_ids);
        
        if ($company_id!=null) {
            $this->db->where('itms_assets.company_id', $company_id);
        }

              
        $query = $this->db->get();
       
         return $query->result();




    }

    function fetch_raw_captures () {
    	$this->db->order_by('ID', 'DESC');
    	$query = $this->db->get('itms_rfid_parkcaptable');

    	return $query->result();

    }

    function get_gps_vehicle_data ($asset_id, $device_id) {
        $this->db->select('itms_assets.asset_id, itms_assets.assets_friendly_nm, itms_assets.assets_name, itms_assets.current_route, itms_assets.current_trip,itms_assets.full_image, itms_assets.plate_image,itms_personnel_master.personnel_id AS driver_id, 
                            concat(itms_personnel_master.fname, " " , itms_personnel_master.lname) AS driver_name,
                                itms_personnel_master.phone_no AS driver_phone, itms_trips.*,
                                    itms_owner_master.owner_id, itms_owner_master.owner_name, itms_last_gps_point.*');
        $this->db->from('itms_assets')
            ->join('itms_last_gps_point', 'itms_last_gps_point.device_id = itms_assets.device_id', 'left')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id','left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left')
            ->join('itms_trips', 'itms_trips.trip_id = itms_assets.current_trip', 'left');
        
        
        $this->db->where('itms_assets.asset_id', $asset_id);
        $query = $this->db->get();

        $res = array();
        
        $data = $query->row_array();
        $res['vehicle_info'] = $data;
        $trip_id = $data['current_trip']; 
        $route_id = $data['current_route'];
        $res['route_data']  = NULL;
        if ($route_id != NULL || $route_id != "") {
             $res['route_data'] = $this->get_route_by_id($route_id);
        }      
        $res['gps_hist'] = $this->get_current_trip_points($device_id, $trip_id);

        return $res;        
    }

    function get_current_trip_points($device_id, $trip_id) {
        $this->db->select('*');
        $this->db->from('itms_gps_track_points');
        $this->db->where('device_id', $device_id);
        $this->db->where('trip_id', $trip_id);

        $query = $this->db->get();

        return $query->result();
    }


    function get_route_by_id($route_id) {
        $this->db->select('*');
        $this->db->from('itms_routes');
        $this->db->where('route_id', $route_id);

        $query = $this->db->get();

        return $query->row_array();
    }

    public function get_available_devices($company_id=null, $user_id=null) {
    	//$query = $this->db->query("SELECT device_id FROM itms_rfid_subjects WHERE status='in progress'");
        $query = $this->db->query("SELECT device_id FROM itms_devices WHERE device_id NOT IN (SELECT device_id FROM itms_rfid_subjects WHERE status='in progress')");
        
        return $query->result();
    }

    function get_routes ($company_id=null) {
        if ($company_id!=null) {
           $this->db->where('company_id', $company_id); 
        }

        $this->db->select('route_id, route_name, route_color, duration, distance, start_address, end_address');
        $this->db->from('itms_routes');
        $query = $this->db->get();

        return $query->result();        
    }



    function get_map_display_routes ($company_id=null) {
        if ($company_id!=null) {
           $this->db->where('company_id', $company_id); 
        }

        $this->db->select('*');
        $this->db->from('itms_routes');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_trips ($company_id=null) {
        
        $this->db->select("itms_trips.*, itms_assets.assets_friendly_nm, itms_assets.assets_name, itms_assets.device_id,
            (itms_personnel_master.fname + ' ' +itms_personnel_master.lname) AS driver_name ,itms_personnel_master.phone_no AS driver_phone, itms_client_master.client_name as client");
        $this->db->from('itms_trips');
        $this->db->join('itms_assets', 'itms_assets.asset_id=itms_trips.asset_id');
        $this->db->join('itms_personnel_master', 'itms_personnel_master.personnel_id=itms_trips.driver_id', 'left');
        $this->db->join('itms_client_master', 'itms_client_master.client_id=itms_trips.client_id', 'left');

        if ($company_id!=null) {
           $this->db->where('itms_trips.company_id', $company_id); 
        }
        
        $this->db->order_by('itms_trips.trip_id', 'DESC');
        $query = $this->db->get();

        return $query->result();        
    }

    function get_landmarks ($company_id=null) {
            
        if ($company_id!=null) {
            $whereCompany = "AND company_id='".$company_id."'";
        }

        $q = "SELECT * 
                FROM itms_landmarks 
                WHERE 1
                AND status=1 
                    {$whereCompany}
                AND del_date is null ORDER BY landmark_name ASC ";

        $query = $this->db->query($q);
        return $query->result();
        
    }

    function get_landmark_by_id ($landmark_id=null) {
            
        if ($landmark_id!=null) {
            $wherelandmark= "AND landmark_id='".$landmark_id."'";
        }

        $q = "SELECT * 
                FROM itms_landmarks 
                WHERE 1
                AND status=1 
                    {$wherelandmark}
                AND del_date is null";

        $query = $this->db->query($q);
        return $query->row_array();
    }

    function delete_landmark($landmark_id){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql="UPDATE itms_landmarks SET del_date = '".$t."' WHERE landmark_id ='".$landmark_id."'";
        $this->db->query($sql);
    }


    function save_subject ($subj) {
    	$tracked = $this->db->get_where('itms_rfid_subjects', array('plate_number'=>$subj['plate_number'], 'status'=>'in progress'));

    	
    	if ($tracked->num_rows() > 0) {
    		return 'tracked';
    		exit;
    	}

    	$device_taken = $this->db->get_where('itms_rfid_subjects', array('device_id'=>$subj['device_id'], 'status'=>'in progress'));

    	if ($device_taken->num_rows() > 0) {
    		return 'taken';
    		exit;
    	}

    	$q = $this->db->insert('itms_rfid_subjects', $subj);
    	$subjid = $this->db->insert_id();

    	if ($q) {
    		$this->db->where('device_id', $subj['device_id']);
    		$this->db->update('itms_assets', array('device_id'=>NULL));

    		return $subjid;
    	} else {
    		return false;
    	}
	}

	function save_asset ($data) {
		$asset_exists = $this->check_asset($data['assets_name']);

		if ($asset_exists) {
			$this->db->where('assets_name',$data['assets_name']);
			$q = $this->db->update('itms_assets', $data);

	    	if ($q) {
	    		return $asset_exists;
	    	} else {
	    		return false;
	    	}
		} else {
			$q = $this->db->insert('itms_assets', $data);

	    	if ($q) {
	    		return $this->db->insert_id();
	    	} else {
	    		return false;
	    	}
		}
		
	}

	function check_asset($assets_name) {
		$q = $this->db->get_where('itms_assets', array('assets_name'=>$assets_name));

		if ($q) {
			$data = $q->row_array();
			return $data['asset_id'];
		} else {
			return false;
		}
	}


	function save_client ($data) {
		$q = $this->db->insert('itms_client_master', $data);

    	if ($q) {
    		return $this->db->insert_id();
    	} else {
    		return false;
    	}
	}

	function save_trip ($data) {
		$q = $this->db->insert('itms_trips', $data);

    	if ($q) {
    		return $this->db->insert_id();
    	} else {
    		return false;
    	}
	}

	function update_assets($data) {
		$this->db->where('asset_id', $data['asset_id']);
		$q = $this->db->update('itms_assets', $data);

    	if ($q) {
    		return true;
    	} else {
    		return false;
    	}
	}



    

    
}
?>