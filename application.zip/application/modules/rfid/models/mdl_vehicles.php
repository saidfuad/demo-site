<?php

class Mdl_vehicles extends CI_Model{

    function __construct () {
        parent::__construct();
    }

    function get_vehicles ($company_id=null) {
        $this->db->select('itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        CONCAT(itms_personnel_master.fname, " ", itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name');
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id', 'left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
            

        
        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('itms_assets.company_id', $this->session->userdata('itms_company_id'));
            $this->db->where('itms_assets.del_date IS NULL');
        }
        
        if ($this->session->userdata('protocal') < 7) {
            //$this->db->where('itms_assets.company_id', $this->session->userdata('itms_company_id'));

        }

        
        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();
    }


    function get_vehicle_by_id ($asset_id) {
        $this->db->select('itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.personnel_id AS driver_id, 
                                        CONCAT(itms_personnel_master.fname, " ", itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name');
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id','left')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id', 'left')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left');
        
        $this->db->where('asset_id', $asset_id);
       
        
        $this->db->order_by('assets_name', 'ASC');
        $query = $this->db->get();
       
        return $query->row_array();
    }

    function save_vehicle($data) {
        if ($this->check_vehicle_by_plate_number($data['assets_name'])) {
            return 77;
            exit;
        }

        $query = $this->db->insert('itms_assets', $data);

        if ($query) {
            $this->session->set_userdata('vehicle_image', '');
            return true;
        }
        
        return false;
        
    }

    function save_tyre_axle_config($data,$axle_pressure_conf) {
        $this->db->where('asset_id', $data['asset_id']);
        $query = $this->db->update('itms_assets', $data);

        if ($query) {
            $this->db->delete('itms_axle_pressure_config', array('asset_id'=>$data['asset_id']));
            $this->db->insert_batch('itms_axle_pressure_config', $axle_pressure_conf);
            return true;
        } else {
            return false;
        }
    }

    function update_vehicle($data) {
        $this->db->where('asset_id', $data['asset_id']);
        $this->db->update('itms_assets', $data);

        if ($query) {
            $this->session->set_userdata('vehicle_image', '');
            return true;
        }
        
        return false;
        
    }

    function delete_vehicle($asset_id){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql="UPDATE itms_assets SET del_date = '".$t."' WHERE asset_id ='".$asset_id."'";
        $this->db->query($sql);
    }

// model function to obtain landmark
    function get_landmarks () {

        $query = $this->db->get('itms_landmarks');

        return $query->result();        
    }
// end of model function to obtain landmarks
    function get_groups ($company_id=null) {
        if ($company_id != null) {
           $this->db->where('itms_vehicle_groups.company_id', $company_id);
        }
        $this->db->where('itms_vehicle_groups.del_date IS NULL');
        $query = $this->db->get('itms_vehicle_groups');

        return $query->result();        
    }

    function edit_groups($company_id=null){

        if ($this->session->userdata('protocal') <= 7) {
                $this->db->where('itms_vehicle_groups.company_id', $company_id);
           }
        $this->db->where('group_id', $this->uri->segment(3));
        $query = $this->db->get('itms_vehicle_groups');
       
        return $query->result();
    }
    function save_group ($data) {
        if ($this->check_vehicle_group_name ($data['group_name'])) {
            return 77;
            exit;
        }

        $query = $this->db->insert('itms_vehicle_groups', $data);

        if ($query) {
            return true;
        }
        
        return false;
        
    }

    function delete_group($group_id){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql="UPDATE itms_vehicle_groups SET del_date = '".$t."' WHERE group_id ='".$group_id."'";
        $this->db->query($sql);
    }
    function update_group_vehicle($data) {
        $this->db->where('group_id', $data['group_id']);
        $this->db->update('itms_vehicle_groups', $data);
    }
    function check_vehicle_group_name($group_name) {
        $query = $this->db->get_where('itms_vehicle_groups', array('group_name'=>$group_name));
        
        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }

    function check_vehicle_by_plate_number($plate_number) {
        $query = $this->db->get_where('itms_assets', array('assets_name'=>$plate_number));
        
        if ($query->num_rows() > 0) {
            return true;
        }

        return false;
    }
    
    
    function get_drivers () {
        $this->db->select('itms_personnel_master.*, itms_roles.role_name');
        $this->db->from('itms_personnel_master')
                ->join('itms_roles', 'itms_roles.role_id=itms_personnel_master.role_id')
                ->where('itms_roles.role_name', 'driver');

                if ($this->session->userdata('protocal') <= 7) {
                    $this->db->where('itms_personnel_master.company_id', $this->session->userdata('itms_company_id'));
                }

        $this->db->order_by('fname', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function get_owners () {
        $this->db->select('itms_owner_master.*');
        $this->db->from('itms_owner_master');
        $this->db->where('itms_owner_master.del_date IS NULL');
        
           if ($this->session->userdata('protocal') <= 7) {
                $this->db->where('itms_owner_master.company_id', $this->session->userdata('itms_company_id'));
           }

        $this->db->order_by('owner_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }
    function delete_owner ($owner_id) {
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql="UPDATE itms_owner_master SET del_date = '".$t."' WHERE owner_id ='".$owner_id."'";
        $this->db->query($sql);

    }

    function get_categories () {
        $this->db->select('itms_assets_categories.*');
        $this->db->from('itms_assets_categories');
           if ($this->session->userdata('protocal') <= 7) {
                $this->db->where('itms_assets_categories.company_id', $this->session->userdata('itms_company_id'));
           }
        $this->db->order_by('assets_cat_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function get_types () {
        $this->db->select('itms_assets_types.*');
        $this->db->from('itms_assets_types');
           if ($this->session->userdata('protocal') <= 7) {
                $this->db->where('itms_assets_types.company_id', $this->session->userdata('itms_company_id'));
           }

        $this->db->order_by('assets_type_nm', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }

    function get_vehicle ($company_id=null) {
        $this->db->select('itms_assets.*, itms_assets_categories.assets_category_id, itms_assets_categories.assets_cat_name,
                                itms_assets_categories.assets_cat_image, itms_assets_types.assets_type_id, 
                                    itms_assets_types.assets_type_nm, itms_personnel_master.phone_no, itms_personnel_master.personnel_id AS driver_id, 
                                        CONCAT(itms_personnel_master.fname, " ", itms_personnel_master.lname) AS driver_name,
                                            itms_owner_master.owner_id, itms_owner_master.owner_name, itms_devices.id, itms_devices.serial_no');
        $this->db->from('itms_assets')
            ->join('itms_assets_categories', 'itms_assets_categories.assets_category_id = itms_assets.assets_category_id')
            ->join('itms_assets_types', 'itms_assets_types.assets_type_id = itms_assets.assets_type_id')
            ->join('itms_personnel_master', 'itms_personnel_master.personnel_id = itms_assets.personnel_id', 'left')
            ->join('itms_owner_master', 'itms_owner_master.owner_id = itms_assets.owner_id', 'left')
            ->join('itms_devices', 'itms_devices.device_id = itms_assets.device_id', 'left');
        
        if ($this->session->userdata('protocal') <= 7 && $company_id!=null) {
            $this->db->where('asset_id', $this->uri->segment(3));
        }

        $query = $this->db->get();
       
        return $query->result();
    }

    public function getcategories($keyword) {   
        $this->db->select('itms_assets_categories.assets_cat_name,itms_assets_categories.assets_category_id'); 
        $this->db->from('itms_assets_categories');
        // $this->db->where('company_id', $this->session->userdata('itms_company_id'));
        $this->db->order_by('assets_category_id', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function gettype($company_id=nulls){
        $this->db->select('itms_assets_types.assets_type_id,itms_assets_types.assets_type_nm');
        $this->db->from('itms_assets_types');
        // $this->db->where('company_id', $this->session->userdata('itms_company_id'));
        $this->db->order_by('assets_type_nm', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getowner($company_id=nulls){
        $this->db->select('itms_owner_master.owner_name,itms_owner_master.owner_id');    
        $this->db->from('itms_owner_master'); 
        $this->db->where('company_id', $this->session->userdata('itms_company_id'));
        $this->db->order_by('owner_id', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getdriver($company_id=nulls){
        $this->db->select('CONCAT(itms_personnel_master.fname, " ", itms_personnel_master.lname) AS driver_name,itms_personnel_master.personnel_id');  
        $this->db->from('itms_personnel_master');
        $this->db->where('role_id', '2'); 
        $this->db->where('company_id', $this->session->userdata('itms_company_id'));
        $this->db->order_by('personnel_id', 'ASC');
        $query = $this->db->get();
        return sizeof(($query->result_array()))>0?$query->result_array():null;
    }

}
