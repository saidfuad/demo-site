<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Rfid extends CI_Controller {
    function __construct() {

        parent::__construct();
        
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
        
        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_userid') == "") {
           redirect('login');
        }

        $this->load->model('mdl_rfid');
        $this->load->model('mdl_landmarks');
        $this->load->model('mdl_user_settings');
        $this->load->model('mdl_gps_tracking');
        $this->load->model('mdl_settings');
        $this->load->model('mdl_routes');
        $this->load->model('mdl_personnel');
        $this->load->library('emailsend');
    }

    public function index () {
        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') !=0)
        {
            $map_center = sprintf( "%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $routesOpt = '';

        $routes = $this->mdl_rfid->get_routes($this->session->userdata('itms_company_id'));
        foreach ($routes as $route)
        {
            $routesOpt .= "<option value='".$route->route_id."'>".$route->route_name."</option>";
            // $deviceList .= "<li data-id='".$device->id."'><a href=''>".addslashes($device->device_id)."</a></li>";
        }

         $vehicleList = '';


        $vehicles = $this->mdl_rfid->fetch_grid_vehicles($this->session->userdata('itms_company_id'));
        
        if(count($vehicles)) {
            foreach ($vehicles as $vehicle) {
                $txt="";
                $txt = addslashes($vehicle->assets_name);
                if($vehicle->assets_friendly_nm!="")
                    $txt.="(".addslashes($vehicle->assets_friendly_nm).")";
                $vehicleNames[] =$txt;
                $vehicleList .= "<li asset-id='".$vehicle->asset_id."'>".$vehicle->assets_name.' - '.addslashes($vehicle->assets_friendly_nm)."</li>";
            }
        }


        $data['vehiclesList'] = $vehicleList;
        $data['map_lat'] = $map_lat;
        $data['routesOpt'] = $routesOpt;
        $data['map_long'] = $map_long;
        $data['content_url'] = 'rfid';
        $data['fa'] = 'fa fa-tags';
        $data['title'] = 'ITMS Africa | RFID Tagging';
        $data['content_title'] = 'RFID Tagging';
        $data['content_subtitle'] = 'RFID & Location Surveillance';
        $data['content'] = 'rfid.php';
       
        //exit;
       
        $this->load->view('main.php', $data);
    }


    public function refresh_grid () {

        $query = $this->input->post('query');

        
        $vehicles = $this->mdl_rfid->get_gps_vehicles ($this->session->userdata('itms_company_id'),  $query);

        $res = array('vehicles'=>$vehicles);

        echo json_encode($res);
    }

    public function get_raw_captures () {
        $res = $this->mdl_rfid->fetch_raw_captures ();

        echo json_encode($res);
    }

    public function get_grid_vehicles () {
        echo $this->mdl_rfid->fetch_grid_vehicles($this->session->userdata('itms_company_id'));
    }

    function get_vehicle_details () {
        $asset_id = $this->input->post('asset_id');
        $device_id = $this->input->post('device_id');

        $data = $this->mdl_rfid->get_gps_vehicle_data($asset_id, $device_id);

        /*print_r('<pre>');
        print_r($data);
        exit;
*/
        echo json_encode($data);
    }

    public function add_subject () {

        $subject =false;
        $asset_id = false;
        $client_id= false;
        $trip_id = false;
        $up = false;

        $data = $this->input->post();

        $timezone = $this->session->userdata('timezone') . ' hours';
        $today = gmdate('Y-m-d H:i:s'); 
        $date = gmdate('Y-m-d H:i:s', strtotime($timezone));
        
        $now = $date;
        $add_uid = $this->session->userdata('itms_userid');
        $company_id = $this->session->userdata('itms_company_id');

        $start = $this->mdl_rfid->get_landmark_by_id($data['start_id']);
        $end = $this->mdl_rfid->get_landmark_by_id($data['end_id']);

        //insert into subjects table
        $subj['company_id'] = $company_id;
        $subj['device_id'] = $data['device_id'];
        $subj['plate_number'] = $data['plate_number'];
        $subj['assets_name'] = $data['assets_name'];
        $subj['start_time']  = $now;
        $subj['add_uid'] = $add_uid;
        $subj['full_image'] = $data['full_image'];
        $subj['plate_image'] = $data['plate_image'];
        $subj['date_created'] = $now;

        $subject = $this->mdl_rfid->save_subject($subj);

        if ($subject == 'tracked') {
            echo 'tracked';
            exit;
        }

        if ($subject == 'taken') {
            echo 'taken';
            exit;
        }


        //insert/update into assets

        if ($subject > 0 && $subject !='tracked' && $subject!='taken') {
            
            $assts['assets_name'] = $data['assets_name'];
            $assts['add_uid'] = $add_uid;
            $assts['device_id'] = $data['device_id'];
            $assts['company_id'] = $company_id;
            $assts['full_image'] = $data['full_image'];
            $assts['plate_image'] = $data['plate_image'];
            

            $asset_id = $this->mdl_rfid->save_asset($assts);
        }

        //add client

        if ($asset_id) {
            $client['client_name'] = $this->session->userdata('first_name').' '.$this->session->userdata('last_name');
            $client['company_id'] = $company_id;
            $client['phone_no']= $this->session->userdata('mobile_number');
            $client['email'] = $this->session->userdata('email_address');
            $client['add_uid'] = $add_uid;

            $client_id = $this->mdl_rfid->save_client($client);
        }

        //create trip

        if ($client_id) {
            $trip['company_id'] = $company_id;
            $trip['trip_name'] = 'To Customs';
            $trip['asset_id'] = $asset_id;
            $trip['route_id'] = $data['route_id'];
            $trip['client_id'] = $client_id;
            $trip['start_time'] = $now;
            $trip['client_name'] = $this->session->userdata('first_name').' '.$this->session->userdata('last_name');
            $trip['pickup_address'] = $start['landmark_name'];
            $trip['pick_lat'] = $start['latitude'];
            $trip['pick_lng'] = $start['longitude'];
            $trip['start_address'] = $start['landmark_name'];
            $trip['start_lat'] = $start['latitude'];
            $trip['start_lng'] = $start['longitude'];
            $trip['destination_address'] = $end['landmark_name'];
            $trip['end_lat'] = $end['latitude'];
            $trip['end_lng'] = $end['longitude'];
            $trip['add_date'] = $now;
            
            $trip_id = $this->mdl_rfid->save_trip($trip);
        }
         
        //update assests

        if ($trip_id) {
            $asstsup['current_route'] = $data['route_id'];
            $asstsup['current_trip'] = $trip_id;
            $asstsup['asset_id'] =  $asset_id;


            $up = $this->mdl_rfid->update_assets($asstsup);
        }
        
        
        if ($up) {
            $up = true;
        }

        


           

        echo $up;
        
    }

    public function vehicles () {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
        
        // die(print_r($data));

        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        
        $data['content_url'] = 'rfid/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicles';
        $data['content_title'] = 'Vehicles';
        $data['content_subtitle'] = 'vehicles list, owners and status';
        $data['content'] = 'view_vehicles.php';
        $this->load->view('main.php', $data);
    }

    public function fetch_vehicles () {
        return $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
    }

      public function save_vehicle () {
        // $data = $this->input->post();
        $t = $this->input->post('assets_type_id');
        $c = $this->input->post('assets_category_id');
        $o = $this->input->post('owner_id');
        $p = $this->input->post('personnel_id');

        $name = explode(" ", "$p");
        $name1 = $name[0];
        $name2 = $name[1];

        $t1 = $this->db->query('SELECT assets_type_id FROM itms_assets_types WHERE assets_type_nm = "'.$t.'"');
        $t2 = $t1->result_array();
        $t3 = $t2[0]['assets_type_id'];

        $c1 = $this->db->query('SELECT assets_category_id FROM itms_assets_categories WHERE assets_cat_name = "'.$c.'"');
        $c2 = $c1->result_array();
        $c3 = $c2[0]['assets_category_id'];

        $o1 = $this->db->query('SELECT owner_id FROM itms_owner_master WHERE owner_name = "'.$o.'"');
        $o2 = $o1->result_array();
        $o3 = $o2[0]['owner_id'];

        $p1 = $this->db->query('SELECT personnel_id FROM itms_personnel_master WHERE fname = "'.$name1.'" AND lname = "'.$name2.'"');
        $p2 = $p1->result_array();
        $p3 = $p2[0]['personnel_id'];

        $data = array('asset_id' => $this->input->post('asset_id'),
                      'assets_friendly_nm' => $this->input->post('assets_friendly_nm'),
                      'assets_name' => $this->input->post('assets_name'),
                      'assets_type_id' => $t3,
                      'assets_category_id' => $c3, 
                      'owner_id' => $o3, 
                      'personnel_id' => $p3, 
                      'km_reading' => $this->input->post('km_reading'),
                      'max_fuel_liters' => $this->input->post('max_fuel_liters'), 
                      'max_speed_limit' => $this->input->post('max_speed_limit'));
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        echo $this->mdl_vehicles->save_vehicle($data);
    }

    public function landmarks () {
        
        $data['landmarks'] = $this->mdl_gps_tracking->get_landmarks($this->session->userdata('itms_company_id'));
        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['content_url'] = 'rfid/landmarks';
        $data['fa'] = 'fa fa-university';
        $data['title'] = 'ITMS Africa | Landmarks';
        $data['content_title'] = 'Landmarks';
        $data['content_subtitle'] = '';
        $data['content'] = 'landmarks.php';
        $this->load->view('main.php', $data);
    }

    public function routes() {
        $data['routes'] = $this->mdl_gps_tracking->get_routes($this->session->userdata('itms_company_id'));
        // var_dump($data);
        // die();
        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['content_url'] = 'rfid/routes';
        $data['fa'] = 'fa fa-road';
        $data['title'] = 'ITMS Africa | Routes';
        $data['content_title'] = 'Routes';
        $data['content_subtitle'] = '';
        $data['content'] = 'routes.php';
        $this->load->view('main.php', $data);
    }

    public function devices() {
        $data ['devices'] = $this->mdl_settings->get_devices($this->session->userdata('itms_company_id'));

        $data['content_btn'] = '<a href="' . site_url('settings/add_device') . '" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Device</a>';
        $data['content_url'] = 'rfid/add_device';
        $data['fa'] = 'fa fa-sitemap';
        $data['title'] = 'ITMS Africa | View Devices';
        $data['content_title'] = 'Devices';
        $data['content_subtitle'] = '';
        $data['content'] = 'devices.php';
        $this->load->view('main.php', $data);
    }

    function delete_device($id) {
        $this->mdl_settings->delete_device($id);
        header('location:' . base_url('index.php/rfid/devices'));
    }

    public function edit_device() {
        $data ['devices'] = $this->mdl_settings->get_device($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'rfid/edit_device';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Edit Device';
        $data['content_title'] = 'Edit Device';
        $data['content_subtitle'] = '';
        $data['content'] = 'edit_device.php';
        $this->load->view('main.php', $data);
    }

    function update_device() {
        $data = array('id' => $this->input->post('id'),
            'device_id' => $this->input->post('device_id'),
            'device_name' => $this->input->post('device_name'),
            'serial_no' => $this->input->post('phone_no'));

        $this->mdl_settings->update_device($data);
    }


    public function personnel () {

        $data['personnel'] = $this->get_personnel ();

        $data['content_btn']= '<a href="'.site_url('personnel/add_personnel').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Personnel</a>';    
        $data['content_url'] = 'rfid/personnel';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Personnel';
        $data['content_title'] = 'View Personnel';
        $data['content_subtitle'] = 'List of all personnel';
        $data['content'] = 'view_personnel.php';
        
        $this->load->view('main.php', $data);
    }

    public function add_personnel () {
        $rolesOpt = '';
        $rolesList = '';

        $roles = $this->mdl_personnel->get_all_roles();
        if(count($roles)) {
            foreach ($roles as $role) {
                if($role->role_id !=1) {
                    $rolesOpt .= "<option value='".$role->role_id."'>".addslashes($role->role_name)."</option>";
                    $rolesList .= "<li user-id='".$role->role_id."'><a href=''>".addslashes($role->role_name)."</a></li>";
                }
            }
        }

        $data['rolesOpt'] = $rolesOpt;

        $data['content_url'] = 'rfid/add_personnel';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Personnel';
        $data['content_title'] = 'Add Personnel';
        $data['content_subtitle'] = '';
        $data['content'] = 'add_personnel.php';
        $this->load->view('main.php', $data);
    }

    
    public function v_personnel () {
        
        $rolesOpt = '';
        $rolesList = '';

        $roles = $this->mdl_personnel->get_all_roles();
        if(count($roles)) {
            foreach ($roles as $role) {
                $rolesOpt .= "<option value='".$role->role_id."'>".addslashes($role->role_name)."</option>";
                $rolesList .= "<li assets-category-id='".$role->role_id."'><a href=''>".addslashes($role->role_name)."</a></li>";
            }
        }

        $data['rolesOpt'] = $rolesOpt;
       
        $data ['personnel'] = $this->mdl_personnel->edit_personnel($this->session->userdata('itms_company_id'));
    
        $data['content_btn']= '<a href="'.site_url('personnel/add_personnel').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Personnel</a>';  
        $data['content_url'] = 'rfid/personnel';
        $data['fa'] = 'fa fa-user';
        $data['title'] = 'ITMS Africa | Personnel';
        $data['content_title'] = 'View Personnel';
        $data['content_subtitle'] = 'Shows Personnel Details';
        $data['content'] = 'v_personnel.php';
        
        $this->load->view('main.php', $data);
    }

    public function save_personnel () {
        $data = $this->input->post();
        
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['thumbnail'] = ($this->session->userdata('personnel_pic') != '') ? $this->session->userdata('personnel_pic') :'personnel-default.png';

        // var_dump($data);

        echo $this->mdl_personnel->save_personnel($data);
    }

   public function edit_personnel () {
    $rolesOpt = '';
        $rolesList = '';

        $roles = $this->mdl_personnel->get_all_roles();
        if(count($roles)) {
            foreach ($roles as $role) {
                if($role->role_id !=1) {
                    $rolesOpt .= "<option value='".$role->role_id."'>".addslashes($role->role_name)."</option>";
                    $rolesList .= "<li user-id='".$role->role_id."'><a href=''>".addslashes($role->role_name)."</a></li>";
                }
                // $rolesOpt .= "<option value='".$role->role_id."'>".addslashes($role->role_name)."</option>";
                // $rolesList .= "<li assets-category-id='".$role->role_id."'><a href=''>".addslashes($role->role_name)."</a></li>";
            }
        }

        $data['rolesOpt'] = $rolesOpt;
        
    $data ['personnel'] = $this->mdl_personnel->edit_personnel($this->session->userdata('itms_company_id'));
    $data['content_url'] = 'rfid/edit_personnel';
    $data['fa'] = 'fa fa-pencil';
    $data['title'] = 'ITMS Africa | Edit Personnel';
    $data['content_title'] = 'Edit Personnel';
    $data['content_subtitle'] = '';
    $data['content'] = '/edit_personnel.php';
    $this->load->view('main/main.php', $data);
    }

    function update_personnel(){
        $data = array('personnel_id' => $this->input->post('personnel_id'),
                      'role_id' => $this->input->post('role_id'), 
                      'id_no' => $this->input->post('id_no'),
                      'fname' => $this->input->post('fname'),
                      'lname' => $this->input->post('lname'), 
                      'gender' => $this->input->post('gender'),
                      'phone_no' => $this->input->post('phone_no'),
                      'email' => $this->input->post('email'), 
                      'address' => $this->input->post('address'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['thumbnail'] = ($this->session->userdata('personnel_pic') != '') ? $this->session->userdata('personnel_pic') :'personnel-default.png';
        
        $this->mdl_personnel->update_personnel($data);
    }

    public function add_user () {
        
        $data['content_url'] = 'rfid/add_user';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add User';
        $data['content_title'] = 'Add User';
        $data['content_subtitle'] = 'Create users to access and manage the system';
        $data['content'] = 'add_user.php';
        $this->load->view('main.php', $data);
    }

    public function save_user () {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['username'] = $data['first_name'] .'.'.$data['last_name'];
        $name = $data['first_name'] .' '.$data['last_name'];
        $data['mobile_number'] = $data['phone_number'];
        $pass = uniqid();
        $data['password'] = $this->encrypt->encode($pass);
        $data['user_logo'] = ($this->session->userdata('personnel_pic') != '') ? $this->session->userdata('personnel_pic') :'user.png';

        $res =  $this->mdl_personnel->save_user($data);

        if (is_numeric($res) && $res > 0) {
            $recipient = array($data['phone_number']);
            $username = $data['username'];
            $link = base_url();
            $message = "Use this link to login to you ITMS account 
                        $link . 
                        Username : $username and Password : $pass";
            $response = $this->smssend->send_text_message ($recipient, $message);
        }

        echo $res;
    }


    public function get_personnel () {
        $user_id = ($this->input->get('add_uid') != "") ? $this->input->get('add_uid') : null;
        $role_id = ($this->input->get('role_id') != "") ? $this->input->get('role_id') : null;
        $company_id = $this->session->userdata('itms_company_id');
        
        $personnel = $this->mdl_personnel->get_personnel($company_id, $user_id, $role_id);

        return $personnel;
    }

    function delete_personnel($personnel_id){
        $this->mdl_personnel->delete_personnel($personnel_id);
        header('location:'.base_url('index.php/rfid/personnel'));
    }


    public function create_personnel () {
       
        $data['content_url'] = 'rfid/create_personnel';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Create Personnel';
        $data['content_title'] = 'Create Personnel';
        $data['content_subtitle'] = 'Add new personnel';
        $data['content'] = 'create_personnel.php';
        
        $this->load->view('main.php', $data);
    }


    public function create_landmarks() {

        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }



        $rows = $this->mdl_landmarks->getIconPaths();
        $images = '';

        foreach ($rows as $row) {
            $images .= '<li title="' . base_url() . $row->image_path . '" value="' . $row->image_path . '">
                            <img src="' . base_url() . $row->image_path . '" alt="landmark image" />
                        </li>';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;

        $data['landmark_images'] = $images;
        $data['content_url'] = 'rfid/create_landmarks';
        $data['fa'] = 'fa fa-map-marker';
        $data['title'] = 'ITMS Africa | Create Landmarks';
        $data['content_title'] = 'Create Landmarks';
        $data['content_subtitle'] = 'Define custom landmarks';
        $data['content'] = 'create_landmarks.php';

        $this->load->view('main.php', $data);
    }

    public function save_landmark() {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');


        //echo json_encode($data);
        echo $this->mdl_landmarks->save_landmark($data);
    }


    public function create_routes() {
        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;


        $data['content_url'] = 'rfid/create_routes';
        $data['fa'] = 'fa fa-map-marker';
        $data['title'] = 'ITMS Africa | Create Routes';
        $data['content_title'] = 'Create Routes';
        $data['content_subtitle'] = 'Define custom routes';
        $data['content'] = 'create_routes.php';

        $this->load->view('main.php', $data);
    }

    public function save_route () {
        $posts = $this->input->post();
        $data = array();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['add_date'] = date('Y-m-d H:i:s');

        //str_replace("\\", "", $posts['data']);

        $json = json_decode($posts['data'], true);
        $start_latlng = json_decode($json['start_latlng'], true);
        $end_latlng   = json_decode($json['end_latlng'], true);
        //print_r('<pre>');
        //print_r($json);


        $data['route_name'] = $posts['route_name'];
        $data['route_color'] = $posts['route_color'];
        $data['start_address'] = $json['start_address'];
        $data['start_lat'] = $start_latlng['lat'];
        $data['start_lng'] = $start_latlng['lng'];
        $data['end_address'] = $json['end_address'];
        $data['end_lat'] = $end_latlng['lat'];
        $data['end_lng'] = $end_latlng['lng'];
        $data['distance'] = $json['distance'];
        $data['distance_value'] = $json['distance_value'];
        $data['duration'] = $json['duration'];
        $data['duration_value'] = $json['duration_value'];
        $data['raw_route'] = $posts['raw_route'];
        //$data['route_path'] = json_encode($json['route_path']);
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['add_date'] = date('Y-m-d H:i:s');

        $route_id = $this->mdl_routes->save_route($data);

        if ($route_id) {
            $waypoints = array();
            foreach ($json['picked_points'] as $k=>$waypoint) {
                $wp = array();
                 $latlng = json_decode($waypoint, true);
                 $wp['route_id'] = $route_id;
                 $wp['company_id'] = $data['company_id'];
                 $wp['latitude'] = $latlng['lat'];
                 $wp['longitude'] = $latlng['lng'];

                 array_push($waypoints, $wp);

            }


            $waypoints_saved = $this->mdl_routes->save_waypoints($waypoints);

            if ($waypoints_saved) {
                $wpt = $this->mdl_routes->set_route_waypoints($route_id);
            }

            $routepoints = array();
            foreach ($json['route_path'] as $k=>$routepoint) {
                $wp = array();
                 $latlng = json_decode($routepoint, true);
                 $wp['route_id'] = $route_id;
                 $wp['company_id'] = $data['company_id'];
                 $wp['latitude'] = $latlng['lat'];
                 $wp['longitude'] = $latlng['lng'];

                 array_push($routepoints, $wp);
            }

            $rpoints_saved = $this->mdl_routes->save_routepoints($routepoints);

            if ($rpoints_saved) {
                $wpt = $this->mdl_routes->set_route_points($route_id);
            }

            $res = true;

        } else {
            $res =false;
        }

        //echo json_encode($data);
        echo $res;
    }

    public function add_device() {
        $data['content_url'] = 'rfid/add_device';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Device';
        $data['content_title'] = 'Add Device';
        $data['content_subtitle'] = '';
        $data['content'] = 'add_device.php';
        $this->load->view('main.php', $data);
    }

    public function save_device() {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');

        echo $this->mdl_settings->save_device($data);
    }

    public function gps_devices_integration () {
        $deviceOpt = '';
        $deviceList = '';    
        $vehicleOpt = '';
        $vehicleList = '';

        $devices = $this->mdl_gps_tracking->get_device($this->session->userdata('itms_company_id'), $role_id=2, $user_id=null);
        foreach ($devices as $device)
        {
            $deviceOpt .= "<option value='".$device->id."'>".$device->device_id."</option>";
            // $deviceList .= "<li data-id='".$device->id."'><a href=''>".addslashes($device->device_id)."</a></li>";
        }

        $vehicles = $this->mdl_gps_tracking->get_vehicle($this->session->userdata('itms_company_id'), $role_id=2, $user_id=null);
        foreach ($vehicles as $vehicle)
        {
            $vehicleOpt .= "<option value='".$vehicle->asset_id."'>".$vehicle->assets_name."</option>";
            // $vehicleList .= "<li data-id='".$vehicle->asset_id."'><a href=''>".addslashes($vehicle->assets_name)."</a></li>";
        }

        //$this->mdl_userprofile->get_user_menu_permissions();
        $data['deviceOpt'] = $deviceOpt;
        $data['vehicleOpt'] = $vehicleOpt;
        $data['content_url'] = 'rfid/gps_devices_integration';
        $data['fa'] = 'fa fa-university';
        $data['title'] = 'ITMS Africa | GPS Devices Integration';
        $data['content_title'] = 'GPS Devices Integration';
        $data['content_subtitle'] = '';
        $data['content'] = 'gps_devices_integration.php';
        $this->load->view('main.php', $data);
    }

    public function integrate(){
        $dev = $this->input->post('device_id');
        $veh = $this->input->post('asset_id');

        $device = $this->db->query('SELECT device_id FROM itms_devices WHERE id = "'.$dev.'"');
        $devi = $device->result_array();
        $dei = $devi[0]["device_id"];

        $this->db->query('UPDATE itms_assets SET device_id = "'.$dei.'" WHERE asset_id = "'.$veh.'"');

        $this->db->query('UPDATE itms_devices SET assigned = 1 WHERE id = "'.$dev.'"');
    }


    public function user_permissions() {

        $data ['users'] = $this->mdl_user_settings->get_user_permissions();

        $data['content_url'] = 'rfid/user_permissions';
        $data['fa'] = 'fa fa-lock';
        $data['title'] = 'ITMS Africa | User Permissions';
        $data['content_title'] = 'User Permissions';
        $data['content_subtitle'] = 'Assigned access priveledges';
        $data['content'] = 'user_permissions.php';

        $this->load->view('main.php', $data);
    }

    public function edit_permissions($user_id) {

        $data ['user'] = $this->mdl_user_settings->get_user_permissions_details($user_id);
        $data ['menus'] = $this->mdl_user_settings->get_menus();
        $data ['reports'] = $this->mdl_user_settings->get_reports();
        $data ['groups'] = $this->mdl_user_settings->get_vehicle_groups();

        $data['content_url'] = 'rfid/edit_permissions';
        $data['fa'] = 'fa fa-lock';
        $data['title'] = 'ITMS Africa | Edit Permissions';
        $data['content_title'] = 'Edit Permissions';
        $data['content_subtitle'] = 'Assign access priveledges';
        $data['content'] = 'edit_permissions.php';

        $this->load->view('main.php', $data);
    }

    public function set_menu_permissions() {

        $menu_ids = $this->input->post('menu_ids');
        $menu_ids = explode(',', $menu_ids);
        $user_id = $this->input->post('user_id');
        $md_array = array();

        $date = date('Y-m-d H:i:s');

        foreach ($menu_ids as $key => $value) {
            $arr = array();
            $arr['user_id'] = $user_id;
            $arr['menu_id'] = $value;
            $arr['company_id'] = $this->session->userdata('itms_company_id');
            $arr['date_created'] = $date;

            array_push($md_array, $arr);
        }


        echo $this->mdl_user_settings->save_menu_permissions($user_id, $md_array);
    }

    public function set_alert_permissions() {

        $data['sms_alert'] = $this->input->post('sms_alert');
        $data['email_alert'] = $this->input->post('email_alert');
        $data['user_id'] = $this->input->post('user_id');

        echo $this->mdl_user_settings->save_alert_permissions($data);
    }

    public function set_group_permissions() {

        $group_ids = $this->input->post('group_ids');
        $group_ids = explode(',', $group_ids);
        $user_id = $this->input->post('user_id');
        $md_array = array();

        $date = date('Y-m-d H:i:s');

        foreach ($group_ids as $key => $value) {
            $arr = array();
            $arr['user_id'] = $user_id;
            $arr['assets_group_id'] = $value;
            $arr['company_id'] = $this->session->userdata('itms_company_id');
            $arr['date_created'] = $date;

            array_push($md_array, $arr);
        }


        echo $this->mdl_user_settings->save_group_permissions($user_id, $md_array);
    }

    public function set_report_permissions() {

        $report_ids = $this->input->post('report_ids');
        $report_ids = explode(',', $report_ids);
        $user_id = $this->input->post('user_id');
        $md_array = array();

        $date = date('Y-m-d H:i:s');

        foreach ($report_ids as $key => $value) {
            $arr = array();
            $arr['user_id'] = $user_id;
            $arr['report_id'] = $value;
            $arr['company_id'] = $this->session->userdata('itms_company_id');
            $arr['date_created'] = $date;

            array_push($md_array, $arr);
        }


        echo $this->mdl_user_settings->save_report_permissions($user_id, $md_array);
    }

    function send_email () {
        $to =array('makaweys@gmail.com');
        $subj = 'test';
        $message = "ITMS Registration Successful. \n\n
                                Username : email \nPassword : pass";

        $this->emailsend->send_email_message ($to, $subj, $message);
    }
}
?>