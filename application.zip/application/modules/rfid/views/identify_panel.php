<?php

$this->load->model('mdl_rfid');

$raw = $this->mdl_rfid->fetch_raw_captures ();


$devices = $this->mdl_rfid->get_available_devices($this->session->userdata('itms_company_id'));
foreach ($devices as $device)
{
    $deviceOpt .= "<option value='".$device->device_id."'>".$device->device_id."</option>";
    // $deviceList .= "<li data-id='".$device->id."'><a href=''>".addslashes($device->device_id)."</a></li>";
}

$landmarks = $this->mdl_rfid->get_landmarks($this->session->userdata('itms_company_id'));
foreach ($landmarks as $landmark)
{
    $landmarksOpt .= "<option value='".$landmark->landmark_id."'>".$landmark->landmark_name."</option>";
    // $deviceList .= "<li data-id='".$device->id."'><a href=''>".addslashes($device->device_id)."</a></li>";
}



?>
<style type="text/css">
    #full-image-area {
        height:300px;
    }

    #full-image-area img{
        height:250px;
        width:100% !important;
        border-radius:10px 10px 0 0     ;
    }

    #plate-area {
        height:60px;
    }

    #plate-area img{
        height:60px;
        
    }

</style>
<div class="panel-diagnostics" id="identify-panel">
    <div class="panel-heading">
        <span><i class="fa fa-eye"></i>&nbsp; Identify</span>
         <i style="margin-left:20%; color:#18bc9c;">Select a record to view</i>
        <span class="close cx"><b>&times;</b></span>
    </div>
    <!--Reports Panel-->
    <div class="controls-area">
        
    </div>
    <div class="panel-body" style="padding-top:10px;">
        <div class="col-md-6">
            <style>
                    /*
Force table width to 100%
                    */
                    table.table-fixedheader {
                        width: 100%;   
                    }
                    /*
                    Set table elements to block mode.  (Normally they are inline).
                    This allows a responsive table, such as one where columns can be stacked
                    if the display is narrow.
                    */
                    table.table-fixedheader, table.table-fixedheader>thead, table.table-fixedheader>tbody, table.table-fixedheader>thead>tr, table.table-fixedheader>tbody>tr, table.table-fixedheader>thead>tr>th, table.table-fixedheader>tbody>td {
                        display: block;
                    }
                    table.table-fixedheader>thead>tr:after, table.table-fixedheader>tbody>tr:after {
                        content:' ';
                        display: block;
                        visibility: hidden;
                        clear: both;
                    }
                    /*
                    When scrolling the table, actually it is only the tbody portion of the
                    table that scrolls (not the entire table: we want the thead to remain
                    fixed).  We must specify an explicit height for the tbody.  We include
                    100px as a default, but it can be overridden elsewhere.
                    
                    Also, we force the scrollbar to always be displayed so that the usable
                    width for the table contents doesn't change (such as becoming narrower
                    when a scrollbar is visible and wider when it is not).
                    */
                    table.table-fixedheader>tbody {
                        overflow-y: scroll;
                        height: 150px;
                        cursor: pointer;

                    }
                    /*
                    We really don't want to scroll the thead contents, but we want to force
                    a scrollbar to be displayed anyway so that the usable width of the thead
                    will exactly match the tbody.
                    */
                    table.table-fixedheader>thead {
                        overflow-y: scroll;    
                    }
                    /*
                    For browsers that support it (webkit), we set the background color of
                    the unneeded scrollbar in the thead to make it invisible.  (Setting
                    visiblity: hidden defeats the purpose, as this alters the usable width
                    of the thead.)
                    */
                    table.table-fixedheader>thead::-webkit-scrollbar {
                        background-color: inherit;
                    }


                    table.table-fixedheader>thead>tr>th:after, table.table-fixedheader>tbody>tr>td:after {
                        content:' ';
                        display: table-cell;
                        visibility: hidden;
                        clear: both;
                    }

                    /*
                    We want to set <th> and <td> elements to float left.
                    We also must explicitly set the width for each column (both for the <th>
                    and the <td>).  We set to 20% here a default placeholder, but it can be
                    overridden elsewhere.
                    */

                    table.table-fixedheader>thead tr th, table.table-fixedheader>tbody tr td {
                        float: left; 
                        width:45%;
                    }

                    table.table-fixedheader>thead tr th:first-child, table.table-fixedheader>tbody tr td:first-child {
                        width:10%;
                    }

                </style>
                <div class="tb-capture" style="border-bottom: 4px solid #f5f5f5;">
                <?php if(sizeof($raw)) { ?> 
                    <table class="table table-striped table-hover table-fixedheader" style="border-bottom:1px solid #eee;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Plate Number</th>
                                <th>Time Captured</th>
                            </tr>
                        </thead>
                        <tbody id="table-body">
                            <?php 
                                $count = 1;
                            foreach ($raw as $key => $value) { ?>
                                <tr class="row-capture">
                                    <td><?php echo $count; ?></td>
                                    <td class="plate-text"><?php echo $value->PLATE_TEXT; ?></td>
                                    <td>
                                        <?php echo $value->CAP_TIME; ?>
                                        <input type="hidden" class="full-image-holder" value="<?php echo $value->FULL_IMAGE; ?>" />
                                        <input type="hidden" class="plate-image-holder" value="<?php echo $value->PLATE_IMAGE; ?>" />
                                    </td>
                                </tr>
                               
                            <?php 
                                $count++;
                            } ?>
                            
                        </tbody>
                    </table> 
                <?php } else { ?>
                    <div class="alert alert-info">No Data Captured</div>   
                <?php } ?>
                </div> 
                <form id="add-asset-form" style="margin-top: 20px">
                    <div class="form-group">
                        <label for="reservation">Plate Number:</label>
                        <input class="form-control" type="text" name="assets_name" id="assets-name" required="required"/>
                        <input class="form-control" type="hidden" name="plate_number" id="plate-number"/>
                    </div>
                    <div class="form-group" id="device">
                        <label for="reservation">Available GPS Devices:</label>
                        <select class="form-control" type="text" name="device_id" id="device-id" required="required">
                            <option value="0">--Select--</option>
                            <?php echo $deviceOpt; ?>
                        </select>

                        <input class="form-control" type="hidden" name="full_image" id="full-image"/>
                        <input class="form-control" type="hidden" name="plate_image" id="plate-image"/>
                    </div> 
                    <div class="form-group" id="device">
                        <label for="reservation">Route:</label>
                        <select class="form-control" type="text" name="route_id" id="route-id" required="required">
                            <option value="0">--Select--</option>
                            <?php echo $routesOpt; ?>
                        </select>

                    </div> 
                    
                </form>
                    


            
        </div>
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-12" style="border:5px solid #f5f5f5;border-radius:10px;margin-bottom:10px;">
                   <div class="row">
                        <div class="col-md-12">
                            <div class="row" id="full-image-area">
                                
                            </div>

                        </div> 
                        <div class="col-md-12" id="plate-area" style="border-top:5px solid #f5f5f5;border-radius:10px;background: #eee;text-align:center;">

                        </div> 
                    </div>
                             
                </div>
                <div class="form-group col-md-6" id="device">
                    <label for="reservation">Start Location:</label>
                    <select class="form-control" type="text" name="start_id" id="start-id" required="required">
                        <option value="0">--Select--</option>
                        <?php echo $landmarksOpt; ?>
                    </select>

                </div> 
                <div class="form-group col-md-6" id="device">
                    <label for="reservation">Destination:</label>
                    <select class="form-control" type="text" name="end_id" id="end-id" required="required">
                        <option value="0">--Select--</option>
                        <?php echo $landmarksOpt; ?>
                    </select>

                </div>
            </div>
        </div>
    </div>
    <div class="panel-footer" align="right">
        <div class="row">
            <div class='col-md-8'></div>
            <div class='col-md-2'>
                <button class="btn btn-default btn-block" id="btn-close-dialog">Cancel</button>
            </div>
            <div class='col-md-2'>
                <button class="btn btn-primary btn-block" id="add-subject">Save <i class="fa fa-floppy-o"></i></button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('.tb-capture').on('click', 'tr', function() {
            //alert();
            var plate_text = $(this).children(".plate-text").html();
            var full_image =  $(this).find(".full-image-holder").val();
            var full_image_path = "<?php echo base_url()?>" + full_image;
            var plate_image =  $(this).find(".plate-image-holder").val();
            var plate_image_path = "<?php echo base_url()?>" + plate_image;

            $('#add-asset-form').find('#assets-name').val(plate_text);
            $('#add-asset-form').find('#plate-number').val(plate_text);
            $('#add-asset-form').find('#full-image').val(full_image);
            $('#add-asset-form').find('#plate-image').val(plate_image);
            $('#full-image-area').html("<img src='"+full_image_path+"' class=''/>");
            $('#plate-area').html("<img src='"+plate_image_path+"' />");
            //alert(plate_image);
        });


         $('#add-subject').on('click' , function () {

                //var $this = $(this);

                var plate_number = $('#assets-name').val();
                var assets_name = $('#assets-name').val();
                var full_image = $('#full-image').val();
                var plate_image = $('#plate-image').val();
                var device_id = $('#device-id').val();
                var route_id = $('#route-id').val();
                var start_id = $('#start-id').val();
                var end_id = $('#end-id').val();






                if (plate_number.length == 0 || full_image.length == 0 || plate_image.length ==0) {
                    swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
                    return false;
                }

                if (device_id ==0) {
                    alert(device_id);
                    swal({   title: "Info",   text: "Select a tracking device",   type: "info",   confirmButtonText: "ok" });
                    return false;
                }

                if (route_id ==0) {
                    swal({   title: "Info",   text: "Select route",   type: "info",   confirmButtonText: "ok" });
                    return false;
                }

                if (start_id ==0) {
                    swal({   title: "Info",   text: "Select start location",   type: "info",   confirmButtonText: "ok" });
                    return false;
                }

                if (end_id==0) {
                    swal({   title: "Info",   text: "Select destination",   type: "info",   confirmButtonText: "ok" });
                    return false;
                }

               
                swal({   
                    title: "Info",   
                    text: "Add Vehicle to Surveillance",   
                    type: "info",   
                    showCancelButton: true,   
                    closeOnConfirm: false, 
                    allowOutsideClick: false,  
                    showLoaderOnConfirm: true                            
                    }, function(){
                    $.ajax({
                        method: 'post',
                        url: '<?= base_url('index.php/rfid/add_subject') ?>',
                        data: {plate_number:plate_number, assets_name:assets_name, full_image:full_image, plate_image:plate_image, device_id:device_id, route_id:route_id, start_id:start_id, end_id:end_id},
                        success: function (response) {
                            alert(response);
                            if (response == 'tracked') {
                                swal({ title: "Info",   text: "This vehicle is already under surveillance",   type: "info",   confirmButtonText: "ok" });
                            } else if (response == 'taken') {
                                swal({ title: "Info",   text: "The device is in use in the moment pick another device",   type: "info",   confirmButtonText: "ok" });
                            } else if (response==1) {
                                $('#add-asset-form').find('input[type="text"]').val('');
                                $('#add-asset-form').find('select').val(0);
                                $('#start-id').val(0);
                                $('#end-id').val(0);

                                swal({   title: "Info",   text: "Vehicle added on the radar successfully",   type: "success",   confirmButtonText: "ok" });
                            } else {
                                swal({   title: "Error",   text: "Something went wrong",   type: "error",   confirmButtonText: "ok" });
                            }

                            
                         }
                    });
                });

                return false;     
            });


         $('#identify').on('click', function() {
                $('#identify-panel').fadeIn(1000);
                $('.overshadow').fadeIn(1000);

                refresh_camera_data();

                //return false; 

            });

            function refresh_camera_data () {

                $('#table-body').html("<div class='col-md-12' style='text-align:center;margin-top:50px;'><i class='fa fa-spinner fa-spin fa-4x'></i></div>");
                //return false;
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/rfid/get_raw_captures') ?>',
                    data: {data:'refresh'},
                    success: function (response) {
                        //alert(response);
                        response = JSON.parse(response);

                        if (response.length) {
                            count = 1;
                            $('#table-body').html("");
                            for (var row in response) {


                                $('#table-body').append("<tr>" + 
                                                            "<td>"+count+"</td>"+
                                                            "<td class='plate-text'>"+response[row].PLATE_TEXT+"</td>"+
                                                            "<td>"+response[row].CAP_TIME+"</td>"+
                                                            "<input type='hidden' class='full-image-holder' value='"+response[row].FULL_IMAGE+"' /><input type='hidden' class='plate-image-holder' value='"+response[row].PLATE_IMAGE+"'/>"+
                                                        "</tr>");
                                count++;
                            }
                        } else {
                            $('#table-body').html("<div class='alert alert-info'>No data</div>");
                        }
                     }
                });

                return false;
            }
                   
    });
</script>