<div class="container-fluid fleet-view">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($landmarks)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Landmark Name</th>
                                <th>Address</th>
                                <th>Radius</th>
                                <th>Action</th>
                            </tr>

                        </thead>
                        <tbody>
                        <?php 
                        $count = 1;
                        foreach ($landmarks as $key => $value) { ?>
                           <tr class="gradeU">
                                <td><?php echo $count; ?></td>
                                <td><?php echo $value->landmark_name; ?></td>
                                <td><?php echo $value->address; ?></td>
                                <td><?php echo $value->radius .' '.$value->distance_unit; ?></td>
                                <td><?php echo "<a href='".base_url('index.php/gps_tracking/delete_landmark/'.$value->landmark_id)
                                            ."'class='btn btn-danger btn-xs' id='del'><span class='fa fa-trash'onclick='onclick='javascript:return confirm(\"Are you sure you want to delete?\")''></span></a>
                                                <a href='".base_url('index.php/gps_tracking/fetch_landmark/'.$value->landmark_id)
                                                ."'class='btn btn-info btn-xs'><span class='fa fa-eye'></span></a>
                                                <a href='".base_url('index.php/gps_tracking/edit_landmark/'.$value->landmark_id)
                                                ."'class='btn btn-success btn-xs'><span class='fa fa-pencil'></span></a>"?></td>
                            </tr>
                        <?php $count++;}?>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <!-- <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Vehicles</h2>
                    <br>
                    <p>Manage Vehicles and begin monitoring your assets Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

                    <a href="<?php echo site_url('vehicles/add_vehicle');?>" class="btn btn-success">Add Vehicles</a> 
                </div> -->
            <?php } ?>

            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>
