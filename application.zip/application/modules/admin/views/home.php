<div class="container-fluid">
    <div class="row fleet-content">
    	<div class="col-lg-6">
            <div class="row">
                <!-- Service Reminders -->
                <div class="col-md-6">
                    <div class="panel panel-square">
                        <div class="panel-heading panel-info clearfix">
                            <h3 class="panel-title">Companies</h3>
                        </div>
                        <div class="panel-body fleet-issues">
                            <div class="row">
                                
                                <!-- Active -->
                                <?php if($count_active_companies > 0) { ?>
                                <a href="admin/view_companies">
                                    <div class="col-sm-6 text-center">
                                        <h1 class="success"><?php if (isset($count_active_companies)) { echo $count_active_companies;}?></h1>
                                        <span class="caption">Active</span>
                                    </div>
                                </a>
                                <?php }else{ ?>
                                <div class="col-sm-6 text-center">
                                    <h1 class="success"><?php if (isset($count_active_companies)) { echo $count_active_companies;}?></h1>
                                    <span class="caption">Active</span>
                                </div>
                                <?php } ?>
                                
                                <!-- Inactive -->
                                <?php if($count_inactive_companies > 0) { ?>
                                <a href="admin/view_companies">
                                    <div class="col-sm-6 text-center">
                                        <h1 class="success"><?php if (isset($count_inactive_companies)) { echo $count_inactive_companies;}?></h1>
                                        <span class="caption">Inactive</span>
                                    </div>
                                </a>
                                <?php }else{ ?>
                                <div class="col-sm-6 text-center">
                                    <h1 class="success"><?php if (isset($count_inactive_companies)) { echo $count_inactive_companies;}?></h1>
                                    <span class="caption">Inactive</span>
                                </div>
                                <?php } ?>
                                
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Renewal Reminders -->
                <div class="col-md-6">
                    <div class="panel panel-square">
                        <div class="panel-heading panel-info clearfix">
                            <h3 class="panel-title">Services</h3>
                        </div>
                        <div class="panel-body fleet-issues">
                            <div class="row">
                                <a href="admin/view_services">
                                    <div class="col-sm-12 text-center">
                                        <h1 class="success"><?php if (isset($count_services)) { echo $count_services;}?></h1>
                                        <span class="caption">Subscription Services</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

                    <div class="row">
                <!--<div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Services Subscriptions
                        </div>
                        <!-- /.panel-heading
                        <div class="panel-body">
                            <div id="service-costs"></div>
                        </div>
                    </div>
                    <!-- /.panel 
                </div>-->
                <!-- /.col-lg-12 -->
                
                <div class="col-lg-12">
                <div class="panel panel-default">
                <div class="panel-heading padding padding-all">
                    Companies
                </div>
                <!-- /.panel-heading -->

                <div class="panel-body">
                     <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Company</th>
                                    <th>Status</th>
                                    <th>Subscribed services</th>
                                    <th>View</th>                                                                
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            $count = 1;
                            foreach ($subscribed_companies as $key => $value) { ?>
                               <tr class="gradeU">
                                    <td><?php echo $count; ?></td>
                                    <td><?php echo $value->company_name; ?></td>
                                    <td><?php echo $value->company_status; ?></td>
                                    <td><?php echo $value->count_subscribed_services;?></td>
                                    <td>
                                        <?php echo "<a href='".base_url('index.php/admin/v_company/'.$value->company_id)
                                                    ."'class='btn btn-info btn-xs'><span class='fa fa-eye'></span></a>"; ?>
                                    </td>
                                </tr>
                            <?php 
                                $count++;
                            }?>
                            </tbody>
                        </table>
                    </div>
                </div>                        
                <!-- /.panel-body -->
                </div>
            </div>
            <!-- /.panel -->
            </div>
        
    </div>
    <!-- /.row --> 
</div>

    <script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

    <script>
    // Initialize Loadie for Page Load
        $(document).ready(function() {
            $('#dataTables-example').dataTable();
        });
    </script>

<!-- Page-Level Plugin Scripts - Dashboard -->
    <script src="<?php echo base_url('assets/js/plugins/morris/raphael-2.1.0.min.js')?>"></script>
    
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js')?>"></script>
    
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.time.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js')?>"></script>
    <script src="<?php echo base_url('assets/js/demo/admin_dash.js')?>"></script>