<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($roles)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Role ID</th>
                                <th>Role Name</th>
                                <th>Role Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        $count = 1;
                        foreach ($roles as $key => $value) { ?>
                           <tr class="gradeU">
                                <td><?php echo $value->role_id; ?></td>
                                <td><?php echo $value->role_name; ?></td>
                                <td><?php echo $value->description; ?></td>
                                <td><?php  
                                    echo "<a href='".base_url('index.php/admin/edit_role/'.$value->role_id)."'class='btn btn-success btn-xs'><span class='fa fa-pencil'></span></a>
                                        <a href='".base_url('index.php/admin/delete_role/'.$value->role_id)."'class='btn btn-danger btn-xs' id='del'><span class='fa fa-trash' onclick='javascript:return confirm(\"Are you sure you want to delete?\")'></span></a>";
                                        }
                                    ?>
                               </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-wrench"></i> roles</h2>
                    <br>
                    <p>No roles registered yet</p>
<!--
                    <a href="<?php echo site_url('admin/add_role');?>" class="btn btn-success">Add role</a> -->
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>