<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-service-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Edit service Details
	                </div>
	                <div class="panel-body">
	                    <?php foreach ($services as $value) { ?> 
	                    <input class="form-control" type="hidden" name="service_id" id="service_id" value="<?php echo $value->service_id; ?>" required="required"/>	
	                    
	                    <div class="form-group">
	                        <label for="reservation">Service Name: <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="services_name" id="service_name" value="<?php echo $value->services_name; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">service Description <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="service_description" id="service_description" value="<?php echo $value->service_description; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Status <sup>*</sup>:</label>
	                        <select class="form-control" type="text" name="status" id="status" required="required">
	                        	<option value="<?php echo $value->status; ?>">
                                    <?php if($value->status == '1') {
                                            echo "active";
                                        }else{
                                            echo "inactive"; 
                                        }; ?>
                                </option>
	                        	<option value="1">active</option>
								<option value="0">inactive</option>
	                        </select>
	                    </div>
	                </div>
	                
	            </div>
                
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="update-service">Update</button>
                </div>
	           <?php } ?>
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="panel panel-default">
                <div class="panel-heading">
                    Upload Service Photo here
                </div>
                <div class="panel-body">
                    <div id="dropzone">
				    	<form action="<?php echo base_url('index.php/upload_images/upload_service_image') ?>" class="dropzone" id="dropzone-container">
				    		<div class="fallback">
				    	    	<input name="file" type="file" multiple />
				    	  	</div>
				    	</form>
				    </div>
                </div>
            </div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script>
    $(function () {

            $('#edit-service-form').on('submit' , function () {

				$('#update-service').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-service').prop('disabled', true);
                //alert ("yes");

                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/admin/update_service') ?>',
                    data: $(this).serialize(),
                    success: function () {
                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
                        $('#update-service').html('Update');
                		$('#update-service').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>     