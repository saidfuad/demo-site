<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-asset_type-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Asset Type Details
	                </div>
	                <div class="panel-body">
	                    
                        <div class="form-group">
	                        <label for="reservation">Asset Type Name <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_type_nm" id="assets_type_nm"/>
	                    </div>
	                              
	                </div>
	                
	            </div>
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="save-asset_type">Save</button>
                </div>
	           
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-users"></i> Asset Types</h2>
				<br>
				<p></p>
				<a href="<?php echo site_url('admin/view_asset_types');?>" class="btn btn-success">View Asset Types</a>	
			</div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script type="text/javascript">
    $(function () {

        $('#add-asset_type-form').on('submit' , function () {

        	// alert('getting in the submit');

			if ($('#assets_type_nm').val().trim() == '') {
				swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
				return false;
			}

			$('#save-asset_type').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-asset_type').prop('disabled', true);

            $.ajax({

                method: 'post',
                url: '<?= base_url('index.php/admin/save_asset_type') ?>',
                data: $(this).serialize(),
                success: function (response) {

                    if (response==1) {

                        $('#add-asset_type-form').find('input[type="text"]').val('');
                        
                        swal({   title: "Info",   text: "Asset Type saved successfully",   type: "success",   confirmButtonText: "ok" });
                    } 
                    else if (response==0) {

                        swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                        
                    }else if (response==80) {

                        swal({   title: "Info",   text: "Asset Type Name already exists, Try again.",   type: "error",   confirmButtonText: "ok" });
                    }

                    $('#save-asset_type').html('Save');
                    $('#save-asset_type').prop('disabled', false);
                 }
            });
            
            return false;     
        });

    });
</script>     