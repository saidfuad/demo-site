<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-company-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   View Company Details
                        <?php foreach ($companies as $value) { ?> 
	                    <a href="<?= base_url('index.php/admin/edit_company/' .$value->company_id); ?>">
                            <span class="edit_personnel btn btn-xs btn-success">Edit <i class="fa fa-pencil"></i></span>
                        </a>
	                </div>
	                <div class="panel-body">
	                    <input class="form-control" type="hidden" name="company_id" id="company_id" value="<?php echo $value->company_id; ?>" disabled/>	
	                    
	                    <div class="form-group">
	                        <label for="reservation">Company Name: <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="company_name" id="company_name" value="<?php echo $value->company_name; ?>" disabled/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Company Address <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="company_address" id="company_address" value="<?php echo $value->company_address_1; ?>" disabled/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Company Phone Number <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="company_phone" id="company_phone" value="<?php echo $value->company_phone_no_1; ?>" disabled/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Status <sup>*</sup>:</label>
	                        <select class="form-control" type="text" name="company_status" id="company_status" disabled>
	                        	<option value="0"><?php echo $value->company_status; ?></option>
	                        	<option value="active">Active</option>
								<option value="inactive">Inactive</option>
	                        </select>
	                    </div>
	                </div>	
	            </div>

	           <?php } ?>
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-institution"></i> Companies</h2>
				<br>
				<p>View Subscribed Companies and their subscriptions services</p>

				<a href="<?php echo site_url('admin/view_companies');?>" class="btn btn-success">View Companies</a>	
			</div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script>
    $(function () {

            $('#edit-company-form').on('submit' , function () {

				$('#update-company').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-company').prop('disabled', true);
               // alert ("yes");

                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/companies/update_company') ?>',
                    data: $(this).serialize(),
                    success: function () {
                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
                        $('#update-company').html('Update');
                		$('#update-company').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>     