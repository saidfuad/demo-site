<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-asset_type-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Edit Asset Type Details
	                </div>
	                <div class="panel-body">
	                    <?php foreach ($asset_types as $value) { ?>
                        <div class="form-group">
	                        <input class="form-control" type="hidden" name="assets_type_id" id="assets_type_id" value="<?php echo $value->assets_type_id; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Asset Type Name: <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_type_nm" id="assets_type_nm" value="<?php echo $value->assets_type_nm; ?>" required="required"/>
	                    </div>
	                </div>
	                
	            </div>
                
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="update-asset_type">Update</button>
                </div>
	           <?php } ?>
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-list-o"></i> Asset Types</h2>
				<br>
				<p><a href="<?php echo site_url('admin/view_asset_types');?>" class="btn btn-success">View Asset Types</a>	
			</div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script>
    $(function () {

            $('#edit-asset_type-form').on('submit' , function () {

				$('#update-asset_type').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-asset_type').prop('disabled', true);
                
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/admin/update_asset_type') ?>',
                    data: $(this).serialize(),
                    success: function (response) {
                        
                        if (response==1) {
                            
                            swal({   title: "Info",   text: "Asset type saved successfully",   type: "success",   confirmButtonText: "ok" });
                            
                        } 
                        else if (response==0) {

                            swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                        
                        }
                        
                        $('#update-asset_type').html('Update');
                		$('#update-asset_type').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>     