<style>
    
    td.details-control {
        background: url('../../../itmsafrica/assets/images/details_open.png') no-repeat center center;
        cursor: pointer;
    }
    tr.shown td.details-control {
        background: url('../../../itmsafrica/assets/images/details_close.png') no-repeat center center;
    }
    
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($subscribed_companies)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th hidden></th>
                                <th>No</th>
                                <th>Company Name</th>
                                <th>No. of Personnel</th>
                                <th>No. of Vehicles</th>
                                <th>Subscribed Services</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        $count = 1;
                        foreach ($subscribed_companies as $key => $value) { ?>
                           <tr class="gradeU">
                                <td class="details-control"></td>
                                <td hidden><?php echo $value->company_id; ?></td>
                                <td><?php echo $count; ?></td>
                                <td><?php echo $value->company_name; ?></td>
                                <td><?php echo $value->no_of_personnel; ?></td>
                                <td><?php echo $value->no_of_vehicles; ?></td>
                                <td><?php echo $value->count_subscribed_services; ?></td>
                                <td><?php if($value->company_status == 'active') {
                                            echo "<a class='btn btn-success btn-xs'>".$value->company_status."</a>";
                                        }else{
                                           echo "<a class='btn btn-warning btn-xs'>".$value->company_status."</a>"; 
                                        }
                                    ?></td>
                                <td>
                                    <?php 
                                        if($value->company_status == 'active') { 
                                            echo "<a href='".base_url('index.php/admin/v_company/'.$value->company_id)
                                                    ."'class='btn btn-info btn-xs'><span class='fa fa-eye'></span></a>
                                                    <a href='".base_url('index.php/admin/edit_company/'.$value->company_id)
                                                    ."'class='btn btn-success btn-xs'><span class='fa fa-pencil'></span></a>
                                                    <a href='".base_url('index.php/admin/delete_company/'.$value->company_id)
                                                ."'class='btn btn-danger btn-xs' id='del'><span class='fa fa-trash' onclick='javascript:return confirm(\"Are you sure you want to delete?\")'></span></a>
                                                    <a href='".base_url('index.php/admin/enable_disable/'.$value->company_id)
                                                    ."'class='btn btn-warning btn-xs' onclick='location.reload()'><span class='fa fa-power-off'></span></a>";
                                        }else{ 
                                            echo "<a href='".base_url('index.php/admin/v_company/'.$value->company_id)
                                                    ."'class='btn btn-info btn-xs'><span class='fa fa-eye'></span></a>
                                                    <a href='".base_url('index.php/admin/enable_disable/'.$value->company_id)
                                                    ."'class='btn btn-success btn-xs' onclick='location.reload()'><span class='fa fa-power-off'></span></a>";
                                        }
                                    ?>
                               </td>
                            </tr>
                            
                            <?php
                                $count++; 
                                } 
                            ?>
                            
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Companies</h2>
                    <br>
                    <p>No Companies registered yet</p>

                    <a href="<?php echo site_url('admin/create_company');?>" class="btn btn-success">Create Company</a> 
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>


<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
    
// Initialize Loadie for Page Load
$(document).ready(function() {

    var table = $('#dataTables-example').DataTable();

    /* Formatting function for row details - modify as you need */
    function format (d) {

        var i;
        var table = '<table class="table table-hover table-striped" style="width: 70%">'+
            '<thead>'+
                '<tr>'+
                    '<th>Subscribed Services</th>'+
                    '<th>Subscription Date</th>'+
                    '<th>Expiry Date</th>'+
                '</tr>'+
            '</thead>'+
            '<tbody>';
        var services = '<?=json_encode($services)?>';
        for(i=0; i<services.length; i++){
            if(d[1] == services[i].company_id){
                table +=
                +'<tr>'+
                    '<td>'+ services[i].services_name +'</td>'+
                    '<td>'+ services[i].start_date +'</td>'+
                    '<td>'+ services[i].expiry_date +'</td>'+
                '</tr>';  
            }
        }
        table += '</tbody></table>';
        
        return table;
    }

    // Add event listener for opening and closing details
    $('#dataTables-example tbody').on('click', 'td.details-control', function () {
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        }
        else {
            // Open this row
            row.child( format(row.data()) ).show();
            tr.addClass('shown');
        }
    });

});
    
</script>
