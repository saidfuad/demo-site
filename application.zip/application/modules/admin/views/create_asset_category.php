<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-asset_category-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Asset Category Details
	                </div>
	                <div class="panel-body">
	                    
                        <div class="form-group">
	                        <label for="reservation">Asset Category Name <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_cat_name" id="assets_cat_name"/>
	                    </div>
	                    <!-- 
	                    <div class="form-group">
	                        <label for="reservation">Role Details:</label>
	                        <textarea class="form-control" type="text" name="description" id="description" rows="3"></textarea>
	                    </div>
	                           -->            
	                </div>
	                
	            </div>
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="save-asset_category">Save</button>
                </div>
	           
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-th-list"></i> Asset Categories</h2>
				<br>
				<p>Manage asset_categories</p>

				<a href="<?php echo site_url('admin/view_asset_categories');?>" class="btn btn-success">View Asset Categories</a>	
			</div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script type="text/javascript">
    $(function () {

        $('#add-asset_category-form').on('submit' , function () {

        	// alert('getting in the submit');

			if ($('#assets_cat_name').val().trim() == '') {
				swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
				return false;
			}

			$('#save-asset_category').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-asset_category').prop('disabled', true);

            $.ajax({

                method: 'post',
                url: '<?= base_url('index.php/admin/save_asset_category') ?>',
                data: $(this).serialize(),
                success: function (response) {

                    if (response==1) {

                        $('#add-asset_category-form').find('input[type="text"]').val('');
                        /*$('#add-asset_category-form').find('select').val(0);
                        $('#add-asset_category-form').find('textarea').val('');
*/
                        swal({   title: "Info",   text: "Asset category saved successfully",   type: "success",   confirmButtonText: "ok" });
                    } 
                    else if (response==0) {

                        swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                        
                    }else if (response==80) {

                        swal({   title: "Info",   text: "Asset category name already exists, Try again.",   type: "error",   confirmButtonText: "ok" });
                    }

                    $('#save-asset_category').html('Save');
                    $('#save-asset_category').prop('disabled', false);
                 }
            });
            
            return false;     
        });

    });
</script>     