<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($asset_categories)) {?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Category ID</th>
                                <th>Category Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                        $count = 1;
                        foreach ($asset_categories as $key => $value) { ?>
                           <tr class="gradeU">
                                <td><?php echo $value->assets_category_id; ?></td>
                                <td><?php echo $value->assets_cat_name; ?></td>
                                <td><?php  
                                    echo "<a href='".base_url('index.php/admin/edit_asset_category/'.$value->assets_category_id)."'class='btn btn-success btn-xs'><span class='fa fa-pencil'></span></a>
                                        <a href='".base_url('index.php/admin/delete_asset_category/'.$value->assets_category_id)."'class='btn btn-danger btn-xs' id='del'><span class='fa fa-trash' onclick='javascript:return confirm(\"Are you sure you want to delete?\")'></span></a>";
                                        }
                                    ?>
                               </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-th-list"></i> Asset Categories</h2>
                    <br>
                    <p>No asset categories registered yet</p>
                    <a href="<?php echo site_url('admin/create_asset_category');?>" class="btn btn-success">Add Asset Category</a>
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>