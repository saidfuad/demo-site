<link href="<?php echo base_url('assets/js/plugins/ion.rangeSlider-1.9.1/css/ion.rangeSlider.css')?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/js/plugins/ion.rangeSlider-1.9.1/css/ion.rangeSlider.skinFlat.css')?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/js/plugins/ion.rangeSlider-1.9.1/css/normalize.min.css')?>" rel="stylesheet" />
    

<div class="container-fluid bg-gray">
    <div class="row">
    	<div class="row">

		        <div class="col-md-3">
		        <h3>Company Info</h3>
		        	<div class="row">
		        		<div class="col-md-12">
				            <div class="user-card-mini row">
				                <div class="col-md-12 col-sm-12 col-xs-12">
				                    <span>Company Name</span>
				                    <span><?php echo $company['company_name']; ?></span>
				                </div>
				            </div>
				        </div>
				        <div class="col-md-12">
				            <div class="user-card-mini row">
				                <div class="col-md-12 col-sm-12 col-xs-12">
				                    <span>Phone</span>
				                    <span><?php echo $company['company_phone_no_1']; ?></span>
				                </div>
				            </div>
				        </div>
				        <div class="col-md-12">
				            <div class="user-card-mini row">
				                <div class="col-md-12 col-sm-12 col-xs-12">
				                    <span>Email</span>
				                    <span><?php echo $company['company_email']; ?></span>
				                </div>
				            </div>
				        </div>
				        <div class="col-md-12">
				            <div class="user-card-mini row">
				                <div class="col-md-12 col-sm-12 col-xs-12">
				                    <span>Admin Details</span>
				                    <span>
				                    	<strong>Username : </strong><?php echo $company['username']; ?> <br>
				                    	<strong>Password : </strong><?php echo $this->encrypt->decode($company['password']); ?>
				                    </span>
				                </div>
				            </div>
				        </div>
				    </div>
		        </div>
		        <div class="col-md-3">
		        	<h3>Services</h3>
		        	<hr>
		        	<div class="row">

		        	<?php foreach ($subscriptions as $key => $value) {?>
		        	
		        		<div class="col-md-12"> 
				            <!-- User Card Mini w/ stats -->
				            <div class="user-card-mini">
				                <div class="row">
				                    <div class="col-md-12 col-sm-12 col-xs-12">
				                        <span><?php echo $value->services_name;?></span>
				                        <span>Subscriptions : KES <?php echo $value->cost;?> per Month</span><br>
				                        <span><strong class="stt_date">Start Date : </strong><i class="st_dt"><?php if($value->start_date!=null) {echo $value->start_date;} else { echo 'Not Set'; }?></i></span><br>
				                        <span><strong>Expiry Date : </strong><i class="exp_date"><?php if($value->expiry_date!=null) {echo $value->expiry_date;} else { echo 'Not Set'; }?></i></span>
				                        <span class="serv-period"><small></small></span>
				                    </div>

				                    
				                </div>
				                <hr>
				                <div class="stats row">
				                	<input type="hidden" class="service-id-cont" value="<?php echo $value->service_id;?>">
				                	<input type="hidden" class="cost-cont" value="<?php echo $value->cost;?>">
				                    <div class="col-md-4 col-sm-4 col-xs-4">
				                        <span>
				                        <input type="radio" class="service-period" name="<?php echo $value->service_id;?>" value='3' /> 3</span>
				                        <span>Months</span>
				                    </div>
				                    <div class="col-md-4 col-sm-4 col-xs-4">
				                        <span>
				                        <input type="radio" class="service-period" name="<?php echo $value->service_id;?>" value='6' /> 6</span>
				                        <span>Months</span>
				                    </div>
				                    <div class="col-md-4 col-sm-4 col-xs-4">
				                        <span>
				                        <input type="radio" class="service-period" name="<?php echo $value->service_id;?>" value='12' /> 12</span>
				                        <span>Months</span>
				                    </div>
				                </div>
				            </div>
				            <!-- end: Us
				            <div class="col-md-4 col-sm-4 col-xs-4">
				                        <span>Projects</span>
				                        <span>5</span>
				                    </div>er Card Mini w/ stats -->
				        </div>
				    <?php }?>
		            </div>
		        </div>
		        <div class="col-md-3">
		        	<h3>SMS</h3>
		        	<hr>
		        	<div class="row">
		        		<div class="col-md-12">
				        	<div class="panel panel-default" style="margin-top:10px;">
					          <div class="panel-heading">
					            Drag SMS Slider
		 			          </div>
					          <div class="panel-body">
					              <!-- Slider -->
					              <input id="example_1" type="text" name="" value="0;5000" style="display: none;">
					              <!-- // Slider END -->
					          </div>
					        </div>
					    </div>
				    </div>
		        </div>
		        <div class="col-md-3">
		        	<div class="panel panel-primary" id="panel-sttls">
		                <div class="panel-heading">
		                	Totals
		                    <!-- Panel Menu -->
		                    <div class="panel-menu">
		                        <button type="button" data-action="minimize" class="btn btn-default btn-action btn-xs"><i class="fa fa-angle-down"></i></button>
		                    </div>
		                    <!-- Panel Menu -->
		                </div>
		                <div class="panel-body">
		                	<form id="subscription-form">
		                			<input type="hidden" name="comp_id" id="comp_id" value="<?php echo $company['company_id']; ?>">
		                	<?php if(sizeof('subscriptions')) {
			                	  foreach ($subscriptions as $key => $value) {?>
			                	<div class="service-holder">
			                		<input type='hidden' class="<?php echo 'start_input_'.$value->service_id; ?>" name="<?php echo 'start_input_'.$value->service_id; ?>">
			                		<input type='hidden' class="<?php echo 'end_input_'.$value->service_id; ?>" name="<?php echo 'end_input_'.$value->service_id; ?>">
			                		<h3><strong><?php echo $value->services_name; ?></strong></h3>
			                		<div class="row">
				                		<div class="col-md-4" id="<?php echo 'service_'.$value->service_id; ?>">
				                			<label></label><i>Not Set</i>
				                		</div>
				                		<div class="col-md-8" id="<?php echo 'cost_'.$value->service_id; ?>" align="right">
				                			<label class="label label-warning t">KES 0</label>
				                		</div>
				                	</div>
			                	</div>
			                	<hr>
			                	<?php }?>
			                <?php } else { ?>
			                <div class="alert alert-info"> No services selected</div>
			                <?php } ?>
			                <div class="s-holder">
		                		<h3><strong>SMS Subscription</strong></h3>
		                		<div class="row">
			                		<div class="col-md-5" id="sms-sub-cont">
			                			<i class="number_of_sms"></i> <label> &nbsp;SMSs</label>
			                		</div>
			                		<div class="col-md-7" id="sms_cash" align="right">
			                			<input type="hidden" id="sms-cost-h" value="1.50">
			                			<label class="label label-warning t">KES 0</label>
			                		</div>
			                	</div>
		                	</div>
		                	<hr>
		                	<button id="total_subs_hold" class="btn btn-primary btn-lg btn-block">Total : 0</button>
		                    
		                </div>
		                <div class="panel-footer" align="right">
		                   <button type="submit" class="btn btn-success">Submit</button>
		                </div>
		            </form>    
		            </div>
		            
		        </div>
       		</div>

    </div>
</div> 

    

<script src="<?php echo base_url('assets/js/plugins/ion.rangeSlider-1.9.1/js/ion-rangeSlider/ion.rangeSlider.js')?>"></script>
<script>
    $(function () {

        $("#example_1").ionRangeSlider({
		    min: 0,
		    max: 5000,
		    step:100,
		    type: 'single',
		    prefix: "",
		    maxPostfix: "",
		    prettify: false,
		    hasGrid: true
		});

		$('.service-period').on('change', function () {
			var period = $(this).val();
			var service_id = $(this).parent().parent().parent().find('.service-id-cont').val().trim();
			var service_cost = parseFloat($(this).parent().parent().parent().find('.cost-cont').val().trim());
			var ttl_cost = service_cost * parseInt(period);

			$('#service_'+service_id).find('i').html(period + ' Months');
			$('#cost_'+service_id).find('label').html('KES ' + ttl_cost);
			$(this).parent().parent().parent().parent().find('.serv-period').html(period + ' Months');

			var d = new Date();
			var e = new Date();
			var now_ = d;
			e.setMonth(d.getMonth() + parseInt(period));
			var end_ = e;

			//var stime = Date.parse(d);
			//var etime = Date.parse(e);

			var st = fetch_date(d);
			var et = fetch_date(e);
			function fetch_date (today) {
				//var today = new Date();
				var cDate = today.getDate();
				var cMonth = today.getMonth() + 1;
				var cYear = today.getFullYear();

				var cHour = today.getHours();
				var cMin = today.getMinutes();
				var cSec = today.getSeconds();


				return cYear +'-'+ cMonth +'-'+ cDate +' '+ cHour+':'+cMin+':'+cSec;
			}
			    


			$(this).parent().parent().parent().parent().find('.st_dt').html(now_);
			$(this).parent().parent().parent().parent().find('.exp_date').html(end_);

			$('.start_input_'+service_id).val(st);
			$('.end_input_'+service_id).val(et);

		});

		$('#subscription-form').on('submit', function () {
			$.ajax({
                method: 'post',
                url: '<?= base_url('index.php/admin/save_services_subs') ?>',
                data: $(this).serialize(),
                success: function (response) {
                	if (response == 1) {
                			window.location.replace('<?= base_url('index.php/admin/view_companies') ?>');
                	} else {
                		swal({   title: "Info",   text: "Failed to save subscription",   type: "info",   confirmButtonText: "ok" });
                	}
                	
                }
            });

            return false;

		});

    });
</script>   