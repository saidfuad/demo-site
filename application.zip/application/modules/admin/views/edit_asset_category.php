<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-asset_category-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Edit Asset Category Details
	                </div>
	                <div class="panel-body">
	                    <?php foreach ($asset_categoryies as $value) { ?>
                        <div class="form-group">
	                        <input class="form-control" type="hidden" name="assets_category_id" id="assets_category_id" value="<?php echo $value->assets_category_id; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Asset Category Name: <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_cat_name" id="assets_cat_name" value="<?php echo $value->assets_cat_name; ?>" required="required"/>
	                    </div>
	                </div>
	                
	            </div>
                
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="update-asset_category">Update</button>
                </div>
	           <?php } ?>
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-th-list"></i> Asset Categories</h2>
				<br>
				<p><a href="<?php echo site_url('admin/view_asset_categories');?>" class="btn btn-success">View Asset Categories</a>	
			</div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script>
    $(function () {

            $('#edit-asset_category-form').on('submit' , function () {

				$('#update-asset_category').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-asset_category').prop('disabled', true);
                
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/admin/update_asset_category') ?>',
                    data: $(this).serialize(),
                    success: function (response) {
                        
                        if (response==1) {
                            
                            swal({   title: "Info",   text: "Asset category saved successfully",   type: "success",   confirmButtonText: "ok" });
                            
                        } 
                        else if (response==0) {

                            swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                        
                        }
                        
                        $('#update-asset_category').html('Update');
                		$('#update-asset_category').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>     