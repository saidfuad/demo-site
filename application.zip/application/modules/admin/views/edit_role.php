<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-role-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Edit role Details
	                </div>
	                <div class="panel-body">
	                    <?php foreach ($roles as $value) { ?>
                        <div class="form-group">
	                        <input class="form-control" type="hidden" name="role_id" id="role_id" value="<?php echo $value->role_id; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Role Name: <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="role_name" id="role_name" value="<?php echo $value->role_name; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Role Description:</label>
	                        <input class="form-control" type="text" name="description" id="description" value="<?php echo $value->description; ?>" />
	                    </div>
	                    
	                </div>
	                
	            </div>
                
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="update-role">Update</button>
                </div>
	           <?php } ?>
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			
            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-users"></i> Roles</h2>
				<br>
				<p>Manage drivers and other employees information. Assign roles to all role and permissions 
					to all users determining who accesses what and when </p>

				<a href="<?php echo site_url('admin/view_roles');?>" class="btn btn-success">View Roles</a>	
			</div>
		</div>

    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script>
    $(function () {

            $('#edit-role-form').on('submit' , function () {

				$('#update-role').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-role').prop('disabled', true);
                
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/admin/update_role') ?>',
                    data: $(this).serialize(),
                    success: function (response) {
                        
                        if (response==1) {
                            
                            swal({   title: "Info",   text: "Role saved successfully",   type: "success",   confirmButtonText: "ok" });
                            
                        } 
                        else if (response==0) {

                            swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                        
                        }
                        
                        $('#update-role').html('Update');
                		$('#update-role').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>     