<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-company-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Company Details
	                </div>
	                <div class="panel-body">
	                    
	                    <div class="form-group">
	                        <label for="reservation">Company Name:</label>
	                        <input class="form-control" type="text" name="company_name" id="company_name" required="required"/>
	                        <input class="form-control" type="hidden" name="protocal" id="protocal" value="7" required="required"/>
	                    </div>
	                    <!--<div class="form-group">
	                        <label for="reservation">Country:</label>
	                        <select class="form-control" name="company_country_id" id="company_country_id" required="required">
	                        	<option value="0">--Select Country--</option>
	                        	<option value="1">Kenya</option>
	                        	<option value="2">Uganda</option>
	                        	<option value="3">Tanzania</option>

	                        </select>
	                    </div>-->
	                    <div class="form-group">
	                        <label for="reservation">Mobile Number:</label>
	                        <input class="form-control" type="text" placeholder="Format : +254701022477" name="company_phone_no_1" id="company_phone_no_1" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Tel No:</label>
	                        <input class="form-control" type="text" name="company_tel_1" id="company_tel_1" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Email:</label>
	                        <input class="form-control" type="email" name="company_email" id="company_email" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Address:</label>
	                        <textarea class="form-control" type="text" name="company_address_1" id="company_address_1" required="required" rows="3"></textarea>
	                    </div>
	                                  
	                </div>
	                
	            </div>
	            
			</div>
		
		<div class="col-md-6 col-lg-6">
			<div class="col-md-12 bg-crumb">
				<h3>Select Services</h3>
				<ul style="list-style-type:none;">
					<?php 
                    $count = 1;
                    foreach ($services as $key => $value) { ?>
                       <li><input class="" type="checkbox" name="service[]" iclass="service" <?php if ($value->status == 0) {?> disabled="disabled" <?php } ?> value="<?php echo $value->service_id; ?>" /> 
                       		<?php echo $value->services_name?>
                       	</li>
                    <?php }?>
				</ul>	
			</div>

			<div class="col-md-12 bg-crumb" id="results-div" style="display: none">
				<h3>Results</h3>
				<div class="panel-body" id="results-panel" style="background:#262626;border-radius:5px;color:#fff">
				</div>
				
			</div>

		</div>
		<div class="col-md-12 col-lg-12">
			<div class="panel-footer" align="right">
        	<button class="btn btn-primary btn-lg" type="submit" id="save-company">Save</button>
        	<a class="btn btn-warning btn-lg" id="next-step" style="display: none">Continue <i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></a>
        </div>
		</div>

		
		</form>

    </div>
</div> 

<!--<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>-->

<script>
    $(function () {

        $('#add-company-form').on('submit' , function () {

        	$('#results-div').fadeOut();

			if ($('#company_name').val().trim().length==0 || $('#company_phone_no_1').val().trim().length==0 ||
					$('#company_email').val().trim().length ==0 || $('#company_tel_1').val().trim().length ==0 ||
							$('#company_country_id').val() ==0 || $('#company_address_1').val().trim().length ==0) {
				swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
				return false;
			}

			$('#save-company').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-company').prop('disabled', true);
           

            $.ajax({
                method: 'post',
                url: '<?= base_url('index.php/admin/save_company') ?>',
                data: $(this).serialize(),
                success: function (response) {

                	if (response =='phone_exists') {
                			swal({   title: "Info",   text: "Sorry, phone number already registered with another account",   type: "info",   confirmButtonText: "ok" });
                			$('#save-company').html('Save');
            				$('#save-company').prop('disabled', false);
                			return false;
                	} else if (response == 'email_exists') {
                		swal({   title: "Info",   text: "Sorry, Email already registered with another account",   type: "info",   confirmButtonText: "ok" });
                			$('#save-company').html('Save');
            				$('#save-company').prop('disabled', false);
                			return false;
					}

                	$res = JSON.parse(response);

                	$('#results-panel').find('results-p').remove();
                	$('#results-div').fadeIn();

                	if ($res.add_admin) {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Company created successfully</p>');
                		$('#next-step').attr("href", "<?php echo site_url('admin/complete_reg'); ?>" + "/" + $res.company_id);
                	} else {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-danger btn-xs"> </span> Failed to create company</p>');
                	}

                	if ($res.add_services) {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Services created successfully</p>');
                	} else {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Failed to activate services subscriptions</p>');
                	}

                	if ($res.add_admin) {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> User:Admin created successfully<br> <strong>Username : </strong>'+$res.username+'<br> <strong>Password : </strong>'+$res.password+'<br><br>(<i>Details Sent to Company email</i>)</p>');
                	}  else {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Failed to create admin</p>');
                	}

                	if ($res.add_menus) {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Menu permissions assigned</p>');
                	}  else {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Failed to create menu permissions</p>');
                	}

                	if ($res.add_reports) {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Reports permissions assigned</p>');
                	}  else {
                		$('#results-panel').append('<p class="results-p"><span class"btn btn-primary btn-xs"> </span> Failed to create reports permissions</p>');
                	}

                	if ($res.add_admin) {
                		$('#save-company').hide();
                		$('#next-step').show();
                	}

                	$('#results-panel').append('<p class="results-p"><strong>Click On continue to complete</strong></p>');
                    
                    $('#save-company').html('Save');
            		$('#save-company').prop('disabled', false);
                 }
            });

            return false;     
        });

    });
</script>        