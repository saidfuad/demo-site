<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-role-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Role Details
	                </div>
	                <div class="panel-body">

                        <div class="form-group">
                          <input class="form-control" type="hidden" name="company_id" id="company_id" value="1"/>
                          <label for="reservation">Role Name <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="role_name" id="role_name"/>
	                    </div>

	                    <div class="form-group">
	                        <label for="reservation">Role Details:</label>
	                        <textarea class="form-control" type="text" name="description" id="description" rows="3"></textarea>
	                    </div>

	                </div>

	            </div>
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="save-role">Save</button>
                </div>

			</div>
		</form>
		<div class="col-md-6 col-lg-6">

            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-users"></i> Roles</h2>
				<br>
				<p>Manage drivers and other employees information. Assign roles to all role and permissions
					to all users determining who accesses what and when </p>

				<a href="<?php echo site_url('admin/view_roles');?>" class="btn btn-success">View Roles</a>
			</div>
		</div>

    </div>
</div>

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script type="text/javascript">
    $(function () {

        $('#add-role-form').on('submit' , function () {

        	// alert('getting in the submit');

			if ($('#role_name').val().trim() == '') {
				swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
				return false;
			}

			$('#save-role').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#save-role').prop('disabled', true);

            $.ajax({

                method: 'post',
                url: '<?= base_url('index.php/admin/save_role') ?>',
                data: $(this).serialize(),
                success: function (response) {

                    if (response==1) {

                        $('#add-role-form').find('input[type="text"]').val('');
                        $('#add-role-form').find('select').val(0);
                        $('#add-role-form').find('textarea').val('');

                        swal({   title: "Info",   text: "Role saved successfully",   type: "success",   confirmButtonText: "ok" });
                    }
                    else if (response==0) {

                        swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });

                    }else if (response==80) {

                        swal({   title: "Info",   text: "Role Name already exists, Try again.",   type: "error",   confirmButtonText: "ok" });
                    }

                    $('#save-role').html('Save');
                    $('#save-role').prop('disabled', false);
                 }
            });

            return false;
        });

    });
</script>
