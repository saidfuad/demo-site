<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-company-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Edit Company Details
	                </div>
	                <div class="panel-body">
	                    <?php foreach ($companies as $value) { ?> 
	                    <input class="form-control" type="hidden" name="company_id" id="company_id" value="<?php echo $value->company_id; ?>" required="required"/>	
	                    
	                    <div class="form-group">
	                        <label for="reservation">Company Name: <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="company_name" id="company_name" value="<?php echo $value->company_name; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Company Address <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="company_address_1" id="company_address_1" value="<?php echo $value->company_address_1; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Company Phone Number <sup>*</sup>:</label>
	                        <input class="form-control" type="text" name="company_phone_no_1" id="company_phone_no_1" value="<?php echo $value->company_phone_no_1; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Status <sup>*</sup>:</label>
	                        <select class="form-control" type="text" name="company_status" id="company_status" required="required">
	                        	<option value="<?php echo $value->company_status; ?>"><?php echo $value->company_status; ?></option>
	                        	<option value="active">Active</option>
								<option value="inactive">Inactive</option>
	                        </select>
	                    </div>
	                </div>
	                
	            </div>
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="update-company">Update</button>
                </div>
	           <?php } ?>
			</div>

		<div class="col-md-6 col-lg-6">
			<div class="panel panel-default">
				<div class="panel-heading">
                    Subscribed Services
                </div>
				<ul style="list-style-type:none;">
					<?php 
                    $count = 1;

                    foreach ($services as $key => $value) {
                    	foreach ($subscribed_services as $key => $svalue) {

                       	if($svalue->service_id == $value->service_id){

                    ?>
                       <li><input class="" type="checkbox" name="service[]" iclass="service" 

                       <?php 
                       	if ($value->status == 0) {
                       	?> disabled="disabled" 
                       	<?php }

                       	?>
                       	checked="checked"
                       
                       	value="<?php echo $value->service_id; ?>" /> 

                       		<?php echo $value->services_name?>

                       	</li>
                    <?php }} }?>
				</ul>	
			</div>
		</div>

		</form>
		<div class="col-md-6 col-lg-6">
			<div class="panel panel-default">
                <div class="panel-heading">
                    Upload Company Photo here
                </div>
                <div class="panel-body">
                    <div id="dropzone">
				    	<form action="<?php echo base_url('index.php/upload_images/upload_company_image') ?>" class="dropzone" id="dropzone-container">
				    		<div class="fallback">
				    	    	<input name="file" type="file" multiple />
				    	  	</div>
				    	</form>
				    </div>
                </div>
            </div>
		</div>
    </div>
</div> 

<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>

<script>
    $(function () {

            $('#edit-company-form').on('submit' , function () {

				$('#update-company').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-company').prop('disabled', true);
               // alert ("yes");

                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/admin/update_company') ?>',
                    data: $(this).serialize(),
                    success: function () {
                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
                        $('#update-company').html('Update');
                		$('#update-company').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>     