<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct() {

        parent::__construct();

        
		if ($this->session->userdata('itms_protocal') != 71) {
            redirect('home');
        }

        $this->load->model('mdl_admin_dashboard');
        $this->load->model('mdl_admin');
        $this->load->library('encrypt');
        $this->load->library('smssend');
        $this->load->library('emailsend');
    }

    public function index() {

        $data['subscribed_companies'] = $this->mdl_admin_dashboard->get_registered_companies();
        $data['active_companies'] = $this->mdl_admin_dashboard->get_registered_companies('active');
        $data['count_active_companies'] = sizeof($data['active_companies']);
        $data['inactive_companies'] = $this->mdl_admin_dashboard->get_registered_companies('inactive');
        $data['count_inactive_companies'] = sizeof($data['inactive_companies']);

        $data['services'] = $this->mdl_admin_dashboard->get_services(0);
        
        $data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'admin';
        $data['fa'] = 'fa fa-laptop';
        $data['title'] = 'ITMS Africa | Super Admin';
        $data['content_title'] = 'Super Admin Dashboard';
        $data['content_subtitle'] = '';
        $data['content'] = 'home.php';
        
        $this->load->view('main', $data);
	}


    public function view_companies () {

        $data['content_btn']= '<a href="'.site_url('admin/create_company').'" class="btn btn-primary btn-m"><i class="fa fa-plus"></i> Create Company</a>';  
        
        $data['subscribed_companies'] = $this->mdl_admin_dashboard->get_registered_companies();
        $data['services'] = $this->mdl_admin_dashboard->get_services_subscriptions();
        
        /*$data['active_companies'] = $this->mdl_admin_dashboard->get_registered_companies('active');
        $data['count_active_companies'] = sizeof($data['active_companies']);
        $data['inactive_companies'] = $this->mdl_admin_dashboard->get_registered_companies('inactive');
        $data['count_inactive_companies'] = sizeof($data['inactive_companies']);*/

        //$data['services'] = $this->mdl_admin_dashboard->get_services(0);
        //$data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'admin/view_companies';
        $data['fa'] = 'fa fa-institution';
        $data['title'] = 'ITMS Africa | Companies';
        $data['content_title'] = 'Companies';
        $data['content_subtitle'] = 'List of all registered companies';
        $data['content'] = 'view_companies.php';
        
        $this->load->view('main', $data);
    }

    public function v_company(){
        
        $data ['companies'] = $this->mdl_admin_dashboard->edit_company($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'admin/view_companies';
        $data['fa'] = 'fa fa-institution';
        $data['title'] = 'ITMS Africa | View Company';
        $data['content_title'] = 'Companies';
        $data['content_subtitle'] = 'View Company Details';
        $data['content'] = 'v_company.php';

        $this->load->view('main', $data); 
        
    }

    public function create_asset_category () {
        
        $data['content_url'] = 'admin/create_asset_category';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Create Asset Category';
        $data['content_title'] = 'Create Asset Category';
        $data['content_subtitle'] = "Create companies' asset category";
        $data['content'] = 'create_asset_category.php';
        $this->load->view('main.php', $data);
    }

    public function save_asset_category () {
        $data = $this->input->post();
        echo $this->mdl_admin_dashboard->save_asset_category($data);
    }

    public function edit_asset_category($assets_category_id){
        
        $data ['asset_categories'] = $this->mdl_admin_dashboard->edit_asset_category($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'admin/view_asset_categories';
        $data['fa'] = 'fa fa-th-list';
        $data['title'] = 'ITMS Africa | Edit Asset Category';
        $data['content_title'] = 'Edit Asset Category';
        $data['content_subtitle'] = 'Edit asset category details';
        $data['content'] = 'edit_asset_category.php';

        $this->load->view('main', $data); 
        
    }
    
    function update_asset_category () {
        $data = array('assets_category_id' => $this->input->post('assets_category_id'),
                      'assets_cat_name' => $this->input->post('assets_cat_name'));
        
        $this->mdl_admin_dashboard->update_asset_category($data);
    }
    
    public function delete_asset_category($assets_category_id){
        $this->mdl_admin_dashboard->delete_asset_category($assets_category_id);
        header('location:'.base_url('index.php/admin/view_asset_categories'));
    }
    
    public function view_asset_categories () {
    
        $data['content_btn']= '<a href="'.site_url('admin/create_asset_category').'" class="btn btn-primary btn-m"><i class="fa fa-plus"></i> Create Asset Category</a>';
        
        $data['asset_categories'] = $this->mdl_admin_dashboard->get_asset_categories();
        
        $data['content_url'] = 'admin/view_asset_categories';
        $data['fa'] = 'fa fa-th-list';
        $data['title'] = 'ITMS Africa | Asset Categories';
        $data['content_title'] = 'Asset Categories';
        $data['content_subtitle'] = 'Categories of Assets';
        $data['content'] = 'view_asset_categories.php';
        
        $this->load->view('main', $data);
    }

    public function create_asset_type () {
        
        $data['content_url'] = 'admin/create_asset_type';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Create Asset Type';
        $data['content_title'] = 'Create Asset Type';
        $data['content_subtitle'] = "Create companies' asset type";
        $data['content'] = 'create_asset_type.php';
        $this->load->view('main.php', $data);
    }

    public function save_asset_type () {
        $data = $this->input->post();
        echo $this->mdl_admin_dashboard->save_asset_type($data);
    }

    public function edit_asset_type($assets_type_id){
        
        $data ['asset_types'] = $this->mdl_admin_dashboard->edit_asset_type($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'admin/view_asset_types';
        $data['fa'] = 'fa fa-th-list';
        $data['title'] = 'ITMS Africa | Edit Asset Type';
        $data['content_title'] = 'Edit Asset Type';
        $data['content_subtitle'] = 'Edit asset type details';
        $data['content'] = 'edit_asset_type.php';

        $this->load->view('main', $data); 
        
    }
    
    function update_asset_type () {
        $data = array('assets_type_id' => $this->input->post('assets_type_id'),
                      'assets_type_nm' => $this->input->post('assets_type_nm'));
        
        $this->mdl_admin_dashboard->update_asset_type($data);
    }
    
    public function delete_asset_type($assets_type_id){
        $this->mdl_admin_dashboard->delete_asset_type($assets_type_id);
        header('location:'.base_url('index.php/admin/view_asset_types'));
    }

    public function view_asset_types () {
    
        $data['content_btn']= '<a href="'.site_url('admin/create_asset_type').'" class="btn btn-primary btn-m"><i class="fa fa-plus"></i> Create Asset Type</a>';
        
        $data['asset_types'] = $this->mdl_admin_dashboard->get_asset_types();
        
        $data['content_url'] = 'admin/view_asset_types';
        $data['fa'] = 'fa fa-list-ol';
        $data['title'] = 'ITMS Africa | Asset Types';
        $data['content_title'] = 'Asset Types';
        $data['content_subtitle'] = 'Types of Assets';
        $data['content'] = 'view_asset_types.php';
        
        $this->load->view('main', $data);
    }
    
    public function create_role () {
        
        $data['content_url'] = 'admin/create_role';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Create Personnel Types';
        $data['content_title'] = 'Create Personnel Types';
        $data['content_subtitle'] = "Create companies' personnel roles";
        $data['content'] = 'create_role.php';
        $this->load->view('main.php', $data);
    }
    
    public function view_roles () {
    
        $data['content_btn']= '<a href="'.site_url('admin/create_role').'" class="btn btn-primary btn-m"><i class="fa fa-plus"></i> Create Role</a>';
        
        $data['roles'] = $this->mdl_admin_dashboard->get_roles();
        
        $data['content_url'] = 'admin/view_roles';
        $data['fa'] = 'fa fa-briefcase';
        $data['title'] = 'ITMS Africa | Personnel Roles';
        $data['content_title'] = 'Personnel Roles';
        $data['content_subtitle'] = '';
        $data['content'] = 'view_roles.php';
        
        $this->load->view('main', $data);
    }
    
    public function edit_role($role_id){
        
        $data ['roles'] = $this->mdl_admin_dashboard->edit_role($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'admin/view_roles';
        $data['fa'] = 'fa fa-briefcase';
        $data['title'] = 'ITMS Africa | Edit Role';
        $data['content_title'] = 'Edit Roles';
        $data['content_subtitle'] = 'Edit personnel role details';
        $data['content'] = 'edit_role.php';

        $this->load->view('main', $data); 
        
    }
    
    function update_role(){
        $data = array('role_id' => $this->input->post('role_id'),
                      'role_name' => $this->input->post('role_name'),
                      'description' => $this->input->post('description'));
        
        $this->mdl_admin_dashboard->update_role($data);
    }
    
    public function delete_role($role_id){
        $this->mdl_admin_dashboard->delete_company($role_id);
        header('location:'.base_url('index.php/admin/view_roles'));
    }
    
    public function save_role () {
        $data = $this->input->post();
        $dat['company_id'] = 1;
        echo $this->mdl_admin_dashboard->save_role($data);
    }

    public function create_company () {

        $data['content_btn']= '<a href="'.site_url('admin/view_companies').'" class="btn btn-success btn-lg"><i class="fa fa-institution"></i> View Companies</a>';    
        
        $data['services'] = $this->mdl_admin_dashboard->get_services(0);
        $data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'admin/create_company';
        $data['fa'] = 'fa fa-institution';
        $data['title'] = 'ITMS Africa | Create Companies';
        $data['content_title'] = 'Create Company';
        $data['content_subtitle'] = 'Register new company';
        $data['content'] = 'create_company.php';
        
        $this->load->view('main', $data);
    }
    
    public function edit_company($company_id){
        
        $data['services'] = $this->mdl_admin_dashboard->get_services(0);
        $data['subscribed_services'] = $this->mdl_admin_dashboard->get_services_subscriptions($company_id);
        $data ['companies'] = $this->mdl_admin_dashboard->edit_company($company_id);
        
        // echo "<pre>";
        // print_r($data['subscribed_services']);
        // exit;

        $data['content_url'] = 'admin/view_companies';
        $data['fa'] = 'fa fa-institution';
        $data['title'] = 'ITMS Africa | Edit Company';
        $data['content_title'] = 'Companies';
        $data['content_subtitle'] = 'Edit Company Details';
        $data['content'] = 'edit_company.php';

        $this->load->view('main', $data); 
        
    }
    
    public function delete_company($company_id){
        $this->mdl_admin_dashboard->delete_company($company_id);
        header('location:'.base_url('index.php/admin/view_companies'));
    }
    
    public function enable_disable($company_id){
        
        $this->mdl_admin_dashboard->enable_disable($company_id);
        header('location:'.base_url('index.php/admin/view_companies'));
        
    }
    
    function update_company(){
        $data = array('company_id' => $this->input->post('company_id'),
                      'company_name' => $this->input->post('company_name'),
                      'company_address_1' => $this->input->post('company_address_1'),
                      'company_phone_no_1' => $this->input->post('company_phone_no_1'), 
                      'company_status' => $this->input->post('company_status'),
                      'services' => $this->post->post('service'));
        
        $this->mdl_admin_dashboard->update_company($data);
    }
    
    public function view_services () {
    
        //$data['content_btn']= '<a href="'.site_url('admin/add_service').'" class="btn btn-success btn-lg"><i class="fa fa-plus"></i> Add Service</a>';
        
        $data['services'] = $this->mdl_admin_dashboard->get_services();
        $data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'view_services';
        $data['fa'] = 'fa fa-laptop';
        $data['title'] = 'ITMS Africa | Subscription Services';
        $data['content_title'] = 'Subscription Services';
        $data['content_subtitle'] = '';
        $data['content'] = 'view_services.php';
        
        $this->load->view('main', $data);
    }
    
    public function edit_service($service_id){
        
        $data ['services'] = $this->mdl_admin_dashboard->edit_service($this->session->userdata('itms_company_id'));
        
        $data['content_url'] = 'admin/view_services';
        $data['fa'] = 'fa fa-institution';
        $data['title'] = 'ITMS Africa | Edit Service';
        $data['content_title'] = 'Services';
        $data['content_subtitle'] = 'Edit Service Details';
        $data['content'] = 'edit_service.php';

        $this->load->view('main', $data); 
        
    }
    
    public function delete_service($service_id){
        $this->mdl_admin_dashboard->delete_company($service_id);
        header('location:'.base_url('index.php/admin/view_services'));
    }
    
    public function enable_disable_service($service_id){
        
        $this->mdl_admin_dashboard->enable_disable_service($service_id);
        header('location:'.base_url('index.php/admin/view_services'));
        
    }
    
    function update_service(){
        $data = array('service_id' => $this->input->post('service_id'),
                      'services_name' => $this->input->post('services_name'),
                      'service_description' => $this->input->post('service_description'), 
                      'service_status' => $this->input->post('service_status'));
        // $data = $this->input->post();
        /*$data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['thumbnail'] = ($this->session->userdata('personnel_pic') != '') ? $this->session->userdata('personnel_pic') :'personnel-default.png';*/
        
        $this->mdl_admin_dashboard->update_service($data);
    }

    public function view_subscriptions () {
 
        $data['subscribed_companies'] = $this->mdl_admin_dashboard->get_registered_companies();
        $data['active_companies'] = $this->mdl_admin_dashboard->get_registered_companies('active');
        $data['count_active_companies'] = sizeof($data['active_companies']);
        $data['inactive_companies'] = $this->mdl_admin_dashboard->get_registered_companies('inactive');
        $data['count_inactive_companies'] = sizeof($data['inactive_companies']);

        $data['services'] = $this->mdl_admin_dashboard->get_services(0);
        $data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'admin';
        $data['fa'] = 'fa fa-laptop';
        $data['title'] = 'ITMS Africa | Super Admin';
        $data['content_title'] = 'Super Admin Dashboard';
        $data['content_subtitle'] = '';
        $data['content'] = 'home.php';
        
        $this->load->view('main', $data);
    }

     public function save_company () {

        $id = $this->db->query('SELECT company_id FROM itms_companies ORDER BY company_id DESC LIMIT 1');
        $t2 = $id->result_array();
        $t3 = $t2[0]['company_id'];
        $t4 = $t3 + 1;

        $path = "./uploads/companies/".$t4.""; //get server url

        if(is_dir($path) === false) //create the folder if it's not already exists
        {
          
          mkdir($path,0755,TRUE);
          // var_dump($path);
        } 
        else{
            //echo "directory exits";
        }

        $response = array('add_company'=>false, 'add_services'=>false, 'add_admin'=>false, 'add_menus' =>false, 'add_reports'=>false);
        $data = $this->input->post();
        $data['company_add_user'] = $this->session->userdata('itms_company_id');
        $data['company_date_created'] = date('Y-m-d H:i:s');
        //$data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        $services = isset($data['service']) ? $data['service'] : false;
        
        unset($data['service']);

        if ($data['company_name'] == "") {
            echo $response;
            exit;
        }
 
        $company_id = $this->mdl_admin->save_company($data);
        $now = date('Y-m-d H:i:s');
        $to_3 = strtotime($now) + (24 * 90 * 60 * 60);
        $to_3 = gmdate('Y-m-d H:i:s', $to_3);

        $admin ['company_id'] = $company_id;
        $admin ['username'] = $this->generate_username($data['company_email']);
        $pass = uniqid();
        $admin ['password'] = $this->encrypt->encode($pass);
        $admin ['protocal'] = 7;
        $admin ['phone_number'] = $data ['company_phone_no_1'];
        $admin ['mobile_number'] = $data ['company_phone_no_1'];
        $admin ['email_address'] = $data ['company_email'];
        $admin ['address'] = $data ['company_address_1'];
        $admin ['company_name'] = $data ['company_name']; 
        $admin ['global_admin'] = 7;
        $admin ['add_date'] = date('Y-m-d H:i:s');      
        $admin ['add_uid'] = $this->session->userdata('itms_userid');
        $admin ['sms_alert'] = 1;
        $admin ['email_alert'] = 1;
        $admin ['overspeeding_sms_alert'] = 1;
        $admin ['overspeeding_email_alert'] = 1;
        $admin ['ignition_on_alert'] = 1;
        $admin ['ignition_off_alert'] = 1;
        $admin ['from_date'] = $now;
        $admin ['to_date'] = $to_3;
        $admin ['first_name'] = 'Admin';
        $admin ['user_logo'] = 'user.png';

        if ($company_id=='phone_exists' || $company_id == 'email_exists') {
            echo $company_id;exit;
        }
        
        

        if ($company_id) {

            $response['add_company'] = true;
            $response['company_id'] = $company_id;
            
            if($services) {
                $service = $this->mdl_admin->create_services_subscriptions($company_id, $services);

                if ($service) {
                    $response['add_services'] = true;    
                }
            }    

            $admin_id = $this->mdl_admin->create_company_admin($admin);

            if($admin_id) {
                $response['add_admin'] = true;
                $response['username'] = $admin ['email_address'];
                $dummy_pass = "************";
                $response['password'] = $dummy_pass;

                if ($service) {
                    $menu_ids = $this->mdl_admin->create_menus($admin_id, $company_id, $services);
                    $response['add_menus'] = ($menu_ids) ? true: false;
                    
                    $report_ids = $this->mdl_admin->create_reports($admin_id, $company_id, $services);
                    $response['add_reports'] = ($report_ids) ? true: false;
                    
                }


                $recipient = array($admin['phone_number']);
                $username = $admin['email_address'];
                $to =array($username);
                $subj = 'ITMS Company Account Registration';
                $message = "ITMS Registration Successful. Username : $username and Password : $pass";
                
                $res = $this->smssend->send_text_message ($recipient, $message);

                $email_alert = $this->email_reg_alert ($admin ['company_name'], $admin ['mobile_number'], $admin ['email_address'], $pass, $admin ['address']);
            }    
        }

        echo json_encode($response);
    }
//$company_name, $mobile, $email, $password, $address
    function email_reg_alert ($company_name, $mobile, $email, $password, $address) {

        //$company_name = "test"; $mobile= "test"; $email = "makaweys@gmail.com";$password= "test";$address= "test";

        $to = array($email);
        $subj = "ITMS Company Account Registration";
        $url = "http://178.63.90.134/itmsafrica/assets/images/system/logo1.png";//base_url('assets/images/system/logo1.png');

        
        $message = '<div class="" style="margin-left:100px;width:500px; position:fixed; top:100px; left:30%;background:#f5f5f5;">
                        <div style="background:#101010;border-bottom:6px solid #18bc9c;padding:10px;text-align: center;">
                            <h1><img src="'.$url.'"></h1>
                        </div>
                        <div style="padding:20px;">
                            Dear Registrant,<br><br>
                            Your company <?php echo $company_name; ?> has been registered in ITMS.
                            Your company account is now active.
                            <br>
                            <br>
                            Login Details<br>
                            Username : ' . $email . '<br>
                            Password: ' . $password . ' <br>
                            <br>
                            <br>
                            Verify carefully the Company information.
                            <br>
                            <br>
                            Company Name: ' .  $company_name . ' <br>
                            Mobile Number : ' . $mobile . ' <br>
                            Email : ' . $email . ' <br>
                            Address : ' . $address . ' <br>
                            Creation Date: ' . date("jS M Y H:i:s") . ' <br><br>
                            In case of any doubts, please feel free to contact ITMS Registrar.<br>
                            <a href="#">ITMSLive16@gmail.com</a> on or <a href="#">+254 (0)729 220 777</a>
                            <br>                        
                        </div>
                    </div>';

        return $this->send_email_message ($to, $subj, $message);


    }

    


    function save_services_subs () {
        $data = $this->input->post();

        $company_id = $data['comp_id'];

        unset($data['comp_id']);

        $new_array = array();

        foreach ($data as $key => $value) {
            $arr = array();
            $arr['company_id'] = $company_id;
            $a = explode('_', $key);
            $arr['service_id'] = $a[2];
            $arr['pos'] = $a[0];
            $arr['time'] = $value;

            //echo gmdate('Y-m-d H:i:s', $value);exit;
            array_push($new_array, $arr);
        }

        $final = array();

        foreach ($new_array as $key => $value) {
            $service_id = $value['service_id'];
            $pos = $value['pos'];
            
            if ($pos == 'start') {
                $start = $value['time'];
                //$start = gmdate('Y-m-d H:i:s', $start);
                foreach ($new_array as $k=>$v) {
                    $pos_2 = $v['pos'];
                    $s_2 = $v['service_id'];
                    $end = $v['time'];
                    //$end = gmdate('Y-m-d H:i:s', $end);
                    if ($pos_2 == 'end' && $service_id == $s_2) {
                        $arr = array();

                        $arr['company_id'] = $company_id;
                        $arr['service_id'] = $service_id;
                        $arr['start_date'] = $start;
                        $arr['expiry_date'] = $end;
                        $arr['status'] = 'active';

                        array_push($final, $arr);
                    }
                }

            }
            
        }

        echo $this->mdl_admin->update_service_subscription($final);

    }

    function generate_username($email) {
        $name = explode('@', $email);
        $name = $name[0];
        $name_length = strlen($name);

        if ($name_length < 7) {
            $rem = 7 - $name_length;

            $add = $this->generate_random_number($rem);
            $name = $name . $add;
        } else  if ($name_length > 7){
            $name = substr($name, 0, 7);
        }

        return $name;
    }

    function generate_random_number ($length) {
        $result = '';

        for($i = 0; $i < $length; $i++) {
            $result .= mt_rand(0, 9);
        }

        return $result;
    }

    public function complete_reg ($company_id) {

        $data['company'] = $this->mdl_admin->get_company_details($company_id);
        $data['subscriptions'] = $this->mdl_admin->get_company_services_subscriptions ($company_id);
        

        $data['content_url'] = 'admin/company_reg';
        $data['fa'] = 'fa fa-institution';
        $data['title'] = 'ITMS Africa | Create Subscriptions';
        $data['content_title'] = 'Create Subscriptions';
        $data['content_subtitle'] = 'Complete subscriptions';
        $data['content'] = 'complete_reg.php';
        
        $this->load->view('main', $data);
    }

    /*public function view_services () {

        //$data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));

        //$data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['subscribed_companies'] = $this->mdl_admin_dashboard->get_registered_companies();
        $data['active_companies'] = $this->mdl_admin_dashboard->get_registered_companies('active');
        $data['count_active_companies'] = sizeof($data['active_companies']);
        $data['inactive_companies'] = $this->mdl_admin_dashboard->get_registered_companies('inactive');
        $data['count_inactive_companies'] = sizeof($data['inactive_companies']);

        $data['services'] = $this->mdl_admin_dashboard->get_services(0);
        $data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'admin';
        $data['fa'] = 'fa fa-laptop';
        $data['title'] = 'ITMS Africa | Super Admin';
        $data['content_title'] = 'Super Admin Dashboard';
        $data['content_subtitle'] = '';
        $data['content'] = 'home.php';
        
        $this->load->view('main', $data);
    }

    public function view_subscriptions () {

        //$data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));

        //$data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['subscribed_companies'] = $this->mdl_admin_dashboard->get_registered_companies();
        $data['active_companies'] = $this->mdl_admin_dashboard->get_registered_companies('active');
        $data['count_active_companies'] = sizeof($data['active_companies']);
        $data['inactive_companies'] = $this->mdl_admin_dashboard->get_registered_companies('inactive');
        $data['count_inactive_companies'] = sizeof($data['inactive_companies']);

        $data['services'] = $this->mdl_admin_dashboard->get_services(0);
        $data['count_services'] = sizeof($data['services']);

        $data['content_url'] = 'admin';
        $data['fa'] = 'fa fa-laptop';
        $data['title'] = 'ITMS Africa | Super Admin';
        $data['content_title'] = 'Super Admin Dashboard';
        $data['content_subtitle'] = '';
        $data['content'] = 'home.php';
        
        $this->load->view('main', $data);
    }*/

    public function get_subscriptions_count () {
        $res = $this->mdl_admin_dashboard->get_subscriptions_count ();
        $all = array();
        
        foreach ($res as $k=>$subscription) {
            $data = array();
            array_push($data, $subscription->services_name);
            array_push($data, $subscription->count_subs);

            array_push($all, $data);
        }


        echo json_encode($all);
    }

    function send_email_message ($to, $subj, $message) {
        return $this->emailsend->send_email_message ($to, $subj, $message);
    }
    
}
