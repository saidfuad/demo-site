<?php

class Mdl_dealers extends CI_Model {

    function get_dealers($company_id = null) {
        $this->db->select('itms_dealer_master.*');
        $this->db->from('itms_dealer_master');
        $this->db->where('itms_dealer_master.del_date IS NULL');

        if ($company_id != null) {
            $this->db->where('itms_dealer_master.company_id', $company_id);
        }

        $this->db->order_by('dealer_name', 'ASC');
        $query = $this->db->get();

        return $query->result();
    }

    function save_dealer($data) {
        if ($this->check_dealer_phone_number($data['phone_no'])) {
            return 77;
            exit;
        }

        if ($this->check_dealer_email($data['email'])) {
            return 78;
            exit;
        }

        $query = $this->db->insert('itms_dealer_master', $data);

        if ($query) {
            //$this->session->set_userdata('vehicle_image', '');
            return true;
        }

        return false;
    }

    function edit_dealer($company_id = null) {

        if ($this->session->userdata('protocal') <= 7) {
            $this->db->where('itms_dealer_master.company_id', $company_id);
        }
        $this->db->where('dealer_id', $this->uri->segment(3));
        $query = $this->db->get('itms_dealer_master');

        return $query->result();
    }

    function check_dealer_phone_number($phone_no) {
        $query = $this->db->get_where('itms_dealer_master', array('phone_no' => $phone_no));

        if ($query->num_rows() != 0) {
            return true;
        }

        return false;
    }

    function check_dealer_email($email) {
        $query = $this->db->get_where('itms_dealer_master', array('email' => $email));

        if ($query->num_rows() != 0) {
            return true;
        }

        return false;
    }

    function delete_dealer($dealer_id) {
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql = "UPDATE itms_dealer_master SET del_date = '" . $t . "' WHERE dealer_id ='" . $dealer_id . "'";
        $this->db->query($sql);
    }

    function update_dealer($data) {
        $this->db->where('dealer_id', $data['dealer_id']);
        $this->db->update('itms_dealer_master', $data);
    }

}

?>