<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dealers extends CI_Controller {

    function __construct() {

        parent::__construct();

        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }

        if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

        if ($this->session->userdata('itms_user_id') != "") {
            redirect(home);
        }

        $this->load->model('mdl_dealers');
    }

    public function index() {
        $data['dealers'] = $this->mdl_dealers->get_dealers($this->session->userdata('itms_company_id'));

        $data['content_btn'] = '<a href="' . site_url('dealers/add_dealer') . '" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Dealers</a>';

        $data['content_url'] = 'dealers/Dealers';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Dealers';
        $data['content_title'] = 'Dealers';
        $data['content_subtitle'] = 'Suppliers of goods and services';
        $data['content'] = 'dealers/view_dealers.php';
        $this->load->view('main/main.php', $data);
    }

    public function add_dealer() {
        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') != 0) {
            $map_center = sprintf("%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf("%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }



        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;

        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'dealers/add_dealer';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Dealer';
        $data['content_title'] = 'Add Dealer';
        $data['content_subtitle'] = 'Suppliers of goods and services';
        $data['content'] = 'dealers/add_dealer.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_dealer() {
        $data ['dealer'] = $this->mdl_dealers->edit_dealer($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'dealers/add_dealer';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Dealer';
        $data['content_title'] = 'Add Dealer';
        $data['content_subtitle'] = 'Suppliers of goods and services';
        $data['content'] = 'dealers/edit_dealer.php';
        $this->load->view('main/main.php', $data);
    }

    public function save_dealer() {

        $data = $this->input->post();

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['add_date'] = date('Y-m-d H:i:s');

        //$data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        echo $this->mdl_dealers->save_dealer($data);
    }

    function delete_dealer($dealer_id) {
        $this->mdl_dealers->delete_dealer($dealer_id);
        header('location:' . base_url('index.php/dealers'));
    }

    function update_dealer() {
        $data = array('dealer_id' => $this->input->post('dealer_id'),
            'dealer_name' => $this->input->post('dealer_name'),
            'dealer_in' => $this->input->post('dealer_in'),
            'phone_no' => $this->input->post('phone_no'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address'));

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');


        $this->mdl_dealers->update_dealer($data);
    }

}
