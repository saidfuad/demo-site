<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-dealer-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Edit Dealer Details
	                </div>
	                <div class="panel-body">
	                    <?php foreach ($dealer as $value) { ?>
	                     <input class="form-control" type="hidden" name="dealer_id" id="dealer_id" value="<?php echo $value->dealer_id; ?>" required="required"/>
	                    <div class="form-group">
	                        <label for="reservation">Dealer Name:</label>
	                        <input class="form-control" type="text" name="dealer_name" id="dealer_name" value="<?php echo $value->dealer_name; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Dealer In:</label>
	                        <input class="form-control"type="text"  name="dealer_in" id="dealer_in" value="<?php echo $value->dealer_in; ?>" required="required"/>
	                        	
	                    </div>
	                   
	                    <div class="form-group">
	                        <label for="reservation">Phone <sup>*</sup>:</label>
	                    </div>
	                    <div class="input-group" style="margin-bottom: 20px; margin-top: -15px;">
						  <span class="input-group-addon" id="basic-addon1">+254</span>
						  <input type="text" class="form-control" aria-describedby="basic-addon1" name="phone_no" id="phone_no" value="<?php echo $value->phone_no; ?>" required="required">
						</div>
	                    <div class="form-group">
	                        <label for="reservation">Email:</label>
	                        <input class="form-control" type="text" name="email" id="email" value="<?php echo $value->email; ?>" required="required"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Address:</label>
	                        <input class="form-control" type="text" name="address" id="address" value="<?php echo $value->address; ?>" required="required">
	                    </div>
	                    
	                    
							                    
	                </div>
	                
	            </div>
	            <div class="panel-footer" align="right">
                	<button class="btn btn-primary" type="submit" id="update-dealer">Update</button>
                </div>

	           <?php } ?>
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-file"></i> Dealers</h2>
				<br>
				<p>Dealers are businesses/partners, in-house or 3rd-party entities that service your vehicles, sell or loan vehicles, 
					supply/provide fuel and or spare parts, and or even more.</p>

				<a href="<?php echo site_url('dealers');?>" class="btn btn-success">View Dealers</a>	
			</div>
		</div>

    </div>
</div> 

<!--<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>-->
<script>
        $(function () {

            $('#edit-dealer-form').on('submit' , function () {

				$('#update-dealer').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-dealer').prop('disabled', true);
               // alert ("yes");
               var str1 = "+254";
				str2 = document.getElementById('phone_no').value;

				while( str2.charAt( 0 ) === '0' )
	    		str2 = str2.slice( 1 );

				var res = str1.concat(str2);

				var elem = document.getElementById("phone_no"); 
				var e = elem.value = res;

				if (e.length == 13){
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/dealers/update_dealer') ?>',
                    data: $(this).serialize(),
                    success: function (response) {
                        if (response==0) {
                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
                        } else if (response==1) {
                        	swal({   title: "Error",   text: "Failed to Update, Try again later",   type: "error",   confirmButtonText: "ok" });
                        } 
                        $('#update-dealer').html('Update');
                		$('#update-dealer').prop('disabled', false);
                     }
                });

            }
            else{ 
                        $('#update-dealer').html('Update');
                		$('#update-dealer').prop('disabled', false);
                document.getElementById('phone_no').value="";
            	swal({   title: "Info",   text: "Wrong Phone number",   type: "error",   confirmButtonText: "ok" });
            }

                return false;     
            });

        });
    </script>   