<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($dealers)) {?>
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Dealer Name</th>
                            <th>Dealing In</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($dealers as $key => $value) { ?>
                       <tr class="gradeU">
                            <td><?php echo $value->dealer_name; ?></td>
                            <td><?php echo $value->dealer_in; ?></td>
                            <td><?php echo $value->phone_no; ?></td>
                            <td><?php echo $value->email; ?></td>
                            <td><?php echo $value->address; ?></td>
                             <td><?php echo "<a data-placement='top' data-toggle='tooltip' data-original-title='Delete Dealers' href='".base_url('index.php/dealers/delete_dealer/'.$value->dealer_id)
                                            ."'class='btn btn-xs btn-danger'><span class='fa fa-trash'onclick='javascript:return confirm(\"Are you sure you want to delete?\")'></span></a>
                                                <a data-placement='top' data-toggle='tooltip' data-original-title='Edit Dealers'  href='".base_url('index.php/dealers/edit_dealer/'.$value->dealer_id)
                                                ."'class='btn btn-xs btn-success'><span class='fa fa-pencil'></span></a>"?></td>
                        </tr>
                    <?php }?>
                    </tbody>
                </table>
            </div>
            <?php } else {?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-file"></i> Dealers</h2>
                    <br>
                    <p>Dealers are businesses/partners, in-house or 3rd-party entities that service your vehicles, sell or loan vehicles, 
                        supply/provide fuel and or spare parts, and or even more.</p>

                    <a href="<?php echo site_url('dealers/add_dealer');?>" class="btn btn-success">Add Dealers</a>    
                </div>
            <?php } ?>
            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>