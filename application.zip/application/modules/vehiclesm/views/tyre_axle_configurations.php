<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form>
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   TPMS Devices Integration
	                </div>
	                <div class="panel-body">
	                    
	                    <div class="form-group">
	                        <label for="reservation">Select Vehicle:</label>
	                        <select class="form-control" type="text" name="asset_id" id="asset_id" required="required">
	                        	<option value="0">-- Select Vehicle --</option>
	                        	<?php foreach ($vehicles as $key => $vehicle) { ?>
	                        		<option value="<?php echo $vehicle->asset_id; ?>"><?php echo $vehicle->assets_name .'-'.$vehicle->assets_friendly_nm ; ?></option>
	                        	<?php }?>
	                        </select>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">No of Axles:</label>
	                        <input class="form-control" type="number" min="1" name="axle_no" id="axle_no" required="required"/>
	                        
	                    </div>
	                    <div class="form-group" id="axles-configs">
	                        <label for="reservation">Axle Tyre configurations: (from the front axle)</label>
		                    
						</div>	
                    </div>
	                    
	                    						                    
                </div>
	                <div class="panel-footer" align="right">
	                	<button class="btn btn-primary" type="submit">Save Configurations</button>
	                </div>
	            </div>
			</form>

			<div class="col-md-6 col-lg-6">
				<div class="bg-crumb">
					<div class="row">
					<div class="col-md-6 fleet-sidebar">
			            <div class="panel fleet-panel panel-blockquote panel-border-info right">
			                <div class="panel-body">
			                    <!-- Car image -->
			                    <div class="text-center fleet-img">
			                        <img width="150" src="https://c1.staticflickr.com/7/6233/6355693919_fa8d88f9db_n.jpg" alt="" class="img-rounded">
			                    </div>

			                    <!-- Title/Car name -->
			                    <h3 class="sidebar-title text-center">BMW 3 Series</h3>

			                    <!-- Car stats -->
			                    <ul class="fleet-stats">
			                        <li>
			                            <div ng-controller="odometerController">
			                                <i class="fa fa-signal text-muted" data-toggle="tooltip" data-placement="top" title="Odometer"></i> <a href="#" data-toggle="tooltip" data-placement="right" title="Last updated {{vehcileOdometer.lastUpdate}}">{{vehcileOdometer.value}}</a> <span class="text-muted">km</span> <a href="#" data-toggle="modal" data-target="#odometerUpdater"><i class="fa fa-pencil-square text-info" data-toggle="tooltip" data-placement="top" title="Edit odometer"></i></a>

			                                <!-- Odometer Updater Modal -->
			                                <div class="modal fade" id="odometerUpdater" tabindex="-1" role="dialog" aria-labelledby="odometerUpdaterLabel" aria-hidden="true">
			                                    <div class="modal-dialog">
			                                        <div class="modal-content">
			                                            <div class="modal-header">
			                                                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			                                                <h4 class="modal-title" id="odometerUpdaterLabel">Update Odometer</h4>
			                                            </div>
			                                            <div class="modal-body">
			                                                <table class="table">
			                                                    <tr>
			                                                        <td>Odometer Value</td>
			                                                        <td><input type="text" ng-model="vehcileOdometer.value"><br /><span class="text-muted">Last value was {{vehcileOdometer.lastValue}} on {{vehcileOdometer.lastUpdate}}</span></td>
			                                                    </tr>
			                                                </table>
			                                            </div>
			                                        </div>
			                                    </div>
			                                </div>
			                            </div>
			                        </li>
			                        <li>
			                            <div ng-controller="vehicleStatusController">
			                                <i class="fa fa-flag text-muted" data-toggle="tooltip" data-placement="top" title="Veicle status"></i> <a href="#" data-toggle="modal" data-target="#statusUpdater">{{vehicleStatus.value}}</a>

			                                <!-- Status Updater Modal -->
			                                <div class="modal fade" id="statusUpdater" tabindex="-1" role="dialog" aria-labelledby="statusUpdaterLabel" aria-hidden="true">
			                                    <div class="modal-dialog">
			                                        <div class="modal-content">
			                                            <div class="modal-header">
			                                                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			                                                <h4 class="modal-title" id="statusUpdaterLabel">Update Status</h4>
			                                            </div>
			                                            <div class="modal-body">
			                                                <table class="table">
			                                                    <tr>
			                                                        <td>Vehicle Status</td>
			                                                        <td>
			                                                            <select ng-model="vehicleStatus.value">
			                                                                <option value="Active">Active</option>
			                                                                <option value="Inactive">Inactive</option>
			                                                            </select>
			                                                        </td>
			                                                    </tr>
			                                                </table>
			                                            </div>
			                                        </div>
			                                    </div>
			                                </div>
			                            </div>
			                        </li>
			                        <li>
			                            <i class="fa fa-tag text-info" data-toggle="tooltip" data-placement="top" title="Vehicle type"></i> <a href="#">Car</a>
			                        </li>    
			                        <li>
			                            <i class="fa fa-map-marker text-warning" data-toggle="tooltip" data-placement="top" title="Location"></i> New York, NY, USA
			                        </li>
			                    </ul>
			                    </div>
			                </div>
			            </div>
                    </div>
				</div>	
			</div>
	           
			</div>
		
		

    </div>
</div> 

<!--<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>-->
<script type="text/javascript">
	$(function () {
		$('#asset_id').on('change', function () {
			var asset_id = $(this).val();
			//alert();
			if (asset_id!=0) {
				$.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/vehicles/get_vehicle_by_id') ?>',
                    data: {asset_id:asset_id},
                    success: function (response) {
                        vehicle = JSON.parse(response);

                        alert(vehicle.asset_id);
                     }
                });
			}



			return false;

		});


		$('#axle_no').on('keyup', function () {
			var axle_no = $(this).val();
			
			if (axle_no !="" && axle_no > 0) {
				set_axles(axle_no);
			}
 			
		});

		$('#axle_no').on('change', function () {
			var axle_no = $(this).val();
 			
 			if (axle_no !="" && axle_no > 0) {
				set_axles(axle_no);
			}
		});

		function set_axles (axle_no) {
			$selects = '';
			
			$count = 1;
			for(i=0; i<axle_no; i++) { 
				
				$('#axles-configs').append('<div class="col-md-12 col-lg-12">'	
												+'<div class="col-md-3 col-lg-3">'
													+'<h4>Axle '+ $count +'</h4>'
												+'</div>'
												+'<div class="col-md-9 col-lg-9">'
													+'<select class="form-control axle_config" type="text" name="axle'+$count+'config" id="axle1config" required="required">'
														+'<option value="S">Single tyre Axle</option>'
														+'<option value="SR">Single tyre retractable Axle</option>'
														+'<option value="T">Twin Tyre Axle</option>'
														+'<option value="TR">Twin Tyre retractable Axle</option>'
							                		+'</select>'
												+'</div>'
											+'</div>');

				$count++;				
			}
		}

	});
</script>