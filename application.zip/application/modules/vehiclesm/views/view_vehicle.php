<div class="container-fluid fleet-view">
    <div class="row" ng-app>
        <!-- Sidebar -->
        <div class="col-md-3 fleet-sidebar">
            <div class="panel fleet-panel panel-blockquote panel-border-info right">
                <div class="panel-body">
                    <!-- Car image -->
                    <div class="text-center fleet-img">
                        <img width="170" height="150" src="<?php echo base_url('assets/images/photos/car2.jpg')?>" alt="" class="img-rounded">
                    </div>
                    <?php foreach ($vehicle as $value) { ?>
                    <!-- Title/Car name -->
                    <h3 class="sidebar-title text-center"><?php echo $value->assets_friendly_nm; ?></h3>


                </div>
            </div>
        </div>
        <!-- Sidebar -->
           <!-- Content -->
        <div class="col-md-9 fleet-content">
            <!-- Content Panel -->
            <div class="panel fleet-panel panel-blockquote">
                <div class="panel-body">
                    <!-- Fleet title -->
                    <h1 id="fleet-car-title"><i class="fa fa-car"></i><?php echo $value->assets_friendly_nm; ?></h1>
                    <div class="separator bottom"></div>

                    <!-- Details Content -->
                    <div class="row">
                        <div class="col-md-6">
                            <!-- Details -->
                            <div class="panel panel-blockquote panel-border-success left" id="fleet-car-details">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Details</h3>
                                    <!-- Panel Menu -->
                                    <div class="panel-menu">
                                        <button type="button" data-action="minimize" class="btn btn-default btn-action btn-xs tooltips hidden-xs hidden-sm" data-original-title="Minimize" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-angle-down"></i></button>
                                        <button type="button" data-action="reload" class="btn btn-default btn-action btn-xs tooltips" data-original-title="Reload" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-refresh"></i></button>
                                        <button type="button" data-action="settings" class="btn btn-default btn-action btn-xs tooltips dropdown-toggle hidden-xs hidden-sm" data-toggle="dropdown" data-original-title="" title=""><i class="fa fa-cog"></i></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="#"><i class="fa fa-comment"></i> Add a note</a></li>
                                            <li><a href="#"><i class="fa fa-tasks"></i> Add to Tasks</a></li>
                                            <li><a href="#"><i class="fa fa-map-marker"></i> Pin to TaskBar</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#"><i class="fa fa-refresh"></i> Reload Content</a></li>
                                            <li class="divider"></li>
                                            <li><a href="#"><i class="fa fa-bell"></i> Alert(s) <input type="checkbox" class="switcher pull-right" /></a></li>
                                            <li><a href="#"><i class="fa fa-lock"></i> Privacy <input type="checkbox" class="switcher pull-right" checked /></a></li>
                                        </ul>
                                        <button type="button" data-action="close" class="btn btn-warning btn-action btn-xs tooltips" data-original-title="Remove" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-times"></i></button>
                                    </div>
                                    <!-- Panel Menu -->
                                </div>
                                <div class="panel-body">
                                    <table class="table table-list">
                                        <tbody>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">Type</td>
                                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right col-md-3">Driver</td>
                                                <td><?php if (strlen($value->driver_name)!=0 || $value->driver_name != 0) {echo $value->driver_name;} else { echo 'Not Assigned';} ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Device ID</td>
                                                <td><?php if (strlen($value->device_id)!=0) {echo $value->device_id;} else { echo 'Not Set';} ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Status</td>
                                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Type</td>
                                                <td><?php echo $value->assets_type_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Category</td>
                                                <td><?php echo $value->assets_cat_name; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">VIN/SN</td>
                                                <td>zzzz123123</td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Year</td>
                                                <td>2005</td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Make</td>
                                                <td><?php echo $value->assets_friendly_nm; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Model</td>
                                                <td>
                                                    3 Series
                                                    <br>
                                                    <small>330i Sedan 4D</small>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">License Plate</td>
                                                <td><?php echo $value->assets_name; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Registration State/Province</td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Color</td>
                                                <td>White</td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Fuel Volume Unit</td>
                                                <td>Liters</td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted text-right">Fuel Type</td>
                                                <td><span class="text-muted">Not Set</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php }?>


                            
                        </div>
                        <div class="col-md-6">
                            <!-- Stats -->
                            <div class="panel panel-square" id="fleet-car-stats">
                                <div class="panel-heading panel-info clearfix">
                                    <h3 class="panel-title">Stats</h3>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="media media-info">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-road"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading">$2.25</div>
                                                    <div class="caption">Cost/Km</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="media media-warning">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-tint"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading">13.5</div>
                                                    <div class="caption">MPG (US)</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="media media-info">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-wrench"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading">$625.00</div>
                                                    <div class="caption">Service Costs</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="media media-danger">
                                                <div class="pull-left">
                                                    <div class="media-object fleet-icon">
                                                        <i class="fa fa-tint"></i>
                                                    </div>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-heading">$389.35</div>
                                                    <div class="caption">Fuel Costs</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Issues -->

                            <div class="panel panel-square">
                                <div class="panel-heading panel-info clearfix">
                                    <h3 class="panel-title">Issues</h3>
                                </div>
                                <div class="panel-body fleet-issues">
                                    <div class="row">
                                        <div class="col-sm-4 text-center">
                                            <h1 class="success">5</h1>
                                            <span class="caption">Open</span>
                                        </div>
                                        <div class="col-sm-4 text-center">
                                            <h1 class="success">0</h1>
                                            <span class="caption">Overdue</span>
                                        </div>
                                        <div class="col-sm-4 text-center">
                                            <h1 class="info">3</h1>
                                            <span class="caption">Resolved</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <!-- Service Reminders -->
                                <div class="col-md-6">
                                    <div class="panel panel-square">
                                        <div class="panel-heading panel-info clearfix">
                                            <h3 class="panel-title">Service Reminders</h3>
                                        </div>
                                        <div class="panel-body fleet-issues">
                                            <div class="row">
                                                <div class="col-sm-6 text-center">
                                                    <h1 class="success">3</h1>
                                                    <span class="caption">Open</span>
                                                </div>
                                                <div class="col-sm-6 text-center">
                                                    <h1 class="warning">1</h1>
                                                    <span class="caption">Overdue</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Renewal Reminders -->
                                <div class="col-md-6">
                                    <div class="panel panel-square">
                                        <div class="panel-heading panel-info clearfix">
                                            <h3 class="panel-title">Renewel Reminders</h3>
                                        </div>
                                        <div class="panel-body fleet-issues">
                                            <div class="row">
                                                <div class="col-sm-6 text-center">
                                                    <h1 class="success">4</h1>
                                                    <span class="caption">Open</span>
                                                </div>
                                                <div class="col-sm-6 text-center">
                                                    <h1 class="success">0</h1>
                                                    <span class="caption">Overdue</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- //. Content -->
    </div>
    <!-- /.row -->
</div>