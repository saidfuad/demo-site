<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="add-vehicle-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Basic Details (<span style="text-transform:lowercase"><sup title="Required field">*</sup> Required fields</span>)
	                </div>
	                <div class="panel-body">
	                    
	                    <div class="form-group">
	                        <label for="reservation">Vehicle Name <sup title="Required field">*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_friendly_nm" id="assets_friendly_nm" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Plate Number <sup title="Required field">*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_name" id="assets_name" />
	                    </div>
	                    <!-- <div class="form-group">
	                        <label for="reservation">Vehicle Type <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="assets_type_id" id="assets_type_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $typeOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<label class="control-lable">Vehicle Type</label>
							<input type="text" id="assets_type_id" autocomplete="off" name="assets_type_id" class="form-control" placeholder="">        
							<ul class="dropdown-menu txt_type" style="margin-top: -629px;margin-left: 31px;border-radius: 5px; width:300px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownType">
							</ul>
	                    </div>
	                    <script type="text/javascript">
	                    	$(document).ready(function () {
							    $("#assets_type_id").keydown(function () {
							        $.ajax({
							            type: "POST",
							            url: "http://localhost/itmsafrica/index.php/vehicles/gettype",
							            data: {
							                keyword: $("#assets_type_id").val()
							            },
							            dataType: "json",
							            success: function (data) {
							                if (data.length > 0) {
							                    $('#DropdownType').empty();
							                    $('#assets_type_id').attr("data-toggle", "dropdown");
							                    $('#DropdownType').dropdown('toggle');

							                }
							                else if (data.length == 0) {
							                    $('#assets_type_id').attr("data-toggle", "");
							                }
							                $.each(data, function (key,value) {
							                    if (data.length >= 0)
							                        $('#DropdownType').append('<li style="font-size:14px;margin-left:5px;" role="presentation" >' + value['assets_type_nm'] + '</li>');
							                });
							            }
							        });
							    });
							    $('ul.txt_type').on('click', 'li', function () {
							        $('#assets_type_id').val($(this).text());
							    });
							});
	                    </script>
	                    <!-- <div class="form-group">
	                        <label for="reservation">Vehicle Category <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="assets_category_id" id="assets_category_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $categoryOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<label class="control-lable">Vehicle Category</label>
							<input type="text" id="assets_category_id" autocomplete="off" name="assets_category_id" class="form-control" placeholder="">        
							<ul class="dropdown-menu cat" style="margin-top: -557px;margin-left: 31px;border-radius: 5px; width:300px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownCategory">
							</ul>
	                    </div>
	                    <script type="text/javascript">
	                    	$(document).ready(function () {
							    $("#assets_category_id").keydown(function () {
							        $.ajax({
							            type: "POST",
							            url: "http://localhost/itmsafrica/index.php/vehicles/getrow",
							            data: {
							                keyword: $("#assets_category_id").val()
							            },
							            dataType: "json",
							            success: function (data) {
							                if (data.length > 0) {
							                    $('#DropdownCategory').empty();
							                    $('#assets_category_id').attr("data-toggle", "dropdown");
							                    $('#DropdownCategory').dropdown('toggle');

							                }
							                else if (data.length == 0) {
							                    $('#assets_category_id').attr("data-toggle", "");
							                }
							                $.each(data, function (key,value) {
							                    if (data.length >= 0)
							                        $('#DropdownCategory').append('<li style="font-size:14px;margin-left:5px;" role="presentation" >' + value['assets_cat_name'] + '</li>');
							                });
							            }
							        });
							    });
							    $('ul.cat').on('click', 'li', function () {
							        $('#assets_category_id').val($(this).text());
							    });
							});
	                    </script>
	                    <!-- <div class="form-group">
	                        <label for="reservation">Owner <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="owner_id" id="owner_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $ownerOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<label class="control-lable">Owner</label>
							<input type="text" id="owner_id" autocomplete="off" name="owner_id" class="form-control" placeholder="">        
							<ul class="dropdown-menu txt_owner" style="margin-top: -484px;margin-left: 31px;border-radius: 5px; width:300px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownOwner">
							</ul>
	                    </div>
	                    <script type="text/javascript">
	                    	$(document).ready(function () {
							    $("#owner_id").keydown(function () {
							        $.ajax({
							            type: "POST",
							            url: "http://localhost/itmsafrica/index.php/vehicles/getowner",
							            data: {
							                keyword: $("#owner_id").val()
							            },
							            dataType: "json",
							            success: function (data) {
							                if (data.length > 0) {
							                    $('#DropdownOwner').empty();
							                    $('#owner_id').attr("data-toggle", "dropdown");
							                    $('#DropdownOwner').dropdown('toggle');

							                }
							                else if (data.length == 0) {
							                    $('#owner_id').attr("data-toggle", "");
							                }
							                $.each(data, function (key,value) {
							                    if (data.length >= 0)
							                        $('#DropdownOwner').append('<li style="font-size:14px;margin-left:5px;" role="presentation" >' + value['owner_name'] + '</li>');
							                });
							            }
							        });
							    });
							    $('ul.txt_owner').on('click', 'li', function () {
							        $('#owner_id').val($(this).text());
							    });
							});
	                    </script>
	                    <!-- <div class="form-group">
	                        <label for="reservation">Assign Driver:</label>
	                        <select class="form-control" name="personnel_id" id="personnel_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $driverOpt; ?>
							</select>
	                    </div> -->
	                    <div class="form-group">
	                    	<label class="control-lable">Assign Driver</label>
							<input type="text" id="personnel_id" autocomplete="off" name="personnel_id" class="form-control" placeholder="">        
							<ul class="dropdown-menu txt_driver" style="margin-top: -413px;margin-left: 31px;border-radius: 5px; width:300px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownDriver">
							</ul>
	                    </div>
	                    <script type="text/javascript">
	                    	$(document).ready(function () {
							    $("#personnel_id").keydown(function () {
							        $.ajax({
							            type: "POST",
							            url: "http://localhost/itmsafrica/index.php/vehicles/getdriver",
							            data: {
							                keyword: $("#personnel_id").val()
							            },
							            dataType: "json",
							            success: function (data) {
							                if (data.length > 0) {
							                    $('#DropdownDriver').empty();
							                    $('#personnel_id').attr("data-toggle", "dropdown");
							                    $('#DropdownDriver').dropdown('toggle');

							                }
							                else if (data.length == 0) {
							                    $('#personnel_id').attr("data-toggle", "");
							                }
							                $.each(data, function (key,value) {
							                    if (data.length >= 0)
							                        $('#DropdownDriver').append('<li style="font-size:14px;margin-left:5px;" role="presentation" >' + value['driver_name'] + '</li>');
							                });
							            }
							        });
							    });
							    $('ul.txt_driver').on('click', 'li', function () {
							        $('#personnel_id').val($(this).text());
							    });
							});
	                    </script>

	                    
					</div>
	            </div>

	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Vehicle Settings
	                </div>
	                <div class="panel-body">
	                    
	                     <div class="form-group">
	                        <label for="reservation">Maximum Fuel Capacity:</label>
	                        <input class="form-control" type="text" name="max_fuel_capacity" id="max_fuel_capacity" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Maximum Fuel Liters:</label>
	                        <input class="form-control" type="number" name="max_fuel_liters" id="max_fuel_liters"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Maximum Speed:</label>
	                        <input class="form-control" type="number" name="max_speed_limit" id="max_speed_limit"/>
	                    </div>
	                    
					</div>
	            </div>
	            <div class="panel-footer " align="right">
	            	<button class="btn btn-primary" type="submit" id="save-vehicle">Save </button>
	            </div>

	            
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="panel panel-default">
                <div class="panel-heading">
                    Upload Vehicle Image
                </div>
                <div class="panel-body">
                    <div id="dropzone">
				    	<form action="<?php echo base_url('index.php/upload_images/upload_vehicle_image') ?>" class="dropzone" id="dropzone-container">
				    		<div class="fallback">
				    	    	<input name="file" type="file" multiple />
				    	  	</div>
				    	</form>
				    </div>
                </div>
            </div>

            <div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-car"></i> Vehicles</h2>
				<br>
				<p>Manage Vehicles and begin monitoring your assets Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

				<a href="<?php echo site_url('vehicles');?>" class="btn btn-success">View Vehicles</a>	
			</div>

		</div>

    </div>
</div> 

<script src="<?php echo  base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>  

<script>
        $(function () {

            $('#add-vehicle-form').on('submit' , function () {

				if ($('#assets_friendly_nm').val().trim().length ==0 || $('#assets_name').val().trim().length ==0 || 
						$('#assets_type_id').val().trim()==0 || $('#assets_category_id').val().trim()==0 ||
							$('#owner_id').val().trim() ==0) {
					swal({   title: "Info",   text: "Fill in all required fields ( * )",   type: "info",   confirmButtonText: "ok" });
					return false;
				}

				$('#save-vehicle').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#save-vehicle').prop('disabled', true);
               

                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/vehicles/save_vehicle') ?>',
                    data: $(this).serialize(),
                    success: function (response) {
                        if (response==1) {
                        	$('#add-vehicle-form').find('input[type="text"]').val('');
                        	$('#add-vehicle-form').find('select').val(0);
                        	swal({   title: "Info",   text: "Saved successfully",   type: "success",   confirmButtonText: "ok" });
                        } else if (response==0) {
                        	swal({   title: "Error",   text: "Failed, Try again later",   type: "error",   confirmButtonText: "ok" });
                        } else if (response==77) {
                        	swal({   title: "Info",   text: "A vehicle with that plate number already exists",   type: "error",   confirmButtonText: "ok" });
                        }

                        $('#save-vehicle').html('Save');
                		$('#save-vehicle').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
    </script> 
    