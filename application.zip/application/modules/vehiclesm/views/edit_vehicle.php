<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-vehicle-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Basic Details (<span style="text-transform:lowercase"><sup title="Required field">*</sup> Required fields</span>)
	                </div>
	                <div class="panel-body">
	                    
	                    <input class="form-control" type="hidden" name="asset_id" id="asset_id" value="<?php echo $vehicle['asset_id']; ?>" />
	                    <div class="form-group">
	                        <label for="reservation">Vehicle Name <sup title="Required field">*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_friendly_nm" id="assets_friendly_nm" value="<?php echo $vehicle['assets_friendly_nm']; ?>" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Plate Number <sup title="Required field">*</sup>:</label>
	                        <input class="form-control" type="text" name="assets_name" id="assets_name" value="<?php echo $vehicle['assets_name']; ?>" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Vehicle Type <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="assets_type_id" id="assets_type_id">
	                        	<option value="0">--Select type--</option>
							  	<?php echo $typeOpt; ?>
							</select>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Vehicle Category <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="assets_category_id" id="assets_category_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $categoryOpt; ?>
							</select>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Owner <sup title="Required field">*</sup>:</label>
	                        <select class="form-control" name="owner_id" id="owner_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $ownerOpt; ?>
							</select>
	                    </div>

	                    <div class="form-group">
	                        <label for="reservation">Assign Driver:</label>
	                        <select class="form-control" name="personnel_id" id="personnel_id">
	                        	<option value="0">--Select--</option>
							  	<?php echo $driverOpt; ?>
							</select>
	                    </div>
	                   

					</div>
	            </div>

	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    Vehicle Settings
	                </div>
	                <div class="panel-body">
	                    
	                     <div class="form-group">
	                        <label for="reservation">Maximum Fuel Capacity:</label>
	                        <input class="form-control" type="text" name="max_fuel_capacity" id="max_fuel_capacity" value="<?php echo $vehicle['max_fuel_capacity']; ?>" />
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Maximum Fuel Liters:</label>
	                        <input class="form-control" type="number" name="max_fuel_liters" id="max_fuel_liters" value="<?php echo $vehicle['max_fuel_liters']; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Maximum Speed:</label>
	                        <input class="form-control" type="number" name="max_speed_limit" id="max_speed_limit"  value="<?php echo $vehicle['max_speed_limit'] ?>"/>
	                    </div>
	                    
					</div>
	            </div>
	            <div class="panel-footer " align="right">
	            	<button class="btn btn-primary" type="submit" id="update-vehicle">Update </button>
	            </div>

	            
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="panel panel-default">
                <div class="panel-heading">
                    Upload Vehicle Image
                </div>
                <div class="panel-body">
                    <div id="dropzone">
				    	<form action="<?php echo base_url('index.php/upload_images/upload_vehicle_image') ?>" class="dropzone" id="dropzone-container">
				    		<div class="fallback">
				    	    	<input name="file" type="file" multiple />
				    	  	</div>
				    	</form>
				    </div>
                </div>
            </div>

            <!--<div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-car"></i> Vehicles</h2>
				<br>
				<p>Manage Vehicles and begin monitoring your assets Location, Fuel usage driver efficiency and schedule preventative maintenance</p>

				<a href="<?php echo site_url('vehicles/groups');?>" class="btn btn-success">View Groups</a>	
			</div>-->

		</div>

    </div>
</div> 

<script src="<?php echo  base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>  

<script>
   $(function () {

            $('#edit-vehicle-form').on('submit' , function () {

				$('#update-vehicle').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-vehicle').prop('disabled', true);
               // alert ("yes");
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/vehicles/update_vehicle') ?>',
                    data: $(this).serialize(),
                    success: function (response) {

                        if (response) {
                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
                        } else {
                        	swal({   title: "Error",   text: "Failed to Update, Try again later",   type: "error",   confirmButtonText: "ok" });
                        } 
                        $('#update-vehicle').html('Update');
                		$('#update-vehicle').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });     
</script> 
    