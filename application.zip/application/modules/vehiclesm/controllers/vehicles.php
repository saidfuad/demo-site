<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicles extends CI_Controller {

	function __construct() {

        parent::__construct();
		
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
		
		if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

		if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

        $this->load->model('mdl_vehicles');
        $this->load->model('mdl_categories');
        $this->load->model('mdl_types');
        $this->load->model('mdl_owners');
        $this->load->model('personnel/mdl_personnel');

    }

	public function index() {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
        
        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicles';
        $data['content_title'] = 'Vehicles';
        $data['content_subtitle'] = 'vehicles list, owners and status';
        $data['content'] = 'vehicles/view_vehicles.php';
        $this->load->view('main/main.php', $data);
    }


   

    public function fetch_vehicles () {
        return $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
    }
   public function drive () {
        $query = $this->mdl_vehicles->get_driver($this->session->userdata('itms_company_id'));
        // echo $query;
        print_r($query);       
    }
    public function fetch () {
        $value = array();
        if ($data=$this->mdl_vehicles->get_vehicle()) {
            $value['vehicle']=$data;
        }
         $this->load->view('view_vehicle', $value);
    }
    public function fetch_vehicle () {
        $data['vehicle'] = $this->mdl_vehicles->get_vehicle($this->session->userdata('itms_company_id'));

        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicle';
        $data['content_title'] = 'Vehicle';
        $data['content_subtitle'] = 'Vehicle Details';
        $data['content'] = 'vehicles/view_vehicle.php';
        $this->load->view('main/main.php', $data);
    }
    function delete_vehicle($asset_id){
        $this->mdl_vehicles->delete_vehicle($asset_id);
        header('location:'.base_url('index.php/vehicles'));
    }
    function datetime(){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        echo $t;
    }
    public function edit_vehicle ($asset_id) {

        $categoryOpt = '';
        $categoryList = '';
        $typeOpt = '';
        $typeList = '';    
        $ownerOpt = '';
        $ownersList = '';
        $driverOpt = '';
        $driversList = '';

        $data['vehicle'] = $this->mdl_vehicles->get_vehicle_by_id ($asset_id);
        $vdetails =  $data['vehicle'];

        $categories = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        if(count($categories)) {
            foreach ($categories as $cat) {
                if($cat->assets_category_id == $vdetails['assets_category_id']) {
                    $selected = 'selected=selected';
                } else {
                    $selected = "";
                }

                $categoryOpt .= "<option value='".$cat->assets_category_id."' " . $selected .">".addslashes($cat->assets_cat_name)."</option>";
                //$categoryList .= "<li assets-category-id='".$cat->assets_category_id."'><a href=''>".addslashes($cat->assets_cat_name)."</a></li>";
            }
        }

        //echo $vdetails['assets_type_id'];
        //exit;

        $types = $this->mdl_types->get_all_types($this->session->userdata('itms_company_id'));
        if(count($types)) {
            foreach ($types as $type) {
                 if($type->assets_type_id == $vdetails['assets_type_id']) {
                    $selected = 'selected=selected';
                } else {
                    $selected = "";
                }

                $typeOpt .= "<option value='".$type->assets_type_id."' ". $selected .">".addslashes($type->assets_type_nm)."</option>";
                //$typeList .= "<li assets-type-id='".$type->assets_type_id."'><a href=''>".addslashes($type->assets_type_nm)."</a></li>";
            }
        }

        $owners = $this->mdl_owners->get_all_owners($this->session->userdata('itms_company_id'));
        foreach ($owners as $owner)
        {
            if($owner->owner_id == $vdetails['owner_id']) {
                $selected = 'selected=selected';
            } else {
                $selected = "";
            }

            $ownerOpt .= "<option value='".$owner->owner_id."' ". $selected .">".$owner->owner_name."</option>";
            //$ownersList .= "<li data-id='".$owner->owner_id."'><a href=''>".addslashes($owner->owner_name)."</a></li>";
        }

        $drivers = $this->mdl_personnel->get_personnel ($this->session->userdata('itms_company_id'), $role_id=2, $user_id=null);
        foreach ($drivers as $driver)
        {
            if($driver->personnel_id == $vdetails['driver_id']) {
                $selected = 'selected=selected';
            } else {
                $selected = "";
            }

            $driverOpt .= "<option value='".$driver->personnel_id."' ". $selected .">".$driver->fname." ".$driver->lname."</option>";
            //$driversList .= "<li data-id='".$driver->personnel_id."'><a href=''>".addslashes($driver->fname)." ".addslashes($driver->lname)."</a></li>";
        }

        
        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Edit Vehicle';
        $data['content_title'] = 'Edit Vehicle Details';
        $data['content_subtitle'] = 'Vehicle Details';
        $data['categoryOpt'] = $categoryOpt;
        $data['typeOpt'] = $typeOpt;
        $data['ownerOpt'] = $ownerOpt;
        $data['driverOpt'] = $driverOpt;

        $data['content'] = 'vehicles/edit_vehicle.php';
        $this->load->view('main/main.php', $data);
    }

    public function update_vehicle () {
        $data = array('asset_id' => $this->input->post('asset_id'),
                      'assets_friendly_nm' => $this->input->post('assets_friendly_nm'),
                      'assets_name' => $this->input->post('assets_name'),
                      'assets_type_id' => $this->input->post('assets_type_id'),
                      'assets_category_id' => $this->input->post('assets_category_id'), 
                      'owner_id' => $this->input->post('owner_id'), 
                      'personnel_id' => $this->input->post('personnel_id'), 
                      'max_fuel_capacity' => $this->input->post('max_fuel_capacity'),
                      'max_fuel_liters' => $this->input->post('max_fuel_liters'), 
                      'max_speed_limit' => $this->input->post('max_speed_limit'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        
        $this->mdl_vehicles->update_vehicle($data);
    }

    public function get_vehicle_by_id () {
        $asset_id = $this->input->post('asset_id');

        $res = $this->mdl_vehicles->get_vehicle_by_id($asset_id);
        echo json_encode($res);
    }

    public function add_vehicle () {

        $categoryOpt = '';
        $categoryList = '';
        $typeOpt = '';
        $typeList = '';    
        $ownerOpt = '';
        $ownersList = '';
        $driverOpt = '';
        $driversList = '';

        $categories = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));


        
        if(count($categories)) {
            foreach ($categories as $cat) {
                $categoryOpt .= "<option value='".$cat->assets_category_id."'>".addslashes($cat->assets_cat_name)."</option>";
                $categoryList .= "<li assets-category-id='".$cat->assets_category_id."'><a href=''>".addslashes($cat->assets_cat_name)."</a></li>";
            }
        }

        $types = $this->mdl_types->get_all_types($this->session->userdata('itms_company_id'));
        if(count($types)) {
            foreach ($types as $type) {
                $typeOpt .= "<option value='".$type->assets_type_id."'>".addslashes($type->assets_type_nm)."</option>";
                $typeList .= "<li assets-type-id='".$type->assets_type_id."'><a href=''>".addslashes($type->assets_type_nm)."</a></li>";
            }
        }

        $owners = $this->mdl_owners->get_all_owners($this->session->userdata('itms_company_id'));
        //print_r($categories);
        //exit;
        foreach ($owners as $owner)
        {
            $ownerOpt .= "<option value='".$owner->owner_id."'>".$owner->owner_name."</option>";
            $ownersList .= "<li data-id='".$owner->owner_id."'><a href=''>".addslashes($owner->owner_name)."</a></li>";
        }

        $drivers = $this->mdl_personnel->get_personnel ($this->session->userdata('itms_company_id'), $role_id=2, $user_id=null);
        foreach ($drivers as $driver)
        {
            $driverOpt .= "<option value='".$driver->personnel_id."'>".$driver->fname." ".$driver->lname."</option>";
            $driversList .= "<li data-id='".$driver->personnel_id."'><a href=''>".addslashes($driver->fname)." ".addslashes($driver->lname)."</a></li>";
        }

        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_vehicle';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Vehicle';
        $data['content_title'] = 'Add Vehicle';
        $data['content_subtitle'] = '';
        $data['categoryOpt'] = $categoryOpt;
        $data['typeOpt'] = $typeOpt;
        $data['ownerOpt'] = $ownerOpt;
        $data['driverOpt'] = $driverOpt;
        $data['content'] = 'vehicles/add_vehicle.php';
        $this->load->view('main/main.php', $data);
    }

    public function getrow(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_vehicles->getrow($keyword);      
        echo json_encode($data);
    }
    public function gettype(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_vehicles->gettype($keyword);      
        echo json_encode($data);
    }

    public function getowner(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_vehicles->getowner($keyword);      
        echo json_encode($data);
    }

    public function getdriver(){
        $keyword=$this->input->post('keyword');
        $data=$this->mdl_vehicles->getdriver($keyword);      
        echo json_encode($data);
    }

    public function save_vehicle () {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        echo $this->mdl_vehicles->save_vehicle($data);
    }

    public function fetch_landmarks () {
        $data['landmark'] = $this->mdl_vehicles->get_landmarks($this->session->userdata('itms_company_id'));

        $data['content_btn']= '<a href="'.site_url('vehicles/add_vehicle').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Vehicles</a>';    
        $data['content_url'] = 'vehicles/vehicles';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Vehicle';
        $data['content_title'] = 'Vehicle';
        $data['content_subtitle'] = 'Vehicle Details';
        $data['content'] = 'vehicles/view_landmarks.php';
        $this->load->view('main/main.php', $data);
    }
// end of landmark function

    public function groups() {
        $data ['groups'] = $this->mdl_vehicles->get_groups($this->session->userdata('itms_company_id'));
        
        $data['content_btn']= '<a href="'.site_url('vehicles/add_group').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Group</a>';    
        $data['content_url'] = 'vehicles/groups';
        $data['fa'] = 'fa fa-sitemap';
        $data['title'] = 'ITMS Africa | Vehicle Groups';
        $data['content_title'] = 'Vehicle Groups';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/view_groups.php';
        $this->load->view('main/main.php', $data);
    }

    public function add_group () {
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_group';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Group';
        $data['content_title'] = 'Add Group';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_group.php';
        $this->load->view('main/main.php', $data);
    }


    public function edit_group () {
        $data ['groups'] = $this->mdl_vehicles->edit_groups($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_group';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Group';
        $data['content_title'] = 'Add Group';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/edit_group.php';
        $this->load->view('main/main.php', $data);
    }

    public function save_vehicle_group () {
        $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        
        if ($this->input->post('group_name')!="") {
            echo $this->mdl_vehicles->save_group($data);
        }

        echo false;
        
    }

    function delete_group($group_id){
        $this->mdl_vehicles->delete_group($group_id);
        header('location:'.base_url('index.php/vehicles/groups'));
    }

    function update_vehicle_group(){
        $data = array('group_id' => $this->input->post('group_id'),
                      'group_name' => $this->input->post('group_name'), 
                      'group_description' => $this->input->post('group_description'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');

        
        $this->mdl_vehicles->update_group_vehicle($data);
    }
    
    public function add_owner () {
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_owner';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Owner';
        $data['content_title'] = 'Add Owner';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_owner.php';
        $this->load->view('main/main.php', $data);
    }

    public function add_dealer () {
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/add_dealer';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Dealer';
        $data['content_title'] = 'Add Dealer';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/add_dealer.php';
        $this->load->view('main/main.php', $data);
    }

    public function categories() {
        $data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/categories';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | vehicles Categories';
        $data['content_title'] = 'vehicles Categories';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/categories.php';
        $this->load->view('main/main.php', $data);
    }


    public function types() {
        $data ['types'] = $this->mdl_types->get_all_types($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/types';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | vehicles Types';
        $data['content_title'] = 'vehicles Types';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/types.php';
        $this->load->view('main/main.php', $data);
    }


    public function owners() {
        $data['owners'] = $this->mdl_owners->get_all_owners($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'vehicles/owners';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicle Owners';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/owners.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_owner() {
        $data['owners'] = $this->mdl_owners->get_owner($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'vehicles/owners';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicle Owners';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/edit_owners.php';
        $this->load->view('main/main.php', $data);
    }

    function delete_owner($owner_id){
        $this->mdl_vehicles->delete_owner($owner_id);
        header('location:'.base_url('index.php/owners'));
    }

    public function update_owners() {
        $data = array('assets_friendly_nm' => $this->input->post('assets_friendly_nm'),
                      'assets_name' => $this->input->post('assets_name'),
                      'project_name' => $this->input->post('project_name'),
                      'lecturer' => $this->input->post('lecturer'), 
                      'picture' => $upload_data['file_name'], 
                      'objective' => $this->input->post('objective'), 
                      'tools' => $this->input->post('tools'),
                      'short_description' => $this->input->post('short_description'), 
                      'tags' => $this->input->post('tags'));
        // $data = $this->input->post();
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        
        $this->mdl_vehicles->update_vehicle($data);
    }


    public function vehicles_pairing() {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));

        $optVehicle = '';
        foreach($data['vehicles'] as $key=>$vehicle) {
            $optVehicle .= '<option value="'.$vehicle->asset_id.'">'.$vehicle->assets_friendly_nm.'</option>';
        }

        $data['optVehicles'] = $optVehicle;
        $data['content_url'] = 'vehicles/vehicles_pairing';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Vehicles Pairing';
        $data['content_title'] = 'Vehicles Owners';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/vehicles_pairing.php';
        $this->load->view('main/main.php', $data);
    }

    public function tyre_axle_configurations() {
        $data['vehicles'] = $this->mdl_vehicles->get_vehicles($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'vehicles/tyre_axle_configurations';
        $data['fa'] = 'fa fa-users';
        $data['title'] = 'ITMS Africa | Tyre Axle Configurations';
        $data['content_title'] = 'Axle and Tyre Settings';
        $data['content_subtitle'] = '';
        $data['content'] = 'vehicles/tyre_axle_configurations.php';
        $this->load->view('main/main.php', $data);
    }

    public function get_drivers_select () {
        $drivers = $this->mdl_vehicles->get_drivers();

        $select_box = "<select>";
        
        if (sizeof($drivers)) {
           foreach ($drivers as $driver) {
                $select_box .= "<option value='" . $driver->personnel_id . "'>" . $driver->fname . " " . $driver->lname. "</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    public function get_owners_select () {
        $owners = $this->mdl_vehicles->get_owners();

        $select_box = "<select>";
        
        if (sizeof($owners)) {
           foreach ($owners as $owner) {
                $select_box .= "<option value='" . $owner->owner_id . "'>" . $owner->owner_name ."</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    public function get_categories_select () {
        $categories = $this->mdl_vehicles->get_categories();

        $select_box = "<select>";
        
        if (sizeof($categories)) {
           foreach ($categories as $category) {
                $select_box .= "<option value='" . $category->assets_category_id . "'>" . $category->assets_cat_name . "</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    public function get_types_select () {
        $types = $this->mdl_vehicles->get_types();

        $select_box = "<select>";
        
        if (sizeof($types)) {
           foreach ($types as $type) {
                $select_box .= "<option value='" . $type->assets_type_id . "'>" . $type->assets_type_nm . "</option>";
            }
        }
            
        $select_box .= "</select>";

        echo $select_box;
    }

    

}
