<?php 

class Mdl_clients extends CI_Model{


    function get_clients ($company_id=null) {
        $this->db->select('itms_client_master.*');
        $this->db->from('itms_client_master');
        $this->db->where('itms_client_master.del_date IS NULL');
          
       if ($company_id != null) {
            $this->db->where('itms_client_master.company_id', $company_id);
       }

        $this->db->order_by('client_name', 'ASC');
        $query = $this->db->get();
       
        return $query->result();

    }
    
    function edit_client ($company_id=null) {
          
       if ($company_id != null) {
            $this->db->where('itms_client_master.company_id', $company_id);
       }
        $this->db->where('client_id', $this->uri->segment(3));
        $query = $this->db->get('itms_client_master');
       
        return $query->result();

    }


    function delete_client($client_id){
        $time = new DateTime();
        $t = $time->format('Y-m-d H:i:s');

        $sql="UPDATE itms_client_master SET del_date = '".$t."' WHERE client_id ='".$client_id."'";
        $this->db->query($sql);
    }

    function check_client ($data) {
        
        if ($this->check_client_phone_number($data['phone_no'])) {
            return 77;
            exit;
        }

        if ($this->check_client_email($data['email'])) {
            return 78;
            exit;
        }

        return false;
        
    }
    
	function save_client ($data) {
        
        $query = $this->db->insert('itms_client_master', $data);

        if ($query) {
            //$this->session->set_userdata('vehicle_image', '');
            return true;
        }
        
        return false;
        
    }

    function check_client_phone_number($phone_no) {
        $query = $this->db->get_where('itms_client_master', array('phone_no'=>$phone_no, 'company_id'=>$this->session->userdata('itms_company_id')));
        
        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }

    function check_client_email($email) {
        $query = $this->db->get_where('itms_client_master', array('email'=>$email, 'company_id'=>$this->session->userdata('itms_company_id')));
        
        if ($query->num_rows() !=0) {
            return true;
        }

        return false;
    }
	
	 function update_client($data){
        $this->db->where('client_id', $data['client_id']);
        $query = $this->db->update('itms_client_master', $data);

        if($query){
            echo 1;
        }else{
            echo 0;
        }
    }
}

?>
