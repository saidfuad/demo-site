<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients extends CI_Controller {

	function __construct() {

        parent::__construct();
		
        if ($this->session->userdata('itms_protocal') == "") {
            redirect('login');
        }
		
		if ($this->session->userdata('itms_protocal') == 71) {
            redirect('admin');
        }

		if ($this->session->userdata('itms_user_id') != "") {
           redirect(home);
        }

       $this->load->model('mdl_clients');

    }

	public function index() {
        $data['clients'] = $this->mdl_clients->get_clients($this->session->userdata('itms_company_id'));

        $data['content_btn']= '<a href="'.site_url('clients/add_client').'" class="btn btn-primary btn-lg"><i class="fa fa-plus"></i> Add Client</a>';    

        $data['content_url'] = 'clients/clients';
        $data['fa'] = 'fa fa-car';
        $data['title'] = 'ITMS Africa | Clients';
        $data['content_title'] = 'Clients';
        $data['content_subtitle'] = '';
        $data['content'] = 'clients/view_clients.php';
        $this->load->view('main/main.php', $data);
    }

    public function add_client () {
        if ($this->session->userdata('company_latitude') != 0 && $this->session->userdata('company_longitude') !=0)
        {
            $map_center = sprintf( "%f, %f", $this->session->userdata('company_latitude'), $this->session->userdata('company_longitude'));
            $map_lat = $this->session->userdata('company_latitude');
            $map_long = $this->session->userdata('company_longitude');
        } else {
            $map_center = sprintf( "%f, %f", '-4.0434771', '39.6682065');
            $map_lat = '-4.0434771';
            $map_long = '39.6682065';
        }

        $data['map_lat'] = $map_lat;
        $data['map_long'] = $map_long;
        //$data ['categories'] = $this->mdl_categories->get_all_categories($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'clients/add_client';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Client';
        $data['content_title'] = 'Add Client';
        $data['content_subtitle'] = '';
        $data['content'] = 'clients/add_client.php';
        $this->load->view('main/main.php', $data);
    }
    
    
    public function v_client () {
        $data ['clients'] = $this->mdl_clients->edit_client($this->session->userdata('itms_company_id'));
        $data['content_url'] = 'clients';
        $data['fa'] = 'fa fa-eye';
        $data['title'] = 'ITMS Africa | View Client';
        $data['content_title'] = 'Clients';
        $data['content_subtitle'] = 'View Client Information';
        $data['content'] = 'clients/v_client.php';
        $this->load->view('main/main.php', $data);
    }

    public function edit_client () {

        $data ['clients'] = $this->mdl_clients->edit_client($this->session->userdata('itms_company_id'));

        //$data['clients'][0] = substr($data['clients']['0'], 0, strpos($data['clients']['0'], "+254"));
//        echo "<pre>";
//        print_r($data);
//        exit;
//
        $data['content_url'] = 'clients/add_client';
        $data['fa'] = 'fa fa-plus';
        $data['title'] = 'ITMS Africa | Add Client';
        $data['content_title'] = 'Add Client';
        $data['content_subtitle'] = '';
        $data['content'] = 'clients/edit_clients.php';
        $this->load->view('main/main.php', $data);
    }

    public function check_client () {
        $data = $this->input->post();
        echo $this->mdl_clients->check_client($data);
    }
    
    public function save_client () {
        $data = $this->input->post();
        unset($data['client_password']);
        $data['phone_no'] = $data['phone_no_2'];
        unset($data['phone_no_2']);

        //print_r($data);
        //exit;

        $res = $this->mdl_clients->check_client($data);
        if ($res) {
            echo $res;
            exit;
        }

        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        $data['add_date'] = date('Y-m-d H:i:s');
        //$data['vehicle_image'] = ($this->session->userdata('vehicle_image') != '') ? $this->session->userdata('vehicle_image') :'vehicle-default.png';

        echo $this->mdl_clients->save_client($data);
    }

    function delete_client($client_id){
        $this->mdl_clients->delete_client($client_id);
        header('location:'.base_url('index.php/clients'));
    }


    function update_client(){
        /*$data = array('client_id' => $this->input->post('client_id'),
                      'client_name' => $this->input->post('client_name'), 
                      'phone_no' => $this->input->post('phone_no'),
                      'email' => $this->input->post('email'),
                      'address' => $this->input->post('address'));
                      //'location' => $this->input->post('location'));*/
        $data = $this->input->post();
        $data['phone_no'] = "+254".$this->input->post('phone_no');
        $data['company_id'] = $this->session->userdata('itms_company_id');
        $data['add_uid'] = $this->session->userdata('user_id');
        
        $this->mdl_clients->update_client($data);
    }

    function consignments(){

        //$data ['consignments'] = $this->mdl_clients->get_consignments($this->session->userdata('itms_company_id'));

        $data['content_url'] = 'clients';
        $data['fa'] = 'fa fa-eye';
        $data['title'] = 'ITMS Africa | Consignments';
        $data['content_title'] = 'Consignments';
        $data['content_subtitle'] = 'View Client Consignment Details';
        $data['content'] = 'clients/consignments.php';
        $this->load->view('main/main.php', $data);
    }

}
