<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <a style="float:right; margin-right: 16px" href="<?php echo "".site_url('clients/add_client').""; ?>" class="btn btn-primary btn-xsm">
                <i class="fa fa-plus"></i>
                Add Client
            </a>
            <br>
            <br>
            <div class="col-md-12 col-lg-12">
            <?php if (sizeof($clients)) {?>
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Client Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <!--<th>Location</th>-->
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($clients as $key => $value) { ?>
                       <tr class="gradeU">
                            <td><?php echo $value->client_name; ?></td>
                            <td><?php echo $value->phone_no; ?></td>
                            <td><?php echo $value->email; ?></td>
                            <td><?php echo $value->address; ?></td>
                            <!--<td><?php echo $value->location; ?></td>-->
                             <td><?php echo "<a data-placement='top' data-toggle='tooltip' data-original-title='Edit Client'  href='".base_url('index.php/clients/edit_client/'.$value->client_id)
                                                ."'class='btn btn-xs btn-success'><span class='fa fa-pencil'></span></a>
                                                "?>
                           </td>
                        </tr>
                    <?php }?>
                    </tbody>
                </table>
            </div>
            <?php } else { ?>
                <div class="col-sm-8 col-md-8 col-md-offset-2 bg-crumb" align="center">
                    <h2><i class="fa fa-car"></i> Clients</h2>
                    <br>
                    <p>Manage the entities that pay for your services</p>

                    <a href="<?php echo site_url('clients/add_client');?>" class="btn btn-success">Add Cients</a> 
                </div>
            <?php } ?>
            </div>
        </div>
    </div>
</div>    

<script src="<?php echo base_url('assets/js/plugins/dataTables/jquery.dataTables.js')?>"></script>
<script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap.js')?>"></script>

<script>
// Initialize Loadie for Page Load
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>
