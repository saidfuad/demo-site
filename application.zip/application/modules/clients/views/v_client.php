<link href="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/css/dropzone.css')?>" rel="stylesheet" />

<div class="container-fluid">
    <div class="row">
        <form id="edit-client-form">
	        <div class="col-md-6">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                   Client Details
                        <?php foreach ($clients as $value) { ?>
                        <a href="<?= base_url('index.php/clients/edit_client/' .$value->client_id); ?>">
                            <span class="edit_personnel btn btn-xs btn-success">Edit <i class="fa fa-pencil"></i></span>
                        </a>
	                </div>
	                <div class="panel-body">
	                    <input class="form-control" type="hidden" name="client_id" id="client_id" value="<?php echo $value->client_id; ?>"/>
	                    <div class="form-group">
	                        <label for="reservation">Client Name:</label>
	                        <input disabled class="form-control" type="text" name="client_name" id="client_name" value="<?php echo $value->client_name; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Phone:</label>
	                        <input disabled class="form-control" type="text" name="phone_no" id="phone_no" value="<?php echo $value->phone_no; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Email:</label>
	                        <input disabled class="form-control" type="text" name="email" id="email" value="<?php echo $value->email; ?>"/>
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Address:</label>
	                        <input disabled class="form-control" type="text" name="address" id="address" value="<?php echo $value->address; ?>">
	                    </div>
	                    <div class="form-group">
	                        <label for="reservation">Location:</label>
	                        <input disabled class="form-control" type="text" name="location" id="location" value="<?php echo $value->location; ?>"/>
	                    </div>             
	                </div>
	            </div>
                <?php } ?>
	           
			</div>
		</form>
		<div class="col-md-6 col-lg-6">
			<div class="col-md-12 bg-crumb" align="center">
				<h2><i class="fa fa-money"></i> Clients</h2>
				<br>
				<p>Manage clients (entities who use your vehicle for tansportation) information in one place.</p>

				<a href="<?php echo site_url('clients');?>" class="btn btn-success">View Clients</a>	
			</div>
		</div>

    </div>
</div> 

<!--<script src="<?php echo base_url('assets/js/plugins/dropzone-3.8.4/downloads/dropzone.min.js')?>"></script>-->

<script>
    $(function () {

            $('#edit-client-form').on('submit' , function () {

				$('#update-client').html('<i class="fa fa-spinner fa-spin"></i>');
                $('#update-client').prop('disabled', true);
               // alert ("yes");
                $.ajax({
                    method: 'post',
                    url: '<?= base_url('index.php/clients/update_client') ?>',
                    data: $(this).serialize(),
                    success: function () {
                        	swal({   title: "Info",   text: "Updated successfully",   type: "success",   confirmButtonText: "ok" });
                        $('#update-client').html('Update');
                		$('#update-client').prop('disabled', false);
                     }
                });

                
                return false;     
            });

        });
</script>   