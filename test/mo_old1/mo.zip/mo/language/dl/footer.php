		<div data-role="footer" class="footer-docs" data-theme="b">
				<?php if($host != 'omexsol.com' && $host != 'vts.trackeron.com') { ?>
				<p>&copy; 2012 NKonnect.com</p>
				<?php }else{ ?>
				<p>&nbsp;</p>
				<?php } ?>
		</div>

	</div>	
</body>
</html>
<?php print_gzipped_page(); ?>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42558408-10']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script> 