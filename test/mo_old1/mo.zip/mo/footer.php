		<div data-role="footer" class="footer-docs" data-theme="b">
				<?php if($host == 'omexsol.com') { ?>
				<p>&copy; 2013 Omex</p>
				<?php } else if($host == 'vts.trackeron.com' || $host == 'test.trackeron.com' || $host == 'gogpslive.com') { ?>
				<p>&copy; 2013 Cadsite</p>
				<?php } else if($host == 'vehicle.worldwidetrackingservices.com') { ?>
				<p>&copy; 2013 Worldwide Tracking Services</p>
				<?php } else { ?>
				<p>&copy; 2012 NKonnect.com</p>
				<?php } ?>
		</div>

	</div>	
</body>
</html>
